import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('ar'),
  ];

  /// Common/Phase 0 UI: appName.
  ///
  /// In en, this message translates to:
  /// **'Bitlogix ERP'**
  String get appName;

  /// Common/Phase 0 UI: brandName.
  ///
  /// In en, this message translates to:
  /// **'bitlogix'**
  String get brandName;

  /// Common/Phase 0 UI: save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// Common/Phase 0 UI: cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// Common/Phase 0 UI: close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get close;

  /// Common/Phase 0 UI: confirm.
  ///
  /// In en, this message translates to:
  /// **'Confirm'**
  String get confirm;

  /// Common/Phase 0 UI: delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// Common/Phase 0 UI: edit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get edit;

  /// Common/Phase 0 UI: add.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get add;

  /// Common/Phase 0 UI: search.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get search;

  /// Common/Phase 0 UI: filter.
  ///
  /// In en, this message translates to:
  /// **'Filter'**
  String get filter;

  /// Common/Phase 0 UI: clear.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get clear;

  /// Common/Phase 0 UI: retry.
  ///
  /// In en, this message translates to:
  /// **'Try again'**
  String get retry;

  /// Common/Phase 0 UI: refresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get refresh;

  /// Common/Phase 0 UI: continueAction.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueAction;

  /// Common/Phase 0 UI: back.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get back;

  /// Common/Phase 0 UI: next.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get next;

  /// Common/Phase 0 UI: done.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get done;

  /// Common/Phase 0 UI: yes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get yes;

  /// Common/Phase 0 UI: no.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get no;

  /// Common/Phase 0 UI: loading.
  ///
  /// In en, this message translates to:
  /// **'Loading'**
  String get loading;

  /// Common/Phase 0 UI: error.
  ///
  /// In en, this message translates to:
  /// **'Error'**
  String get error;

  /// Common/Phase 0 UI: success.
  ///
  /// In en, this message translates to:
  /// **'Success'**
  String get success;

  /// Common/Phase 0 UI: warning.
  ///
  /// In en, this message translates to:
  /// **'Warning'**
  String get warning;

  /// Common/Phase 0 UI: noData.
  ///
  /// In en, this message translates to:
  /// **'No data'**
  String get noData;

  /// Common/Phase 0 UI: somethingWentWrong.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong'**
  String get somethingWentWrong;

  /// Common/Phase 0 UI: home.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get home;

  /// Common/Phase 0 UI: more.
  ///
  /// In en, this message translates to:
  /// **'More'**
  String get more;

  /// Common/Phase 0 UI: email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// Common/Phase 0 UI: phone.
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get phone;

  /// Common/Phase 0 UI: emailOrPhone.
  ///
  /// In en, this message translates to:
  /// **'Email or phone'**
  String get emailOrPhone;

  /// Common/Phase 0 UI: password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// Common/Phase 0 UI: language.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get language;

  /// Common/Phase 0 UI: english.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get english;

  /// Common/Phase 0 UI: arabic.
  ///
  /// In en, this message translates to:
  /// **'Arabic'**
  String get arabic;

  /// Common/Phase 0 UI: active.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get active;

  /// Common/Phase 0 UI: inactive.
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get inactive;

  /// Common/Phase 0 UI: pending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get pending;

  /// Common/Phase 0 UI: approved.
  ///
  /// In en, this message translates to:
  /// **'Approved'**
  String get approved;

  /// Common/Phase 0 UI: rejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected'**
  String get rejected;

  /// Common/Phase 0 UI: failed.
  ///
  /// In en, this message translates to:
  /// **'Failed'**
  String get failed;

  /// Common/Phase 0 UI: synced.
  ///
  /// In en, this message translates to:
  /// **'Synced'**
  String get synced;

  /// Common/Phase 0 UI: draft.
  ///
  /// In en, this message translates to:
  /// **'Draft'**
  String get draft;

  /// Common/Phase 0 UI: scheduled.
  ///
  /// In en, this message translates to:
  /// **'Scheduled'**
  String get scheduled;

  /// Common/Phase 0 UI: actions.
  ///
  /// In en, this message translates to:
  /// **'Actions'**
  String get actions;

  /// Common/Phase 0 UI: primaryAction.
  ///
  /// In en, this message translates to:
  /// **'Primary action'**
  String get primaryAction;

  /// Common/Phase 0 UI: previewActionComplete.
  ///
  /// In en, this message translates to:
  /// **'Preview action complete'**
  String get previewActionComplete;

  /// Common/Phase 0 UI: secondaryAction.
  ///
  /// In en, this message translates to:
  /// **'Secondary'**
  String get secondaryAction;

  /// Common/Phase 0 UI: textAction.
  ///
  /// In en, this message translates to:
  /// **'Text action'**
  String get textAction;

  /// Common/Phase 0 UI: moreOptions.
  ///
  /// In en, this message translates to:
  /// **'More options'**
  String get moreOptions;

  /// Common/Phase 0 UI: disabled.
  ///
  /// In en, this message translates to:
  /// **'Disabled'**
  String get disabled;

  /// Common/Phase 0 UI: saving.
  ///
  /// In en, this message translates to:
  /// **'Saving'**
  String get saving;

  /// Common/Phase 0 UI: fullName.
  ///
  /// In en, this message translates to:
  /// **'Full name'**
  String get fullName;

  /// Common/Phase 0 UI: enterName.
  ///
  /// In en, this message translates to:
  /// **'Enter a name'**
  String get enterName;

  /// Common/Phase 0 UI: validationExample.
  ///
  /// In en, this message translates to:
  /// **'Validation example'**
  String get validationExample;

  /// Common/Phase 0 UI: informationCard.
  ///
  /// In en, this message translates to:
  /// **'Information card'**
  String get informationCard;

  /// Common/Phase 0 UI: informationCardMessage.
  ///
  /// In en, this message translates to:
  /// **'Use a concise explanation to help people make a decision.'**
  String get informationCardMessage;

  /// Common/Phase 0 UI: statusAndFeedback.
  ///
  /// In en, this message translates to:
  /// **'Status & feedback'**
  String get statusAndFeedback;

  /// Common/Phase 0 UI: localChangesAvailable.
  ///
  /// In en, this message translates to:
  /// **'Your changes are available on this device.'**
  String get localChangesAvailable;

  /// Common/Phase 0 UI: recordsNeedAttention.
  ///
  /// In en, this message translates to:
  /// **'Some records need your attention.'**
  String get recordsNeedAttention;

  /// Common/Phase 0 UI: actionFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to complete this action.'**
  String get actionFailed;

  /// Common/Phase 0 UI: loadingRecords.
  ///
  /// In en, this message translates to:
  /// **'Loading records...'**
  String get loadingRecords;

  /// Common/Phase 0 UI: noRecordsYet.
  ///
  /// In en, this message translates to:
  /// **'No records yet'**
  String get noRecordsYet;

  /// Common/Phase 0 UI: noRecordsMessage.
  ///
  /// In en, this message translates to:
  /// **'Records will appear here when your team gets started.'**
  String get noRecordsMessage;

  /// Common/Phase 0 UI: retryWhenConnected.
  ///
  /// In en, this message translates to:
  /// **'Please try again when a connection is available.'**
  String get retryWhenConnected;

  /// Common/Phase 0 UI: filtersAndTable.
  ///
  /// In en, this message translates to:
  /// **'Filters & table'**
  String get filtersAndTable;

  /// Common/Phase 0 UI: status.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get status;

  /// Common/Phase 0 UI: pageNotFound.
  ///
  /// In en, this message translates to:
  /// **'This page could not be found.'**
  String get pageNotFound;

  /// Common/Phase 0 UI: showPassword.
  ///
  /// In en, this message translates to:
  /// **'Show password'**
  String get showPassword;

  /// Common/Phase 0 UI: hidePassword.
  ///
  /// In en, this message translates to:
  /// **'Hide password'**
  String get hidePassword;

  /// Common/Phase 0 UI: searchRecords.
  ///
  /// In en, this message translates to:
  /// **'Search records'**
  String get searchRecords;

  /// Common/Phase 0 UI: selectDate.
  ///
  /// In en, this message translates to:
  /// **'Select date'**
  String get selectDate;

  /// Common/Phase 0 UI: selectTime.
  ///
  /// In en, this message translates to:
  /// **'Select time'**
  String get selectTime;

  /// Common/Phase 0 UI: unableToLoadRecords.
  ///
  /// In en, this message translates to:
  /// **'Unable to load records'**
  String get unableToLoadRecords;

  /// Common/Phase 0 UI: noRecords.
  ///
  /// In en, this message translates to:
  /// **'No records'**
  String get noRecords;

  /// Common/Phase 0 UI: previousPage.
  ///
  /// In en, this message translates to:
  /// **'Previous page'**
  String get previousPage;

  /// Common/Phase 0 UI: nextPage.
  ///
  /// In en, this message translates to:
  /// **'Next page'**
  String get nextPage;

  /// Common/Phase 0 UI: fieldRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required'**
  String get fieldRequired;

  /// Common/Phase 0 UI: emailRequired.
  ///
  /// In en, this message translates to:
  /// **'Email is required'**
  String get emailRequired;

  /// Common/Phase 0 UI: emailInvalid.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid email address'**
  String get emailInvalid;

  /// Common/Phase 0 UI: failureTimeout.
  ///
  /// In en, this message translates to:
  /// **'The request timed out. Please try again.'**
  String get failureTimeout;

  /// Common/Phase 0 UI: failureOffline.
  ///
  /// In en, this message translates to:
  /// **'Connection unavailable. Your local data is still available.'**
  String get failureOffline;

  /// Common/Phase 0 UI: failureCancelled.
  ///
  /// In en, this message translates to:
  /// **'Request cancelled.'**
  String get failureCancelled;

  /// Common/Phase 0 UI: failureSessionExpired.
  ///
  /// In en, this message translates to:
  /// **'Your session has expired.'**
  String get failureSessionExpired;

  /// Common/Phase 0 UI: failureRequest.
  ///
  /// In en, this message translates to:
  /// **'Unable to complete the request.'**
  String get failureRequest;

  /// Common/Phase 0 UI: failureInvalidData.
  ///
  /// In en, this message translates to:
  /// **'The response could not be read.'**
  String get failureInvalidData;

  /// Common/Phase 0 UI: failureLocationDisabled.
  ///
  /// In en, this message translates to:
  /// **'Enable location services to continue.'**
  String get failureLocationDisabled;

  /// Common/Phase 0 UI: failureLocationPermission.
  ///
  /// In en, this message translates to:
  /// **'Location permission is required for this action.'**
  String get failureLocationPermission;

  /// Common/Phase 0 UI: failureLocationUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Unable to determine your location.'**
  String get failureLocationUnavailable;

  /// Common/Phase 0 UI: failureStorageWrite.
  ///
  /// In en, this message translates to:
  /// **'Unable to save changes on this device.'**
  String get failureStorageWrite;

  /// Common/Phase 0 UI: failureStorageUpdate.
  ///
  /// In en, this message translates to:
  /// **'Unable to update local changes.'**
  String get failureStorageUpdate;

  /// Common/Phase 0 UI: failureSync.
  ///
  /// In en, this message translates to:
  /// **'Some changes could not be synchronized.'**
  String get failureSync;

  /// Common/Phase 0 UI: failurePreferencesWrite.
  ///
  /// In en, this message translates to:
  /// **'Language changed for this session, but could not be saved.'**
  String get failurePreferencesWrite;

  /// Common/Phase 0 UI: failurePreferencesRead.
  ///
  /// In en, this message translates to:
  /// **'Saved language could not be restored.'**
  String get failurePreferencesRead;

  /// Common/Phase 0 UI: formattingTitle.
  ///
  /// In en, this message translates to:
  /// **'Locale-aware formatting'**
  String get formattingTitle;

  /// Common/Phase 0 UI: date.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get date;

  /// Common/Phase 0 UI: time.
  ///
  /// In en, this message translates to:
  /// **'Time'**
  String get time;

  /// Common/Phase 0 UI: duration.
  ///
  /// In en, this message translates to:
  /// **'Duration'**
  String get duration;

  /// Common/Phase 0 UI: number.
  ///
  /// In en, this message translates to:
  /// **'Number'**
  String get number;

  /// Common/Phase 0 UI: percentage.
  ///
  /// In en, this message translates to:
  /// **'Percentage'**
  String get percentage;

  /// Common/Phase 0 UI: currency.
  ///
  /// In en, this message translates to:
  /// **'Currency'**
  String get currency;

  /// Common/Phase 0 UI: month.
  ///
  /// In en, this message translates to:
  /// **'Month'**
  String get month;

  /// paginationSummary
  ///
  /// In en, this message translates to:
  /// **'{start}–{end} of {total}'**
  String paginationSummary(String start, String end, String total);

  /// Shell navigation module section: HR.
  ///
  /// In en, this message translates to:
  /// **'Human resources'**
  String get navSectionHr;

  /// Shell navigation module section: Services.
  ///
  /// In en, this message translates to:
  /// **'Services'**
  String get navSectionServices;

  /// Shell navigation module section: Settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get navSectionSettings;

  /// Shell navigation module section: Account.
  ///
  /// In en, this message translates to:
  /// **'Account'**
  String get navSectionAccount;

  /// durationHoursMinutes
  ///
  /// In en, this message translates to:
  /// **'{hours}h {minutes}m'**
  String durationHoursMinutes(String hours, String minutes);

  /// No description provided for @durationHoursOnly.
  ///
  /// In en, this message translates to:
  /// **'{hours}h'**
  String durationHoursOnly(String hours);

  /// No description provided for @selectOption.
  ///
  /// In en, this message translates to:
  /// **'Select an option'**
  String get selectOption;

  /// No description provided for @noSelection.
  ///
  /// In en, this message translates to:
  /// **'Not assigned'**
  String get noSelection;

  /// No description provided for @timeRange.
  ///
  /// In en, this message translates to:
  /// **'{start} → {end}'**
  String timeRange(String start, String end);

  /// No description provided for @dateTimeValue.
  ///
  /// In en, this message translates to:
  /// **'{date} · {time}'**
  String dateTimeValue(String date, String time);

  /// No description provided for @labeledValue.
  ///
  /// In en, this message translates to:
  /// **'{label}: {value}'**
  String labeledValue(String label, String value);

  /// No description provided for @viewDetails.
  ///
  /// In en, this message translates to:
  /// **'View details'**
  String get viewDetails;

  /// No description provided for @filters.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get filters;

  /// No description provided for @moreFilters.
  ///
  /// In en, this message translates to:
  /// **'More filters'**
  String get moreFilters;

  /// No description provided for @resetFilters.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get resetFilters;

  /// No description provided for @periodLabel.
  ///
  /// In en, this message translates to:
  /// **'Period'**
  String get periodLabel;

  /// Common/Phase 0 UI: settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// Common/Phase 0 UI: profile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get profile;

  /// Common/Phase 0 UI: login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// Common/Phase 0 UI: logout.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// Common/Phase 0 UI: forgotPassword.
  ///
  /// In en, this message translates to:
  /// **'Forgot password'**
  String get forgotPassword;

  /// Common/Phase 0 UI: changePassword.
  ///
  /// In en, this message translates to:
  /// **'Change password'**
  String get changePassword;

  /// Common/Phase 0 UI: welcomeBack.
  ///
  /// In en, this message translates to:
  /// **'Welcome back'**
  String get welcomeBack;

  /// Common/Phase 0 UI: workspace.
  ///
  /// In en, this message translates to:
  /// **'Workspace'**
  String get workspace;

  /// Common/Phase 0 UI: overview.
  ///
  /// In en, this message translates to:
  /// **'Overview'**
  String get overview;

  /// Common/Phase 0 UI: internal.
  ///
  /// In en, this message translates to:
  /// **'Internal'**
  String get internal;

  /// Common/Phase 0 UI: designSystem.
  ///
  /// In en, this message translates to:
  /// **'Design system'**
  String get designSystem;

  /// Common/Phase 0 UI: erpWorkspace.
  ///
  /// In en, this message translates to:
  /// **'ERP workspace'**
  String get erpWorkspace;

  /// Common/Phase 0 UI: foundationPhase.
  ///
  /// In en, this message translates to:
  /// **'Foundation / Phase 0'**
  String get foundationPhase;

  /// Common/Phase 0 UI: designPreview.
  ///
  /// In en, this message translates to:
  /// **'Design preview'**
  String get designPreview;

  /// Common/Phase 0 UI: designSystemSubtitle.
  ///
  /// In en, this message translates to:
  /// **'The shared language of your ERP workspace.'**
  String get designSystemSubtitle;

  /// Common/Phase 0 UI: internalPreview.
  ///
  /// In en, this message translates to:
  /// **'Internal preview'**
  String get internalPreview;

  /// Common/Phase 0 UI: openDialog.
  ///
  /// In en, this message translates to:
  /// **'Open dialog'**
  String get openDialog;

  /// Common/Phase 0 UI: reviewChanges.
  ///
  /// In en, this message translates to:
  /// **'Review changes'**
  String get reviewChanges;

  /// Common/Phase 0 UI: confirmationPreview.
  ///
  /// In en, this message translates to:
  /// **'This is a preview of the shared confirmation dialog.'**
  String get confirmationPreview;

  /// Common/Phase 0 UI: looksGood.
  ///
  /// In en, this message translates to:
  /// **'Looks good'**
  String get looksGood;

  /// Common/Phase 0 UI: consistencyNotice.
  ///
  /// In en, this message translates to:
  /// **'Consistent by design. Every future module uses these foundations.'**
  String get consistencyNotice;

  /// Common/Phase 0 UI: designLanguage.
  ///
  /// In en, this message translates to:
  /// **'Design language'**
  String get designLanguage;

  /// Common/Phase 0 UI: oneSystem.
  ///
  /// In en, this message translates to:
  /// **'One system'**
  String get oneSystem;

  /// Common/Phase 0 UI: sharedAcrossModules.
  ///
  /// In en, this message translates to:
  /// **'Shared across every module'**
  String get sharedAcrossModules;

  /// Common/Phase 0 UI: dataStrategy.
  ///
  /// In en, this message translates to:
  /// **'Data strategy'**
  String get dataStrategy;

  /// Common/Phase 0 UI: localFirst.
  ///
  /// In en, this message translates to:
  /// **'Local first'**
  String get localFirst;

  /// Common/Phase 0 UI: repositorySourceOfTruth.
  ///
  /// In en, this message translates to:
  /// **'Repositories own the source of truth'**
  String get repositorySourceOfTruth;

  /// Common/Phase 0 UI: layout.
  ///
  /// In en, this message translates to:
  /// **'Layout'**
  String get layout;

  /// Common/Phase 0 UI: adaptive.
  ///
  /// In en, this message translates to:
  /// **'Adaptive'**
  String get adaptive;

  /// Common/Phase 0 UI: adaptiveDetail.
  ///
  /// In en, this message translates to:
  /// **'Compact through large workspaces'**
  String get adaptiveDetail;

  /// Common/Phase 0 UI: typography.
  ///
  /// In en, this message translates to:
  /// **'Typography'**
  String get typography;

  /// Common/Phase 0 UI: typographySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Inter / locally bundled / clear at every density'**
  String get typographySubtitle;

  /// Common/Phase 0 UI: typographyDisplay.
  ///
  /// In en, this message translates to:
  /// **'Display'**
  String get typographyDisplay;

  /// Common/Phase 0 UI: typographyPageTitle.
  ///
  /// In en, this message translates to:
  /// **'Page title'**
  String get typographyPageTitle;

  /// Common/Phase 0 UI: typographySectionTitle.
  ///
  /// In en, this message translates to:
  /// **'Section title'**
  String get typographySectionTitle;

  /// Common/Phase 0 UI: typographyCardTitle.
  ///
  /// In en, this message translates to:
  /// **'Card title'**
  String get typographyCardTitle;

  /// Common/Phase 0 UI: typographyBodyLarge.
  ///
  /// In en, this message translates to:
  /// **'Body large'**
  String get typographyBodyLarge;

  /// Common/Phase 0 UI: typographyBody.
  ///
  /// In en, this message translates to:
  /// **'Body'**
  String get typographyBody;

  /// Common/Phase 0 UI: typographyBodySmall.
  ///
  /// In en, this message translates to:
  /// **'Body small'**
  String get typographyBodySmall;

  /// Common/Phase 0 UI: typographyLabel.
  ///
  /// In en, this message translates to:
  /// **'Label'**
  String get typographyLabel;

  /// Common/Phase 0 UI: typographyCaption.
  ///
  /// In en, this message translates to:
  /// **'Caption'**
  String get typographyCaption;

  /// Common/Phase 0 UI: semanticPalette.
  ///
  /// In en, this message translates to:
  /// **'Semantic palette'**
  String get semanticPalette;

  /// Common/Phase 0 UI: colorBrand.
  ///
  /// In en, this message translates to:
  /// **'Brand'**
  String get colorBrand;

  /// Common/Phase 0 UI: colorSurface.
  ///
  /// In en, this message translates to:
  /// **'Surface'**
  String get colorSurface;

  /// Common/Phase 0 UI: colorBackground.
  ///
  /// In en, this message translates to:
  /// **'Background'**
  String get colorBackground;

  /// Common/Phase 0 UI: colorBorder.
  ///
  /// In en, this message translates to:
  /// **'Border'**
  String get colorBorder;

  /// Common/Phase 0 UI: colorTextPrimary.
  ///
  /// In en, this message translates to:
  /// **'Text primary'**
  String get colorTextPrimary;

  /// Common/Phase 0 UI: colorTextSecondary.
  ///
  /// In en, this message translates to:
  /// **'Text secondary'**
  String get colorTextSecondary;

  /// Common/Phase 0 UI: colorTextMuted.
  ///
  /// In en, this message translates to:
  /// **'Text muted'**
  String get colorTextMuted;

  /// Common/Phase 0 UI: colorDanger.
  ///
  /// In en, this message translates to:
  /// **'Danger'**
  String get colorDanger;

  /// Common/Phase 0 UI: colorInfo.
  ///
  /// In en, this message translates to:
  /// **'Info'**
  String get colorInfo;

  /// Common/Phase 0 UI: formControls.
  ///
  /// In en, this message translates to:
  /// **'Form controls'**
  String get formControls;

  /// Common/Phase 0 UI: formControlsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Shared field styling, validation and accessible labels.'**
  String get formControlsSubtitle;

  /// Common/Phase 0 UI: illustrativeRecords.
  ///
  /// In en, this message translates to:
  /// **'Illustrative records / no operational employee data'**
  String get illustrativeRecords;

  /// Common/Phase 0 UI: activeOnly.
  ///
  /// In en, this message translates to:
  /// **'Active only'**
  String get activeOnly;

  /// Common/Phase 0 UI: clearFilters.
  ///
  /// In en, this message translates to:
  /// **'Clear filters'**
  String get clearFilters;

  /// Common/Phase 0 UI: sampleAlex.
  ///
  /// In en, this message translates to:
  /// **'Alex Morgan'**
  String get sampleAlex;

  /// Common/Phase 0 UI: sampleSam.
  ///
  /// In en, this message translates to:
  /// **'Sam Taylor'**
  String get sampleSam;

  /// Common/Phase 0 UI: dialogsAndSheets.
  ///
  /// In en, this message translates to:
  /// **'Dialogs & sheets'**
  String get dialogsAndSheets;

  /// Common/Phase 0 UI: previewDialog.
  ///
  /// In en, this message translates to:
  /// **'Preview dialog'**
  String get previewDialog;

  /// Common/Phase 0 UI: sharedDialog.
  ///
  /// In en, this message translates to:
  /// **'Shared dialog'**
  String get sharedDialog;

  /// Common/Phase 0 UI: sharedDialogMessage.
  ///
  /// In en, this message translates to:
  /// **'Focused content for a clear decision.'**
  String get sharedDialogMessage;

  /// Common/Phase 0 UI: previewBottomSheet.
  ///
  /// In en, this message translates to:
  /// **'Preview bottom sheet'**
  String get previewBottomSheet;

  /// Common/Phase 0 UI: quickDetails.
  ///
  /// In en, this message translates to:
  /// **'Quick details'**
  String get quickDetails;

  /// Common/Phase 0 UI: quickDetailsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'A shared mobile presentation pattern.'**
  String get quickDetailsSubtitle;

  /// Common/Phase 0 UI: foundationDetails.
  ///
  /// In en, this message translates to:
  /// **'Foundation details'**
  String get foundationDetails;

  /// Common/Phase 0 UI: architecture.
  ///
  /// In en, this message translates to:
  /// **'Architecture'**
  String get architecture;

  /// Common/Phase 0 UI: featureFirst.
  ///
  /// In en, this message translates to:
  /// **'Feature first'**
  String get featureFirst;

  /// Common/Phase 0 UI: theme.
  ///
  /// In en, this message translates to:
  /// **'Theme'**
  String get theme;

  /// Common/Phase 0 UI: lightSemanticTokens.
  ///
  /// In en, this message translates to:
  /// **'Light / semantic tokens'**
  String get lightSemanticTokens;

  /// Common/Phase 0 UI: persistence.
  ///
  /// In en, this message translates to:
  /// **'Persistence'**
  String get persistence;

  /// Common/Phase 0 UI: persistenceDetail.
  ///
  /// In en, this message translates to:
  /// **'Drift + secure session storage'**
  String get persistenceDetail;

  /// Common/Phase 0 UI: internalPreviewPhase.
  ///
  /// In en, this message translates to:
  /// **'Internal preview / Phase 0'**
  String get internalPreviewPhase;

  /// Common/Phase 0 UI: workspaceTitle.
  ///
  /// In en, this message translates to:
  /// **'A foundation for what is next'**
  String get workspaceTitle;

  /// Common/Phase 0 UI: workspaceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'One workspace. Every ERP module.'**
  String get workspaceSubtitle;

  /// Common/Phase 0 UI: workspaceInfoTitle.
  ///
  /// In en, this message translates to:
  /// **'Your ERP starts here'**
  String get workspaceInfoTitle;

  /// Common/Phase 0 UI: workspaceInfoMessage.
  ///
  /// In en, this message translates to:
  /// **'The local-first architecture and shared design system are ready. Business modules will be introduced in future phases.'**
  String get workspaceInfoMessage;

  /// Common/Phase 0 UI: phaseReady.
  ///
  /// In en, this message translates to:
  /// **'Phase 0 / Foundation ready'**
  String get phaseReady;

  /// Common/Phase 0 UI: languageSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Language and layout update immediately.'**
  String get languageSubtitle;

  /// No description provided for @englishNativeName.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get englishNativeName;

  /// No description provided for @arabicNativeName.
  ///
  /// In en, this message translates to:
  /// **'العربية'**
  String get arabicNativeName;

  /// typographySample
  ///
  /// In en, this message translates to:
  /// **'{level} / Built for clarity'**
  String typographySample(String level);

  /// No description provided for @authWelcomeBack.
  ///
  /// In en, this message translates to:
  /// **'Welcome back'**
  String get authWelcomeBack;

  /// No description provided for @authSignInSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Sign in to your Bitlogix workspace.'**
  String get authSignInSubtitle;

  /// No description provided for @authIdentifier.
  ///
  /// In en, this message translates to:
  /// **'Email or phone number'**
  String get authIdentifier;

  /// No description provided for @authIdentifierHint.
  ///
  /// In en, this message translates to:
  /// **'name@company.com'**
  String get authIdentifierHint;

  /// No description provided for @authIdentifierRequired.
  ///
  /// In en, this message translates to:
  /// **'Email or phone number is required'**
  String get authIdentifierRequired;

  /// No description provided for @authIdentifierInvalid.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid email or phone number'**
  String get authIdentifierInvalid;

  /// No description provided for @authPasswordRequired.
  ///
  /// In en, this message translates to:
  /// **'Password is required'**
  String get authPasswordRequired;

  /// No description provided for @authInvalidCredentials.
  ///
  /// In en, this message translates to:
  /// **'Incorrect email, phone number, or password.'**
  String get authInvalidCredentials;

  /// No description provided for @authLoggingIn.
  ///
  /// In en, this message translates to:
  /// **'Signing in…'**
  String get authLoggingIn;

  /// No description provided for @authBrandStatement.
  ///
  /// In en, this message translates to:
  /// **'A connected workspace.\nA clearer working day.'**
  String get authBrandStatement;

  /// No description provided for @authBrandDescription.
  ///
  /// In en, this message translates to:
  /// **'One place for your people, operations, and the work ahead.'**
  String get authBrandDescription;

  /// No description provided for @authWorkspaceLabel.
  ///
  /// In en, this message translates to:
  /// **'Company workspace'**
  String get authWorkspaceLabel;

  /// No description provided for @authSecureSession.
  ///
  /// In en, this message translates to:
  /// **'Your session stays secure on this device.'**
  String get authSecureSession;

  /// No description provided for @authSecureSessionLabel.
  ///
  /// In en, this message translates to:
  /// **'Secure session'**
  String get authSecureSessionLabel;

  /// No description provided for @authWorkforce.
  ///
  /// In en, this message translates to:
  /// **'Workforce'**
  String get authWorkforce;

  /// No description provided for @authActiveEmployees.
  ///
  /// In en, this message translates to:
  /// **'active employees'**
  String get authActiveEmployees;

  /// No description provided for @authWorking.
  ///
  /// In en, this message translates to:
  /// **'Working'**
  String get authWorking;

  /// No description provided for @authAttendanceActive.
  ///
  /// In en, this message translates to:
  /// **'Attendance active'**
  String get authAttendanceActive;

  /// No description provided for @authLive.
  ///
  /// In en, this message translates to:
  /// **'Live'**
  String get authLive;

  /// No description provided for @authDeveloperAccess.
  ///
  /// In en, this message translates to:
  /// **'Developer access'**
  String get authDeveloperAccess;

  /// No description provided for @productEyebrow.
  ///
  /// In en, this message translates to:
  /// **'Modular business workspace'**
  String get productEyebrow;

  /// No description provided for @productHeadline.
  ///
  /// In en, this message translates to:
  /// **'Everything your business runs on.\nConnected.'**
  String get productHeadline;

  /// No description provided for @productWorkspaceTitle.
  ///
  /// In en, this message translates to:
  /// **'Bitlogix Workspace'**
  String get productWorkspaceTitle;

  /// No description provided for @productWorkspaceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Unified business system'**
  String get productWorkspaceSubtitle;

  /// No description provided for @productWorkspaceFooter.
  ///
  /// In en, this message translates to:
  /// **'Connected by one workspace'**
  String get productWorkspaceFooter;

  /// No description provided for @modulePeople.
  ///
  /// In en, this message translates to:
  /// **'People'**
  String get modulePeople;

  /// No description provided for @moduleOperations.
  ///
  /// In en, this message translates to:
  /// **'Operations'**
  String get moduleOperations;

  /// No description provided for @moduleOperationsDesc.
  ///
  /// In en, this message translates to:
  /// **'Workflows'**
  String get moduleOperationsDesc;

  /// No description provided for @moduleCustomers.
  ///
  /// In en, this message translates to:
  /// **'Customers'**
  String get moduleCustomers;

  /// No description provided for @moduleCustomersDesc.
  ///
  /// In en, this message translates to:
  /// **'Relationships'**
  String get moduleCustomersDesc;

  /// No description provided for @moduleFinance.
  ///
  /// In en, this message translates to:
  /// **'Finance'**
  String get moduleFinance;

  /// No description provided for @moduleServices.
  ///
  /// In en, this message translates to:
  /// **'Services'**
  String get moduleServices;

  /// No description provided for @moduleServicesDesc.
  ///
  /// In en, this message translates to:
  /// **'Service requests'**
  String get moduleServicesDesc;

  /// No description provided for @moduleInventory.
  ///
  /// In en, this message translates to:
  /// **'Inventory'**
  String get moduleInventory;

  /// No description provided for @moduleInventoryDesc.
  ///
  /// In en, this message translates to:
  /// **'Assets'**
  String get moduleInventoryDesc;

  /// No description provided for @moduleReports.
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get moduleReports;

  /// No description provided for @moduleReportsDesc.
  ///
  /// In en, this message translates to:
  /// **'Scheduled exports'**
  String get moduleReportsDesc;

  /// No description provided for @moduleInsights.
  ///
  /// In en, this message translates to:
  /// **'Insights'**
  String get moduleInsights;

  /// No description provided for @moduleInsightsDesc.
  ///
  /// In en, this message translates to:
  /// **'Overview'**
  String get moduleInsightsDesc;

  /// No description provided for @authWorkdayTitle.
  ///
  /// In en, this message translates to:
  /// **'Your workday,\nall in one place.'**
  String get authWorkdayTitle;

  /// No description provided for @authWorkingDay.
  ///
  /// In en, this message translates to:
  /// **'Working day'**
  String get authWorkingDay;

  /// No description provided for @authNow.
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get authNow;

  /// No description provided for @authShiftGeneral.
  ///
  /// In en, this message translates to:
  /// **'General shift'**
  String get authShiftGeneral;

  /// No description provided for @authShiftToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get authShiftToday;

  /// No description provided for @authWorkLocationMain.
  ///
  /// In en, this message translates to:
  /// **'Main office'**
  String get authWorkLocationMain;

  /// No description provided for @authEmployeesActiveCount.
  ///
  /// In en, this message translates to:
  /// **'{count} employees active'**
  String authEmployeesActiveCount(int count);

  /// No description provided for @authDemoUse.
  ///
  /// In en, this message translates to:
  /// **'Use a demo account'**
  String get authDemoUse;

  /// No description provided for @authSessionNote.
  ///
  /// In en, this message translates to:
  /// **'Your session stays signed in on this device until you sign out or it expires.'**
  String get authSessionNote;

  /// No description provided for @authInitializing.
  ///
  /// In en, this message translates to:
  /// **'Preparing your workspace…'**
  String get authInitializing;

  /// No description provided for @authDemoAccounts.
  ///
  /// In en, this message translates to:
  /// **'Demo accounts'**
  String get authDemoAccounts;

  /// No description provided for @authDemoNotice.
  ///
  /// In en, this message translates to:
  /// **'Local demonstration only. No backend is connected.'**
  String get authDemoNotice;

  /// No description provided for @authDemoDisabled.
  ///
  /// In en, this message translates to:
  /// **'Demo authentication is disabled in this configuration. A backend has not been connected yet.'**
  String get authDemoDisabled;

  /// No description provided for @authDemoPassword.
  ///
  /// In en, this message translates to:
  /// **'Demo password'**
  String get authDemoPassword;

  /// No description provided for @authSessionStorageError.
  ///
  /// In en, this message translates to:
  /// **'We could not access the secure session. Please try again.'**
  String get authSessionStorageError;

  /// No description provided for @authServerError.
  ///
  /// In en, this message translates to:
  /// **'The sign-in service is temporarily unavailable. Please try again.'**
  String get authServerError;

  /// No description provided for @authForgotTitle.
  ///
  /// In en, this message translates to:
  /// **'Reset your password'**
  String get authForgotTitle;

  /// No description provided for @authForgotSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enter the email or phone number associated with your account.'**
  String get authForgotSubtitle;

  /// No description provided for @authResetInformation.
  ///
  /// In en, this message translates to:
  /// **'If an account matches these details, password reset instructions will be sent.'**
  String get authResetInformation;

  /// No description provided for @authResetDemoNote.
  ///
  /// In en, this message translates to:
  /// **'In this demo, no email or SMS is sent.'**
  String get authResetDemoNote;

  /// No description provided for @authResetTitle.
  ///
  /// In en, this message translates to:
  /// **'Request received'**
  String get authResetTitle;

  /// No description provided for @authBackToLogin.
  ///
  /// In en, this message translates to:
  /// **'Back to sign in'**
  String get authBackToLogin;

  /// No description provided for @authSubmitting.
  ///
  /// In en, this message translates to:
  /// **'Please wait…'**
  String get authSubmitting;

  /// No description provided for @authChangePassword.
  ///
  /// In en, this message translates to:
  /// **'Change password'**
  String get authChangePassword;

  /// No description provided for @authChangeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose a strong password for your account.'**
  String get authChangeSubtitle;

  /// No description provided for @authCurrentPassword.
  ///
  /// In en, this message translates to:
  /// **'Current password'**
  String get authCurrentPassword;

  /// No description provided for @authNewPassword.
  ///
  /// In en, this message translates to:
  /// **'New password'**
  String get authNewPassword;

  /// No description provided for @authConfirmPassword.
  ///
  /// In en, this message translates to:
  /// **'Confirm new password'**
  String get authConfirmPassword;

  /// No description provided for @authPasswordConstraints.
  ///
  /// In en, this message translates to:
  /// **'Use at least 8 characters, including a letter and a number.'**
  String get authPasswordConstraints;

  /// No description provided for @authPasswordsMismatch.
  ///
  /// In en, this message translates to:
  /// **'Passwords do not match'**
  String get authPasswordsMismatch;

  /// No description provided for @authPasswordMustDiffer.
  ///
  /// In en, this message translates to:
  /// **'Choose a password different from your current password'**
  String get authPasswordMustDiffer;

  /// No description provided for @authCurrentPasswordInvalid.
  ///
  /// In en, this message translates to:
  /// **'The current password is incorrect.'**
  String get authCurrentPasswordInvalid;

  /// No description provided for @authPasswordChanged.
  ///
  /// In en, this message translates to:
  /// **'Password updated for this demo session.'**
  String get authPasswordChanged;

  /// No description provided for @authPasswordDemoNote.
  ///
  /// In en, this message translates to:
  /// **'Demo password changes last until the app restarts. No password is stored on this device.'**
  String get authPasswordDemoNote;

  /// No description provided for @authBackToWorkspace.
  ///
  /// In en, this message translates to:
  /// **'Back to workspace'**
  String get authBackToWorkspace;

  /// No description provided for @authConfirmLogout.
  ///
  /// In en, this message translates to:
  /// **'Sign out of your workspace?'**
  String get authConfirmLogout;

  /// No description provided for @authLogoutMessage.
  ///
  /// In en, this message translates to:
  /// **'Your secure session will be removed from this device.'**
  String get authLogoutMessage;

  /// No description provided for @authHomeTitle.
  ///
  /// In en, this message translates to:
  /// **'Your workspace is ready'**
  String get authHomeTitle;

  /// No description provided for @authHomeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'You are signed in. Business modules will be added in the next phases.'**
  String get authHomeSubtitle;

  /// No description provided for @authAccount.
  ///
  /// In en, this message translates to:
  /// **'Account'**
  String get authAccount;

  /// No description provided for @authCompany.
  ///
  /// In en, this message translates to:
  /// **'Company'**
  String get authCompany;

  /// No description provided for @authPermissions.
  ///
  /// In en, this message translates to:
  /// **'Permissions'**
  String get authPermissions;

  /// No description provided for @authAccountStatus.
  ///
  /// In en, this message translates to:
  /// **'Account status'**
  String get authAccountStatus;

  /// No description provided for @authStatusActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get authStatusActive;

  /// No description provided for @authStatusSuspended.
  ///
  /// In en, this message translates to:
  /// **'Suspended'**
  String get authStatusSuspended;

  /// No description provided for @authStatusInactive.
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get authStatusInactive;

  /// No description provided for @authPermissionViewer.
  ///
  /// In en, this message translates to:
  /// **'Assigned permissions'**
  String get authPermissionViewer;

  /// No description provided for @authEmployeeLinked.
  ///
  /// In en, this message translates to:
  /// **'Linked employee record'**
  String get authEmployeeLinked;

  /// No description provided for @authEmployeeUnlinked.
  ///
  /// In en, this message translates to:
  /// **'No employee record linked'**
  String get authEmployeeUnlinked;

  /// No description provided for @authPermissionCount.
  ///
  /// In en, this message translates to:
  /// **'{count} permissions assigned'**
  String authPermissionCount(String count);

  /// No description provided for @authGreeting.
  ///
  /// In en, this message translates to:
  /// **'Welcome, {name}'**
  String authGreeting(String name);

  /// No description provided for @permissionCompanyManage.
  ///
  /// In en, this message translates to:
  /// **'Manage company'**
  String get permissionCompanyManage;

  /// No description provided for @permissionUserManage.
  ///
  /// In en, this message translates to:
  /// **'Manage user accounts'**
  String get permissionUserManage;

  /// No description provided for @shellDashboard.
  ///
  /// In en, this message translates to:
  /// **'Dashboard'**
  String get shellDashboard;

  /// No description provided for @shellEmployees.
  ///
  /// In en, this message translates to:
  /// **'Employees'**
  String get shellEmployees;

  /// No description provided for @shellAttendance.
  ///
  /// In en, this message translates to:
  /// **'Attendance'**
  String get shellAttendance;

  /// No description provided for @shellReports.
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get shellReports;

  /// No description provided for @shellSettings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get shellSettings;

  /// No description provided for @shellProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get shellProfile;

  /// No description provided for @shellMore.
  ///
  /// In en, this message translates to:
  /// **'More'**
  String get shellMore;

  /// No description provided for @shellGeneral.
  ///
  /// In en, this message translates to:
  /// **'Workspace'**
  String get shellGeneral;

  /// No description provided for @shellPeople.
  ///
  /// In en, this message translates to:
  /// **'People'**
  String get shellPeople;

  /// No description provided for @shellWorkforce.
  ///
  /// In en, this message translates to:
  /// **'Workforce'**
  String get shellWorkforce;

  /// No description provided for @shellInsights.
  ///
  /// In en, this message translates to:
  /// **'Insights'**
  String get shellInsights;

  /// No description provided for @shellAdministration.
  ///
  /// In en, this message translates to:
  /// **'Administration'**
  String get shellAdministration;

  /// No description provided for @shellAccount.
  ///
  /// In en, this message translates to:
  /// **'Account'**
  String get shellAccount;

  /// No description provided for @shellServices.
  ///
  /// In en, this message translates to:
  /// **'Services'**
  String get shellServices;

  /// No description provided for @shellFinance.
  ///
  /// In en, this message translates to:
  /// **'Finance'**
  String get shellFinance;

  /// No description provided for @shellProfileDescription.
  ///
  /// In en, this message translates to:
  /// **'Your account, preferences and attendance settings.'**
  String get shellProfileDescription;

  /// No description provided for @shellPlaceholderTitle.
  ///
  /// In en, this message translates to:
  /// **'Ready for the next phase'**
  String get shellPlaceholderTitle;

  /// No description provided for @shellPlaceholderMessage.
  ///
  /// In en, this message translates to:
  /// **'This area is reserved for a future ERP module. No business data is available yet.'**
  String get shellPlaceholderMessage;

  /// No description provided for @shellMoreDescription.
  ///
  /// In en, this message translates to:
  /// **'Explore the other areas available to your account.'**
  String get shellMoreDescription;

  /// No description provided for @shellSearchTitle.
  ///
  /// In en, this message translates to:
  /// **'Global search'**
  String get shellSearchTitle;

  /// No description provided for @shellSearchMessage.
  ///
  /// In en, this message translates to:
  /// **'Global search will become available as ERP modules are added.'**
  String get shellSearchMessage;

  /// No description provided for @shellNotifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get shellNotifications;

  /// No description provided for @shellNoNotifications.
  ///
  /// In en, this message translates to:
  /// **'No notifications'**
  String get shellNoNotifications;

  /// No description provided for @shellNotificationsMessage.
  ///
  /// In en, this message translates to:
  /// **'There are no notifications to display.'**
  String get shellNotificationsMessage;

  /// No description provided for @shellAccessRestricted.
  ///
  /// In en, this message translates to:
  /// **'Access restricted'**
  String get shellAccessRestricted;

  /// No description provided for @shellAccessMessage.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to access this area.'**
  String get shellAccessMessage;

  /// No description provided for @shellModuleUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Module unavailable'**
  String get shellModuleUnavailable;

  /// No description provided for @shellModuleUnavailableMessage.
  ///
  /// In en, this message translates to:
  /// **'This module is not enabled for your organization.'**
  String get shellModuleUnavailableMessage;

  /// No description provided for @shellNotFound.
  ///
  /// In en, this message translates to:
  /// **'Page not found'**
  String get shellNotFound;

  /// No description provided for @shellNotFoundMessage.
  ///
  /// In en, this message translates to:
  /// **'The page you requested could not be found.'**
  String get shellNotFoundMessage;

  /// No description provided for @shellReturnToWorkspace.
  ///
  /// In en, this message translates to:
  /// **'Return to workspace'**
  String get shellReturnToWorkspace;

  /// No description provided for @shellGoBack.
  ///
  /// In en, this message translates to:
  /// **'Go back'**
  String get shellGoBack;

  /// No description provided for @shellCollapseSidebar.
  ///
  /// In en, this message translates to:
  /// **'Collapse sidebar'**
  String get shellCollapseSidebar;

  /// No description provided for @shellExpandSidebar.
  ///
  /// In en, this message translates to:
  /// **'Expand sidebar'**
  String get shellExpandSidebar;

  /// No description provided for @shellCompanyInformation.
  ///
  /// In en, this message translates to:
  /// **'Company information'**
  String get shellCompanyInformation;

  /// No description provided for @shellTimezone.
  ///
  /// In en, this message translates to:
  /// **'Time zone'**
  String get shellTimezone;

  /// No description provided for @shellCompanyCode.
  ///
  /// In en, this message translates to:
  /// **'Company code'**
  String get shellCompanyCode;

  /// No description provided for @shellAccountMenu.
  ///
  /// In en, this message translates to:
  /// **'Open account menu'**
  String get shellAccountMenu;

  /// No description provided for @shellBreadcrumbs.
  ///
  /// In en, this message translates to:
  /// **'Breadcrumb navigation'**
  String get shellBreadcrumbs;

  /// No description provided for @shellNoDestinations.
  ///
  /// In en, this message translates to:
  /// **'No available destinations'**
  String get shellNoDestinations;

  /// No description provided for @shellNoDestinationsMessage.
  ///
  /// In en, this message translates to:
  /// **'No workspace areas are available for this account. Contact your administrator.'**
  String get shellNoDestinationsMessage;

  /// No description provided for @syncOfflineTitle.
  ///
  /// In en, this message translates to:
  /// **'You\'re offline'**
  String get syncOfflineTitle;

  /// No description provided for @syncOfflineMessage.
  ///
  /// In en, this message translates to:
  /// **'Changes will sync when your connection returns.'**
  String get syncOfflineMessage;

  /// No description provided for @syncServiceUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Service temporarily unavailable'**
  String get syncServiceUnavailable;

  /// No description provided for @syncSyncing.
  ///
  /// In en, this message translates to:
  /// **'Syncing'**
  String get syncSyncing;

  /// No description provided for @syncAllChangesSynced.
  ///
  /// In en, this message translates to:
  /// **'All changes synced'**
  String get syncAllChangesSynced;

  /// No description provided for @syncPending.
  ///
  /// In en, this message translates to:
  /// **'Pending sync'**
  String get syncPending;

  /// No description provided for @syncFailed.
  ///
  /// In en, this message translates to:
  /// **'Sync failed'**
  String get syncFailed;

  /// No description provided for @syncNeedsAttention.
  ///
  /// In en, this message translates to:
  /// **'Sync needs attention'**
  String get syncNeedsAttention;

  /// No description provided for @syncRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get syncRetry;

  /// No description provided for @syncRetryNow.
  ///
  /// In en, this message translates to:
  /// **'Retry now'**
  String get syncRetryNow;

  /// No description provided for @syncNow.
  ///
  /// In en, this message translates to:
  /// **'Sync now'**
  String get syncNow;

  /// No description provided for @syncLastSync.
  ///
  /// In en, this message translates to:
  /// **'Last sync'**
  String get syncLastSync;

  /// No description provided for @syncNever.
  ///
  /// In en, this message translates to:
  /// **'Not yet synced'**
  String get syncNever;

  /// No description provided for @syncChangesWaiting.
  ///
  /// In en, this message translates to:
  /// **'Changes waiting to sync'**
  String get syncChangesWaiting;

  /// No description provided for @syncDataAndSync.
  ///
  /// In en, this message translates to:
  /// **'Data and sync'**
  String get syncDataAndSync;

  /// No description provided for @syncNoPendingChanges.
  ///
  /// In en, this message translates to:
  /// **'No changes waiting'**
  String get syncNoPendingChanges;

  /// No description provided for @syncSyncSucceeded.
  ///
  /// In en, this message translates to:
  /// **'Sync complete'**
  String get syncSyncSucceeded;

  /// No description provided for @syncStatusTitle.
  ///
  /// In en, this message translates to:
  /// **'Sync status'**
  String get syncStatusTitle;

  /// No description provided for @syncPendingOperations.
  ///
  /// In en, this message translates to:
  /// **'Pending operations'**
  String get syncPendingOperations;

  /// No description provided for @syncFailedOperations.
  ///
  /// In en, this message translates to:
  /// **'Failed operations'**
  String get syncFailedOperations;

  /// No description provided for @syncSwitchAccount.
  ///
  /// In en, this message translates to:
  /// **'Sign in to sync'**
  String get syncSwitchAccount;

  /// No description provided for @notificationsTitle.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notificationsTitle;

  /// No description provided for @notificationsNoItems.
  ///
  /// In en, this message translates to:
  /// **'No notifications'**
  String get notificationsNoItems;

  /// No description provided for @notificationsNoItemsMessage.
  ///
  /// In en, this message translates to:
  /// **'You are all caught up.'**
  String get notificationsNoItemsMessage;

  /// No description provided for @notificationsMarkAllRead.
  ///
  /// In en, this message translates to:
  /// **'Mark all as read'**
  String get notificationsMarkAllRead;

  /// No description provided for @notificationsToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get notificationsToday;

  /// No description provided for @notificationsEarlier.
  ///
  /// In en, this message translates to:
  /// **'Earlier'**
  String get notificationsEarlier;

  /// No description provided for @notificationsUnread.
  ///
  /// In en, this message translates to:
  /// **'Unread'**
  String get notificationsUnread;

  /// No description provided for @notificationsReminders.
  ///
  /// In en, this message translates to:
  /// **'Notifications and reminders'**
  String get notificationsReminders;

  /// No description provided for @notificationsOpen.
  ///
  /// In en, this message translates to:
  /// **'Open notifications'**
  String get notificationsOpen;

  /// No description provided for @reminderAttendanceSection.
  ///
  /// In en, this message translates to:
  /// **'Attendance reminders'**
  String get reminderAttendanceSection;

  /// No description provided for @reminderShift.
  ///
  /// In en, this message translates to:
  /// **'Shift reminder'**
  String get reminderShift;

  /// No description provided for @reminderPunchOut.
  ///
  /// In en, this message translates to:
  /// **'Punch out reminder'**
  String get reminderPunchOut;

  /// No description provided for @reminderNotifyBefore.
  ///
  /// In en, this message translates to:
  /// **'Notify before shift'**
  String get reminderNotifyBefore;

  /// No description provided for @reminderMinutesBefore.
  ///
  /// In en, this message translates to:
  /// **'Minutes before'**
  String get reminderMinutesBefore;

  /// No description provided for @reminderNotificationPermission.
  ///
  /// In en, this message translates to:
  /// **'Notification permission'**
  String get reminderNotificationPermission;

  /// No description provided for @reminderPermissionRequired.
  ///
  /// In en, this message translates to:
  /// **'Notification permission required'**
  String get reminderPermissionRequired;

  /// No description provided for @reminderNotificationsDisabled.
  ///
  /// In en, this message translates to:
  /// **'Notifications disabled'**
  String get reminderNotificationsDisabled;

  /// No description provided for @reminderNotificationsEnabled.
  ///
  /// In en, this message translates to:
  /// **'Reminders enabled in the app'**
  String get reminderNotificationsEnabled;

  /// No description provided for @reminderOpenSettings.
  ///
  /// In en, this message translates to:
  /// **'Open settings'**
  String get reminderOpenSettings;

  /// No description provided for @reminderSaved.
  ///
  /// In en, this message translates to:
  /// **'Reminder settings saved'**
  String get reminderSaved;

  /// No description provided for @reminderSaveFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not save reminder settings'**
  String get reminderSaveFailed;

  /// No description provided for @reminderPermissionHint.
  ///
  /// In en, this message translates to:
  /// **'Enable reminders to receive shift notifications.'**
  String get reminderPermissionHint;

  /// No description provided for @notifShiftSoonTitle.
  ///
  /// In en, this message translates to:
  /// **'Your shift starts soon'**
  String get notifShiftSoonTitle;

  /// No description provided for @notifShiftSoonBody.
  ///
  /// In en, this message translates to:
  /// **'Your shift is about to start. Open attendance to check in.'**
  String get notifShiftSoonBody;

  /// No description provided for @notifPunchOutTitle.
  ///
  /// In en, this message translates to:
  /// **'Remember to punch out'**
  String get notifPunchOutTitle;

  /// No description provided for @notifPunchOutBody.
  ///
  /// In en, this message translates to:
  /// **'Your shift has ended. Remember to punch out.'**
  String get notifPunchOutBody;

  /// No description provided for @notifShiftEndingOnBreakBody.
  ///
  /// In en, this message translates to:
  /// **'Your shift is ending. Review your attendance before leaving.'**
  String get notifShiftEndingOnBreakBody;

  /// No description provided for @notifCorrectionApprovedTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance correction approved'**
  String get notifCorrectionApprovedTitle;

  /// No description provided for @notifCorrectionApprovedBody.
  ///
  /// In en, this message translates to:
  /// **'Your attendance correction was approved and applied.'**
  String get notifCorrectionApprovedBody;

  /// No description provided for @notifCorrectionRejectedTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance correction rejected'**
  String get notifCorrectionRejectedTitle;

  /// No description provided for @notifCorrectionRejectedBody.
  ///
  /// In en, this message translates to:
  /// **'Your attendance correction request was not approved.'**
  String get notifCorrectionRejectedBody;

  /// No description provided for @notifSyncFailedTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance needs attention'**
  String get notifSyncFailedTitle;

  /// No description provided for @notifSyncFailedBody.
  ///
  /// In en, this message translates to:
  /// **'Some attendance changes could not be synced.'**
  String get notifSyncFailedBody;

  /// No description provided for @notifConflictTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance needs review'**
  String get notifConflictTitle;

  /// No description provided for @notifConflictBody.
  ///
  /// In en, this message translates to:
  /// **'Your local attendance does not match the latest server record.'**
  String get notifConflictBody;

  /// No description provided for @notifPendingReviewTitle.
  ///
  /// In en, this message translates to:
  /// **'New attendance correction request'**
  String get notifPendingReviewTitle;

  /// No description provided for @notifPendingReviewBody.
  ///
  /// In en, this message translates to:
  /// **'A correction request is waiting for review.'**
  String get notifPendingReviewBody;

  /// No description provided for @notifLeaveSubmittedTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave request submitted'**
  String get notifLeaveSubmittedTitle;

  /// No description provided for @notifLeaveSubmittedBody.
  ///
  /// In en, this message translates to:
  /// **'Your leave request was submitted for approval.'**
  String get notifLeaveSubmittedBody;

  /// No description provided for @notifLeaveApprovedTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave request approved'**
  String get notifLeaveApprovedTitle;

  /// No description provided for @notifLeaveApprovedBody.
  ///
  /// In en, this message translates to:
  /// **'Your leave request was approved.'**
  String get notifLeaveApprovedBody;

  /// No description provided for @notifLeaveRejectedTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave request rejected'**
  String get notifLeaveRejectedTitle;

  /// No description provided for @notifLeaveRejectedBody.
  ///
  /// In en, this message translates to:
  /// **'Your leave request was not approved.'**
  String get notifLeaveRejectedBody;

  /// No description provided for @notifLeaveCancelledTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave request cancelled'**
  String get notifLeaveCancelledTitle;

  /// No description provided for @notifLeaveCancelledBody.
  ///
  /// In en, this message translates to:
  /// **'A leave request was cancelled.'**
  String get notifLeaveCancelledBody;

  /// No description provided for @notifLeaveApprovalRequiredTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave approval required'**
  String get notifLeaveApprovalRequiredTitle;

  /// No description provided for @notifLeaveApprovalRequiredBody.
  ///
  /// In en, this message translates to:
  /// **'A team leave request is waiting for your review.'**
  String get notifLeaveApprovalRequiredBody;

  /// No description provided for @notifUnknownTitle.
  ///
  /// In en, this message translates to:
  /// **'Notification'**
  String get notifUnknownTitle;

  /// No description provided for @notifUnknownBody.
  ///
  /// In en, this message translates to:
  /// **'You have a new notification.'**
  String get notifUnknownBody;

  /// No description provided for @timeJustNow.
  ///
  /// In en, this message translates to:
  /// **'Just now'**
  String get timeJustNow;

  /// No description provided for @timeMinutesAgo.
  ///
  /// In en, this message translates to:
  /// **'{count} min ago'**
  String timeMinutesAgo(Object count);

  /// No description provided for @timeHoursAgo.
  ///
  /// In en, this message translates to:
  /// **'{count} h ago'**
  String timeHoursAgo(Object count);

  /// No description provided for @timeYesterday.
  ///
  /// In en, this message translates to:
  /// **'Yesterday'**
  String get timeYesterday;

  /// No description provided for @profileMyProfile.
  ///
  /// In en, this message translates to:
  /// **'My profile'**
  String get profileMyProfile;

  /// No description provided for @profileOverview.
  ///
  /// In en, this message translates to:
  /// **'Overview'**
  String get profileOverview;

  /// No description provided for @profileWorkInformation.
  ///
  /// In en, this message translates to:
  /// **'Work information'**
  String get profileWorkInformation;

  /// No description provided for @profileAccountAccess.
  ///
  /// In en, this message translates to:
  /// **'Account and access'**
  String get profileAccountAccess;

  /// No description provided for @profileSecurity.
  ///
  /// In en, this message translates to:
  /// **'Security'**
  String get profileSecurity;

  /// No description provided for @profilePreferences.
  ///
  /// In en, this message translates to:
  /// **'Preferences'**
  String get profilePreferences;

  /// No description provided for @profileAccess.
  ///
  /// In en, this message translates to:
  /// **'Access'**
  String get profileAccess;

  /// No description provided for @profileAdministrativeAccess.
  ///
  /// In en, this message translates to:
  /// **'Administrative access'**
  String get profileAdministrativeAccess;

  /// No description provided for @profileEmploymentStatus.
  ///
  /// In en, this message translates to:
  /// **'Employment status'**
  String get profileEmploymentStatus;

  /// No description provided for @profileLoginEmail.
  ///
  /// In en, this message translates to:
  /// **'Login email'**
  String get profileLoginEmail;

  /// No description provided for @profileWorkEmail.
  ///
  /// In en, this message translates to:
  /// **'Work email'**
  String get profileWorkEmail;

  /// No description provided for @profileMyAttendance.
  ///
  /// In en, this message translates to:
  /// **'My attendance'**
  String get profileMyAttendance;

  /// No description provided for @profileViewEmployeeRecord.
  ///
  /// In en, this message translates to:
  /// **'View employment details'**
  String get profileViewEmployeeRecord;

  /// No description provided for @profileNoEmployeeLinked.
  ///
  /// In en, this message translates to:
  /// **'No employee profile is linked to this account.'**
  String get profileNoEmployeeLinked;

  /// No description provided for @profileTeamUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Team access cannot be resolved.'**
  String get profileTeamUnavailable;

  /// No description provided for @profileEmploymentUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Employment information is currently unavailable.'**
  String get profileEmploymentUnavailable;

  /// No description provided for @profileCurrentCompany.
  ///
  /// In en, this message translates to:
  /// **'Current company'**
  String get profileCurrentCompany;

  /// No description provided for @profileManage.
  ///
  /// In en, this message translates to:
  /// **'Manage'**
  String get profileManage;

  /// No description provided for @settingsIntro.
  ///
  /// In en, this message translates to:
  /// **'Manage your organization, attendance configuration and preferences.'**
  String get settingsIntro;

  /// No description provided for @settingsAttendanceCategory.
  ///
  /// In en, this message translates to:
  /// **'Attendance configuration'**
  String get settingsAttendanceCategory;

  /// No description provided for @settingsAttendanceCategoryDesc.
  ///
  /// In en, this message translates to:
  /// **'Configure how employees work and record attendance.'**
  String get settingsAttendanceCategoryDesc;

  /// No description provided for @settingsPreferencesCategory.
  ///
  /// In en, this message translates to:
  /// **'Personal preferences'**
  String get settingsPreferencesCategory;

  /// No description provided for @settingsPreferencesCategoryDesc.
  ///
  /// In en, this message translates to:
  /// **'Adjust your own app preferences.'**
  String get settingsPreferencesCategoryDesc;

  /// No description provided for @settingsSystemCategory.
  ///
  /// In en, this message translates to:
  /// **'System'**
  String get settingsSystemCategory;

  /// No description provided for @settingsSystemCategoryDesc.
  ///
  /// In en, this message translates to:
  /// **'Sync and application status.'**
  String get settingsSystemCategoryDesc;

  /// No description provided for @settingsShiftDesc.
  ///
  /// In en, this message translates to:
  /// **'Set working hours, working days and break defaults.'**
  String get settingsShiftDesc;

  /// No description provided for @settingsLocationDesc.
  ///
  /// In en, this message translates to:
  /// **'Manage workplaces and attendance location rules.'**
  String get settingsLocationDesc;

  /// No description provided for @settingsPolicyDesc.
  ///
  /// In en, this message translates to:
  /// **'Define attendance, break and correction rules.'**
  String get settingsPolicyDesc;

  /// No description provided for @settingsLanguageDesc.
  ///
  /// In en, this message translates to:
  /// **'Choose your preferred application language.'**
  String get settingsLanguageDesc;

  /// No description provided for @settingsNotificationsDesc.
  ///
  /// In en, this message translates to:
  /// **'Control attendance reminders for your account.'**
  String get settingsNotificationsDesc;

  /// No description provided for @settingsSyncDesc.
  ///
  /// In en, this message translates to:
  /// **'View sync status and retry failed changes.'**
  String get settingsSyncDesc;

  /// No description provided for @shellLeave.
  ///
  /// In en, this message translates to:
  /// **'Leave'**
  String get shellLeave;

  /// No description provided for @settingsLeaveCategory.
  ///
  /// In en, this message translates to:
  /// **'Leave & holidays'**
  String get settingsLeaveCategory;

  /// No description provided for @settingsLeaveCategoryDesc.
  ///
  /// In en, this message translates to:
  /// **'Configure leave types, policies and holidays.'**
  String get settingsLeaveCategoryDesc;

  /// No description provided for @permissionAccessUsersView.
  ///
  /// In en, this message translates to:
  /// **'View Users & Access'**
  String get permissionAccessUsersView;

  /// No description provided for @permissionAccessPermissionsManage.
  ///
  /// In en, this message translates to:
  /// **'Manage user access'**
  String get permissionAccessPermissionsManage;

  /// No description provided for @permissionCompanyModulesView.
  ///
  /// In en, this message translates to:
  /// **'View company modules'**
  String get permissionCompanyModulesView;

  /// No description provided for @permissionPlatformModulesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage platform modules'**
  String get permissionPlatformModulesManage;

  /// No description provided for @accessModulePlatform.
  ///
  /// In en, this message translates to:
  /// **'Administration'**
  String get accessModulePlatform;

  /// No description provided for @accessSubAccess.
  ///
  /// In en, this message translates to:
  /// **'Access & modules'**
  String get accessSubAccess;

  /// No description provided for @accessUsersView.
  ///
  /// In en, this message translates to:
  /// **'View users & access'**
  String get accessUsersView;

  /// No description provided for @accessUsersViewDesc.
  ///
  /// In en, this message translates to:
  /// **'Open the Users & Access administration area.'**
  String get accessUsersViewDesc;

  /// No description provided for @accessPermissionsManage.
  ///
  /// In en, this message translates to:
  /// **'Manage user access'**
  String get accessPermissionsManage;

  /// No description provided for @accessPermissionsManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Grant and revoke ERP permissions and scopes.'**
  String get accessPermissionsManageDesc;

  /// No description provided for @accessModulesView.
  ///
  /// In en, this message translates to:
  /// **'View company modules'**
  String get accessModulesView;

  /// No description provided for @accessModulesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See which ERP modules are enabled for the company.'**
  String get accessModulesViewDesc;

  /// No description provided for @accessCompanyUsersManage.
  ///
  /// In en, this message translates to:
  /// **'Manage company users'**
  String get accessCompanyUsersManage;

  /// No description provided for @accessCompanyUsersManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Manage company user accounts.'**
  String get accessCompanyUsersManageDesc;

  /// No description provided for @accessPlatformCompaniesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage platform companies'**
  String get accessPlatformCompaniesManage;

  /// No description provided for @accessPlatformCompaniesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Platform-only: manage companies across the platform.'**
  String get accessPlatformCompaniesManageDesc;

  /// No description provided for @accessPlatformModulesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage platform modules'**
  String get accessPlatformModulesManage;

  /// No description provided for @accessPlatformModulesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Platform-only: enable or disable modules for companies.'**
  String get accessPlatformModulesManageDesc;

  /// No description provided for @usersAccessTitle.
  ///
  /// In en, this message translates to:
  /// **'Users & access'**
  String get usersAccessTitle;

  /// No description provided for @usersAccessSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Control what each user can access and what records they can work with.'**
  String get usersAccessSubtitle;

  /// No description provided for @accessCompanyModules.
  ///
  /// In en, this message translates to:
  /// **'Company modules'**
  String get accessCompanyModules;

  /// No description provided for @accessCompanyModulesSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Which ERP modules are enabled for this company.'**
  String get accessCompanyModulesSubtitle;

  /// No description provided for @accessManage.
  ///
  /// In en, this message translates to:
  /// **'Manage access'**
  String get accessManage;

  /// No description provided for @accessNoLogin.
  ///
  /// In en, this message translates to:
  /// **'No login'**
  String get accessNoLogin;

  /// No description provided for @accessNoBusinessAccess.
  ///
  /// In en, this message translates to:
  /// **'No business access assigned.'**
  String get accessNoBusinessAccess;

  /// No description provided for @accessModuleHr.
  ///
  /// In en, this message translates to:
  /// **'HR'**
  String get accessModuleHr;

  /// No description provided for @accessModuleServices.
  ///
  /// In en, this message translates to:
  /// **'Services'**
  String get accessModuleServices;

  /// No description provided for @accessScopeNone.
  ///
  /// In en, this message translates to:
  /// **'No access'**
  String get accessScopeNone;

  /// No description provided for @accessScopeSelf.
  ///
  /// In en, this message translates to:
  /// **'Self (own records)'**
  String get accessScopeSelf;

  /// No description provided for @accessScopeAssigned.
  ///
  /// In en, this message translates to:
  /// **'Assigned to me'**
  String get accessScopeAssigned;

  /// No description provided for @accessScopeTeam.
  ///
  /// In en, this message translates to:
  /// **'Team (my team)'**
  String get accessScopeTeam;

  /// No description provided for @accessScopeAll.
  ///
  /// In en, this message translates to:
  /// **'Company (all)'**
  String get accessScopeAll;

  /// No description provided for @accessSaveChanges.
  ///
  /// In en, this message translates to:
  /// **'Save changes'**
  String get accessSaveChanges;

  /// No description provided for @accessResetChanges.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get accessResetChanges;

  /// No description provided for @accessSaved.
  ///
  /// In en, this message translates to:
  /// **'Access updated.'**
  String get accessSaved;

  /// No description provided for @accessSaveFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not update access.'**
  String get accessSaveFailed;

  /// No description provided for @accessConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Update access?'**
  String get accessConfirmTitle;

  /// No description provided for @accessConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'Apply the access changes for this user?'**
  String get accessConfirmMessage;

  /// No description provided for @accessAdded.
  ///
  /// In en, this message translates to:
  /// **'Added'**
  String get accessAdded;

  /// No description provided for @accessRemoved.
  ///
  /// In en, this message translates to:
  /// **'Removed'**
  String get accessRemoved;

  /// No description provided for @accessChanged.
  ///
  /// In en, this message translates to:
  /// **'Changed'**
  String get accessChanged;

  /// No description provided for @accessNoChanges.
  ///
  /// In en, this message translates to:
  /// **'No changes'**
  String get accessNoChanges;

  /// No description provided for @accessSummary.
  ///
  /// In en, this message translates to:
  /// **'Access summary'**
  String get accessSummary;

  /// No description provided for @accessGrantedPermissions.
  ///
  /// In en, this message translates to:
  /// **'Granted permissions'**
  String get accessGrantedPermissions;

  /// No description provided for @accessEmployeeLinked.
  ///
  /// In en, this message translates to:
  /// **'Employee linked'**
  String get accessEmployeeLinked;

  /// No description provided for @accessEmployeeNotLinked.
  ///
  /// In en, this message translates to:
  /// **'No linked employee'**
  String get accessEmployeeNotLinked;

  /// No description provided for @accessEmployeeLinkRequired.
  ///
  /// In en, this message translates to:
  /// **'This access requires a linked active employee record.'**
  String get accessEmployeeLinkRequired;

  /// No description provided for @accessSelfEscalation.
  ///
  /// In en, this message translates to:
  /// **'You cannot change your own access.'**
  String get accessSelfEscalation;

  /// No description provided for @accessLastAdmin.
  ///
  /// In en, this message translates to:
  /// **'The final access administrator cannot be removed.'**
  String get accessLastAdmin;

  /// No description provided for @accessNotPermitted.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to do this.'**
  String get accessNotPermitted;

  /// No description provided for @accessModuleDisabled.
  ///
  /// In en, this message translates to:
  /// **'This module is not enabled for the company.'**
  String get accessModuleDisabled;

  /// No description provided for @accessPlatformOnly.
  ///
  /// In en, this message translates to:
  /// **'Only a platform administrator can grant this.'**
  String get accessPlatformOnly;

  /// No description provided for @accessHistory.
  ///
  /// In en, this message translates to:
  /// **'Access history'**
  String get accessHistory;

  /// No description provided for @accessNoHistory.
  ///
  /// In en, this message translates to:
  /// **'No access changes yet.'**
  String get accessNoHistory;

  /// No description provided for @accessSearchUsers.
  ///
  /// In en, this message translates to:
  /// **'Search users'**
  String get accessSearchUsers;

  /// No description provided for @accessFilterAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get accessFilterAll;

  /// No description provided for @accessEnabled.
  ///
  /// In en, this message translates to:
  /// **'Enabled'**
  String get accessEnabled;

  /// No description provided for @accessDisabled.
  ///
  /// In en, this message translates to:
  /// **'Disabled'**
  String get accessDisabled;

  /// No description provided for @accessModulesReadOnly.
  ///
  /// In en, this message translates to:
  /// **'Module availability is managed at platform level in this demo.'**
  String get accessModulesReadOnly;

  /// No description provided for @accessStatusActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get accessStatusActive;

  /// No description provided for @accessStatusInactive.
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get accessStatusInactive;

  /// No description provided for @accessLogin.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get accessLogin;

  /// No description provided for @accessEmployee.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get accessEmployee;

  /// No description provided for @accessDesignation.
  ///
  /// In en, this message translates to:
  /// **'Designation'**
  String get accessDesignation;

  /// No description provided for @accessDepartment.
  ///
  /// In en, this message translates to:
  /// **'Department'**
  String get accessDepartment;

  /// No description provided for @accessClearModule.
  ///
  /// In en, this message translates to:
  /// **'Clear module access'**
  String get accessClearModule;

  /// No description provided for @accessNoAccessAssigned.
  ///
  /// In en, this message translates to:
  /// **'No access'**
  String get accessNoAccessAssigned;

  /// No description provided for @accessPlatformOnlyBadge.
  ///
  /// In en, this message translates to:
  /// **'Platform only'**
  String get accessPlatformOnlyBadge;

  /// No description provided for @accessEmployeeRequiredBadge.
  ///
  /// In en, this message translates to:
  /// **'Requires employee'**
  String get accessEmployeeRequiredBadge;

  /// No description provided for @accessGrantView.
  ///
  /// In en, this message translates to:
  /// **'Grant view'**
  String get accessGrantView;

  /// No description provided for @accessGrantFull.
  ///
  /// In en, this message translates to:
  /// **'Grant full'**
  String get accessGrantFull;

  /// No description provided for @accessClear.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get accessClear;

  /// No description provided for @accessHasAccess.
  ///
  /// In en, this message translates to:
  /// **'Access configured'**
  String get accessHasAccess;

  /// No description provided for @accessFullConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Grant full module access?'**
  String get accessFullConfirmTitle;

  /// No description provided for @accessFullConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'This grants every delegable permission for this module. You can refine scopes afterwards.'**
  String get accessFullConfirmMessage;

  /// No description provided for @accessModuleAccess.
  ///
  /// In en, this message translates to:
  /// **'Module access'**
  String get accessModuleAccess;

  /// No description provided for @accessGranted.
  ///
  /// In en, this message translates to:
  /// **'Granted'**
  String get accessGranted;

  /// No description provided for @accessNotGranted.
  ///
  /// In en, this message translates to:
  /// **'Not granted'**
  String get accessNotGranted;

  /// No description provided for @accessExpandAll.
  ///
  /// In en, this message translates to:
  /// **'Expand all'**
  String get accessExpandAll;

  /// No description provided for @accessCollapseAll.
  ///
  /// In en, this message translates to:
  /// **'Collapse all'**
  String get accessCollapseAll;

  /// No description provided for @accessUsersSummary.
  ///
  /// In en, this message translates to:
  /// **'Showing {count} users · {withAccess} with access'**
  String accessUsersSummary(Object count, Object withAccess);

  /// No description provided for @accessScopeHint.
  ///
  /// In en, this message translates to:
  /// **'Scope sets which records a permission applies to: Self = the user’s own records, Team = their team, Company = all records in the company.'**
  String get accessScopeHint;

  /// No description provided for @accessScopeLabel.
  ///
  /// In en, this message translates to:
  /// **'Scope'**
  String get accessScopeLabel;

  /// No description provided for @accessSelfRequiresEmployee.
  ///
  /// In en, this message translates to:
  /// **'Personal (self) permissions need a linked employee. This user has no linked employee, so they stay off.'**
  String get accessSelfRequiresEmployee;

  /// No description provided for @accessNoLinkedEmployeeTitle.
  ///
  /// In en, this message translates to:
  /// **'No linked employee'**
  String get accessNoLinkedEmployeeTitle;

  /// No description provided for @accessLinkEmployeeHint.
  ///
  /// In en, this message translates to:
  /// **'Personal permissions (punch in/out, my attendance, my leave) apply to an employee record. To enable them, link this user to an employee from HR → Employees → open the employee → Account access.'**
  String get accessLinkEmployeeHint;

  /// No description provided for @accessLinkedEmployee.
  ///
  /// In en, this message translates to:
  /// **'Linked employee'**
  String get accessLinkedEmployee;

  /// No description provided for @accessNotLinked.
  ///
  /// In en, this message translates to:
  /// **'Not linked'**
  String get accessNotLinked;

  /// No description provided for @demoPersonaPlatformAdmin.
  ///
  /// In en, this message translates to:
  /// **'Super admin'**
  String get demoPersonaPlatformAdmin;

  /// No description provided for @demoPersonaCompanyAdmin.
  ///
  /// In en, this message translates to:
  /// **'Company admin'**
  String get demoPersonaCompanyAdmin;

  /// No description provided for @demoPersonaHr.
  ///
  /// In en, this message translates to:
  /// **'HR'**
  String get demoPersonaHr;

  /// No description provided for @demoPersonaManager.
  ///
  /// In en, this message translates to:
  /// **'Manager'**
  String get demoPersonaManager;

  /// No description provided for @demoPersonaEmployee.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get demoPersonaEmployee;

  /// No description provided for @demoAccessPlatformAdmin.
  ///
  /// In en, this message translates to:
  /// **'Platform administration · every module and every access'**
  String get demoAccessPlatformAdmin;

  /// No description provided for @demoAccessCompanyAdmin.
  ///
  /// In en, this message translates to:
  /// **'Every company module and access'**
  String get demoAccessCompanyAdmin;

  /// No description provided for @demoAccessHr.
  ///
  /// In en, this message translates to:
  /// **'HR: employees, attendance, leave, reports, configuration'**
  String get demoAccessHr;

  /// No description provided for @demoAccessManager.
  ///
  /// In en, this message translates to:
  /// **'Team attendance and team leave approvals'**
  String get demoAccessManager;

  /// No description provided for @demoAccessEmployee.
  ///
  /// In en, this message translates to:
  /// **'Self attendance and self leave'**
  String get demoAccessEmployee;

  /// No description provided for @authDemoSignIn.
  ///
  /// In en, this message translates to:
  /// **'Sign in'**
  String get authDemoSignIn;

  /// No description provided for @universalDashboardSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Your work and company activity at a glance'**
  String get universalDashboardSubtitle;

  /// No description provided for @universalDashboardMyDay.
  ///
  /// In en, this message translates to:
  /// **'My day'**
  String get universalDashboardMyDay;

  /// No description provided for @universalDashboardNeedsAttention.
  ///
  /// In en, this message translates to:
  /// **'Needs attention'**
  String get universalDashboardNeedsAttention;

  /// No description provided for @universalDashboardMetrics.
  ///
  /// In en, this message translates to:
  /// **'Key metrics'**
  String get universalDashboardMetrics;

  /// No description provided for @universalDashboardSchedule.
  ///
  /// In en, this message translates to:
  /// **'Today\'s schedule'**
  String get universalDashboardSchedule;

  /// No description provided for @universalDashboardMyWork.
  ///
  /// In en, this message translates to:
  /// **'My work'**
  String get universalDashboardMyWork;

  /// No description provided for @universalDashboardTeam.
  ///
  /// In en, this message translates to:
  /// **'Team and company'**
  String get universalDashboardTeam;

  /// No description provided for @universalDashboardRecentActivity.
  ///
  /// In en, this message translates to:
  /// **'Recent activity'**
  String get universalDashboardRecentActivity;

  /// No description provided for @universalDashboardQuickActions.
  ///
  /// In en, this message translates to:
  /// **'Quick actions'**
  String get universalDashboardQuickActions;

  /// No description provided for @universalDashboardAllClear.
  ///
  /// In en, this message translates to:
  /// **'No tasks require your attention right now.'**
  String get universalDashboardAllClear;

  /// No description provided for @universalDashboardNoSchedule.
  ///
  /// In en, this message translates to:
  /// **'Nothing scheduled for today.'**
  String get universalDashboardNoSchedule;

  /// No description provided for @universalDashboardNoWork.
  ///
  /// In en, this message translates to:
  /// **'Nothing is assigned to you right now.'**
  String get universalDashboardNoWork;

  /// No description provided for @universalDashboardNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No recent activity.'**
  String get universalDashboardNoActivity;

  /// No description provided for @universalDashboardEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'You\'re all caught up'**
  String get universalDashboardEmptyTitle;

  /// No description provided for @universalDashboardError.
  ///
  /// In en, this message translates to:
  /// **'We couldn\'t load your dashboard. Please try again.'**
  String get universalDashboardError;

  /// No description provided for @universalDashboardPartial.
  ///
  /// In en, this message translates to:
  /// **'Some dashboard sections could not be loaded.'**
  String get universalDashboardPartial;

  /// No description provided for @universalDashboardRefresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get universalDashboardRefresh;

  /// No description provided for @universalDashboardRefreshing.
  ///
  /// In en, this message translates to:
  /// **'Refreshing dashboard'**
  String get universalDashboardRefreshing;

  /// No description provided for @universalDashboardViewAll.
  ///
  /// In en, this message translates to:
  /// **'View all'**
  String get universalDashboardViewAll;

  /// No description provided for @universalDashboardToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get universalDashboardToday;

  /// No description provided for @universalDashboardOpen.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get universalDashboardOpen;

  /// Common/Phase 0 UI: dashboard.
  ///
  /// In en, this message translates to:
  /// **'Dashboard'**
  String get dashboard;

  /// Common/Phase 0 UI: employees.
  ///
  /// In en, this message translates to:
  /// **'Employees'**
  String get employees;

  /// Common/Phase 0 UI: attendance.
  ///
  /// In en, this message translates to:
  /// **'Attendance'**
  String get attendance;

  /// Common/Phase 0 UI: requests.
  ///
  /// In en, this message translates to:
  /// **'Requests'**
  String get requests;

  /// Common/Phase 0 UI: reports.
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get reports;

  /// Common/Phase 0 UI: workLocation.
  ///
  /// In en, this message translates to:
  /// **'Work location'**
  String get workLocation;

  /// Common/Phase 0 UI: office.
  ///
  /// In en, this message translates to:
  /// **'Office'**
  String get office;

  /// Common/Phase 0 UI: remote.
  ///
  /// In en, this message translates to:
  /// **'Remote'**
  String get remote;

  /// Common/Phase 0 UI: effectiveDate.
  ///
  /// In en, this message translates to:
  /// **'Effective date'**
  String get effectiveDate;

  /// Common/Phase 0 UI: startTime.
  ///
  /// In en, this message translates to:
  /// **'Start time'**
  String get startTime;

  /// Common/Phase 0 UI: employee.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get employee;

  /// Common/Phase 0 UI: location.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get location;

  /// No description provided for @permissionEmployeeViewSelf.
  ///
  /// In en, this message translates to:
  /// **'View own employee record'**
  String get permissionEmployeeViewSelf;

  /// No description provided for @permissionEmployeeViewTeam.
  ///
  /// In en, this message translates to:
  /// **'View team employees'**
  String get permissionEmployeeViewTeam;

  /// No description provided for @permissionEmployeeViewAll.
  ///
  /// In en, this message translates to:
  /// **'View all employees'**
  String get permissionEmployeeViewAll;

  /// No description provided for @permissionEmployeeCreate.
  ///
  /// In en, this message translates to:
  /// **'Create employees'**
  String get permissionEmployeeCreate;

  /// No description provided for @permissionEmployeeUpdate.
  ///
  /// In en, this message translates to:
  /// **'Update employees'**
  String get permissionEmployeeUpdate;

  /// No description provided for @permissionEmployeeDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate employees'**
  String get permissionEmployeeDeactivate;

  /// No description provided for @permissionAttendanceViewSelf.
  ///
  /// In en, this message translates to:
  /// **'View own attendance'**
  String get permissionAttendanceViewSelf;

  /// No description provided for @permissionAttendanceViewTeam.
  ///
  /// In en, this message translates to:
  /// **'View team attendance'**
  String get permissionAttendanceViewTeam;

  /// No description provided for @permissionAttendanceViewAll.
  ///
  /// In en, this message translates to:
  /// **'View all attendance'**
  String get permissionAttendanceViewAll;

  /// No description provided for @permissionAttendancePunchIn.
  ///
  /// In en, this message translates to:
  /// **'Punch in'**
  String get permissionAttendancePunchIn;

  /// No description provided for @permissionAttendancePunchOut.
  ///
  /// In en, this message translates to:
  /// **'Punch out'**
  String get permissionAttendancePunchOut;

  /// No description provided for @permissionAttendanceBreak.
  ///
  /// In en, this message translates to:
  /// **'Manage own breaks'**
  String get permissionAttendanceBreak;

  /// No description provided for @permissionAttendanceRequestCorrection.
  ///
  /// In en, this message translates to:
  /// **'Request attendance corrections'**
  String get permissionAttendanceRequestCorrection;

  /// No description provided for @permissionAttendanceCorrect.
  ///
  /// In en, this message translates to:
  /// **'Correct attendance'**
  String get permissionAttendanceCorrect;

  /// No description provided for @permissionAttendanceApprove.
  ///
  /// In en, this message translates to:
  /// **'Approve attendance'**
  String get permissionAttendanceApprove;

  /// No description provided for @permissionShiftView.
  ///
  /// In en, this message translates to:
  /// **'View shifts'**
  String get permissionShiftView;

  /// No description provided for @permissionShiftManage.
  ///
  /// In en, this message translates to:
  /// **'Manage shifts'**
  String get permissionShiftManage;

  /// No description provided for @permissionWorkLocationView.
  ///
  /// In en, this message translates to:
  /// **'View work locations'**
  String get permissionWorkLocationView;

  /// No description provided for @permissionWorkLocationManage.
  ///
  /// In en, this message translates to:
  /// **'Manage work locations'**
  String get permissionWorkLocationManage;

  /// No description provided for @permissionAttendancePolicyView.
  ///
  /// In en, this message translates to:
  /// **'View attendance policies'**
  String get permissionAttendancePolicyView;

  /// No description provided for @permissionAttendancePolicyManage.
  ///
  /// In en, this message translates to:
  /// **'Manage attendance policies'**
  String get permissionAttendancePolicyManage;

  /// No description provided for @permissionAttendanceReportView.
  ///
  /// In en, this message translates to:
  /// **'View attendance reports'**
  String get permissionAttendanceReportView;

  /// No description provided for @dashboardMorning.
  ///
  /// In en, this message translates to:
  /// **'Good morning, {name}'**
  String dashboardMorning(String name);

  /// No description provided for @dashboardAfternoon.
  ///
  /// In en, this message translates to:
  /// **'Good afternoon, {name}'**
  String dashboardAfternoon(String name);

  /// No description provided for @dashboardEvening.
  ///
  /// In en, this message translates to:
  /// **'Good evening, {name}'**
  String dashboardEvening(String name);

  /// No description provided for @dashboardDemo.
  ///
  /// In en, this message translates to:
  /// **'Demo preview · {date}'**
  String dashboardDemo(String date);

  /// No description provided for @dashboardSelfContext.
  ///
  /// In en, this message translates to:
  /// **'Your workday at a glance'**
  String get dashboardSelfContext;

  /// No description provided for @dashboardNoShiftTitle.
  ///
  /// In en, this message translates to:
  /// **'Work schedule not configured'**
  String get dashboardNoShiftTitle;

  /// No description provided for @dashboardNoShiftMessage.
  ///
  /// In en, this message translates to:
  /// **'No shift has been assigned to your employee profile yet. Contact HR to complete your attendance setup.'**
  String get dashboardNoShiftMessage;

  /// No description provided for @dashboardThisWeek.
  ///
  /// In en, this message translates to:
  /// **'This week'**
  String get dashboardThisWeek;

  /// No description provided for @dashboardRecentAttendance.
  ///
  /// In en, this message translates to:
  /// **'Recent attendance'**
  String get dashboardRecentAttendance;

  /// No description provided for @dashboardViewFullHistory.
  ///
  /// In en, this message translates to:
  /// **'View full history'**
  String get dashboardViewFullHistory;

  /// No description provided for @dashboardNoRecentAttendance.
  ///
  /// In en, this message translates to:
  /// **'No previous attendance yet.'**
  String get dashboardNoRecentAttendance;

  /// No description provided for @dashboardNoRecentAttendanceMessage.
  ///
  /// In en, this message translates to:
  /// **'Your completed workdays will appear here.'**
  String get dashboardNoRecentAttendanceMessage;

  /// No description provided for @dashboardNoWeek.
  ///
  /// In en, this message translates to:
  /// **'No attendance recorded this week.'**
  String get dashboardNoWeek;

  /// No description provided for @dashboardWeekOff.
  ///
  /// In en, this message translates to:
  /// **'Week off'**
  String get dashboardWeekOff;

  /// No description provided for @dashboardTeamContext.
  ///
  /// In en, this message translates to:
  /// **'Your team at a glance'**
  String get dashboardTeamContext;

  /// No description provided for @dashboardCompanyContext.
  ///
  /// In en, this message translates to:
  /// **'Your company workforce at a glance'**
  String get dashboardCompanyContext;

  /// No description provided for @dashboardNoScope.
  ///
  /// In en, this message translates to:
  /// **'Your workspace'**
  String get dashboardNoScope;

  /// No description provided for @dashboardToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get dashboardToday;

  /// No description provided for @dashboardMonth.
  ///
  /// In en, this message translates to:
  /// **'This month'**
  String get dashboardMonth;

  /// No description provided for @dashboardEmployees.
  ///
  /// In en, this message translates to:
  /// **'Total employees'**
  String get dashboardEmployees;

  /// No description provided for @dashboardTeamSize.
  ///
  /// In en, this message translates to:
  /// **'Team size'**
  String get dashboardTeamSize;

  /// No description provided for @dashboardPresent.
  ///
  /// In en, this message translates to:
  /// **'Present'**
  String get dashboardPresent;

  /// No description provided for @dashboardLate.
  ///
  /// In en, this message translates to:
  /// **'Late'**
  String get dashboardLate;

  /// No description provided for @dashboardAbsent.
  ///
  /// In en, this message translates to:
  /// **'Absent'**
  String get dashboardAbsent;

  /// No description provided for @dashboardLeave.
  ///
  /// In en, this message translates to:
  /// **'On leave'**
  String get dashboardLeave;

  /// No description provided for @dashboardWorking.
  ///
  /// In en, this message translates to:
  /// **'Currently working'**
  String get dashboardWorking;

  /// No description provided for @dashboardBreak.
  ///
  /// In en, this message translates to:
  /// **'On break'**
  String get dashboardBreak;

  /// No description provided for @dashboardCorrections.
  ///
  /// In en, this message translates to:
  /// **'Pending corrections'**
  String get dashboardCorrections;

  /// No description provided for @dashboardHours.
  ///
  /// In en, this message translates to:
  /// **'Work hours'**
  String get dashboardHours;

  /// No description provided for @dashboardRate.
  ///
  /// In en, this message translates to:
  /// **'Attendance rate'**
  String get dashboardRate;

  /// No description provided for @dashboardLocations.
  ///
  /// In en, this message translates to:
  /// **'Work locations'**
  String get dashboardLocations;

  /// No description provided for @dashboardUsers.
  ///
  /// In en, this message translates to:
  /// **'Active users'**
  String get dashboardUsers;

  /// No description provided for @dashboardShift.
  ///
  /// In en, this message translates to:
  /// **'Shift'**
  String get dashboardShift;

  /// No description provided for @dashboardLocation.
  ///
  /// In en, this message translates to:
  /// **'Work location'**
  String get dashboardLocation;

  /// No description provided for @dashboardOffice.
  ///
  /// In en, this message translates to:
  /// **'Hyderabad office · demo'**
  String get dashboardOffice;

  /// No description provided for @dashboardNotStarted.
  ///
  /// In en, this message translates to:
  /// **'Not started · preview'**
  String get dashboardNotStarted;

  /// No description provided for @dashboardAttendance.
  ///
  /// In en, this message translates to:
  /// **'Attendance status'**
  String get dashboardAttendance;

  /// No description provided for @dashboardAttention.
  ///
  /// In en, this message translates to:
  /// **'Needs attention'**
  String get dashboardAttention;

  /// No description provided for @dashboardActivity.
  ///
  /// In en, this message translates to:
  /// **'Recent activity'**
  String get dashboardActivity;

  /// No description provided for @dashboardQuickActions.
  ///
  /// In en, this message translates to:
  /// **'Quick access'**
  String get dashboardQuickActions;

  /// No description provided for @dashboardStatus.
  ///
  /// In en, this message translates to:
  /// **'Attendance snapshot'**
  String get dashboardStatus;

  /// No description provided for @dashboardOnTime.
  ///
  /// In en, this message translates to:
  /// **'On time'**
  String get dashboardOnTime;

  /// No description provided for @dashboardPresentDetail.
  ///
  /// In en, this message translates to:
  /// **'Includes late arrivals'**
  String get dashboardPresentDetail;

  /// No description provided for @dashboardLateAlert.
  ///
  /// In en, this message translates to:
  /// **'{count} late arrivals to review'**
  String dashboardLateAlert(String count);

  /// No description provided for @dashboardCorrectionsAlert.
  ///
  /// In en, this message translates to:
  /// **'{count} corrections awaiting review'**
  String dashboardCorrectionsAlert(String count);

  /// No description provided for @dashboardLateAlertDetail.
  ///
  /// In en, this message translates to:
  /// **'Review attendance'**
  String get dashboardLateAlertDetail;

  /// No description provided for @dashboardCorrectionsAlertDetail.
  ///
  /// In en, this message translates to:
  /// **'Awaiting review'**
  String get dashboardCorrectionsAlertDetail;

  /// No description provided for @dashboardSelfCheckedIn.
  ///
  /// In en, this message translates to:
  /// **'Checked in'**
  String get dashboardSelfCheckedIn;

  /// No description provided for @dashboardSelfBreakStarted.
  ///
  /// In en, this message translates to:
  /// **'Started a break'**
  String get dashboardSelfBreakStarted;

  /// No description provided for @dashboardSelfCorrectionSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Submitted a correction'**
  String get dashboardSelfCorrectionSubmitted;

  /// No description provided for @dashboardCheckedIn.
  ///
  /// In en, this message translates to:
  /// **'{name} checked in'**
  String dashboardCheckedIn(String name);

  /// No description provided for @dashboardBreakStarted.
  ///
  /// In en, this message translates to:
  /// **'{name} started a break'**
  String dashboardBreakStarted(String name);

  /// No description provided for @dashboardCorrectionSubmitted.
  ///
  /// In en, this message translates to:
  /// **'{name} submitted a correction'**
  String dashboardCorrectionSubmitted(String name);

  /// No description provided for @dashboardActivityDetail.
  ///
  /// In en, this message translates to:
  /// **'Demo attendance activity'**
  String get dashboardActivityDetail;

  /// No description provided for @dashboardNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No recent activity'**
  String get dashboardNoActivity;

  /// No description provided for @dashboardNoAttention.
  ///
  /// In en, this message translates to:
  /// **'Nothing needs attention'**
  String get dashboardNoAttention;

  /// No description provided for @dashboardEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No workforce data yet'**
  String get dashboardEmptyTitle;

  /// No description provided for @dashboardEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Workforce insights appear here when data and access are available.'**
  String get dashboardEmptyMessage;

  /// No description provided for @dashboardError.
  ///
  /// In en, this message translates to:
  /// **'We couldn’t load your dashboard. Please try again.'**
  String get dashboardError;

  /// No description provided for @dashboardRefreshError.
  ///
  /// In en, this message translates to:
  /// **'Refresh failed. Your previous snapshot is still available.'**
  String get dashboardRefreshError;

  /// No description provided for @dashboardRefresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get dashboardRefresh;

  /// No description provided for @dashboardRefreshing.
  ///
  /// In en, this message translates to:
  /// **'Refreshing dashboard'**
  String get dashboardRefreshing;

  /// No description provided for @dashboardTimeRange.
  ///
  /// In en, this message translates to:
  /// **'{start} – {end}'**
  String dashboardTimeRange(String start, String end);

  /// No description provided for @empAdd.
  ///
  /// In en, this message translates to:
  /// **'Add employee'**
  String get empAdd;

  /// No description provided for @empEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit employee'**
  String get empEdit;

  /// No description provided for @empDetails.
  ///
  /// In en, this message translates to:
  /// **'Employee details'**
  String get empDetails;

  /// No description provided for @empPersonal.
  ///
  /// In en, this message translates to:
  /// **'Personal information'**
  String get empPersonal;

  /// No description provided for @empEmployment.
  ///
  /// In en, this message translates to:
  /// **'Employment information'**
  String get empEmployment;

  /// No description provided for @empAttendanceConfig.
  ///
  /// In en, this message translates to:
  /// **'Attendance configuration'**
  String get empAttendanceConfig;

  /// No description provided for @empAccountAccess.
  ///
  /// In en, this message translates to:
  /// **'Account access'**
  String get empAccountAccess;

  /// No description provided for @empCode.
  ///
  /// In en, this message translates to:
  /// **'Employee code'**
  String get empCode;

  /// No description provided for @empFirst.
  ///
  /// In en, this message translates to:
  /// **'First name *'**
  String get empFirst;

  /// No description provided for @empMiddle.
  ///
  /// In en, this message translates to:
  /// **'Middle name'**
  String get empMiddle;

  /// No description provided for @empLast.
  ///
  /// In en, this message translates to:
  /// **'Last name (optional)'**
  String get empLast;

  /// No description provided for @empDepartment.
  ///
  /// In en, this message translates to:
  /// **'Department'**
  String get empDepartment;

  /// No description provided for @empDesignation.
  ///
  /// In en, this message translates to:
  /// **'Designation'**
  String get empDesignation;

  /// No description provided for @empManager.
  ///
  /// In en, this message translates to:
  /// **'Manager'**
  String get empManager;

  /// No description provided for @empJoined.
  ///
  /// In en, this message translates to:
  /// **'Joining date'**
  String get empJoined;

  /// No description provided for @empType.
  ///
  /// In en, this message translates to:
  /// **'Employment type'**
  String get empType;

  /// No description provided for @empPolicy.
  ///
  /// In en, this message translates to:
  /// **'Attendance policy'**
  String get empPolicy;

  /// No description provided for @empLogin.
  ///
  /// In en, this message translates to:
  /// **'Enable app login'**
  String get empLogin;

  /// No description provided for @empGenerated.
  ///
  /// In en, this message translates to:
  /// **'Automatically generated on save'**
  String get empGenerated;

  /// No description provided for @empUnassigned.
  ///
  /// In en, this message translates to:
  /// **'Not assigned'**
  String get empUnassigned;

  /// No description provided for @empLoginNotice.
  ///
  /// In en, this message translates to:
  /// **'Local account configuration. New credentials and invitations are not issued in this phase.'**
  String get empLoginNotice;

  /// No description provided for @empCredentialPending.
  ///
  /// In en, this message translates to:
  /// **'Credential setup pending'**
  String get empCredentialPending;

  /// No description provided for @empNoLogin.
  ///
  /// In en, this message translates to:
  /// **'No linked account'**
  String get empNoLogin;

  /// No description provided for @empActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get empActive;

  /// No description provided for @empInactive.
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get empInactive;

  /// No description provided for @empFullTime.
  ///
  /// In en, this message translates to:
  /// **'Full time'**
  String get empFullTime;

  /// No description provided for @empPartTime.
  ///
  /// In en, this message translates to:
  /// **'Part time'**
  String get empPartTime;

  /// No description provided for @empContract.
  ///
  /// In en, this message translates to:
  /// **'Contract'**
  String get empContract;

  /// No description provided for @empIntern.
  ///
  /// In en, this message translates to:
  /// **'Intern'**
  String get empIntern;

  /// No description provided for @empTemporary.
  ///
  /// In en, this message translates to:
  /// **'Temporary'**
  String get empTemporary;

  /// No description provided for @empFilters.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get empFilters;

  /// No description provided for @empClear.
  ///
  /// In en, this message translates to:
  /// **'Clear filters'**
  String get empClear;

  /// No description provided for @empApply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get empApply;

  /// No description provided for @empReset.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get empReset;

  /// No description provided for @empAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get empAll;

  /// No description provided for @empSort.
  ///
  /// In en, this message translates to:
  /// **'Sort'**
  String get empSort;

  /// No description provided for @empNameAsc.
  ///
  /// In en, this message translates to:
  /// **'Name A–Z'**
  String get empNameAsc;

  /// No description provided for @empNameDesc.
  ///
  /// In en, this message translates to:
  /// **'Name Z–A'**
  String get empNameDesc;

  /// No description provided for @empNewest.
  ///
  /// In en, this message translates to:
  /// **'Newest joined'**
  String get empNewest;

  /// No description provided for @empOldest.
  ///
  /// In en, this message translates to:
  /// **'Oldest joined'**
  String get empOldest;

  /// No description provided for @empEmpty.
  ///
  /// In en, this message translates to:
  /// **'No employees yet'**
  String get empEmpty;

  /// No description provided for @empEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Add your first employee to start managing your workforce.'**
  String get empEmptyMessage;

  /// No description provided for @empNoResults.
  ///
  /// In en, this message translates to:
  /// **'No employees found'**
  String get empNoResults;

  /// No description provided for @empNoResultsMessage.
  ///
  /// In en, this message translates to:
  /// **'Try changing your search or filters.'**
  String get empNoResultsMessage;

  /// No description provided for @empNotFound.
  ///
  /// In en, this message translates to:
  /// **'Employee not found'**
  String get empNotFound;

  /// No description provided for @empNotFoundMessage.
  ///
  /// In en, this message translates to:
  /// **'This employee is unavailable.'**
  String get empNotFoundMessage;

  /// No description provided for @empView.
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get empView;

  /// No description provided for @empActivate.
  ///
  /// In en, this message translates to:
  /// **'Activate employee'**
  String get empActivate;

  /// No description provided for @empDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate employee'**
  String get empDeactivate;

  /// No description provided for @empStatusConfirm.
  ///
  /// In en, this message translates to:
  /// **'Change employee status?'**
  String get empStatusConfirm;

  /// No description provided for @empStatusMessage.
  ///
  /// In en, this message translates to:
  /// **'This changes active workforce status and linked account access. It can be reversed.'**
  String get empStatusMessage;

  /// No description provided for @empCreated.
  ///
  /// In en, this message translates to:
  /// **'Employee created successfully'**
  String get empCreated;

  /// No description provided for @empUpdated.
  ///
  /// In en, this message translates to:
  /// **'Employee updated successfully'**
  String get empUpdated;

  /// No description provided for @empStatusSaved.
  ///
  /// In en, this message translates to:
  /// **'Employee status updated'**
  String get empStatusSaved;

  /// No description provided for @empSave.
  ///
  /// In en, this message translates to:
  /// **'Save employee'**
  String get empSave;

  /// No description provided for @empDiscard.
  ///
  /// In en, this message translates to:
  /// **'Discard changes?'**
  String get empDiscard;

  /// No description provided for @empDiscardMessage.
  ///
  /// In en, this message translates to:
  /// **'You have unsaved changes. Discard them and leave this form?'**
  String get empDiscardMessage;

  /// No description provided for @empDiscardAction.
  ///
  /// In en, this message translates to:
  /// **'Discard'**
  String get empDiscardAction;

  /// No description provided for @empRequired.
  ///
  /// In en, this message translates to:
  /// **'Complete the required fields and choose a valid joining date.'**
  String get empRequired;

  /// No description provided for @empInvalidEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid email address.'**
  String get empInvalidEmail;

  /// No description provided for @empInvalidPhone.
  ///
  /// In en, this message translates to:
  /// **'Enter a phone number with 7–15 digits.'**
  String get empInvalidPhone;

  /// No description provided for @empDuplicateEmail.
  ///
  /// In en, this message translates to:
  /// **'This email is already assigned to another employee.'**
  String get empDuplicateEmail;

  /// No description provided for @empDuplicatePhone.
  ///
  /// In en, this message translates to:
  /// **'This phone is already assigned to another employee.'**
  String get empDuplicatePhone;

  /// No description provided for @empInvalidManager.
  ///
  /// In en, this message translates to:
  /// **'Choose an active manager without a circular reporting relationship.'**
  String get empInvalidManager;

  /// No description provided for @empInvalidReference.
  ///
  /// In en, this message translates to:
  /// **'Choose an active department and designation.'**
  String get empInvalidReference;

  /// No description provided for @empStorageError.
  ///
  /// In en, this message translates to:
  /// **'We couldn’t complete this local operation. Please try again.'**
  String get empStorageError;

  /// No description provided for @empPending.
  ///
  /// In en, this message translates to:
  /// **'Pending sync'**
  String get empPending;

  /// No description provided for @empBack.
  ///
  /// In en, this message translates to:
  /// **'Back to employees'**
  String get empBack;

  /// No description provided for @empSelfProfile.
  ///
  /// In en, this message translates to:
  /// **'View employee profile'**
  String get empSelfProfile;

  /// No description provided for @empRelated.
  ///
  /// In en, this message translates to:
  /// **'Related records'**
  String get empRelated;

  /// No description provided for @empPreview.
  ///
  /// In en, this message translates to:
  /// **'Attendance preview'**
  String get empPreview;

  /// No description provided for @empSelect.
  ///
  /// In en, this message translates to:
  /// **'Select an option'**
  String get empSelect;

  /// No description provided for @empActions.
  ///
  /// In en, this message translates to:
  /// **'Employee actions'**
  String get empActions;

  /// No description provided for @empCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} employees'**
  String empCount(String filtered, String total);

  /// No description provided for @empFilterCount.
  ///
  /// In en, this message translates to:
  /// **'Filters ({count})'**
  String empFilterCount(String count);

  /// No description provided for @cfgConfiguration.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get cfgConfiguration;

  /// No description provided for @cfgShifts.
  ///
  /// In en, this message translates to:
  /// **'Shifts'**
  String get cfgShifts;

  /// No description provided for @cfgShift.
  ///
  /// In en, this message translates to:
  /// **'Shift'**
  String get cfgShift;

  /// No description provided for @cfgPolicy.
  ///
  /// In en, this message translates to:
  /// **'Attendance policy'**
  String get cfgPolicy;

  /// No description provided for @cfgLocations.
  ///
  /// In en, this message translates to:
  /// **'Work locations'**
  String get cfgLocations;

  /// No description provided for @cfgPolicies.
  ///
  /// In en, this message translates to:
  /// **'Attendance policies'**
  String get cfgPolicies;

  /// No description provided for @cfgIntro.
  ///
  /// In en, this message translates to:
  /// **'Define when, where, and under which rules employees work.'**
  String get cfgIntro;

  /// No description provided for @cfgShiftIntro.
  ///
  /// In en, this message translates to:
  /// **'Working hours, weekdays, and planned breaks.'**
  String get cfgShiftIntro;

  /// No description provided for @cfgLocationIntro.
  ///
  /// In en, this message translates to:
  /// **'Work addresses and location validation settings.'**
  String get cfgLocationIntro;

  /// No description provided for @cfgPolicyIntro.
  ///
  /// In en, this message translates to:
  /// **'Rules prepared for future attendance workflows.'**
  String get cfgPolicyIntro;

  /// No description provided for @cfgNew.
  ///
  /// In en, this message translates to:
  /// **'Create record'**
  String get cfgNew;

  /// No description provided for @cfgEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit record'**
  String get cfgEdit;

  /// No description provided for @cfgSaved.
  ///
  /// In en, this message translates to:
  /// **'Configuration saved locally.'**
  String get cfgSaved;

  /// No description provided for @cfgStatusSaved.
  ///
  /// In en, this message translates to:
  /// **'Status updated locally.'**
  String get cfgStatusSaved;

  /// No description provided for @cfgName.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get cfgName;

  /// No description provided for @cfgCode.
  ///
  /// In en, this message translates to:
  /// **'Code (optional)'**
  String get cfgCode;

  /// No description provided for @cfgDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get cfgDescription;

  /// No description provided for @cfgAll.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get cfgAll;

  /// No description provided for @cfgActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get cfgActive;

  /// No description provided for @cfgInactive.
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get cfgInactive;

  /// No description provided for @cfgActivate.
  ///
  /// In en, this message translates to:
  /// **'Activate'**
  String get cfgActivate;

  /// No description provided for @cfgDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate'**
  String get cfgDeactivate;

  /// No description provided for @cfgStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get cfgStatus;

  /// No description provided for @cfgAssigned.
  ///
  /// In en, this message translates to:
  /// **'Assigned employees'**
  String get cfgAssigned;

  /// No description provided for @cfgDeactivateMessage.
  ///
  /// In en, this message translates to:
  /// **'Existing assignments are retained. This record will no longer be available for new assignments.'**
  String get cfgDeactivateMessage;

  /// No description provided for @cfgActivateMessage.
  ///
  /// In en, this message translates to:
  /// **'Make this record available for new employee assignments.'**
  String get cfgActivateMessage;

  /// No description provided for @cfgEmpty.
  ///
  /// In en, this message translates to:
  /// **'No configuration records yet'**
  String get cfgEmpty;

  /// No description provided for @cfgEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Create a record to prepare employee attendance assignments.'**
  String get cfgEmptyMessage;

  /// No description provided for @cfgNoResults.
  ///
  /// In en, this message translates to:
  /// **'No matching records'**
  String get cfgNoResults;

  /// No description provided for @cfgNoResultsMessage.
  ///
  /// In en, this message translates to:
  /// **'Try another search or status filter.'**
  String get cfgNoResultsMessage;

  /// No description provided for @cfgNotFound.
  ///
  /// In en, this message translates to:
  /// **'Record not found'**
  String get cfgNotFound;

  /// No description provided for @cfgNotFoundMessage.
  ///
  /// In en, this message translates to:
  /// **'This record is unavailable in the current company.'**
  String get cfgNotFoundMessage;

  /// No description provided for @cfgRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required.'**
  String get cfgRequired;

  /// No description provided for @cfgDuplicateName.
  ///
  /// In en, this message translates to:
  /// **'An active record with this name already exists.'**
  String get cfgDuplicateName;

  /// No description provided for @cfgInvalidTime.
  ///
  /// In en, this message translates to:
  /// **'Choose different valid start and end times.'**
  String get cfgInvalidTime;

  /// No description provided for @cfgWorkingDaysError.
  ///
  /// In en, this message translates to:
  /// **'Select at least one working day.'**
  String get cfgWorkingDaysError;

  /// No description provided for @cfgInvalidGrace.
  ///
  /// In en, this message translates to:
  /// **'Grace must be non-negative and shorter than the shift.'**
  String get cfgInvalidGrace;

  /// No description provided for @cfgInvalidBreak.
  ///
  /// In en, this message translates to:
  /// **'Fixed break must be shorter than the shift.'**
  String get cfgInvalidBreak;

  /// No description provided for @cfgInvalidMinimum.
  ///
  /// In en, this message translates to:
  /// **'Minimum work must fit within expected working time.'**
  String get cfgInvalidMinimum;

  /// No description provided for @cfgInvalidCoordinates.
  ///
  /// In en, this message translates to:
  /// **'Enter coordinates within valid latitude and longitude ranges.'**
  String get cfgInvalidCoordinates;

  /// No description provided for @cfgInvalidRadius.
  ///
  /// In en, this message translates to:
  /// **'Enter a positive, finite radius.'**
  String get cfgInvalidRadius;

  /// No description provided for @cfgInvalidAccuracy.
  ///
  /// In en, this message translates to:
  /// **'Enter a positive, finite accuracy limit.'**
  String get cfgInvalidAccuracy;

  /// No description provided for @cfgCountryError.
  ///
  /// In en, this message translates to:
  /// **'Enter a two-letter country code.'**
  String get cfgCountryError;

  /// No description provided for @cfgPolicyError.
  ///
  /// In en, this message translates to:
  /// **'Require location for at least one attendance event.'**
  String get cfgPolicyError;

  /// No description provided for @cfgEarlyError.
  ///
  /// In en, this message translates to:
  /// **'Enter an early arrival limit from 0 to 1440 minutes.'**
  String get cfgEarlyError;

  /// No description provided for @cfgAssignmentError.
  ///
  /// In en, this message translates to:
  /// **'Choose an active record from the current company.'**
  String get cfgAssignmentError;

  /// No description provided for @cfgStorageError.
  ///
  /// In en, this message translates to:
  /// **'Unable to read or save local configuration. Please retry.'**
  String get cfgStorageError;

  /// No description provided for @cfgStart.
  ///
  /// In en, this message translates to:
  /// **'Start time'**
  String get cfgStart;

  /// No description provided for @cfgEnd.
  ///
  /// In en, this message translates to:
  /// **'End time'**
  String get cfgEnd;

  /// No description provided for @cfgDays.
  ///
  /// In en, this message translates to:
  /// **'Working days'**
  String get cfgDays;

  /// No description provided for @cfgGrace.
  ///
  /// In en, this message translates to:
  /// **'Grace period'**
  String get cfgGrace;

  /// No description provided for @cfgBreakMode.
  ///
  /// In en, this message translates to:
  /// **'Break mode'**
  String get cfgBreakMode;

  /// No description provided for @cfgManualBreak.
  ///
  /// In en, this message translates to:
  /// **'Manual breaks'**
  String get cfgManualBreak;

  /// No description provided for @cfgFixedBreak.
  ///
  /// In en, this message translates to:
  /// **'Fixed planned break'**
  String get cfgFixedBreak;

  /// No description provided for @cfgNoBreak.
  ///
  /// In en, this message translates to:
  /// **'No breaks'**
  String get cfgNoBreak;

  /// No description provided for @cfgBreakMinutes.
  ///
  /// In en, this message translates to:
  /// **'Planned break duration'**
  String get cfgBreakMinutes;

  /// No description provided for @cfgMinimumWork.
  ///
  /// In en, this message translates to:
  /// **'Minimum work duration (optional)'**
  String get cfgMinimumWork;

  /// No description provided for @cfgDuration.
  ///
  /// In en, this message translates to:
  /// **'Shift duration'**
  String get cfgDuration;

  /// No description provided for @cfgExpectedWork.
  ///
  /// In en, this message translates to:
  /// **'Expected working time'**
  String get cfgExpectedWork;

  /// No description provided for @cfgOvernight.
  ///
  /// In en, this message translates to:
  /// **'Overnight shift'**
  String get cfgOvernight;

  /// No description provided for @cfgSchedule.
  ///
  /// In en, this message translates to:
  /// **'Schedule'**
  String get cfgSchedule;

  /// No description provided for @cfgMinutes.
  ///
  /// In en, this message translates to:
  /// **'minutes'**
  String get cfgMinutes;

  /// No description provided for @cfgMeters.
  ///
  /// In en, this message translates to:
  /// **'meters'**
  String get cfgMeters;

  /// No description provided for @cfgAddress.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get cfgAddress;

  /// No description provided for @cfgAddress1.
  ///
  /// In en, this message translates to:
  /// **'Address line 1'**
  String get cfgAddress1;

  /// No description provided for @cfgAddress2.
  ///
  /// In en, this message translates to:
  /// **'Address line 2 (optional)'**
  String get cfgAddress2;

  /// No description provided for @cfgCity.
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get cfgCity;

  /// No description provided for @cfgState.
  ///
  /// In en, this message translates to:
  /// **'State / region'**
  String get cfgState;

  /// No description provided for @cfgPostal.
  ///
  /// In en, this message translates to:
  /// **'Postal code'**
  String get cfgPostal;

  /// No description provided for @cfgCountry.
  ///
  /// In en, this message translates to:
  /// **'Country code'**
  String get cfgCountry;

  /// No description provided for @cfgLatitude.
  ///
  /// In en, this message translates to:
  /// **'Latitude'**
  String get cfgLatitude;

  /// No description provided for @cfgLongitude.
  ///
  /// In en, this message translates to:
  /// **'Longitude'**
  String get cfgLongitude;

  /// No description provided for @cfgRadius.
  ///
  /// In en, this message translates to:
  /// **'Allowed radius'**
  String get cfgRadius;

  /// No description provided for @cfgAccuracy.
  ///
  /// In en, this message translates to:
  /// **'Maximum accepted accuracy'**
  String get cfgAccuracy;

  /// No description provided for @cfgValidationMode.
  ///
  /// In en, this message translates to:
  /// **'Location validation'**
  String get cfgValidationMode;

  /// No description provided for @cfgGeofenceRequired.
  ///
  /// In en, this message translates to:
  /// **'Geofence required'**
  String get cfgGeofenceRequired;

  /// No description provided for @cfgGeofencePreferred.
  ///
  /// In en, this message translates to:
  /// **'Geofence preferred'**
  String get cfgGeofencePreferred;

  /// No description provided for @cfgCaptureOnly.
  ///
  /// In en, this message translates to:
  /// **'Capture location only'**
  String get cfgCaptureOnly;

  /// No description provided for @cfgNoLocation.
  ///
  /// In en, this message translates to:
  /// **'No location validation'**
  String get cfgNoLocation;

  /// No description provided for @cfgPreview.
  ///
  /// In en, this message translates to:
  /// **'Location preview'**
  String get cfgPreview;

  /// No description provided for @cfgPreviewNote.
  ///
  /// In en, this message translates to:
  /// **'Coordinates and radius preview. A map provider can be added later.'**
  String get cfgPreviewNote;

  /// No description provided for @cfgCurrentLocation.
  ///
  /// In en, this message translates to:
  /// **'Use current location'**
  String get cfgCurrentLocation;

  /// No description provided for @cfgLocating.
  ///
  /// In en, this message translates to:
  /// **'Finding location…'**
  String get cfgLocating;

  /// No description provided for @cfgOpenSettings.
  ///
  /// In en, this message translates to:
  /// **'Open settings'**
  String get cfgOpenSettings;

  /// No description provided for @cfgLocationDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission was denied. You can enter coordinates manually.'**
  String get cfgLocationDenied;

  /// No description provided for @cfgLocationPermanent.
  ///
  /// In en, this message translates to:
  /// **'Location permission is blocked. Enable it in app settings.'**
  String get cfgLocationPermanent;

  /// No description provided for @cfgLocationDisabled.
  ///
  /// In en, this message translates to:
  /// **'Location services are off. Enable them in device settings.'**
  String get cfgLocationDisabled;

  /// No description provided for @cfgLocationTimeout.
  ///
  /// In en, this message translates to:
  /// **'Location request timed out. Retry or enter coordinates manually.'**
  String get cfgLocationTimeout;

  /// No description provided for @cfgLocationUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Current location is unavailable. You can enter coordinates manually.'**
  String get cfgLocationUnavailable;

  /// No description provided for @cfgPoorAccuracy.
  ///
  /// In en, this message translates to:
  /// **'The captured position has poor accuracy. Review these coordinates before saving.'**
  String get cfgPoorAccuracy;

  /// No description provided for @cfgCapturedAccuracy.
  ///
  /// In en, this message translates to:
  /// **'Captured accuracy'**
  String get cfgCapturedAccuracy;

  /// No description provided for @cfgLocationRules.
  ///
  /// In en, this message translates to:
  /// **'Location rules'**
  String get cfgLocationRules;

  /// No description provided for @cfgBreakRules.
  ///
  /// In en, this message translates to:
  /// **'Break rules'**
  String get cfgBreakRules;

  /// No description provided for @cfgTimingRules.
  ///
  /// In en, this message translates to:
  /// **'Timing rules'**
  String get cfgTimingRules;

  /// No description provided for @cfgOfflineRules.
  ///
  /// In en, this message translates to:
  /// **'Offline behavior'**
  String get cfgOfflineRules;

  /// No description provided for @cfgGeneralRules.
  ///
  /// In en, this message translates to:
  /// **'General rules'**
  String get cfgGeneralRules;

  /// No description provided for @cfgRequireLocation.
  ///
  /// In en, this message translates to:
  /// **'Require location'**
  String get cfgRequireLocation;

  /// No description provided for @cfgOutside.
  ///
  /// In en, this message translates to:
  /// **'Allow attendance outside the assigned location'**
  String get cfgOutside;

  /// No description provided for @cfgRemote.
  ///
  /// In en, this message translates to:
  /// **'Allow remote attendance'**
  String get cfgRemote;

  /// No description provided for @cfgLocationIn.
  ///
  /// In en, this message translates to:
  /// **'Require location on punch in'**
  String get cfgLocationIn;

  /// No description provided for @cfgLocationOut.
  ///
  /// In en, this message translates to:
  /// **'Require location on punch out'**
  String get cfgLocationOut;

  /// No description provided for @cfgLocationBreak.
  ///
  /// In en, this message translates to:
  /// **'Require location for breaks'**
  String get cfgLocationBreak;

  /// No description provided for @cfgRequireAccuracy.
  ///
  /// In en, this message translates to:
  /// **'Require acceptable location accuracy'**
  String get cfgRequireAccuracy;

  /// No description provided for @cfgTrackBreaks.
  ///
  /// In en, this message translates to:
  /// **'Track breaks'**
  String get cfgTrackBreaks;

  /// No description provided for @cfgMultipleBreaks.
  ///
  /// In en, this message translates to:
  /// **'Allow multiple breaks'**
  String get cfgMultipleBreaks;

  /// No description provided for @cfgOutDuringBreak.
  ///
  /// In en, this message translates to:
  /// **'Allow punch out during a break'**
  String get cfgOutDuringBreak;

  /// No description provided for @cfgCorrections.
  ///
  /// In en, this message translates to:
  /// **'Allow employee correction requests'**
  String get cfgCorrections;

  /// No description provided for @cfgEarlyIn.
  ///
  /// In en, this message translates to:
  /// **'Allow early punch in'**
  String get cfgEarlyIn;

  /// No description provided for @cfgEarlyLimit.
  ///
  /// In en, this message translates to:
  /// **'Early arrival limit'**
  String get cfgEarlyLimit;

  /// No description provided for @cfgLateIn.
  ///
  /// In en, this message translates to:
  /// **'Allow late punch in'**
  String get cfgLateIn;

  /// No description provided for @cfgEarlyOut.
  ///
  /// In en, this message translates to:
  /// **'Allow early punch out'**
  String get cfgEarlyOut;

  /// No description provided for @cfgOfflineMode.
  ///
  /// In en, this message translates to:
  /// **'Offline attendance mode'**
  String get cfgOfflineMode;

  /// No description provided for @cfgOfflineNo.
  ///
  /// In en, this message translates to:
  /// **'Not allowed'**
  String get cfgOfflineNo;

  /// No description provided for @cfgOfflinePending.
  ///
  /// In en, this message translates to:
  /// **'Allow pending validation'**
  String get cfgOfflinePending;

  /// No description provided for @cfgOfflineWarning.
  ///
  /// In en, this message translates to:
  /// **'Allow with a warning'**
  String get cfgOfflineWarning;

  /// No description provided for @cfgYes.
  ///
  /// In en, this message translates to:
  /// **'Allowed'**
  String get cfgYes;

  /// No description provided for @cfgNo.
  ///
  /// In en, this message translates to:
  /// **'Not allowed'**
  String get cfgNo;

  /// No description provided for @cfgFoundationNote.
  ///
  /// In en, this message translates to:
  /// **'Configuration only. Attendance actions and rule evaluation will be implemented in Phase 6.'**
  String get cfgFoundationNote;

  /// No description provided for @cfgInactiveAssignment.
  ///
  /// In en, this message translates to:
  /// **'Inactive • current assignment retained'**
  String get cfgInactiveAssignment;

  /// No description provided for @cfgMon.
  ///
  /// In en, this message translates to:
  /// **'Mon'**
  String get cfgMon;

  /// No description provided for @cfgTue.
  ///
  /// In en, this message translates to:
  /// **'Tue'**
  String get cfgTue;

  /// No description provided for @cfgWed.
  ///
  /// In en, this message translates to:
  /// **'Wed'**
  String get cfgWed;

  /// No description provided for @cfgThu.
  ///
  /// In en, this message translates to:
  /// **'Thu'**
  String get cfgThu;

  /// No description provided for @cfgFri.
  ///
  /// In en, this message translates to:
  /// **'Fri'**
  String get cfgFri;

  /// No description provided for @cfgSat.
  ///
  /// In en, this message translates to:
  /// **'Sat'**
  String get cfgSat;

  /// No description provided for @cfgSun.
  ///
  /// In en, this message translates to:
  /// **'Sun'**
  String get cfgSun;

  /// No description provided for @cfgActions.
  ///
  /// In en, this message translates to:
  /// **'Actions'**
  String get cfgActions;

  /// No description provided for @cfgValidation.
  ///
  /// In en, this message translates to:
  /// **'Review the highlighted fields before saving.'**
  String get cfgValidation;

  /// No description provided for @cfgPending.
  ///
  /// In en, this message translates to:
  /// **'Pending sync'**
  String get cfgPending;

  /// No description provided for @cfgView.
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get cfgView;

  /// No description provided for @cfgKeepEditing.
  ///
  /// In en, this message translates to:
  /// **'Keep editing'**
  String get cfgKeepEditing;

  /// No description provided for @cfgDiscard.
  ///
  /// In en, this message translates to:
  /// **'Discard changes?'**
  String get cfgDiscard;

  /// No description provided for @cfgDiscardMessage.
  ///
  /// In en, this message translates to:
  /// **'You have unsaved changes. Discard them and leave this form?'**
  String get cfgDiscardMessage;

  /// No description provided for @cfgDiscardAction.
  ///
  /// In en, this message translates to:
  /// **'Discard changes'**
  String get cfgDiscardAction;

  /// No description provided for @attendanceNotLinkedToEmployee.
  ///
  /// In en, this message translates to:
  /// **'No employee profile is linked to this account'**
  String get attendanceNotLinkedToEmployee;

  /// No description provided for @attendanceEmployeeInactive.
  ///
  /// In en, this message translates to:
  /// **'Employee account is inactive'**
  String get attendanceEmployeeInactive;

  /// No description provided for @attendanceAccountInactive.
  ///
  /// In en, this message translates to:
  /// **'Your account is inactive or your session has ended'**
  String get attendanceAccountInactive;

  /// No description provided for @attendancePermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission for this attendance action'**
  String get attendancePermissionDenied;

  /// No description provided for @attendanceShiftNotAssigned.
  ///
  /// In en, this message translates to:
  /// **'No shift is assigned'**
  String get attendanceShiftNotAssigned;

  /// No description provided for @attendancePolicyNotAssigned.
  ///
  /// In en, this message translates to:
  /// **'No attendance policy is assigned'**
  String get attendancePolicyNotAssigned;

  /// No description provided for @attendanceWorkLocationRequiredButMissing.
  ///
  /// In en, this message translates to:
  /// **'No work location is assigned'**
  String get attendanceWorkLocationRequiredButMissing;

  /// No description provided for @attendanceLocationRequired.
  ///
  /// In en, this message translates to:
  /// **'Location is required'**
  String get attendanceLocationRequired;

  /// No description provided for @attendanceLocationUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Your location is unavailable'**
  String get attendanceLocationUnavailable;

  /// No description provided for @attendanceLocationPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission is required'**
  String get attendanceLocationPermissionDenied;

  /// No description provided for @attendanceLocationServicesDisabled.
  ///
  /// In en, this message translates to:
  /// **'Location services are disabled'**
  String get attendanceLocationServicesDisabled;

  /// No description provided for @attendanceLocationAccuracyTooLow.
  ///
  /// In en, this message translates to:
  /// **'Location accuracy is too low'**
  String get attendanceLocationAccuracyTooLow;

  /// No description provided for @attendanceOutsideAllowedLocation.
  ///
  /// In en, this message translates to:
  /// **'You are outside the allowed work location'**
  String get attendanceOutsideAllowedLocation;

  /// No description provided for @attendanceAlreadyPunchedIn.
  ///
  /// In en, this message translates to:
  /// **'You have already punched in'**
  String get attendanceAlreadyPunchedIn;

  /// No description provided for @attendanceNotPunchedIn.
  ///
  /// In en, this message translates to:
  /// **'Not punched in'**
  String get attendanceNotPunchedIn;

  /// No description provided for @attendanceAlreadyOnBreak.
  ///
  /// In en, this message translates to:
  /// **'You are already on a break'**
  String get attendanceAlreadyOnBreak;

  /// No description provided for @attendanceNotOnBreak.
  ///
  /// In en, this message translates to:
  /// **'No active break was found'**
  String get attendanceNotOnBreak;

  /// No description provided for @attendanceBreakTrackingDisabled.
  ///
  /// In en, this message translates to:
  /// **'Break tracking is disabled'**
  String get attendanceBreakTrackingDisabled;

  /// No description provided for @attendanceMultipleBreaksNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Multiple breaks are not allowed'**
  String get attendanceMultipleBreaksNotAllowed;

  /// No description provided for @attendancePunchOutDuringBreakNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Punch out is not allowed during a break'**
  String get attendancePunchOutDuringBreakNotAllowed;

  /// No description provided for @attendanceAlreadyCompleted.
  ///
  /// In en, this message translates to:
  /// **'Your workday is already complete'**
  String get attendanceAlreadyCompleted;

  /// No description provided for @attendanceTooEarlyToPunchIn.
  ///
  /// In en, this message translates to:
  /// **'You are too early to punch in'**
  String get attendanceTooEarlyToPunchIn;

  /// No description provided for @attendanceLatePunchInNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Late punch in is not allowed'**
  String get attendanceLatePunchInNotAllowed;

  /// No description provided for @attendanceEarlyPunchOutNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Early punch out is not allowed'**
  String get attendanceEarlyPunchOutNotAllowed;

  /// No description provided for @attendanceUnscheduledDay.
  ///
  /// In en, this message translates to:
  /// **'This is not a scheduled working day'**
  String get attendanceUnscheduledDay;

  /// No description provided for @attendanceOfflineAttendanceNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Offline attendance is not allowed'**
  String get attendanceOfflineAttendanceNotAllowed;

  /// No description provided for @attendanceInvalidAttendanceState.
  ///
  /// In en, this message translates to:
  /// **'The attendance timeline is inconsistent'**
  String get attendanceInvalidAttendanceState;

  /// No description provided for @attendancePersistenceFailure.
  ///
  /// In en, this message translates to:
  /// **'Attendance could not be saved. Please retry'**
  String get attendancePersistenceFailure;

  /// No description provided for @attendanceInvalidLocationEvidence.
  ///
  /// In en, this message translates to:
  /// **'Location evidence is invalid'**
  String get attendanceInvalidLocationEvidence;

  /// No description provided for @attendanceStaleLocationEvidence.
  ///
  /// In en, this message translates to:
  /// **'Please capture your location again'**
  String get attendanceStaleLocationEvidence;

  /// No description provided for @attendanceRemoteAttendanceNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Remote attendance is not allowed'**
  String get attendanceRemoteAttendanceNotAllowed;

  /// No description provided for @attendanceInvalidTimestamp.
  ///
  /// In en, this message translates to:
  /// **'The attendance timestamp is invalid'**
  String get attendanceInvalidTimestamp;

  /// No description provided for @attendanceDuplicateRequestId.
  ///
  /// In en, this message translates to:
  /// **'This attendance request has already been submitted'**
  String get attendanceDuplicateRequestId;

  /// No description provided for @attendanceOperationNotFound.
  ///
  /// In en, this message translates to:
  /// **'The attendance operation was not found'**
  String get attendanceOperationNotFound;

  /// No description provided for @attendanceSyncUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Attendance sync is not configured'**
  String get attendanceSyncUnavailable;

  /// No description provided for @attendanceSynchronizationFailed.
  ///
  /// In en, this message translates to:
  /// **'Attendance synchronization failed'**
  String get attendanceSynchronizationFailed;

  /// No description provided for @attendanceUnsupportedTimezone.
  ///
  /// In en, this message translates to:
  /// **'The company timezone is not supported yet'**
  String get attendanceUnsupportedTimezone;

  /// No description provided for @attendanceCompanyUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Attendance is unavailable for this company'**
  String get attendanceCompanyUnavailable;

  /// No description provided for @attendanceWarningOutsideAllowedLocation.
  ///
  /// In en, this message translates to:
  /// **'Outside the office location; attendance is permitted'**
  String get attendanceWarningOutsideAllowedLocation;

  /// No description provided for @attendanceWarningOfflinePending.
  ///
  /// In en, this message translates to:
  /// **'Attendance saved and waiting to sync'**
  String get attendanceWarningOfflinePending;

  /// No description provided for @attendanceWarningLatePunchIn.
  ///
  /// In en, this message translates to:
  /// **'Late punch in'**
  String get attendanceWarningLatePunchIn;

  /// No description provided for @attendanceWarningEarlyPunchOut.
  ///
  /// In en, this message translates to:
  /// **'Early punch out'**
  String get attendanceWarningEarlyPunchOut;

  /// No description provided for @attendanceWarningUnscheduledDay.
  ///
  /// In en, this message translates to:
  /// **'Attendance on an unscheduled day'**
  String get attendanceWarningUnscheduledDay;

  /// No description provided for @attendanceNotStarted.
  ///
  /// In en, this message translates to:
  /// **'Not started'**
  String get attendanceNotStarted;

  /// No description provided for @attendanceWorking.
  ///
  /// In en, this message translates to:
  /// **'Working'**
  String get attendanceWorking;

  /// No description provided for @attendanceOnBreak.
  ///
  /// In en, this message translates to:
  /// **'On break'**
  String get attendanceOnBreak;

  /// No description provided for @attendanceCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get attendanceCompleted;

  /// No description provided for @attendanceLate.
  ///
  /// In en, this message translates to:
  /// **'Late'**
  String get attendanceLate;

  /// No description provided for @attendancePending.
  ///
  /// In en, this message translates to:
  /// **'Pending sync'**
  String get attendancePending;

  /// No description provided for @attendanceSynced.
  ///
  /// In en, this message translates to:
  /// **'Synced'**
  String get attendanceSynced;

  /// No description provided for @attendanceFailed.
  ///
  /// In en, this message translates to:
  /// **'Sync failed'**
  String get attendanceFailed;

  /// No description provided for @attendanceRejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected'**
  String get attendanceRejected;

  /// No description provided for @attendancePunchIn.
  ///
  /// In en, this message translates to:
  /// **'Punch in'**
  String get attendancePunchIn;

  /// No description provided for @attendanceBreakStart.
  ///
  /// In en, this message translates to:
  /// **'Start break'**
  String get attendanceBreakStart;

  /// No description provided for @attendanceBreakEnd.
  ///
  /// In en, this message translates to:
  /// **'Resume work'**
  String get attendanceBreakEnd;

  /// No description provided for @attendancePunchOut.
  ///
  /// In en, this message translates to:
  /// **'Punch out'**
  String get attendancePunchOut;

  /// No description provided for @attendancePunchInNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Punch in is not allowed'**
  String get attendancePunchInNotAllowed;

  /// No description provided for @attendanceTodayTitle.
  ///
  /// In en, this message translates to:
  /// **'Today\'s attendance'**
  String get attendanceTodayTitle;

  /// No description provided for @attendanceWorkday.
  ///
  /// In en, this message translates to:
  /// **'YOUR WORKDAY'**
  String get attendanceWorkday;

  /// No description provided for @attendanceCompleteTitle.
  ///
  /// In en, this message translates to:
  /// **'Workday complete'**
  String get attendanceCompleteTitle;

  /// No description provided for @attendancePunchingIn.
  ///
  /// In en, this message translates to:
  /// **'Punching in…'**
  String get attendancePunchingIn;

  /// No description provided for @attendancePunchingOut.
  ///
  /// In en, this message translates to:
  /// **'Punching out…'**
  String get attendancePunchingOut;

  /// No description provided for @attendanceTakeBreak.
  ///
  /// In en, this message translates to:
  /// **'Take break'**
  String get attendanceTakeBreak;

  /// No description provided for @attendanceStartingBreak.
  ///
  /// In en, this message translates to:
  /// **'Starting break…'**
  String get attendanceStartingBreak;

  /// No description provided for @attendanceResumeWork.
  ///
  /// In en, this message translates to:
  /// **'Resume work'**
  String get attendanceResumeWork;

  /// No description provided for @attendanceResumingWork.
  ///
  /// In en, this message translates to:
  /// **'Resuming work…'**
  String get attendanceResumingWork;

  /// No description provided for @attendanceWorkTime.
  ///
  /// In en, this message translates to:
  /// **'Current work time'**
  String get attendanceWorkTime;

  /// No description provided for @attendanceCurrentLoggedWorkTime.
  ///
  /// In en, this message translates to:
  /// **'Current Logged Work Time (Today)'**
  String get attendanceCurrentLoggedWorkTime;

  /// No description provided for @attendanceInsideGeofence.
  ///
  /// In en, this message translates to:
  /// **'Inside {name} Geofence ({distance})'**
  String attendanceInsideGeofence(String name, String distance);

  /// No description provided for @attendanceCurrentBreak.
  ///
  /// In en, this message translates to:
  /// **'Current break'**
  String get attendanceCurrentBreak;

  /// No description provided for @attendanceTotalBreak.
  ///
  /// In en, this message translates to:
  /// **'Total break'**
  String get attendanceTotalBreak;

  /// No description provided for @attendanceElapsedTime.
  ///
  /// In en, this message translates to:
  /// **'Elapsed time'**
  String get attendanceElapsedTime;

  /// No description provided for @attendanceWorkedTime.
  ///
  /// In en, this message translates to:
  /// **'Worked time'**
  String get attendanceWorkedTime;

  /// No description provided for @attendanceBreakTime.
  ///
  /// In en, this message translates to:
  /// **'Break time'**
  String get attendanceBreakTime;

  /// No description provided for @attendanceTodayShift.
  ///
  /// In en, this message translates to:
  /// **'Today\'s shift'**
  String get attendanceTodayShift;

  /// No description provided for @attendanceWorkLocation.
  ///
  /// In en, this message translates to:
  /// **'Work location'**
  String get attendanceWorkLocation;

  /// No description provided for @attendanceLocationChecking.
  ///
  /// In en, this message translates to:
  /// **'Checking your location…'**
  String get attendanceLocationChecking;

  /// No description provided for @attendanceLocationReady.
  ///
  /// In en, this message translates to:
  /// **'Location ready'**
  String get attendanceLocationReady;

  /// No description provided for @attendanceInsideLocation.
  ///
  /// In en, this message translates to:
  /// **'Inside work location'**
  String get attendanceInsideLocation;

  /// No description provided for @attendanceOutsideLocation.
  ///
  /// In en, this message translates to:
  /// **'Outside work location'**
  String get attendanceOutsideLocation;

  /// No description provided for @attendanceLocationNotRequired.
  ///
  /// In en, this message translates to:
  /// **'Location verification not required'**
  String get attendanceLocationNotRequired;

  /// No description provided for @attendanceLocationRequiredNote.
  ///
  /// In en, this message translates to:
  /// **'Your location will be checked when you submit this action.'**
  String get attendanceLocationRequiredNote;

  /// No description provided for @attendanceAccuracy.
  ///
  /// In en, this message translates to:
  /// **'Location accuracy'**
  String get attendanceAccuracy;

  /// No description provided for @attendanceRadius.
  ///
  /// In en, this message translates to:
  /// **'Allowed radius'**
  String get attendanceRadius;

  /// No description provided for @attendanceRefreshLocation.
  ///
  /// In en, this message translates to:
  /// **'Refresh location'**
  String get attendanceRefreshLocation;

  /// No description provided for @attendanceAllowLocation.
  ///
  /// In en, this message translates to:
  /// **'Allow location'**
  String get attendanceAllowLocation;

  /// No description provided for @attendanceOpenSettings.
  ///
  /// In en, this message translates to:
  /// **'Open settings'**
  String get attendanceOpenSettings;

  /// No description provided for @attendancePermissionSettings.
  ///
  /// In en, this message translates to:
  /// **'Location permission is disabled in system settings.'**
  String get attendancePermissionSettings;

  /// No description provided for @attendanceServicesNote.
  ///
  /// In en, this message translates to:
  /// **'Turn on location services to continue.'**
  String get attendanceServicesNote;

  /// No description provided for @attendanceNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity yet'**
  String get attendanceNoActivity;

  /// No description provided for @attendanceActivityNote.
  ///
  /// In en, this message translates to:
  /// **'Your punch-in and break activity will appear here.'**
  String get attendanceActivityNote;

  /// No description provided for @attendanceTodayActivity.
  ///
  /// In en, this message translates to:
  /// **'Today\'s activity'**
  String get attendanceTodayActivity;

  /// No description provided for @attendancePunchInTime.
  ///
  /// In en, this message translates to:
  /// **'Punch-in time'**
  String get attendancePunchInTime;

  /// No description provided for @attendancePunchOutTime.
  ///
  /// In en, this message translates to:
  /// **'Punch out'**
  String get attendancePunchOutTime;

  /// No description provided for @attendanceCurrentTime.
  ///
  /// In en, this message translates to:
  /// **'Current time'**
  String get attendanceCurrentTime;

  /// No description provided for @attendanceBreakStartedLabel.
  ///
  /// In en, this message translates to:
  /// **'Break started'**
  String get attendanceBreakStartedLabel;

  /// No description provided for @attendanceWorkResumedLabel.
  ///
  /// In en, this message translates to:
  /// **'Work resumed'**
  String get attendanceWorkResumedLabel;

  /// No description provided for @attendanceEndWorkday.
  ///
  /// In en, this message translates to:
  /// **'End your workday?'**
  String get attendanceEndWorkday;

  /// No description provided for @attendanceConfirmAction.
  ///
  /// In en, this message translates to:
  /// **'Confirm attendance action'**
  String get attendanceConfirmAction;

  /// No description provided for @attendanceContinue.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get attendanceContinue;

  /// No description provided for @attendanceCloseBreakNote.
  ///
  /// In en, this message translates to:
  /// **'Your current break will end when you punch out.'**
  String get attendanceCloseBreakNote;

  /// No description provided for @attendancePendingTitle.
  ///
  /// In en, this message translates to:
  /// **'Pending sync'**
  String get attendancePendingTitle;

  /// No description provided for @attendancePendingNote.
  ///
  /// In en, this message translates to:
  /// **'Saved on this device. Waiting for verification when sync becomes available.'**
  String get attendancePendingNote;

  /// No description provided for @attendanceFailedTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance sync needs attention'**
  String get attendanceFailedTitle;

  /// No description provided for @attendanceFailedNote.
  ///
  /// In en, this message translates to:
  /// **'Your attendance is saved locally but could not be verified.'**
  String get attendanceFailedNote;

  /// No description provided for @attendanceRejectedTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance could not be verified'**
  String get attendanceRejectedTitle;

  /// No description provided for @attendanceRejectedNote.
  ///
  /// In en, this message translates to:
  /// **'Your recorded events are retained. Contact HR to resolve this issue.'**
  String get attendanceRejectedNote;

  /// No description provided for @attendanceRetrySync.
  ///
  /// In en, this message translates to:
  /// **'Retry sync'**
  String get attendanceRetrySync;

  /// No description provided for @attendanceRequeuedNote.
  ///
  /// In en, this message translates to:
  /// **'Attendance is queued for sync. No sync service is configured yet.'**
  String get attendanceRequeuedNote;

  /// No description provided for @attendanceNotConfigured.
  ///
  /// In en, this message translates to:
  /// **'Attendance is not configured yet'**
  String get attendanceNotConfigured;

  /// No description provided for @attendanceContactHr.
  ///
  /// In en, this message translates to:
  /// **'Contact HR to complete your attendance setup.'**
  String get attendanceContactHr;

  /// No description provided for @attendanceUnavailableTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance unavailable'**
  String get attendanceUnavailableTitle;

  /// No description provided for @attendanceStartNote.
  ///
  /// In en, this message translates to:
  /// **'Punch in to begin your workday.'**
  String get attendanceStartNote;

  /// No description provided for @attendanceWorkingNote.
  ///
  /// In en, this message translates to:
  /// **'Your work time is calculated from recorded activity.'**
  String get attendanceWorkingNote;

  /// No description provided for @attendanceBreakNote.
  ///
  /// In en, this message translates to:
  /// **'Work time is paused while you are on a break.'**
  String get attendanceBreakNote;

  /// No description provided for @attendanceCompleteNote.
  ///
  /// In en, this message translates to:
  /// **'Your final totals and activity are recorded below.'**
  String get attendanceCompleteNote;

  /// No description provided for @attendanceExpectedHours.
  ///
  /// In en, this message translates to:
  /// **'Expected work'**
  String get attendanceExpectedHours;

  /// No description provided for @attendanceGrace.
  ///
  /// In en, this message translates to:
  /// **'Grace period'**
  String get attendanceGrace;

  /// No description provided for @attendanceOnTime.
  ///
  /// In en, this message translates to:
  /// **'On-time'**
  String get attendanceOnTime;

  /// No description provided for @attendanceTarget.
  ///
  /// In en, this message translates to:
  /// **'Target'**
  String get attendanceTarget;

  /// No description provided for @attendanceShiftRemaining.
  ///
  /// In en, this message translates to:
  /// **'Shift remaining'**
  String get attendanceShiftRemaining;

  /// No description provided for @attendanceOpenAttendance.
  ///
  /// In en, this message translates to:
  /// **'Open attendance'**
  String get attendanceOpenAttendance;

  /// No description provided for @attendanceViewAttendance.
  ///
  /// In en, this message translates to:
  /// **'View attendance'**
  String get attendanceViewAttendance;

  /// No description provided for @attendanceStartsAt.
  ///
  /// In en, this message translates to:
  /// **'Starts at'**
  String get attendanceStartsAt;

  /// No description provided for @attendanceWorked.
  ///
  /// In en, this message translates to:
  /// **'Worked'**
  String get attendanceWorked;

  /// No description provided for @attendanceBreak.
  ///
  /// In en, this message translates to:
  /// **'Break'**
  String get attendanceBreak;

  /// No description provided for @attendanceLastCheck.
  ///
  /// In en, this message translates to:
  /// **'Last location check'**
  String get attendanceLastCheck;

  /// No description provided for @attendanceCheckingSetup.
  ///
  /// In en, this message translates to:
  /// **'Loading attendance setup'**
  String get attendanceCheckingSetup;

  /// No description provided for @attendanceWarningNote.
  ///
  /// In en, this message translates to:
  /// **'Review these details before recording your attendance.'**
  String get attendanceWarningNote;

  /// No description provided for @attendanceDistance.
  ///
  /// In en, this message translates to:
  /// **'Distance from work location'**
  String get attendanceDistance;

  /// No description provided for @attendanceTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Try again'**
  String get attendanceTryAgain;

  /// No description provided for @attendanceLocationCaptureReady.
  ///
  /// In en, this message translates to:
  /// **'Location captured'**
  String get attendanceLocationCaptureReady;

  /// No description provided for @attendanceAccuracyLimit.
  ///
  /// In en, this message translates to:
  /// **'Required accuracy'**
  String get attendanceAccuracyLimit;

  /// No description provided for @attendanceNoLocation.
  ///
  /// In en, this message translates to:
  /// **'No work location assigned'**
  String get attendanceNoLocation;

  /// No description provided for @attendanceGoodMorning.
  ///
  /// In en, this message translates to:
  /// **'Good morning'**
  String get attendanceGoodMorning;

  /// No description provided for @attendanceGoodAfternoon.
  ///
  /// In en, this message translates to:
  /// **'Good afternoon'**
  String get attendanceGoodAfternoon;

  /// No description provided for @attendanceGoodEvening.
  ///
  /// In en, this message translates to:
  /// **'Good evening'**
  String get attendanceGoodEvening;

  /// No description provided for @attendanceMeters.
  ///
  /// In en, this message translates to:
  /// **'{value} m'**
  String attendanceMeters(String value);

  /// No description provided for @historyTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance history'**
  String get historyTitle;

  /// No description provided for @historyNav.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get historyNav;

  /// No description provided for @historyMonthlySummary.
  ///
  /// In en, this message translates to:
  /// **'Monthly summary'**
  String get historyMonthlySummary;

  /// No description provided for @historyPreviousMonth.
  ///
  /// In en, this message translates to:
  /// **'Previous month'**
  String get historyPreviousMonth;

  /// No description provided for @historyNextMonth.
  ///
  /// In en, this message translates to:
  /// **'Next month'**
  String get historyNextMonth;

  /// No description provided for @historyPresent.
  ///
  /// In en, this message translates to:
  /// **'Present'**
  String get historyPresent;

  /// No description provided for @historyLate.
  ///
  /// In en, this message translates to:
  /// **'Late'**
  String get historyLate;

  /// No description provided for @historyIncomplete.
  ///
  /// In en, this message translates to:
  /// **'Incomplete'**
  String get historyIncomplete;

  /// No description provided for @historyCompletedOnly.
  ///
  /// In en, this message translates to:
  /// **'Work and break totals include completed records only.'**
  String get historyCompletedOnly;

  /// No description provided for @historyEmpty.
  ///
  /// In en, this message translates to:
  /// **'No attendance records'**
  String get historyEmpty;

  /// No description provided for @historyFilteredEmpty.
  ///
  /// In en, this message translates to:
  /// **'No matching attendance records'**
  String get historyFilteredEmpty;

  /// No description provided for @historyEmptyNote.
  ///
  /// In en, this message translates to:
  /// **'No activity was recorded in this month.'**
  String get historyEmptyNote;

  /// No description provided for @historyFilteredNote.
  ///
  /// In en, this message translates to:
  /// **'Try another status or clear your filters.'**
  String get historyFilteredNote;

  /// No description provided for @historyClearFilters.
  ///
  /// In en, this message translates to:
  /// **'Clear filters'**
  String get historyClearFilters;

  /// No description provided for @historyAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get historyAllStatuses;

  /// No description provided for @historyFilters.
  ///
  /// In en, this message translates to:
  /// **'Status filters'**
  String get historyFilters;

  /// No description provided for @historyApply.
  ///
  /// In en, this message translates to:
  /// **'Apply filters'**
  String get historyApply;

  /// No description provided for @historyReset.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get historyReset;

  /// No description provided for @historyDetails.
  ///
  /// In en, this message translates to:
  /// **'Attendance details'**
  String get historyDetails;

  /// No description provided for @historyDailySummary.
  ///
  /// In en, this message translates to:
  /// **'Daily summary'**
  String get historyDailySummary;

  /// No description provided for @historyTimeline.
  ///
  /// In en, this message translates to:
  /// **'Timeline'**
  String get historyTimeline;

  /// No description provided for @historyBreaks.
  ///
  /// In en, this message translates to:
  /// **'Breaks'**
  String get historyBreaks;

  /// No description provided for @historyMissingOut.
  ///
  /// In en, this message translates to:
  /// **'Missing punch out'**
  String get historyMissingOut;

  /// No description provided for @historyOpenBreak.
  ///
  /// In en, this message translates to:
  /// **'Incomplete break'**
  String get historyOpenBreak;

  /// No description provided for @historyNotRecorded.
  ///
  /// In en, this message translates to:
  /// **'Not recorded'**
  String get historyNotRecorded;

  /// No description provided for @historyNeedsAttention.
  ///
  /// In en, this message translates to:
  /// **'Needs attention'**
  String get historyNeedsAttention;

  /// No description provided for @historyIncompleteNote.
  ///
  /// In en, this message translates to:
  /// **'This record has no punch out. Final work and break totals are unavailable.'**
  String get historyIncompleteNote;

  /// No description provided for @historyOpenBreakNote.
  ///
  /// In en, this message translates to:
  /// **'No resume recorded. This break has no final duration.'**
  String get historyOpenBreakNote;

  /// No description provided for @historyGoToday.
  ///
  /// In en, this message translates to:
  /// **'Open today’s attendance'**
  String get historyGoToday;

  /// No description provided for @historyActiveNote.
  ///
  /// In en, this message translates to:
  /// **'This record is still open. Use Today for live totals and attendance actions.'**
  String get historyActiveNote;

  /// No description provided for @historyNotFound.
  ///
  /// In en, this message translates to:
  /// **'Attendance record unavailable'**
  String get historyNotFound;

  /// No description provided for @historyNotFoundNote.
  ///
  /// In en, this message translates to:
  /// **'This record was not found in your attendance history.'**
  String get historyNotFoundNote;

  /// No description provided for @historyOvernight.
  ///
  /// In en, this message translates to:
  /// **'Overnight shift'**
  String get historyOvernight;

  /// No description provided for @historyExpected.
  ///
  /// In en, this message translates to:
  /// **'Expected duration'**
  String get historyExpected;

  /// No description provided for @historyGrace.
  ///
  /// In en, this message translates to:
  /// **'Grace period'**
  String get historyGrace;

  /// No description provided for @historyWithinArea.
  ///
  /// In en, this message translates to:
  /// **'Within assigned area'**
  String get historyWithinArea;

  /// No description provided for @historyOutsideAllowed.
  ///
  /// In en, this message translates to:
  /// **'Outside assigned area · allowed by policy'**
  String get historyOutsideAllowed;

  /// No description provided for @historyVerificationIssue.
  ///
  /// In en, this message translates to:
  /// **'Verification issue'**
  String get historyVerificationIssue;

  /// No description provided for @historyContactHr.
  ///
  /// In en, this message translates to:
  /// **'The original record is retained. Contact HR about this verification issue.'**
  String get historyContactHr;

  /// No description provided for @historyDate.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get historyDate;

  /// No description provided for @historyStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get historyStatus;

  /// No description provided for @historyNow.
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get historyNow;

  /// No description provided for @historyRetry.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get historyRetry;

  /// No description provided for @historyAverageWork.
  ///
  /// In en, this message translates to:
  /// **'Average worked per completed day'**
  String get historyAverageWork;

  /// No description provided for @historyNoBreaks.
  ///
  /// In en, this message translates to:
  /// **'No breaks recorded'**
  String get historyNoBreaks;

  /// No description provided for @historyFilterCount.
  ///
  /// In en, this message translates to:
  /// **'Status filters ({count})'**
  String historyFilterCount(String count);

  /// No description provided for @correctionRequest.
  ///
  /// In en, this message translates to:
  /// **'Request correction'**
  String get correctionRequest;

  /// No description provided for @correctionMyRequests.
  ///
  /// In en, this message translates to:
  /// **'My requests'**
  String get correctionMyRequests;

  /// No description provided for @correctionReviewQueue.
  ///
  /// In en, this message translates to:
  /// **'Correction requests'**
  String get correctionReviewQueue;

  /// No description provided for @correctionType.
  ///
  /// In en, this message translates to:
  /// **'Correction type'**
  String get correctionType;

  /// No description provided for @correctionRequestedTime.
  ///
  /// In en, this message translates to:
  /// **'Requested date and time'**
  String get correctionRequestedTime;

  /// No description provided for @correctionReason.
  ///
  /// In en, this message translates to:
  /// **'Reason'**
  String get correctionReason;

  /// No description provided for @correctionReviewNote.
  ///
  /// In en, this message translates to:
  /// **'Review note'**
  String get correctionReviewNote;

  /// No description provided for @correctionSubmit.
  ///
  /// In en, this message translates to:
  /// **'Submit request'**
  String get correctionSubmit;

  /// No description provided for @correctionCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel request'**
  String get correctionCancel;

  /// No description provided for @correctionApprove.
  ///
  /// In en, this message translates to:
  /// **'Approve'**
  String get correctionApprove;

  /// No description provided for @correctionReject.
  ///
  /// In en, this message translates to:
  /// **'Reject'**
  String get correctionReject;

  /// No description provided for @correctionPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get correctionPending;

  /// No description provided for @correctionApproved.
  ///
  /// In en, this message translates to:
  /// **'Approved'**
  String get correctionApproved;

  /// No description provided for @correctionRejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected'**
  String get correctionRejected;

  /// No description provided for @correctionCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get correctionCancelled;

  /// No description provided for @correctionOriginal.
  ///
  /// In en, this message translates to:
  /// **'Original'**
  String get correctionOriginal;

  /// No description provided for @correctionRequested.
  ///
  /// In en, this message translates to:
  /// **'Requested'**
  String get correctionRequested;

  /// No description provided for @correctionNoRequests.
  ///
  /// In en, this message translates to:
  /// **'No correction requests'**
  String get correctionNoRequests;

  /// No description provided for @correctionMissingPunchIn.
  ///
  /// In en, this message translates to:
  /// **'Missing punch in'**
  String get correctionMissingPunchIn;

  /// No description provided for @correctionMissingPunchOut.
  ///
  /// In en, this message translates to:
  /// **'Missing punch out'**
  String get correctionMissingPunchOut;

  /// No description provided for @correctionChangePunchIn.
  ///
  /// In en, this message translates to:
  /// **'Change punch in time'**
  String get correctionChangePunchIn;

  /// No description provided for @correctionChangePunchOut.
  ///
  /// In en, this message translates to:
  /// **'Change punch out time'**
  String get correctionChangePunchOut;

  /// No description provided for @correctionMissingBreakStart.
  ///
  /// In en, this message translates to:
  /// **'Missing break start'**
  String get correctionMissingBreakStart;

  /// No description provided for @correctionMissingBreakEnd.
  ///
  /// In en, this message translates to:
  /// **'Missing break end'**
  String get correctionMissingBreakEnd;

  /// No description provided for @correctionChangeBreakStart.
  ///
  /// In en, this message translates to:
  /// **'Change break start time'**
  String get correctionChangeBreakStart;

  /// No description provided for @correctionChangeBreakEnd.
  ///
  /// In en, this message translates to:
  /// **'Change break end time'**
  String get correctionChangeBreakEnd;

  /// No description provided for @correctionPreview.
  ///
  /// In en, this message translates to:
  /// **'Effective result preview'**
  String get correctionPreview;

  /// No description provided for @correctionInvalid.
  ///
  /// In en, this message translates to:
  /// **'Check the requested time and event order.'**
  String get correctionInvalid;

  /// No description provided for @correctionSaved.
  ///
  /// In en, this message translates to:
  /// **'Correction request submitted'**
  String get correctionSaved;

  /// No description provided for @correctionReviewSaved.
  ///
  /// In en, this message translates to:
  /// **'Review saved'**
  String get correctionReviewSaved;

  /// No description provided for @correctionReasonRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter a reason'**
  String get correctionReasonRequired;

  /// No description provided for @workforceTeam.
  ///
  /// In en, this message translates to:
  /// **'Team attendance'**
  String get workforceTeam;

  /// No description provided for @workforceAll.
  ///
  /// In en, this message translates to:
  /// **'All attendance'**
  String get workforceAll;

  /// No description provided for @workforceNotStarted.
  ///
  /// In en, this message translates to:
  /// **'Not started'**
  String get workforceNotStarted;

  /// No description provided for @workforceWorking.
  ///
  /// In en, this message translates to:
  /// **'Working'**
  String get workforceWorking;

  /// No description provided for @workforceOnBreak.
  ///
  /// In en, this message translates to:
  /// **'On break'**
  String get workforceOnBreak;

  /// No description provided for @workforceCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get workforceCompleted;

  /// No description provided for @workforceIncomplete.
  ///
  /// In en, this message translates to:
  /// **'Incomplete'**
  String get workforceIncomplete;

  /// No description provided for @workforceNoSchedule.
  ///
  /// In en, this message translates to:
  /// **'No schedule'**
  String get workforceNoSchedule;

  /// No description provided for @workforceNoRecord.
  ///
  /// In en, this message translates to:
  /// **'No record'**
  String get workforceNoRecord;

  /// No description provided for @workforceSearch.
  ///
  /// In en, this message translates to:
  /// **'Search employees'**
  String get workforceSearch;

  /// No description provided for @workforceNoEmployees.
  ///
  /// In en, this message translates to:
  /// **'No employees match'**
  String get workforceNoEmployees;

  /// No description provided for @workforceDepartment.
  ///
  /// In en, this message translates to:
  /// **'Department'**
  String get workforceDepartment;

  /// No description provided for @workforceShift.
  ///
  /// In en, this message translates to:
  /// **'Shift'**
  String get workforceShift;

  /// No description provided for @workforceLocation.
  ///
  /// In en, this message translates to:
  /// **'Work location'**
  String get workforceLocation;

  /// No description provided for @workforceDate.
  ///
  /// In en, this message translates to:
  /// **'Attendance date'**
  String get workforceDate;

  /// No description provided for @workforceToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get workforceToday;

  /// No description provided for @workforcePrevious.
  ///
  /// In en, this message translates to:
  /// **'Previous day'**
  String get workforcePrevious;

  /// No description provided for @workforceNext.
  ///
  /// In en, this message translates to:
  /// **'Next day'**
  String get workforceNext;

  /// No description provided for @workforcePendingCorrection.
  ///
  /// In en, this message translates to:
  /// **'Pending correction'**
  String get workforcePendingCorrection;

  /// No description provided for @workforceSort.
  ///
  /// In en, this message translates to:
  /// **'Sort by'**
  String get workforceSort;

  /// No description provided for @workforceName.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get workforceName;

  /// No description provided for @workforceNameDescending.
  ///
  /// In en, this message translates to:
  /// **'Name (Z–A)'**
  String get workforceNameDescending;

  /// No description provided for @workforceCode.
  ///
  /// In en, this message translates to:
  /// **'Employee code'**
  String get workforceCode;

  /// No description provided for @workforceAllFilter.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get workforceAllFilter;

  /// No description provided for @reportTitle.
  ///
  /// In en, this message translates to:
  /// **'Attendance reports'**
  String get reportTitle;

  /// No description provided for @reportOverview.
  ///
  /// In en, this message translates to:
  /// **'Overview'**
  String get reportOverview;

  /// No description provided for @reportWorkHours.
  ///
  /// In en, this message translates to:
  /// **'Work hours'**
  String get reportWorkHours;

  /// No description provided for @reportLate.
  ///
  /// In en, this message translates to:
  /// **'Late attendance'**
  String get reportLate;

  /// No description provided for @reportBreaks.
  ///
  /// In en, this message translates to:
  /// **'Break analysis'**
  String get reportBreaks;

  /// No description provided for @reportIssues.
  ///
  /// In en, this message translates to:
  /// **'Attendance issues'**
  String get reportIssues;

  /// No description provided for @reportEmployees.
  ///
  /// In en, this message translates to:
  /// **'Employee summary'**
  String get reportEmployees;

  /// No description provided for @reportToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get reportToday;

  /// No description provided for @reportThisWeek.
  ///
  /// In en, this message translates to:
  /// **'This week'**
  String get reportThisWeek;

  /// No description provided for @reportThisMonth.
  ///
  /// In en, this message translates to:
  /// **'This month'**
  String get reportThisMonth;

  /// No description provided for @reportLastMonth.
  ///
  /// In en, this message translates to:
  /// **'Last month'**
  String get reportLastMonth;

  /// No description provided for @reportCustom.
  ///
  /// In en, this message translates to:
  /// **'Custom range'**
  String get reportCustom;

  /// No description provided for @reportFrom.
  ///
  /// In en, this message translates to:
  /// **'From'**
  String get reportFrom;

  /// No description provided for @reportTo.
  ///
  /// In en, this message translates to:
  /// **'To'**
  String get reportTo;

  /// No description provided for @reportScopeTeam.
  ///
  /// In en, this message translates to:
  /// **'My team'**
  String get reportScopeTeam;

  /// No description provided for @reportScopeCompany.
  ///
  /// In en, this message translates to:
  /// **'Company'**
  String get reportScopeCompany;

  /// No description provided for @reportRecordedDays.
  ///
  /// In en, this message translates to:
  /// **'Recorded workdays'**
  String get reportRecordedDays;

  /// No description provided for @reportCompletedDays.
  ///
  /// In en, this message translates to:
  /// **'Completed workdays'**
  String get reportCompletedDays;

  /// No description provided for @reportLateDays.
  ///
  /// In en, this message translates to:
  /// **'Late records'**
  String get reportLateDays;

  /// No description provided for @reportIncompleteDays.
  ///
  /// In en, this message translates to:
  /// **'Incomplete records'**
  String get reportIncompleteDays;

  /// No description provided for @reportWorkTotal.
  ///
  /// In en, this message translates to:
  /// **'Worked time'**
  String get reportWorkTotal;

  /// No description provided for @reportBreakTotal.
  ///
  /// In en, this message translates to:
  /// **'Break time'**
  String get reportBreakTotal;

  /// No description provided for @reportAverageWork.
  ///
  /// In en, this message translates to:
  /// **'Average per recorded day'**
  String get reportAverageWork;

  /// No description provided for @reportPendingCorrections.
  ///
  /// In en, this message translates to:
  /// **'Pending corrections'**
  String get reportPendingCorrections;

  /// No description provided for @reportIssueDays.
  ///
  /// In en, this message translates to:
  /// **'Days with issues'**
  String get reportIssueDays;

  /// No description provided for @reportTrend.
  ///
  /// In en, this message translates to:
  /// **'Recorded workdays by date'**
  String get reportTrend;

  /// No description provided for @reportDaily.
  ///
  /// In en, this message translates to:
  /// **'Daily'**
  String get reportDaily;

  /// No description provided for @reportWeekly.
  ///
  /// In en, this message translates to:
  /// **'Weekly'**
  String get reportWeekly;

  /// No description provided for @reportMonthly.
  ///
  /// In en, this message translates to:
  /// **'Monthly'**
  String get reportMonthly;

  /// No description provided for @reportGroupBy.
  ///
  /// In en, this message translates to:
  /// **'Group by'**
  String get reportGroupBy;

  /// No description provided for @reportNoData.
  ///
  /// In en, this message translates to:
  /// **'No recorded attendance matches this period and filters.'**
  String get reportNoData;

  /// No description provided for @reportInProgress.
  ///
  /// In en, this message translates to:
  /// **'Today\'s active attendance is provisional until punch out.'**
  String get reportInProgress;

  /// No description provided for @reportFilter.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get reportFilter;

  /// No description provided for @reportClearFilters.
  ///
  /// In en, this message translates to:
  /// **'Clear filters'**
  String get reportClearFilters;

  /// No description provided for @reportEmployee.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get reportEmployee;

  /// No description provided for @reportStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get reportStatus;

  /// No description provided for @reportCorrections.
  ///
  /// In en, this message translates to:
  /// **'Corrections'**
  String get reportCorrections;

  /// No description provided for @reportAny.
  ///
  /// In en, this message translates to:
  /// **'Any'**
  String get reportAny;

  /// No description provided for @reportYes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get reportYes;

  /// No description provided for @reportNo.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get reportNo;

  /// No description provided for @reportApply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get reportApply;

  /// No description provided for @reportExport.
  ///
  /// In en, this message translates to:
  /// **'Export'**
  String get reportExport;

  /// No description provided for @reportCsv.
  ///
  /// In en, this message translates to:
  /// **'Export CSV'**
  String get reportCsv;

  /// No description provided for @reportPdf.
  ///
  /// In en, this message translates to:
  /// **'Export PDF'**
  String get reportPdf;

  /// No description provided for @reportExported.
  ///
  /// In en, this message translates to:
  /// **'Report saved'**
  String get reportExported;

  /// No description provided for @reportExportFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not export report'**
  String get reportExportFailed;

  /// No description provided for @reportLoading.
  ///
  /// In en, this message translates to:
  /// **'Loading report'**
  String get reportLoading;

  /// No description provided for @reportRefreshFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not refresh report'**
  String get reportRefreshFailed;

  /// No description provided for @reportUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Attendance reports are unavailable.'**
  String get reportUnavailable;

  /// No description provided for @reportDate.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get reportDate;

  /// No description provided for @reportWorked.
  ///
  /// In en, this message translates to:
  /// **'Worked'**
  String get reportWorked;

  /// No description provided for @reportBreak.
  ///
  /// In en, this message translates to:
  /// **'Break'**
  String get reportBreak;

  /// No description provided for @reportLateBy.
  ///
  /// In en, this message translates to:
  /// **'Late by'**
  String get reportLateBy;

  /// No description provided for @reportRecorded.
  ///
  /// In en, this message translates to:
  /// **'Recorded days'**
  String get reportRecorded;

  /// No description provided for @reportCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get reportCompleted;

  /// No description provided for @reportLateCount.
  ///
  /// In en, this message translates to:
  /// **'Late'**
  String get reportLateCount;

  /// No description provided for @reportIssuesCount.
  ///
  /// In en, this message translates to:
  /// **'Issues'**
  String get reportIssuesCount;

  /// No description provided for @reportPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get reportPending;

  /// No description provided for @reportShiftStart.
  ///
  /// In en, this message translates to:
  /// **'Shift start'**
  String get reportShiftStart;

  /// No description provided for @reportPunchIn.
  ///
  /// In en, this message translates to:
  /// **'Punch in'**
  String get reportPunchIn;

  /// No description provided for @reportDepartment.
  ///
  /// In en, this message translates to:
  /// **'Department'**
  String get reportDepartment;

  /// No description provided for @reportLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get reportLocation;

  /// No description provided for @reportPeriod.
  ///
  /// In en, this message translates to:
  /// **'Period'**
  String get reportPeriod;

  /// No description provided for @reportGenerated.
  ///
  /// In en, this message translates to:
  /// **'Generated'**
  String get reportGenerated;

  /// No description provided for @reportPage.
  ///
  /// In en, this message translates to:
  /// **'Page'**
  String get reportPage;

  /// No description provided for @reportSortNewest.
  ///
  /// In en, this message translates to:
  /// **'Newest first'**
  String get reportSortNewest;

  /// No description provided for @reportSortOldest.
  ///
  /// In en, this message translates to:
  /// **'Oldest first'**
  String get reportSortOldest;

  /// No description provided for @reportSortEmployee.
  ///
  /// In en, this message translates to:
  /// **'Employee name'**
  String get reportSortEmployee;

  /// No description provided for @reportSortWork.
  ///
  /// In en, this message translates to:
  /// **'Most worked time'**
  String get reportSortWork;

  /// No description provided for @reportSortBreak.
  ///
  /// In en, this message translates to:
  /// **'Most break time'**
  String get reportSortBreak;

  /// No description provided for @reportFiltersApplied.
  ///
  /// In en, this message translates to:
  /// **'Applied filters'**
  String get reportFiltersApplied;

  /// No description provided for @attendanceNeedsReview.
  ///
  /// In en, this message translates to:
  /// **'Attendance needs review'**
  String get attendanceNeedsReview;

  /// No description provided for @attendanceConflict.
  ///
  /// In en, this message translates to:
  /// **'Attendance conflict'**
  String get attendanceConflict;

  /// No description provided for @attendanceConflictMessage.
  ///
  /// In en, this message translates to:
  /// **'Your local attendance does not match the latest server record.'**
  String get attendanceConflictMessage;

  /// No description provided for @attendanceCouldNotBeVerified.
  ///
  /// In en, this message translates to:
  /// **'Attendance could not be verified'**
  String get attendanceCouldNotBeVerified;

  /// No description provided for @attendanceNeedsAttention.
  ///
  /// In en, this message translates to:
  /// **'Attendance needs attention'**
  String get attendanceNeedsAttention;

  /// No description provided for @reportSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Analyze attendance activity, work hours, timing and record quality.'**
  String get reportSubtitle;

  /// No description provided for @reportActivityTrend.
  ///
  /// In en, this message translates to:
  /// **'Attendance activity'**
  String get reportActivityTrend;

  /// No description provided for @reportActivityTrendDesc.
  ///
  /// In en, this message translates to:
  /// **'Recorded records by date.'**
  String get reportActivityTrendDesc;

  /// No description provided for @reportStatusDistribution.
  ///
  /// In en, this message translates to:
  /// **'Attendance status'**
  String get reportStatusDistribution;

  /// No description provided for @reportStatusDistributionDesc.
  ///
  /// In en, this message translates to:
  /// **'Composition of recorded records.'**
  String get reportStatusDistributionDesc;

  /// No description provided for @reportWorkHoursTrend.
  ///
  /// In en, this message translates to:
  /// **'Recorded work hours'**
  String get reportWorkHoursTrend;

  /// No description provided for @reportWorkHoursTrendDesc.
  ///
  /// In en, this message translates to:
  /// **'Total recorded work time by date.'**
  String get reportWorkHoursTrendDesc;

  /// No description provided for @reportLateTrend.
  ///
  /// In en, this message translates to:
  /// **'Late attendance'**
  String get reportLateTrend;

  /// No description provided for @reportLateTrendDesc.
  ///
  /// In en, this message translates to:
  /// **'Late records by date.'**
  String get reportLateTrendDesc;

  /// No description provided for @reportBreakTrend.
  ///
  /// In en, this message translates to:
  /// **'Break time'**
  String get reportBreakTrend;

  /// No description provided for @reportBreakTrendDesc.
  ///
  /// In en, this message translates to:
  /// **'Recorded break time by date.'**
  String get reportBreakTrendDesc;

  /// No description provided for @reportIssuesByType.
  ///
  /// In en, this message translates to:
  /// **'Issues by type'**
  String get reportIssuesByType;

  /// No description provided for @reportIssuesByTypeDesc.
  ///
  /// In en, this message translates to:
  /// **'What needs attention in this period.'**
  String get reportIssuesByTypeDesc;

  /// No description provided for @reportNeedsAttention.
  ///
  /// In en, this message translates to:
  /// **'Needs attention'**
  String get reportNeedsAttention;

  /// No description provided for @reportDetailedRecords.
  ///
  /// In en, this message translates to:
  /// **'Detailed records'**
  String get reportDetailedRecords;

  /// No description provided for @reportStatusWorking.
  ///
  /// In en, this message translates to:
  /// **'Working'**
  String get reportStatusWorking;

  /// No description provided for @reportStatusCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get reportStatusCompleted;

  /// No description provided for @reportStatusLate.
  ///
  /// In en, this message translates to:
  /// **'Late'**
  String get reportStatusLate;

  /// No description provided for @reportStatusIssues.
  ///
  /// In en, this message translates to:
  /// **'Issues'**
  String get reportStatusIssues;

  /// No description provided for @reportIssueRejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected attendance'**
  String get reportIssueRejected;

  /// No description provided for @reportIssueSyncFailure.
  ///
  /// In en, this message translates to:
  /// **'Sync failure'**
  String get reportIssueSyncFailure;

  /// No description provided for @reportIssuePendingCorrection.
  ///
  /// In en, this message translates to:
  /// **'Pending correction'**
  String get reportIssuePendingCorrection;

  /// No description provided for @reportIssueMissingPunchOut.
  ///
  /// In en, this message translates to:
  /// **'Missing punch out'**
  String get reportIssueMissingPunchOut;

  /// No description provided for @reportViewTeam.
  ///
  /// In en, this message translates to:
  /// **'Team view'**
  String get reportViewTeam;

  /// No description provided for @reportViewCompany.
  ///
  /// In en, this message translates to:
  /// **'Company view'**
  String get reportViewCompany;

  /// No description provided for @reportRecordedEmployees.
  ///
  /// In en, this message translates to:
  /// **'Recorded employees'**
  String get reportRecordedEmployees;

  /// No description provided for @permissionLeaveViewSelf.
  ///
  /// In en, this message translates to:
  /// **'View own leave'**
  String get permissionLeaveViewSelf;

  /// No description provided for @permissionLeaveRequest.
  ///
  /// In en, this message translates to:
  /// **'Request leave'**
  String get permissionLeaveRequest;

  /// No description provided for @permissionLeaveCancelSelf.
  ///
  /// In en, this message translates to:
  /// **'Cancel own leave'**
  String get permissionLeaveCancelSelf;

  /// No description provided for @permissionLeaveViewTeam.
  ///
  /// In en, this message translates to:
  /// **'View team leave'**
  String get permissionLeaveViewTeam;

  /// No description provided for @permissionLeaveApproveTeam.
  ///
  /// In en, this message translates to:
  /// **'Approve team leave'**
  String get permissionLeaveApproveTeam;

  /// No description provided for @permissionLeaveViewAll.
  ///
  /// In en, this message translates to:
  /// **'View company leave'**
  String get permissionLeaveViewAll;

  /// No description provided for @permissionLeaveApproveAll.
  ///
  /// In en, this message translates to:
  /// **'Approve company leave'**
  String get permissionLeaveApproveAll;

  /// No description provided for @permissionLeaveManage.
  ///
  /// In en, this message translates to:
  /// **'Manage leave'**
  String get permissionLeaveManage;

  /// No description provided for @permissionLeaveBalanceViewSelf.
  ///
  /// In en, this message translates to:
  /// **'View own leave balance'**
  String get permissionLeaveBalanceViewSelf;

  /// No description provided for @permissionLeaveBalanceViewTeam.
  ///
  /// In en, this message translates to:
  /// **'View team leave balances'**
  String get permissionLeaveBalanceViewTeam;

  /// No description provided for @permissionLeaveBalanceViewAll.
  ///
  /// In en, this message translates to:
  /// **'View company leave balances'**
  String get permissionLeaveBalanceViewAll;

  /// No description provided for @permissionLeaveBalanceAdjust.
  ///
  /// In en, this message translates to:
  /// **'Adjust leave balances'**
  String get permissionLeaveBalanceAdjust;

  /// No description provided for @permissionLeaveTypeView.
  ///
  /// In en, this message translates to:
  /// **'View leave types'**
  String get permissionLeaveTypeView;

  /// No description provided for @permissionLeaveTypeManage.
  ///
  /// In en, this message translates to:
  /// **'Manage leave types'**
  String get permissionLeaveTypeManage;

  /// No description provided for @permissionLeavePolicyView.
  ///
  /// In en, this message translates to:
  /// **'View leave policies'**
  String get permissionLeavePolicyView;

  /// No description provided for @permissionLeavePolicyManage.
  ///
  /// In en, this message translates to:
  /// **'Manage leave policies'**
  String get permissionLeavePolicyManage;

  /// No description provided for @permissionHolidayView.
  ///
  /// In en, this message translates to:
  /// **'View holidays'**
  String get permissionHolidayView;

  /// No description provided for @permissionHolidayManage.
  ///
  /// In en, this message translates to:
  /// **'Manage holidays'**
  String get permissionHolidayManage;

  /// No description provided for @permissionLeaveReportView.
  ///
  /// In en, this message translates to:
  /// **'View leave reports'**
  String get permissionLeaveReportView;

  /// No description provided for @leaveMyLeave.
  ///
  /// In en, this message translates to:
  /// **'My leave'**
  String get leaveMyLeave;

  /// No description provided for @leaveNewRequest.
  ///
  /// In en, this message translates to:
  /// **'New request'**
  String get leaveNewRequest;

  /// No description provided for @leaveMyRequests.
  ///
  /// In en, this message translates to:
  /// **'My requests'**
  String get leaveMyRequests;

  /// No description provided for @leaveApprovals.
  ///
  /// In en, this message translates to:
  /// **'Approvals'**
  String get leaveApprovals;

  /// No description provided for @leaveTeam.
  ///
  /// In en, this message translates to:
  /// **'Team leave'**
  String get leaveTeam;

  /// No description provided for @leaveAllNav.
  ///
  /// In en, this message translates to:
  /// **'All leave'**
  String get leaveAllNav;

  /// No description provided for @leaveBalancesNav.
  ///
  /// In en, this message translates to:
  /// **'Balances'**
  String get leaveBalancesNav;

  /// No description provided for @leaveCalendarNav.
  ///
  /// In en, this message translates to:
  /// **'Calendar'**
  String get leaveCalendarNav;

  /// No description provided for @leaveTypesNav.
  ///
  /// In en, this message translates to:
  /// **'Leave types'**
  String get leaveTypesNav;

  /// No description provided for @leavePoliciesNav.
  ///
  /// In en, this message translates to:
  /// **'Leave policies'**
  String get leavePoliciesNav;

  /// No description provided for @holidaysNav.
  ///
  /// In en, this message translates to:
  /// **'Holidays'**
  String get holidaysNav;

  /// No description provided for @leaveTypeIntro.
  ///
  /// In en, this message translates to:
  /// **'Configure the kinds of leave employees can request.'**
  String get leaveTypeIntro;

  /// No description provided for @leavePolicyIntro.
  ///
  /// In en, this message translates to:
  /// **'Define entitlement and request rules for each leave type.'**
  String get leavePolicyIntro;

  /// No description provided for @holidayIntro.
  ///
  /// In en, this message translates to:
  /// **'Configure public, company and optional holidays.'**
  String get holidayIntro;

  /// No description provided for @leaveType.
  ///
  /// In en, this message translates to:
  /// **'Leave type'**
  String get leaveType;

  /// No description provided for @leaveCompensation.
  ///
  /// In en, this message translates to:
  /// **'Compensation'**
  String get leaveCompensation;

  /// No description provided for @leaveRequiresApproval.
  ///
  /// In en, this message translates to:
  /// **'Requires approval'**
  String get leaveRequiresApproval;

  /// No description provided for @leaveAllowsHalfDay.
  ///
  /// In en, this message translates to:
  /// **'Allows half day'**
  String get leaveAllowsHalfDay;

  /// No description provided for @leaveRequiresReason.
  ///
  /// In en, this message translates to:
  /// **'Reason required'**
  String get leaveRequiresReason;

  /// No description provided for @leaveRequiresAttachment.
  ///
  /// In en, this message translates to:
  /// **'Attachment required'**
  String get leaveRequiresAttachment;

  /// No description provided for @leaveCompensationPaid.
  ///
  /// In en, this message translates to:
  /// **'Paid'**
  String get leaveCompensationPaid;

  /// No description provided for @leaveCompensationUnpaid.
  ///
  /// In en, this message translates to:
  /// **'Unpaid'**
  String get leaveCompensationUnpaid;

  /// No description provided for @leaveCompensationInformational.
  ///
  /// In en, this message translates to:
  /// **'Informational'**
  String get leaveCompensationInformational;

  /// No description provided for @leavePolicy.
  ///
  /// In en, this message translates to:
  /// **'Leave policy'**
  String get leavePolicy;

  /// No description provided for @leavePolicyLeaveType.
  ///
  /// In en, this message translates to:
  /// **'Leave type'**
  String get leavePolicyLeaveType;

  /// No description provided for @leavePolicyEntitlement.
  ///
  /// In en, this message translates to:
  /// **'Annual entitlement'**
  String get leavePolicyEntitlement;

  /// No description provided for @leavePolicyMinDays.
  ///
  /// In en, this message translates to:
  /// **'Minimum request'**
  String get leavePolicyMinDays;

  /// No description provided for @leavePolicyMaxConsecutive.
  ///
  /// In en, this message translates to:
  /// **'Maximum consecutive days'**
  String get leavePolicyMaxConsecutive;

  /// No description provided for @leavePolicyAdvanceNotice.
  ///
  /// In en, this message translates to:
  /// **'Advance notice'**
  String get leavePolicyAdvanceNotice;

  /// No description provided for @leavePolicyAllowPast.
  ///
  /// In en, this message translates to:
  /// **'Allow past requests'**
  String get leavePolicyAllowPast;

  /// No description provided for @leavePolicyPastWindow.
  ///
  /// In en, this message translates to:
  /// **'Past request window'**
  String get leavePolicyPastWindow;

  /// No description provided for @leavePolicyNegative.
  ///
  /// In en, this message translates to:
  /// **'Allow negative balance'**
  String get leavePolicyNegative;

  /// No description provided for @leavePolicyCarryForward.
  ///
  /// In en, this message translates to:
  /// **'Carry forward'**
  String get leavePolicyCarryForward;

  /// No description provided for @leavePolicyCarryLimit.
  ///
  /// In en, this message translates to:
  /// **'Carry forward limit'**
  String get leavePolicyCarryLimit;

  /// No description provided for @leavePolicyEmployment.
  ///
  /// In en, this message translates to:
  /// **'Applicable employment types'**
  String get leavePolicyEmployment;

  /// No description provided for @days.
  ///
  /// In en, this message translates to:
  /// **'days'**
  String get days;

  /// No description provided for @holiday.
  ///
  /// In en, this message translates to:
  /// **'Holiday'**
  String get holiday;

  /// No description provided for @holidayDate.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get holidayDate;

  /// No description provided for @holidayEndDate.
  ///
  /// In en, this message translates to:
  /// **'End date'**
  String get holidayEndDate;

  /// No description provided for @holidayTypeField.
  ///
  /// In en, this message translates to:
  /// **'Type'**
  String get holidayTypeField;

  /// No description provided for @holidayScopeField.
  ///
  /// In en, this message translates to:
  /// **'Scope'**
  String get holidayScopeField;

  /// No description provided for @holidayWorkLocations.
  ///
  /// In en, this message translates to:
  /// **'Work locations'**
  String get holidayWorkLocations;

  /// No description provided for @holidayOptional.
  ///
  /// In en, this message translates to:
  /// **'Optional holiday'**
  String get holidayOptional;

  /// No description provided for @holidayTypePublic.
  ///
  /// In en, this message translates to:
  /// **'Public holiday'**
  String get holidayTypePublic;

  /// No description provided for @holidayTypeCompany.
  ///
  /// In en, this message translates to:
  /// **'Company holiday'**
  String get holidayTypeCompany;

  /// No description provided for @holidayTypeOptional.
  ///
  /// In en, this message translates to:
  /// **'Optional holiday'**
  String get holidayTypeOptional;

  /// No description provided for @holidayTypeSpecial.
  ///
  /// In en, this message translates to:
  /// **'Special closure'**
  String get holidayTypeSpecial;

  /// No description provided for @holidayScopeCompanyWide.
  ///
  /// In en, this message translates to:
  /// **'Company wide'**
  String get holidayScopeCompanyWide;

  /// No description provided for @holidayScopeSpecific.
  ///
  /// In en, this message translates to:
  /// **'Specific work locations'**
  String get holidayScopeSpecific;

  /// No description provided for @leaveRequestTitle.
  ///
  /// In en, this message translates to:
  /// **'Request leave'**
  String get leaveRequestTitle;

  /// No description provided for @leaveStartDate.
  ///
  /// In en, this message translates to:
  /// **'Start date'**
  String get leaveStartDate;

  /// No description provided for @leaveEndDate.
  ///
  /// In en, this message translates to:
  /// **'End date'**
  String get leaveEndDate;

  /// No description provided for @leaveStartPortion.
  ///
  /// In en, this message translates to:
  /// **'First day'**
  String get leaveStartPortion;

  /// No description provided for @leaveEndPortion.
  ///
  /// In en, this message translates to:
  /// **'Last day'**
  String get leaveEndPortion;

  /// No description provided for @leaveDayFull.
  ///
  /// In en, this message translates to:
  /// **'Full day'**
  String get leaveDayFull;

  /// No description provided for @leaveDayFirstHalf.
  ///
  /// In en, this message translates to:
  /// **'First half'**
  String get leaveDayFirstHalf;

  /// No description provided for @leaveDaySecondHalf.
  ///
  /// In en, this message translates to:
  /// **'Second half'**
  String get leaveDaySecondHalf;

  /// No description provided for @leaveReasonLabel.
  ///
  /// In en, this message translates to:
  /// **'Reason'**
  String get leaveReasonLabel;

  /// No description provided for @leaveAttachmentLabel.
  ///
  /// In en, this message translates to:
  /// **'Attachment'**
  String get leaveAttachmentLabel;

  /// No description provided for @leavePreviewTitle.
  ///
  /// In en, this message translates to:
  /// **'Summary'**
  String get leavePreviewTitle;

  /// No description provided for @leaveRequestedDays.
  ///
  /// In en, this message translates to:
  /// **'Requested days'**
  String get leaveRequestedDays;

  /// No description provided for @leaveAvailableDays.
  ///
  /// In en, this message translates to:
  /// **'Available'**
  String get leaveAvailableDays;

  /// No description provided for @leaveAfterApproval.
  ///
  /// In en, this message translates to:
  /// **'After approval'**
  String get leaveAfterApproval;

  /// No description provided for @leaveExcludedWeekends.
  ///
  /// In en, this message translates to:
  /// **'Weekends excluded'**
  String get leaveExcludedWeekends;

  /// No description provided for @leaveExcludedHolidays.
  ///
  /// In en, this message translates to:
  /// **'Holidays excluded'**
  String get leaveExcludedHolidays;

  /// No description provided for @leaveSubmitRequest.
  ///
  /// In en, this message translates to:
  /// **'Submit request'**
  String get leaveSubmitRequest;

  /// No description provided for @leaveNoTypes.
  ///
  /// In en, this message translates to:
  /// **'No leave types are available.'**
  String get leaveNoTypes;

  /// No description provided for @leaveSelectType.
  ///
  /// In en, this message translates to:
  /// **'Select leave type'**
  String get leaveSelectType;

  /// No description provided for @leaveStatusPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get leaveStatusPending;

  /// No description provided for @leaveStatusApproved.
  ///
  /// In en, this message translates to:
  /// **'Approved'**
  String get leaveStatusApproved;

  /// No description provided for @leaveStatusRejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected'**
  String get leaveStatusRejected;

  /// No description provided for @leaveStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get leaveStatusCancelled;

  /// No description provided for @leaveApprove.
  ///
  /// In en, this message translates to:
  /// **'Approve'**
  String get leaveApprove;

  /// No description provided for @leaveReject.
  ///
  /// In en, this message translates to:
  /// **'Reject'**
  String get leaveReject;

  /// No description provided for @leaveCancelRequest.
  ///
  /// In en, this message translates to:
  /// **'Cancel request'**
  String get leaveCancelRequest;

  /// No description provided for @leaveReviewNote.
  ///
  /// In en, this message translates to:
  /// **'Note'**
  String get leaveReviewNote;

  /// No description provided for @leaveCancelReason.
  ///
  /// In en, this message translates to:
  /// **'Cancellation reason'**
  String get leaveCancelReason;

  /// No description provided for @leaveEmployee.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get leaveEmployee;

  /// No description provided for @leaveDepartment.
  ///
  /// In en, this message translates to:
  /// **'Department'**
  String get leaveDepartment;

  /// No description provided for @leaveDateRange.
  ///
  /// In en, this message translates to:
  /// **'Dates'**
  String get leaveDateRange;

  /// No description provided for @leaveApprovedBy.
  ///
  /// In en, this message translates to:
  /// **'Reviewed by'**
  String get leaveApprovedBy;

  /// No description provided for @leaveSubmittedOn.
  ///
  /// In en, this message translates to:
  /// **'Submitted'**
  String get leaveSubmittedOn;

  /// No description provided for @leaveViewDetails.
  ///
  /// In en, this message translates to:
  /// **'View details'**
  String get leaveViewDetails;

  /// No description provided for @leaveApply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get leaveApply;

  /// No description provided for @leaveBalancesTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave balances'**
  String get leaveBalancesTitle;

  /// No description provided for @leaveEntitlement.
  ///
  /// In en, this message translates to:
  /// **'Entitlement'**
  String get leaveEntitlement;

  /// No description provided for @leaveUsed.
  ///
  /// In en, this message translates to:
  /// **'Used'**
  String get leaveUsed;

  /// No description provided for @leavePendingBalance.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get leavePendingBalance;

  /// No description provided for @leaveAvailable.
  ///
  /// In en, this message translates to:
  /// **'Available'**
  String get leaveAvailable;

  /// No description provided for @leaveAdjustBalance.
  ///
  /// In en, this message translates to:
  /// **'Adjust balance'**
  String get leaveAdjustBalance;

  /// No description provided for @leaveAdjustAdd.
  ///
  /// In en, this message translates to:
  /// **'Add days'**
  String get leaveAdjustAdd;

  /// No description provided for @leaveAdjustRemove.
  ///
  /// In en, this message translates to:
  /// **'Remove days'**
  String get leaveAdjustRemove;

  /// No description provided for @leaveAdjustQuantity.
  ///
  /// In en, this message translates to:
  /// **'Days'**
  String get leaveAdjustQuantity;

  /// No description provided for @leaveAdjustReason.
  ///
  /// In en, this message translates to:
  /// **'Reason'**
  String get leaveAdjustReason;

  /// No description provided for @leaveLedger.
  ///
  /// In en, this message translates to:
  /// **'Balance history'**
  String get leaveLedger;

  /// No description provided for @leaveNoBalance.
  ///
  /// In en, this message translates to:
  /// **'No balance records.'**
  String get leaveNoBalance;

  /// No description provided for @leaveSelectEmployee.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get leaveSelectEmployee;

  /// No description provided for @leaveEmployeeFilter.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get leaveEmployeeFilter;

  /// No description provided for @leaveCalendarTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave calendar'**
  String get leaveCalendarTitle;

  /// No description provided for @leaveCalendarLegendLeave.
  ///
  /// In en, this message translates to:
  /// **'Leave'**
  String get leaveCalendarLegendLeave;

  /// No description provided for @leaveCalendarLegendHoliday.
  ///
  /// In en, this message translates to:
  /// **'Holiday'**
  String get leaveCalendarLegendHoliday;

  /// No description provided for @leaveCalendarEmpty.
  ///
  /// In en, this message translates to:
  /// **'No leave or holidays in this period.'**
  String get leaveCalendarEmpty;

  /// No description provided for @leaveFrom.
  ///
  /// In en, this message translates to:
  /// **'From'**
  String get leaveFrom;

  /// No description provided for @leaveTo.
  ///
  /// In en, this message translates to:
  /// **'To'**
  String get leaveTo;

  /// No description provided for @leaveRequestsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No leave requests.'**
  String get leaveRequestsEmpty;

  /// No description provided for @leaveApprovalsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No requests are waiting for review.'**
  String get leaveApprovalsEmpty;

  /// No description provided for @leaveNoPendingRequests.
  ///
  /// In en, this message translates to:
  /// **'You have no pending leave requests.'**
  String get leaveNoPendingRequests;

  /// No description provided for @leaveOnLeaveToday.
  ///
  /// In en, this message translates to:
  /// **'On leave today'**
  String get leaveOnLeaveToday;

  /// No description provided for @workdayScheduled.
  ///
  /// In en, this message translates to:
  /// **'Scheduled'**
  String get workdayScheduled;

  /// No description provided for @workdayWorking.
  ///
  /// In en, this message translates to:
  /// **'Working'**
  String get workdayWorking;

  /// No description provided for @workdayOnBreak.
  ///
  /// In en, this message translates to:
  /// **'On break'**
  String get workdayOnBreak;

  /// No description provided for @workdayCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get workdayCompleted;

  /// No description provided for @workdayIncomplete.
  ///
  /// In en, this message translates to:
  /// **'Incomplete'**
  String get workdayIncomplete;

  /// No description provided for @workdayOnLeave.
  ///
  /// In en, this message translates to:
  /// **'On leave'**
  String get workdayOnLeave;

  /// No description provided for @workdayHoliday.
  ///
  /// In en, this message translates to:
  /// **'Holiday'**
  String get workdayHoliday;

  /// No description provided for @workdayNonWorking.
  ///
  /// In en, this message translates to:
  /// **'Non-working'**
  String get workdayNonWorking;

  /// No description provided for @workdayIssue.
  ///
  /// In en, this message translates to:
  /// **'Issue'**
  String get workdayIssue;

  /// No description provided for @leavePermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have access to leave.'**
  String get leavePermissionDenied;

  /// No description provided for @leaveStorageError.
  ///
  /// In en, this message translates to:
  /// **'Leave data could not be loaded.'**
  String get leaveStorageError;

  /// No description provided for @leaveUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Leave is not available.'**
  String get leaveUnavailable;

  /// No description provided for @leaveTypeInactive.
  ///
  /// In en, this message translates to:
  /// **'The selected leave type is not available.'**
  String get leaveTypeInactive;

  /// No description provided for @leaveNoEmployee.
  ///
  /// In en, this message translates to:
  /// **'Your account is not linked to an employee.'**
  String get leaveNoEmployee;

  /// No description provided for @leaveInvalidDateRange.
  ///
  /// In en, this message translates to:
  /// **'The end date must be after the start date.'**
  String get leaveInvalidDateRange;

  /// No description provided for @leaveReasonRequired.
  ///
  /// In en, this message translates to:
  /// **'A reason is required.'**
  String get leaveReasonRequired;

  /// No description provided for @leaveNoWorkingDays.
  ///
  /// In en, this message translates to:
  /// **'The selected range has no working days.'**
  String get leaveNoWorkingDays;

  /// No description provided for @leaveMinimumDays.
  ///
  /// In en, this message translates to:
  /// **'The request is shorter than the policy minimum.'**
  String get leaveMinimumDays;

  /// No description provided for @leaveOverlapping.
  ///
  /// In en, this message translates to:
  /// **'This request overlaps an existing request.'**
  String get leaveOverlapping;

  /// No description provided for @leaveInsufficientBalance.
  ///
  /// In en, this message translates to:
  /// **'There is not enough leave balance.'**
  String get leaveInsufficientBalance;

  /// No description provided for @leavePastRequestNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'Past-dated leave is not allowed.'**
  String get leavePastRequestNotAllowed;

  /// No description provided for @leaveAdvanceNoticeRequired.
  ///
  /// In en, this message translates to:
  /// **'This request does not meet the advance notice requirement.'**
  String get leaveAdvanceNoticeRequired;

  /// No description provided for @leaveInvalidQuantity.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid quantity.'**
  String get leaveInvalidQuantity;

  /// No description provided for @leaveRequestNotFound.
  ///
  /// In en, this message translates to:
  /// **'The leave request was not found.'**
  String get leaveRequestNotFound;

  /// No description provided for @leaveAlreadyReviewed.
  ///
  /// In en, this message translates to:
  /// **'This request has already been reviewed.'**
  String get leaveAlreadyReviewed;

  /// No description provided for @leaveCannotCancelApproved.
  ///
  /// In en, this message translates to:
  /// **'Approved leave can only be cancelled by a manager.'**
  String get leaveCannotCancelApproved;

  /// No description provided for @leaveReviewNoteRequired.
  ///
  /// In en, this message translates to:
  /// **'A note is required.'**
  String get leaveReviewNoteRequired;

  /// No description provided for @leaveSelfApprovalNotAllowed.
  ///
  /// In en, this message translates to:
  /// **'You cannot approve your own leave.'**
  String get leaveSelfApprovalNotAllowed;

  /// No description provided for @leaveSaved.
  ///
  /// In en, this message translates to:
  /// **'Leave saved.'**
  String get leaveSaved;

  /// No description provided for @leaveRequestSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Leave request submitted.'**
  String get leaveRequestSubmitted;

  /// No description provided for @leaveIncludeInactive.
  ///
  /// In en, this message translates to:
  /// **'Include inactive'**
  String get leaveIncludeInactive;

  /// No description provided for @leaveUpcoming.
  ///
  /// In en, this message translates to:
  /// **'Upcoming'**
  String get leaveUpcoming;

  /// No description provided for @leavePendingApproval.
  ///
  /// In en, this message translates to:
  /// **'Pending approval'**
  String get leavePendingApproval;

  /// No description provided for @leaveApprovedThisMonth.
  ///
  /// In en, this message translates to:
  /// **'Approved this month'**
  String get leaveApprovedThisMonth;

  /// No description provided for @leaveTeamMembers.
  ///
  /// In en, this message translates to:
  /// **'Team members'**
  String get leaveTeamMembers;

  /// No description provided for @leaveNoEmployeesOnLeave.
  ///
  /// In en, this message translates to:
  /// **'No employees are on leave today.'**
  String get leaveNoEmployeesOnLeave;

  /// No description provided for @leaveNoUpcoming.
  ///
  /// In en, this message translates to:
  /// **'No upcoming leave.'**
  String get leaveNoUpcoming;

  /// No description provided for @leaveHalfDay.
  ///
  /// In en, this message translates to:
  /// **'Half day'**
  String get leaveHalfDay;

  /// No description provided for @leaveFullDay.
  ///
  /// In en, this message translates to:
  /// **'Full day'**
  String get leaveFullDay;

  /// No description provided for @leaveReturnDate.
  ///
  /// In en, this message translates to:
  /// **'Return date'**
  String get leaveReturnDate;

  /// No description provided for @leaveStatusField.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get leaveStatusField;

  /// No description provided for @leaveReviewRequest.
  ///
  /// In en, this message translates to:
  /// **'Review request'**
  String get leaveReviewRequest;

  /// No description provided for @leaveCompanyLeave.
  ///
  /// In en, this message translates to:
  /// **'Company leave'**
  String get leaveCompanyLeave;

  /// No description provided for @leaveApprovalsTitle.
  ///
  /// In en, this message translates to:
  /// **'Leave approvals'**
  String get leaveApprovalsTitle;

  /// No description provided for @leaveApprovalsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Review employee leave requests that require your action.'**
  String get leaveApprovalsSubtitle;

  /// No description provided for @leaveTeamSubtitle.
  ///
  /// In en, this message translates to:
  /// **'View upcoming leave, team availability and leave requests.'**
  String get leaveTeamSubtitle;

  /// No description provided for @leaveAllSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Monitor company leave, availability and leave requests.'**
  String get leaveAllSubtitle;

  /// No description provided for @leaveOverviewSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Your leave, team availability and requests.'**
  String get leaveOverviewSubtitle;

  /// No description provided for @leavePendingRequests.
  ///
  /// In en, this message translates to:
  /// **'Pending requests'**
  String get leavePendingRequests;

  /// No description provided for @leaveStartingSoon.
  ///
  /// In en, this message translates to:
  /// **'Starting soon'**
  String get leaveStartingSoon;

  /// No description provided for @leaveTeamRequests.
  ///
  /// In en, this message translates to:
  /// **'Team requests'**
  String get leaveTeamRequests;

  /// No description provided for @leaveCompanyRequests.
  ///
  /// In en, this message translates to:
  /// **'Company requests'**
  String get leaveCompanyRequests;

  /// No description provided for @leaveAvailableBalance.
  ///
  /// In en, this message translates to:
  /// **'Available balance'**
  String get leaveAvailableBalance;

  /// No description provided for @leaveBalanceAfterApproval.
  ///
  /// In en, this message translates to:
  /// **'Balance after approval'**
  String get leaveBalanceAfterApproval;

  /// No description provided for @leaveViewEmployeeLeave.
  ///
  /// In en, this message translates to:
  /// **'View employee leave'**
  String get leaveViewEmployeeLeave;

  /// No description provided for @leaveEmployeeLeave.
  ///
  /// In en, this message translates to:
  /// **'Employee leave'**
  String get leaveEmployeeLeave;

  /// No description provided for @leaveNoPendingApprovals.
  ///
  /// In en, this message translates to:
  /// **'No requests need your approval.'**
  String get leaveNoPendingApprovals;

  /// No description provided for @leaveSearchEmployee.
  ///
  /// In en, this message translates to:
  /// **'Search employee'**
  String get leaveSearchEmployee;

  /// No description provided for @leavePeriodAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get leavePeriodAll;

  /// No description provided for @leavePeriodToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get leavePeriodToday;

  /// No description provided for @leavePeriodThisWeek.
  ///
  /// In en, this message translates to:
  /// **'This week'**
  String get leavePeriodThisWeek;

  /// No description provided for @leavePeriodThisMonth.
  ///
  /// In en, this message translates to:
  /// **'This month'**
  String get leavePeriodThisMonth;

  /// No description provided for @leavePeriodNext30.
  ///
  /// In en, this message translates to:
  /// **'Next 30 days'**
  String get leavePeriodNext30;

  /// No description provided for @leavePeriodCustom.
  ///
  /// In en, this message translates to:
  /// **'Custom'**
  String get leavePeriodCustom;

  /// No description provided for @leaveClearFilters.
  ///
  /// In en, this message translates to:
  /// **'Clear filters'**
  String get leaveClearFilters;

  /// No description provided for @leaveActiveFilters.
  ///
  /// In en, this message translates to:
  /// **'Active filters'**
  String get leaveActiveFilters;

  /// No description provided for @leaveManageSettings.
  ///
  /// In en, this message translates to:
  /// **'Manage leave settings'**
  String get leaveManageSettings;

  /// No description provided for @leaveViewAllLeave.
  ///
  /// In en, this message translates to:
  /// **'View all leave'**
  String get leaveViewAllLeave;

  /// No description provided for @leaveReviewQueue.
  ///
  /// In en, this message translates to:
  /// **'Review queue'**
  String get leaveReviewQueue;

  /// No description provided for @leaveNoBalanceForFilters.
  ///
  /// In en, this message translates to:
  /// **'No leave balance found for selected filters.'**
  String get leaveNoBalanceForFilters;

  /// No description provided for @leaveRequestSection.
  ///
  /// In en, this message translates to:
  /// **'Request'**
  String get leaveRequestSection;

  /// No description provided for @leaveEmployeeSection.
  ///
  /// In en, this message translates to:
  /// **'Employee'**
  String get leaveEmployeeSection;

  /// No description provided for @leaveBalanceSection.
  ///
  /// In en, this message translates to:
  /// **'Balance'**
  String get leaveBalanceSection;

  /// No description provided for @leaveDecisionSection.
  ///
  /// In en, this message translates to:
  /// **'Decision'**
  String get leaveDecisionSection;

  /// No description provided for @leaveWorkingDays.
  ///
  /// In en, this message translates to:
  /// **'Working leave days'**
  String get leaveWorkingDays;

  /// No description provided for @leavePortion.
  ///
  /// In en, this message translates to:
  /// **'Portion'**
  String get leavePortion;

  /// No description provided for @leaveStart.
  ///
  /// In en, this message translates to:
  /// **'Start'**
  String get leaveStart;

  /// No description provided for @leaveReturn.
  ///
  /// In en, this message translates to:
  /// **'Return'**
  String get leaveReturn;

  /// No description provided for @leaveOnLeave.
  ///
  /// In en, this message translates to:
  /// **'On leave'**
  String get leaveOnLeave;

  /// No description provided for @leaveUpcomingHoliday.
  ///
  /// In en, this message translates to:
  /// **'Upcoming holiday'**
  String get leaveUpcomingHoliday;

  /// No description provided for @leaveUpcomingTeamLeave.
  ///
  /// In en, this message translates to:
  /// **'Upcoming team leave'**
  String get leaveUpcomingTeamLeave;

  /// No description provided for @leavePendingApprovals.
  ///
  /// In en, this message translates to:
  /// **'Pending approvals'**
  String get leavePendingApprovals;

  /// No description provided for @leaveMyLeaveOverview.
  ///
  /// In en, this message translates to:
  /// **'My leave'**
  String get leaveMyLeaveOverview;

  /// No description provided for @leaveTeamOverview.
  ///
  /// In en, this message translates to:
  /// **'Team leave'**
  String get leaveTeamOverview;

  /// No description provided for @leaveCompanyOverview.
  ///
  /// In en, this message translates to:
  /// **'Company leave'**
  String get leaveCompanyOverview;

  /// No description provided for @leaveEmployeeUnavailable.
  ///
  /// In en, this message translates to:
  /// **'This employee\'s leave information is unavailable.'**
  String get leaveEmployeeUnavailable;

  /// No description provided for @leaveScopeDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have access to this leave scope.'**
  String get leaveScopeDenied;

  /// No description provided for @leaveRecentRequests.
  ///
  /// In en, this message translates to:
  /// **'Recent requests'**
  String get leaveRecentRequests;

  /// No description provided for @leaveBalanceLedger.
  ///
  /// In en, this message translates to:
  /// **'Balance history'**
  String get leaveBalanceLedger;

  /// No description provided for @leaveAdjustmentAdded.
  ///
  /// In en, this message translates to:
  /// **'Added to balance'**
  String get leaveAdjustmentAdded;

  /// No description provided for @leaveAdjustmentDeducted.
  ///
  /// In en, this message translates to:
  /// **'Deducted from balance'**
  String get leaveAdjustmentDeducted;

  /// No description provided for @leaveEffectiveDate.
  ///
  /// In en, this message translates to:
  /// **'Effective date'**
  String get leaveEffectiveDate;

  /// No description provided for @leaveCurrentAvailable.
  ///
  /// In en, this message translates to:
  /// **'Current available'**
  String get leaveCurrentAvailable;

  /// No description provided for @leavePreviewNewAvailable.
  ///
  /// In en, this message translates to:
  /// **'New available balance'**
  String get leavePreviewNewAvailable;

  /// No description provided for @leaveNoTeam.
  ///
  /// In en, this message translates to:
  /// **'No team is available for this account.'**
  String get leaveNoTeam;

  /// No description provided for @leaveApprovalsEmptyQueue.
  ///
  /// In en, this message translates to:
  /// **'You have no requests waiting for review.'**
  String get leaveApprovalsEmptyQueue;

  /// No description provided for @leaveRequestedPeriod.
  ///
  /// In en, this message translates to:
  /// **'Requested period'**
  String get leaveRequestedPeriod;

  /// No description provided for @holidayTypeFestival.
  ///
  /// In en, this message translates to:
  /// **'Festival holiday'**
  String get holidayTypeFestival;

  /// No description provided for @holidayTypeRegional.
  ///
  /// In en, this message translates to:
  /// **'Regional holiday'**
  String get holidayTypeRegional;

  /// No description provided for @holidaySourceManual.
  ///
  /// In en, this message translates to:
  /// **'Manual'**
  String get holidaySourceManual;

  /// No description provided for @holidaySourceCopied.
  ///
  /// In en, this message translates to:
  /// **'Copied from previous year'**
  String get holidaySourceCopied;

  /// No description provided for @holidaySourceImported.
  ///
  /// In en, this message translates to:
  /// **'Imported'**
  String get holidaySourceImported;

  /// No description provided for @holidaySourceTemplate.
  ///
  /// In en, this message translates to:
  /// **'Company template'**
  String get holidaySourceTemplate;

  /// No description provided for @holidayCalendarTitle.
  ///
  /// In en, this message translates to:
  /// **'Holiday calendar'**
  String get holidayCalendarTitle;

  /// No description provided for @holidayCalendarSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manage public, festival, regional and company holidays.'**
  String get holidayCalendarSubtitle;

  /// No description provided for @holidayYearLabel.
  ///
  /// In en, this message translates to:
  /// **'Holiday year'**
  String get holidayYearLabel;

  /// No description provided for @addHoliday.
  ///
  /// In en, this message translates to:
  /// **'Add holiday'**
  String get addHoliday;

  /// No description provided for @editHoliday.
  ///
  /// In en, this message translates to:
  /// **'Edit holiday'**
  String get editHoliday;

  /// No description provided for @manageHolidays.
  ///
  /// In en, this message translates to:
  /// **'Manage holidays'**
  String get manageHolidays;

  /// No description provided for @copyPreviousYear.
  ///
  /// In en, this message translates to:
  /// **'Copy previous year'**
  String get copyPreviousYear;

  /// No description provided for @importHolidays.
  ///
  /// In en, this message translates to:
  /// **'Import holidays'**
  String get importHolidays;

  /// No description provided for @setUpHolidayCalendar.
  ///
  /// In en, this message translates to:
  /// **'Set up holiday calendar'**
  String get setUpHolidayCalendar;

  /// No description provided for @startBlank.
  ///
  /// In en, this message translates to:
  /// **'Start blank'**
  String get startBlank;

  /// No description provided for @holidayCalendarStatus.
  ///
  /// In en, this message translates to:
  /// **'Holiday calendar status'**
  String get holidayCalendarStatus;

  /// No description provided for @activeHolidays.
  ///
  /// In en, this message translates to:
  /// **'Active holidays'**
  String get activeHolidays;

  /// No description provided for @nextHoliday.
  ///
  /// In en, this message translates to:
  /// **'Next holiday'**
  String get nextHoliday;

  /// No description provided for @holidayNotConfigured.
  ///
  /// In en, this message translates to:
  /// **'Not configured'**
  String get holidayNotConfigured;

  /// No description provided for @noHolidaysConfigured.
  ///
  /// In en, this message translates to:
  /// **'No holidays configured for this year.'**
  String get noHolidaysConfigured;

  /// No description provided for @holidayPublishedEmpty.
  ///
  /// In en, this message translates to:
  /// **'No company holidays have been published for this period.'**
  String get holidayPublishedEmpty;

  /// No description provided for @applyTo.
  ///
  /// In en, this message translates to:
  /// **'Applies to'**
  String get applyTo;

  /// No description provided for @holidayMultiDay.
  ///
  /// In en, this message translates to:
  /// **'Multi-day holiday'**
  String get holidayMultiDay;

  /// No description provided for @holidayBasicInfo.
  ///
  /// In en, this message translates to:
  /// **'Basic information'**
  String get holidayBasicInfo;

  /// No description provided for @holidayApplicability.
  ///
  /// In en, this message translates to:
  /// **'Applicability'**
  String get holidayApplicability;

  /// No description provided for @holidayOptionality.
  ///
  /// In en, this message translates to:
  /// **'Optionality'**
  String get holidayOptionality;

  /// No description provided for @holidaySourceField.
  ///
  /// In en, this message translates to:
  /// **'Source'**
  String get holidaySourceField;

  /// No description provided for @holidayDuplicateWarning.
  ///
  /// In en, this message translates to:
  /// **'A holiday with the same name, date and scope already exists.'**
  String get holidayDuplicateWarning;

  /// No description provided for @holidayImportPreview.
  ///
  /// In en, this message translates to:
  /// **'Import preview'**
  String get holidayImportPreview;

  /// No description provided for @holidayImportPaste.
  ///
  /// In en, this message translates to:
  /// **'Paste CSV'**
  String get holidayImportPaste;

  /// No description provided for @holidayImportHint.
  ///
  /// In en, this message translates to:
  /// **'Columns: name, date, endDate, type, optional, scope, workLocations, description'**
  String get holidayImportHint;

  /// No description provided for @holidayImportConfirm.
  ///
  /// In en, this message translates to:
  /// **'Import'**
  String get holidayImportConfirm;

  /// No description provided for @holidayImportImported.
  ///
  /// In en, this message translates to:
  /// **'Imported'**
  String get holidayImportImported;

  /// No description provided for @holidayImportSkipped.
  ///
  /// In en, this message translates to:
  /// **'Skipped'**
  String get holidayImportSkipped;

  /// No description provided for @holidayCopyNote.
  ///
  /// In en, this message translates to:
  /// **'Copied entries keep their month and day — verify festival dates before confirming.'**
  String get holidayCopyNote;

  /// No description provided for @verifyFestivalDates.
  ///
  /// In en, this message translates to:
  /// **'Copied from previous year — verify festival dates.'**
  String get verifyFestivalDates;

  /// No description provided for @holidaySelectLocations.
  ///
  /// In en, this message translates to:
  /// **'Select work locations'**
  String get holidaySelectLocations;

  /// No description provided for @holidaySearchLocations.
  ///
  /// In en, this message translates to:
  /// **'Search work locations'**
  String get holidaySearchLocations;

  /// No description provided for @holidayTypeHelperPublic.
  ///
  /// In en, this message translates to:
  /// **'Government/public holidays'**
  String get holidayTypeHelperPublic;

  /// No description provided for @holidayTypeHelperFestival.
  ///
  /// In en, this message translates to:
  /// **'Religious or festival holidays'**
  String get holidayTypeHelperFestival;

  /// No description provided for @holidayTypeHelperRegional.
  ///
  /// In en, this message translates to:
  /// **'State/regional holidays'**
  String get holidayTypeHelperRegional;

  /// No description provided for @holidayTypeHelperCompany.
  ///
  /// In en, this message translates to:
  /// **'Company-declared holidays'**
  String get holidayTypeHelperCompany;

  /// No description provided for @holidayTypeHelperClosure.
  ///
  /// In en, this message translates to:
  /// **'Special closures and shutdowns'**
  String get holidayTypeHelperClosure;

  /// No description provided for @nextHolidayDaysAway.
  ///
  /// In en, this message translates to:
  /// **'days away'**
  String get nextHolidayDaysAway;

  /// No description provided for @upcomingLeave.
  ///
  /// In en, this message translates to:
  /// **'Upcoming leave'**
  String get upcomingLeave;

  /// No description provided for @pendingRequest.
  ///
  /// In en, this message translates to:
  /// **'Pending request'**
  String get pendingRequest;

  /// No description provided for @teamCalendar.
  ///
  /// In en, this message translates to:
  /// **'Team calendar'**
  String get teamCalendar;

  /// No description provided for @reviewRequests.
  ///
  /// In en, this message translates to:
  /// **'Review requests'**
  String get reviewRequests;

  /// No description provided for @viewRequests.
  ///
  /// In en, this message translates to:
  /// **'Requests'**
  String get viewRequests;

  /// No description provided for @viewUpcoming.
  ///
  /// In en, this message translates to:
  /// **'Upcoming'**
  String get viewUpcoming;

  /// No description provided for @viewToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get viewToday;

  /// No description provided for @selectedDay.
  ///
  /// In en, this message translates to:
  /// **'Selected day'**
  String get selectedDay;

  /// No description provided for @dayAgenda.
  ///
  /// In en, this message translates to:
  /// **'Agenda'**
  String get dayAgenda;

  /// No description provided for @noEventsOnDay.
  ///
  /// In en, this message translates to:
  /// **'No leave or holidays on this day.'**
  String get noEventsOnDay;

  /// No description provided for @leaveAndHolidayCalendar.
  ///
  /// In en, this message translates to:
  /// **'Leave & holiday calendar'**
  String get leaveAndHolidayCalendar;

  /// No description provided for @leaveViewMode.
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get leaveViewMode;

  /// No description provided for @leaveBalanceAvailableLabel.
  ///
  /// In en, this message translates to:
  /// **'available'**
  String get leaveBalanceAvailableLabel;

  /// No description provided for @leaveBalanceUsedLabel.
  ///
  /// In en, this message translates to:
  /// **'used'**
  String get leaveBalanceUsedLabel;

  /// No description provided for @leaveBalancePendingLabel.
  ///
  /// In en, this message translates to:
  /// **'pending'**
  String get leaveBalancePendingLabel;

  /// No description provided for @leaveBalanceEntitlementLabel.
  ///
  /// In en, this message translates to:
  /// **'entitlement'**
  String get leaveBalanceEntitlementLabel;

  /// No description provided for @leaveHolidayThisYear.
  ///
  /// In en, this message translates to:
  /// **'Holidays this year'**
  String get leaveHolidayThisYear;

  /// No description provided for @leaveManageHolidaysHint.
  ///
  /// In en, this message translates to:
  /// **'Manage the company\'s annual public, festival and company holiday calendar.'**
  String get leaveManageHolidaysHint;

  /// No description provided for @leaveSearchOrFilter.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get leaveSearchOrFilter;

  /// No description provided for @leaveAllTypes.
  ///
  /// In en, this message translates to:
  /// **'All types'**
  String get leaveAllTypes;

  /// No description provided for @leaveAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get leaveAllStatuses;

  /// No description provided for @leaveAllPeriods.
  ///
  /// In en, this message translates to:
  /// **'All periods'**
  String get leaveAllPeriods;

  /// No description provided for @leaveDayOne.
  ///
  /// In en, this message translates to:
  /// **'day'**
  String get leaveDayOne;

  /// No description provided for @hrPermModuleHr.
  ///
  /// In en, this message translates to:
  /// **'Human resources'**
  String get hrPermModuleHr;

  /// No description provided for @hrPermSubEmployees.
  ///
  /// In en, this message translates to:
  /// **'Employees'**
  String get hrPermSubEmployees;

  /// No description provided for @hrPermSubAttendance.
  ///
  /// In en, this message translates to:
  /// **'Attendance'**
  String get hrPermSubAttendance;

  /// No description provided for @hrPermSubLeave.
  ///
  /// In en, this message translates to:
  /// **'Leave & holidays'**
  String get hrPermSubLeave;

  /// No description provided for @hrPermSubReports.
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get hrPermSubReports;

  /// No description provided for @hrPermSubConfiguration.
  ///
  /// In en, this message translates to:
  /// **'Configuration'**
  String get hrPermSubConfiguration;

  /// No description provided for @hrPermEmployeesView.
  ///
  /// In en, this message translates to:
  /// **'View employee records'**
  String get hrPermEmployeesView;

  /// No description provided for @hrPermEmployeesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See employee records within the selected scope.'**
  String get hrPermEmployeesViewDesc;

  /// No description provided for @hrPermEmployeesCreate.
  ///
  /// In en, this message translates to:
  /// **'Create employee'**
  String get hrPermEmployeesCreate;

  /// No description provided for @hrPermEmployeesCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Add new employees to the company.'**
  String get hrPermEmployeesCreateDesc;

  /// No description provided for @hrPermEmployeesEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit employee'**
  String get hrPermEmployeesEdit;

  /// No description provided for @hrPermEmployeesEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Update employee details and assignments.'**
  String get hrPermEmployeesEditDesc;

  /// No description provided for @hrPermEmployeesDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate employee'**
  String get hrPermEmployeesDeactivate;

  /// No description provided for @hrPermEmployeesDeactivateDesc.
  ///
  /// In en, this message translates to:
  /// **'Deactivate or reactivate employee records.'**
  String get hrPermEmployeesDeactivateDesc;

  /// No description provided for @hrPermAttendanceSelfView.
  ///
  /// In en, this message translates to:
  /// **'View my attendance'**
  String get hrPermAttendanceSelfView;

  /// No description provided for @hrPermAttendanceSelfViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View personal attendance and history.'**
  String get hrPermAttendanceSelfViewDesc;

  /// No description provided for @hrPermAttendanceSelfPunch.
  ///
  /// In en, this message translates to:
  /// **'Punch in'**
  String get hrPermAttendanceSelfPunch;

  /// No description provided for @hrPermAttendanceSelfPunchDesc.
  ///
  /// In en, this message translates to:
  /// **'Start the workday.'**
  String get hrPermAttendanceSelfPunchDesc;

  /// No description provided for @hrPermAttendanceSelfPunchOut.
  ///
  /// In en, this message translates to:
  /// **'Punch out'**
  String get hrPermAttendanceSelfPunchOut;

  /// No description provided for @hrPermAttendanceSelfPunchOutDesc.
  ///
  /// In en, this message translates to:
  /// **'End the workday.'**
  String get hrPermAttendanceSelfPunchOutDesc;

  /// No description provided for @hrPermAttendanceSelfBreak.
  ///
  /// In en, this message translates to:
  /// **'Take a break'**
  String get hrPermAttendanceSelfBreak;

  /// No description provided for @hrPermAttendanceSelfBreakDesc.
  ///
  /// In en, this message translates to:
  /// **'Start and end breaks.'**
  String get hrPermAttendanceSelfBreakDesc;

  /// No description provided for @hrPermAttendanceSelfCorrection.
  ///
  /// In en, this message translates to:
  /// **'Request attendance correction'**
  String get hrPermAttendanceSelfCorrection;

  /// No description provided for @hrPermAttendanceSelfCorrectionDesc.
  ///
  /// In en, this message translates to:
  /// **'Submit attendance correction requests.'**
  String get hrPermAttendanceSelfCorrectionDesc;

  /// No description provided for @hrPermAttendanceRecordsView.
  ///
  /// In en, this message translates to:
  /// **'View attendance records'**
  String get hrPermAttendanceRecordsView;

  /// No description provided for @hrPermAttendanceRecordsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See workforce attendance within the selected scope.'**
  String get hrPermAttendanceRecordsViewDesc;

  /// No description provided for @hrPermAttendanceCorrectionsReview.
  ///
  /// In en, this message translates to:
  /// **'Review attendance corrections'**
  String get hrPermAttendanceCorrectionsReview;

  /// No description provided for @hrPermAttendanceCorrectionsReviewDesc.
  ///
  /// In en, this message translates to:
  /// **'Approve or reject attendance correction requests.'**
  String get hrPermAttendanceCorrectionsReviewDesc;

  /// No description provided for @hrPermAttendanceCorrectionsApply.
  ///
  /// In en, this message translates to:
  /// **'Apply attendance corrections'**
  String get hrPermAttendanceCorrectionsApply;

  /// No description provided for @hrPermAttendanceCorrectionsApplyDesc.
  ///
  /// In en, this message translates to:
  /// **'Directly correct attendance records.'**
  String get hrPermAttendanceCorrectionsApplyDesc;

  /// No description provided for @hrPermAttendanceReportsView.
  ///
  /// In en, this message translates to:
  /// **'View attendance reports'**
  String get hrPermAttendanceReportsView;

  /// No description provided for @hrPermAttendanceReportsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See attendance reports and analytics.'**
  String get hrPermAttendanceReportsViewDesc;

  /// No description provided for @hrPermLeaveSelfView.
  ///
  /// In en, this message translates to:
  /// **'View my leave'**
  String get hrPermLeaveSelfView;

  /// No description provided for @hrPermLeaveSelfViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View personal leave requests.'**
  String get hrPermLeaveSelfViewDesc;

  /// No description provided for @hrPermLeaveSelfRequest.
  ///
  /// In en, this message translates to:
  /// **'Request leave'**
  String get hrPermLeaveSelfRequest;

  /// No description provided for @hrPermLeaveSelfRequestDesc.
  ///
  /// In en, this message translates to:
  /// **'Submit new leave requests.'**
  String get hrPermLeaveSelfRequestDesc;

  /// No description provided for @hrPermLeaveSelfCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel my leave'**
  String get hrPermLeaveSelfCancel;

  /// No description provided for @hrPermLeaveSelfCancelDesc.
  ///
  /// In en, this message translates to:
  /// **'Cancel personal pending leave requests.'**
  String get hrPermLeaveSelfCancelDesc;

  /// No description provided for @hrPermLeaveSelfBalance.
  ///
  /// In en, this message translates to:
  /// **'View my balance'**
  String get hrPermLeaveSelfBalance;

  /// No description provided for @hrPermLeaveSelfBalanceDesc.
  ///
  /// In en, this message translates to:
  /// **'View personal leave balances.'**
  String get hrPermLeaveSelfBalanceDesc;

  /// No description provided for @hrPermLeaveRecordsView.
  ///
  /// In en, this message translates to:
  /// **'View leave records'**
  String get hrPermLeaveRecordsView;

  /// No description provided for @hrPermLeaveRecordsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See leave records within the selected scope.'**
  String get hrPermLeaveRecordsViewDesc;

  /// No description provided for @hrPermLeaveRequestsReview.
  ///
  /// In en, this message translates to:
  /// **'Review leave requests'**
  String get hrPermLeaveRequestsReview;

  /// No description provided for @hrPermLeaveRequestsReviewDesc.
  ///
  /// In en, this message translates to:
  /// **'Approve or reject leave requests within the selected scope.'**
  String get hrPermLeaveRequestsReviewDesc;

  /// No description provided for @hrPermLeaveBalancesView.
  ///
  /// In en, this message translates to:
  /// **'View leave balances'**
  String get hrPermLeaveBalancesView;

  /// No description provided for @hrPermLeaveBalancesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See leave balances within the selected scope.'**
  String get hrPermLeaveBalancesViewDesc;

  /// No description provided for @hrPermLeaveBalancesAdjust.
  ///
  /// In en, this message translates to:
  /// **'Adjust leave balances'**
  String get hrPermLeaveBalancesAdjust;

  /// No description provided for @hrPermLeaveBalancesAdjustDesc.
  ///
  /// In en, this message translates to:
  /// **'Add or deduct leave balance for employees.'**
  String get hrPermLeaveBalancesAdjustDesc;

  /// No description provided for @hrPermLeaveSettingsManage.
  ///
  /// In en, this message translates to:
  /// **'Manage leave settings'**
  String get hrPermLeaveSettingsManage;

  /// No description provided for @hrPermLeaveSettingsManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Manage leave configuration overall.'**
  String get hrPermLeaveSettingsManageDesc;

  /// No description provided for @hrPermLeaveTypesView.
  ///
  /// In en, this message translates to:
  /// **'View leave types'**
  String get hrPermLeaveTypesView;

  /// No description provided for @hrPermLeaveTypesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See leave types.'**
  String get hrPermLeaveTypesViewDesc;

  /// No description provided for @hrPermLeaveTypesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage leave types'**
  String get hrPermLeaveTypesManage;

  /// No description provided for @hrPermLeaveTypesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit leave types.'**
  String get hrPermLeaveTypesManageDesc;

  /// No description provided for @hrPermLeavePoliciesView.
  ///
  /// In en, this message translates to:
  /// **'View leave policies'**
  String get hrPermLeavePoliciesView;

  /// No description provided for @hrPermLeavePoliciesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See leave policies.'**
  String get hrPermLeavePoliciesViewDesc;

  /// No description provided for @hrPermLeavePoliciesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage leave policies'**
  String get hrPermLeavePoliciesManage;

  /// No description provided for @hrPermLeavePoliciesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit leave policies.'**
  String get hrPermLeavePoliciesManageDesc;

  /// No description provided for @hrPermHolidaysView.
  ///
  /// In en, this message translates to:
  /// **'View holidays'**
  String get hrPermHolidaysView;

  /// No description provided for @hrPermHolidaysViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See the holiday calendar.'**
  String get hrPermHolidaysViewDesc;

  /// No description provided for @hrPermHolidaysManage.
  ///
  /// In en, this message translates to:
  /// **'Manage holidays'**
  String get hrPermHolidaysManage;

  /// No description provided for @hrPermHolidaysManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Configure holidays and calendars.'**
  String get hrPermHolidaysManageDesc;

  /// No description provided for @hrPermReportsLeaveView.
  ///
  /// In en, this message translates to:
  /// **'View leave reports'**
  String get hrPermReportsLeaveView;

  /// No description provided for @hrPermReportsLeaveViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See leave reports and analytics.'**
  String get hrPermReportsLeaveViewDesc;

  /// No description provided for @hrPermShiftsView.
  ///
  /// In en, this message translates to:
  /// **'View shifts'**
  String get hrPermShiftsView;

  /// No description provided for @hrPermShiftsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See shift configuration.'**
  String get hrPermShiftsViewDesc;

  /// No description provided for @hrPermShiftsManage.
  ///
  /// In en, this message translates to:
  /// **'Manage shifts'**
  String get hrPermShiftsManage;

  /// No description provided for @hrPermShiftsManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit shifts.'**
  String get hrPermShiftsManageDesc;

  /// No description provided for @hrPermLocationsView.
  ///
  /// In en, this message translates to:
  /// **'View work locations'**
  String get hrPermLocationsView;

  /// No description provided for @hrPermLocationsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See work location configuration.'**
  String get hrPermLocationsViewDesc;

  /// No description provided for @hrPermLocationsManage.
  ///
  /// In en, this message translates to:
  /// **'Manage work locations'**
  String get hrPermLocationsManage;

  /// No description provided for @hrPermLocationsManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit work locations.'**
  String get hrPermLocationsManageDesc;

  /// No description provided for @hrPermPoliciesView.
  ///
  /// In en, this message translates to:
  /// **'View attendance policies'**
  String get hrPermPoliciesView;

  /// No description provided for @hrPermPoliciesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See attendance policy configuration.'**
  String get hrPermPoliciesViewDesc;

  /// No description provided for @hrPermPoliciesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage attendance policies'**
  String get hrPermPoliciesManage;

  /// No description provided for @hrPermPoliciesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit attendance policies.'**
  String get hrPermPoliciesManageDesc;

  /// No description provided for @servicesPermModuleServices.
  ///
  /// In en, this message translates to:
  /// **'Services'**
  String get servicesPermModuleServices;

  /// No description provided for @servicesPermSubCustomers.
  ///
  /// In en, this message translates to:
  /// **'Customers'**
  String get servicesPermSubCustomers;

  /// No description provided for @servicesPermSubSites.
  ///
  /// In en, this message translates to:
  /// **'Service sites'**
  String get servicesPermSubSites;

  /// No description provided for @servicesPermSubTeams.
  ///
  /// In en, this message translates to:
  /// **'Service teams'**
  String get servicesPermSubTeams;

  /// No description provided for @servicesPermSubConfiguration.
  ///
  /// In en, this message translates to:
  /// **'Configuration'**
  String get servicesPermSubConfiguration;

  /// No description provided for @servicesPermCustomersView.
  ///
  /// In en, this message translates to:
  /// **'View customers'**
  String get servicesPermCustomersView;

  /// No description provided for @servicesPermCustomersViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See the service customer directory.'**
  String get servicesPermCustomersViewDesc;

  /// No description provided for @servicesPermCustomersCreate.
  ///
  /// In en, this message translates to:
  /// **'Create customer'**
  String get servicesPermCustomersCreate;

  /// No description provided for @servicesPermCustomersCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Add new service customers.'**
  String get servicesPermCustomersCreateDesc;

  /// No description provided for @servicesPermCustomersEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit customer'**
  String get servicesPermCustomersEdit;

  /// No description provided for @servicesPermCustomersEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Update customer details.'**
  String get servicesPermCustomersEditDesc;

  /// No description provided for @servicesPermCustomersDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate customer'**
  String get servicesPermCustomersDeactivate;

  /// No description provided for @servicesPermCustomersDeactivateDesc.
  ///
  /// In en, this message translates to:
  /// **'Deactivate or reactivate customers.'**
  String get servicesPermCustomersDeactivateDesc;

  /// No description provided for @servicesPermSitesView.
  ///
  /// In en, this message translates to:
  /// **'View service sites'**
  String get servicesPermSitesView;

  /// No description provided for @servicesPermSitesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See service sites.'**
  String get servicesPermSitesViewDesc;

  /// No description provided for @servicesPermSitesCreate.
  ///
  /// In en, this message translates to:
  /// **'Create site'**
  String get servicesPermSitesCreate;

  /// No description provided for @servicesPermSitesCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Add service sites to customers.'**
  String get servicesPermSitesCreateDesc;

  /// No description provided for @servicesPermSitesEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit site'**
  String get servicesPermSitesEdit;

  /// No description provided for @servicesPermSitesEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Update site details.'**
  String get servicesPermSitesEditDesc;

  /// No description provided for @servicesPermSitesDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate site'**
  String get servicesPermSitesDeactivate;

  /// No description provided for @servicesPermSitesDeactivateDesc.
  ///
  /// In en, this message translates to:
  /// **'Deactivate or reactivate sites.'**
  String get servicesPermSitesDeactivateDesc;

  /// No description provided for @servicesPermTeamsView.
  ///
  /// In en, this message translates to:
  /// **'View service teams'**
  String get servicesPermTeamsView;

  /// No description provided for @servicesPermTeamsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See service teams and membership.'**
  String get servicesPermTeamsViewDesc;

  /// No description provided for @servicesPermTeamsManage.
  ///
  /// In en, this message translates to:
  /// **'Manage service teams'**
  String get servicesPermTeamsManage;

  /// No description provided for @servicesPermTeamsManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create teams and manage membership.'**
  String get servicesPermTeamsManageDesc;

  /// No description provided for @servicesPermServiceTypesView.
  ///
  /// In en, this message translates to:
  /// **'View service types'**
  String get servicesPermServiceTypesView;

  /// No description provided for @servicesPermServiceTypesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See configured service types.'**
  String get servicesPermServiceTypesViewDesc;

  /// No description provided for @servicesPermServiceTypesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage service types'**
  String get servicesPermServiceTypesManage;

  /// No description provided for @servicesPermServiceTypesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit service types.'**
  String get servicesPermServiceTypesManageDesc;

  /// No description provided for @servicesPermComplaintTypesView.
  ///
  /// In en, this message translates to:
  /// **'View complaint types'**
  String get servicesPermComplaintTypesView;

  /// No description provided for @servicesPermComplaintTypesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See configured complaint types.'**
  String get servicesPermComplaintTypesViewDesc;

  /// No description provided for @servicesPermComplaintTypesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage complaint types'**
  String get servicesPermComplaintTypesManage;

  /// No description provided for @servicesPermComplaintTypesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit complaint types.'**
  String get servicesPermComplaintTypesManageDesc;

  /// No description provided for @servicesPermPrioritiesView.
  ///
  /// In en, this message translates to:
  /// **'View priorities'**
  String get servicesPermPrioritiesView;

  /// No description provided for @servicesPermPrioritiesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See configured service priorities.'**
  String get servicesPermPrioritiesViewDesc;

  /// No description provided for @servicesPermPrioritiesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage priorities'**
  String get servicesPermPrioritiesManage;

  /// No description provided for @servicesPermPrioritiesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit service priorities.'**
  String get servicesPermPrioritiesManageDesc;

  /// No description provided for @servicesPermTicketTypesView.
  ///
  /// In en, this message translates to:
  /// **'View ticket types'**
  String get servicesPermTicketTypesView;

  /// No description provided for @servicesPermTicketTypesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See configured ticket types.'**
  String get servicesPermTicketTypesViewDesc;

  /// No description provided for @servicesPermTicketTypesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage ticket types'**
  String get servicesPermTicketTypesManage;

  /// No description provided for @servicesPermTicketTypesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit ticket types.'**
  String get servicesPermTicketTypesManageDesc;

  /// No description provided for @permissionServiceCustomerView.
  ///
  /// In en, this message translates to:
  /// **'View customers'**
  String get permissionServiceCustomerView;

  /// No description provided for @permissionServiceCustomerCreate.
  ///
  /// In en, this message translates to:
  /// **'Create customer'**
  String get permissionServiceCustomerCreate;

  /// No description provided for @permissionServiceCustomerEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit customer'**
  String get permissionServiceCustomerEdit;

  /// No description provided for @permissionServiceCustomerDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate customer'**
  String get permissionServiceCustomerDeactivate;

  /// No description provided for @permissionServiceSiteView.
  ///
  /// In en, this message translates to:
  /// **'View service sites'**
  String get permissionServiceSiteView;

  /// No description provided for @permissionServiceSiteCreate.
  ///
  /// In en, this message translates to:
  /// **'Create site'**
  String get permissionServiceSiteCreate;

  /// No description provided for @permissionServiceSiteEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit site'**
  String get permissionServiceSiteEdit;

  /// No description provided for @permissionServiceSiteDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate site'**
  String get permissionServiceSiteDeactivate;

  /// No description provided for @permissionServiceTeamView.
  ///
  /// In en, this message translates to:
  /// **'View service teams'**
  String get permissionServiceTeamView;

  /// No description provided for @permissionServiceTeamManage.
  ///
  /// In en, this message translates to:
  /// **'Manage service teams'**
  String get permissionServiceTeamManage;

  /// No description provided for @permissionServiceTypeView.
  ///
  /// In en, this message translates to:
  /// **'View service types'**
  String get permissionServiceTypeView;

  /// No description provided for @permissionServiceTypeManage.
  ///
  /// In en, this message translates to:
  /// **'Manage service types'**
  String get permissionServiceTypeManage;

  /// No description provided for @permissionComplaintTypeView.
  ///
  /// In en, this message translates to:
  /// **'View complaint types'**
  String get permissionComplaintTypeView;

  /// No description provided for @permissionComplaintTypeManage.
  ///
  /// In en, this message translates to:
  /// **'Manage complaint types'**
  String get permissionComplaintTypeManage;

  /// No description provided for @permissionServicePriorityView.
  ///
  /// In en, this message translates to:
  /// **'View priorities'**
  String get permissionServicePriorityView;

  /// No description provided for @permissionServicePriorityManage.
  ///
  /// In en, this message translates to:
  /// **'Manage priorities'**
  String get permissionServicePriorityManage;

  /// No description provided for @permissionServiceTicketTypeView.
  ///
  /// In en, this message translates to:
  /// **'View ticket types'**
  String get permissionServiceTicketTypeView;

  /// No description provided for @permissionServiceTicketTypeManage.
  ///
  /// In en, this message translates to:
  /// **'Manage ticket types'**
  String get permissionServiceTicketTypeManage;

  /// No description provided for @servicesNavOverview.
  ///
  /// In en, this message translates to:
  /// **'Overview'**
  String get servicesNavOverview;

  /// No description provided for @servicesNavCustomers.
  ///
  /// In en, this message translates to:
  /// **'Customers'**
  String get servicesNavCustomers;

  /// No description provided for @servicesNavSites.
  ///
  /// In en, this message translates to:
  /// **'Sites'**
  String get servicesNavSites;

  /// No description provided for @servicesNavTeams.
  ///
  /// In en, this message translates to:
  /// **'Teams'**
  String get servicesNavTeams;

  /// No description provided for @servicesNavSettings.
  ///
  /// In en, this message translates to:
  /// **'Services settings'**
  String get servicesNavSettings;

  /// No description provided for @servicesOverviewSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manage your service directory, teams and operational configuration.'**
  String get servicesOverviewSubtitle;

  /// No description provided for @servicesSummaryCustomers.
  ///
  /// In en, this message translates to:
  /// **'Customers'**
  String get servicesSummaryCustomers;

  /// No description provided for @servicesSummarySites.
  ///
  /// In en, this message translates to:
  /// **'Active sites'**
  String get servicesSummarySites;

  /// No description provided for @servicesSummaryTeams.
  ///
  /// In en, this message translates to:
  /// **'Service teams'**
  String get servicesSummaryTeams;

  /// No description provided for @servicesSetupTitle.
  ///
  /// In en, this message translates to:
  /// **'Setup'**
  String get servicesSetupTitle;

  /// No description provided for @servicesSetupServiceTypes.
  ///
  /// In en, this message translates to:
  /// **'Service types'**
  String get servicesSetupServiceTypes;

  /// No description provided for @servicesSetupPriorities.
  ///
  /// In en, this message translates to:
  /// **'Priorities'**
  String get servicesSetupPriorities;

  /// No description provided for @servicesSetupReady.
  ///
  /// In en, this message translates to:
  /// **'Configured'**
  String get servicesSetupReady;

  /// No description provided for @servicesSetupMissing.
  ///
  /// In en, this message translates to:
  /// **'Not configured'**
  String get servicesSetupMissing;

  /// No description provided for @servicesDirectoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Customer directory'**
  String get servicesDirectoryTitle;

  /// No description provided for @servicesRecentCustomers.
  ///
  /// In en, this message translates to:
  /// **'Recent customers'**
  String get servicesRecentCustomers;

  /// No description provided for @servicesNoCustomersYet.
  ///
  /// In en, this message translates to:
  /// **'No customers yet'**
  String get servicesNoCustomersYet;

  /// No description provided for @servicesCustomersTitle.
  ///
  /// In en, this message translates to:
  /// **'Customers'**
  String get servicesCustomersTitle;

  /// No description provided for @servicesCustomerAdd.
  ///
  /// In en, this message translates to:
  /// **'Add customer'**
  String get servicesCustomerAdd;

  /// No description provided for @servicesCustomerEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit customer'**
  String get servicesCustomerEdit;

  /// No description provided for @servicesCustomerCode.
  ///
  /// In en, this message translates to:
  /// **'Code'**
  String get servicesCustomerCode;

  /// No description provided for @servicesCustomerName.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get servicesCustomerName;

  /// No description provided for @servicesCustomerKind.
  ///
  /// In en, this message translates to:
  /// **'Type'**
  String get servicesCustomerKind;

  /// No description provided for @servicesCustomerKindIndividual.
  ///
  /// In en, this message translates to:
  /// **'Individual'**
  String get servicesCustomerKindIndividual;

  /// No description provided for @servicesCustomerKindOrganization.
  ///
  /// In en, this message translates to:
  /// **'Organization'**
  String get servicesCustomerKindOrganization;

  /// No description provided for @servicesCustomerMobile.
  ///
  /// In en, this message translates to:
  /// **'Mobile'**
  String get servicesCustomerMobile;

  /// No description provided for @servicesCustomerAlternateMobile.
  ///
  /// In en, this message translates to:
  /// **'Alternate mobile'**
  String get servicesCustomerAlternateMobile;

  /// No description provided for @servicesCustomerEmail.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get servicesCustomerEmail;

  /// No description provided for @servicesCustomerNotes.
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get servicesCustomerNotes;

  /// No description provided for @servicesCustomerSites.
  ///
  /// In en, this message translates to:
  /// **'Sites'**
  String get servicesCustomerSites;

  /// No description provided for @servicesCustomerContact.
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get servicesCustomerContact;

  /// No description provided for @servicesCustomerLastUpdated.
  ///
  /// In en, this message translates to:
  /// **'Last updated'**
  String get servicesCustomerLastUpdated;

  /// No description provided for @servicesCustomerSaved.
  ///
  /// In en, this message translates to:
  /// **'Customer saved.'**
  String get servicesCustomerSaved;

  /// No description provided for @servicesCustomerStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the customer.'**
  String get servicesCustomerStorageError;

  /// No description provided for @servicesCustomerNotFound.
  ///
  /// In en, this message translates to:
  /// **'Customer not found.'**
  String get servicesCustomerNotFound;

  /// No description provided for @servicesCustomerEmpty.
  ///
  /// In en, this message translates to:
  /// **'No customers yet'**
  String get servicesCustomerEmpty;

  /// No description provided for @servicesCustomerEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Add your first customer to get started.'**
  String get servicesCustomerEmptyMessage;

  /// No description provided for @servicesCustomerNoResults.
  ///
  /// In en, this message translates to:
  /// **'No customers match your search.'**
  String get servicesCustomerNoResults;

  /// No description provided for @servicesCustomerRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required.'**
  String get servicesCustomerRequired;

  /// No description provided for @servicesCustomerInvalidMobile.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid mobile number.'**
  String get servicesCustomerInvalidMobile;

  /// No description provided for @servicesCustomerInvalidEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid email.'**
  String get servicesCustomerInvalidEmail;

  /// No description provided for @servicesCustomerDuplicateMobile.
  ///
  /// In en, this message translates to:
  /// **'A customer with this mobile already exists.'**
  String get servicesCustomerDuplicateMobile;

  /// No description provided for @servicesCustomerDuplicateEmail.
  ///
  /// In en, this message translates to:
  /// **'A customer with this email already exists.'**
  String get servicesCustomerDuplicateEmail;

  /// No description provided for @servicesCustomerDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate'**
  String get servicesCustomerDeactivate;

  /// No description provided for @servicesCustomerActivate.
  ///
  /// In en, this message translates to:
  /// **'Activate'**
  String get servicesCustomerActivate;

  /// No description provided for @servicesCustomerSearch.
  ///
  /// In en, this message translates to:
  /// **'Search customers'**
  String get servicesCustomerSearch;

  /// No description provided for @servicesCustomerAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get servicesCustomerAllStatuses;

  /// No description provided for @servicesCustomerActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesCustomerActivity;

  /// No description provided for @servicesCustomerNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity yet.'**
  String get servicesCustomerNoActivity;

  /// No description provided for @servicesCustomerSelect.
  ///
  /// In en, this message translates to:
  /// **'Select customer'**
  String get servicesCustomerSelect;

  /// No description provided for @servicesCustomerStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesCustomerStatus;

  /// No description provided for @servicesCustomerDiscardMessage.
  ///
  /// In en, this message translates to:
  /// **'You have unsaved changes.'**
  String get servicesCustomerDiscardMessage;

  /// No description provided for @servicesCustomerDiscardAction.
  ///
  /// In en, this message translates to:
  /// **'Discard'**
  String get servicesCustomerDiscardAction;

  /// No description provided for @servicesSitesTitle.
  ///
  /// In en, this message translates to:
  /// **'Service sites'**
  String get servicesSitesTitle;

  /// No description provided for @servicesSiteAdd.
  ///
  /// In en, this message translates to:
  /// **'Add site'**
  String get servicesSiteAdd;

  /// No description provided for @servicesSiteEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit site'**
  String get servicesSiteEdit;

  /// No description provided for @servicesSiteCode.
  ///
  /// In en, this message translates to:
  /// **'Code'**
  String get servicesSiteCode;

  /// No description provided for @servicesSiteName.
  ///
  /// In en, this message translates to:
  /// **'Site name'**
  String get servicesSiteName;

  /// No description provided for @servicesSiteCustomer.
  ///
  /// In en, this message translates to:
  /// **'Customer'**
  String get servicesSiteCustomer;

  /// No description provided for @servicesSiteTenant.
  ///
  /// In en, this message translates to:
  /// **'Tenant'**
  String get servicesSiteTenant;

  /// No description provided for @servicesSiteBuilding.
  ///
  /// In en, this message translates to:
  /// **'Building'**
  String get servicesSiteBuilding;

  /// No description provided for @servicesSiteUnit.
  ///
  /// In en, this message translates to:
  /// **'Unit'**
  String get servicesSiteUnit;

  /// No description provided for @servicesSiteContactName.
  ///
  /// In en, this message translates to:
  /// **'Contact name'**
  String get servicesSiteContactName;

  /// No description provided for @servicesSiteContactMobile.
  ///
  /// In en, this message translates to:
  /// **'Contact mobile'**
  String get servicesSiteContactMobile;

  /// No description provided for @servicesSiteContactEmail.
  ///
  /// In en, this message translates to:
  /// **'Contact email'**
  String get servicesSiteContactEmail;

  /// No description provided for @servicesSiteAddress1.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get servicesSiteAddress1;

  /// No description provided for @servicesSiteAddress2.
  ///
  /// In en, this message translates to:
  /// **'Address line 2'**
  String get servicesSiteAddress2;

  /// No description provided for @servicesSiteArea.
  ///
  /// In en, this message translates to:
  /// **'Area'**
  String get servicesSiteArea;

  /// No description provided for @servicesSiteCity.
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get servicesSiteCity;

  /// No description provided for @servicesSiteState.
  ///
  /// In en, this message translates to:
  /// **'State/region'**
  String get servicesSiteState;

  /// No description provided for @servicesSitePostalCode.
  ///
  /// In en, this message translates to:
  /// **'Postal code'**
  String get servicesSitePostalCode;

  /// No description provided for @servicesSiteCountry.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get servicesSiteCountry;

  /// No description provided for @servicesSiteLatitude.
  ///
  /// In en, this message translates to:
  /// **'Latitude'**
  String get servicesSiteLatitude;

  /// No description provided for @servicesSiteLongitude.
  ///
  /// In en, this message translates to:
  /// **'Longitude'**
  String get servicesSiteLongitude;

  /// No description provided for @servicesSiteNotes.
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get servicesSiteNotes;

  /// No description provided for @servicesSiteBuildingUnit.
  ///
  /// In en, this message translates to:
  /// **'Building / unit'**
  String get servicesSiteBuildingUnit;

  /// No description provided for @servicesSiteSaved.
  ///
  /// In en, this message translates to:
  /// **'Site saved.'**
  String get servicesSiteSaved;

  /// No description provided for @servicesSiteStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the site.'**
  String get servicesSiteStorageError;

  /// No description provided for @servicesSiteNotFound.
  ///
  /// In en, this message translates to:
  /// **'Site not found.'**
  String get servicesSiteNotFound;

  /// No description provided for @servicesSiteEmpty.
  ///
  /// In en, this message translates to:
  /// **'No sites yet'**
  String get servicesSiteEmpty;

  /// No description provided for @servicesSiteEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Add a site to a customer to schedule work.'**
  String get servicesSiteEmptyMessage;

  /// No description provided for @servicesSiteNoResults.
  ///
  /// In en, this message translates to:
  /// **'No sites match your search.'**
  String get servicesSiteNoResults;

  /// No description provided for @servicesSiteRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required.'**
  String get servicesSiteRequired;

  /// No description provided for @servicesSiteDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate'**
  String get servicesSiteDeactivate;

  /// No description provided for @servicesSiteActivate.
  ///
  /// In en, this message translates to:
  /// **'Activate'**
  String get servicesSiteActivate;

  /// No description provided for @servicesSiteSearch.
  ///
  /// In en, this message translates to:
  /// **'Search sites'**
  String get servicesSiteSearch;

  /// No description provided for @servicesSiteDetails.
  ///
  /// In en, this message translates to:
  /// **'Site'**
  String get servicesSiteDetails;

  /// No description provided for @servicesSiteActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesSiteActivity;

  /// No description provided for @servicesSiteLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get servicesSiteLocation;

  /// No description provided for @servicesSiteIdentity.
  ///
  /// In en, this message translates to:
  /// **'Site identity'**
  String get servicesSiteIdentity;

  /// No description provided for @servicesSiteAddress.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get servicesSiteAddress;

  /// No description provided for @servicesSiteContact.
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get servicesSiteContact;

  /// No description provided for @servicesSiteCustomerRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a customer.'**
  String get servicesSiteCustomerRequired;

  /// No description provided for @servicesSiteSelectCustomer.
  ///
  /// In en, this message translates to:
  /// **'Select customer'**
  String get servicesSiteSelectCustomer;

  /// No description provided for @servicesTeamsTitle.
  ///
  /// In en, this message translates to:
  /// **'Service teams'**
  String get servicesTeamsTitle;

  /// No description provided for @servicesTeamAdd.
  ///
  /// In en, this message translates to:
  /// **'Add team'**
  String get servicesTeamAdd;

  /// No description provided for @servicesTeamEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit team'**
  String get servicesTeamEdit;

  /// No description provided for @servicesTeamCode.
  ///
  /// In en, this message translates to:
  /// **'Code'**
  String get servicesTeamCode;

  /// No description provided for @servicesTeamName.
  ///
  /// In en, this message translates to:
  /// **'Team name'**
  String get servicesTeamName;

  /// No description provided for @servicesTeamDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesTeamDescription;

  /// No description provided for @servicesTeamLead.
  ///
  /// In en, this message translates to:
  /// **'Team lead'**
  String get servicesTeamLead;

  /// No description provided for @servicesTeamMembers.
  ///
  /// In en, this message translates to:
  /// **'Members'**
  String get servicesTeamMembers;

  /// No description provided for @servicesTeamMemberAdd.
  ///
  /// In en, this message translates to:
  /// **'Add member'**
  String get servicesTeamMemberAdd;

  /// No description provided for @servicesTeamMemberSearch.
  ///
  /// In en, this message translates to:
  /// **'Search employees'**
  String get servicesTeamMemberSearch;

  /// No description provided for @servicesTeamNoMembers.
  ///
  /// In en, this message translates to:
  /// **'No members yet'**
  String get servicesTeamNoMembers;

  /// No description provided for @servicesTeamSaved.
  ///
  /// In en, this message translates to:
  /// **'Team saved.'**
  String get servicesTeamSaved;

  /// No description provided for @servicesTeamStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the team.'**
  String get servicesTeamStorageError;

  /// No description provided for @servicesTeamNotFound.
  ///
  /// In en, this message translates to:
  /// **'Team not found.'**
  String get servicesTeamNotFound;

  /// No description provided for @servicesTeamEmpty.
  ///
  /// In en, this message translates to:
  /// **'No teams yet'**
  String get servicesTeamEmpty;

  /// No description provided for @servicesTeamEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Create a team to group employees for service work.'**
  String get servicesTeamEmptyMessage;

  /// No description provided for @servicesTeamNoResults.
  ///
  /// In en, this message translates to:
  /// **'No teams match your search.'**
  String get servicesTeamNoResults;

  /// No description provided for @servicesTeamRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required.'**
  String get servicesTeamRequired;

  /// No description provided for @servicesTeamDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate'**
  String get servicesTeamDeactivate;

  /// No description provided for @servicesTeamActivate.
  ///
  /// In en, this message translates to:
  /// **'Activate'**
  String get servicesTeamActivate;

  /// No description provided for @servicesTeamSearch.
  ///
  /// In en, this message translates to:
  /// **'Search teams'**
  String get servicesTeamSearch;

  /// No description provided for @servicesTeamDetails.
  ///
  /// In en, this message translates to:
  /// **'Team'**
  String get servicesTeamDetails;

  /// No description provided for @servicesTeamActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesTeamActivity;

  /// No description provided for @servicesTeamLeadOptional.
  ///
  /// In en, this message translates to:
  /// **'No lead'**
  String get servicesTeamLeadOptional;

  /// No description provided for @servicesTeamSelectLead.
  ///
  /// In en, this message translates to:
  /// **'Select lead'**
  String get servicesTeamSelectLead;

  /// No description provided for @servicesTeamMembersCount.
  ///
  /// In en, this message translates to:
  /// **'Members'**
  String get servicesTeamMembersCount;

  /// No description provided for @servicesSettingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Services settings'**
  String get servicesSettingsTitle;

  /// No description provided for @servicesSettingsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Configure the master data used by service operations.'**
  String get servicesSettingsSubtitle;

  /// No description provided for @servicesServiceTypesTitle.
  ///
  /// In en, this message translates to:
  /// **'Service types'**
  String get servicesServiceTypesTitle;

  /// No description provided for @servicesComplaintTypesTitle.
  ///
  /// In en, this message translates to:
  /// **'Complaint types'**
  String get servicesComplaintTypesTitle;

  /// No description provided for @servicesPrioritiesTitle.
  ///
  /// In en, this message translates to:
  /// **'Priorities'**
  String get servicesPrioritiesTitle;

  /// No description provided for @servicesTicketTypesTitle.
  ///
  /// In en, this message translates to:
  /// **'Ticket types'**
  String get servicesTicketTypesTitle;

  /// No description provided for @servicesAddMaster.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get servicesAddMaster;

  /// No description provided for @servicesEditMaster.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get servicesEditMaster;

  /// No description provided for @servicesMasterCode.
  ///
  /// In en, this message translates to:
  /// **'Code'**
  String get servicesMasterCode;

  /// No description provided for @servicesMasterName.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get servicesMasterName;

  /// No description provided for @servicesMasterDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesMasterDescription;

  /// No description provided for @servicesMasterSortOrder.
  ///
  /// In en, this message translates to:
  /// **'Sort order'**
  String get servicesMasterSortOrder;

  /// No description provided for @servicesMasterRank.
  ///
  /// In en, this message translates to:
  /// **'Rank'**
  String get servicesMasterRank;

  /// No description provided for @servicesMasterDefault.
  ///
  /// In en, this message translates to:
  /// **'Default'**
  String get servicesMasterDefault;

  /// No description provided for @servicesMasterServiceType.
  ///
  /// In en, this message translates to:
  /// **'Service type'**
  String get servicesMasterServiceType;

  /// No description provided for @servicesMasterSaved.
  ///
  /// In en, this message translates to:
  /// **'Saved.'**
  String get servicesMasterSaved;

  /// No description provided for @servicesMasterStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save.'**
  String get servicesMasterStorageError;

  /// No description provided for @servicesMasterNotFound.
  ///
  /// In en, this message translates to:
  /// **'Record not found.'**
  String get servicesMasterNotFound;

  /// No description provided for @servicesMasterEmpty.
  ///
  /// In en, this message translates to:
  /// **'Nothing configured yet'**
  String get servicesMasterEmpty;

  /// No description provided for @servicesMasterNoResults.
  ///
  /// In en, this message translates to:
  /// **'No records match your search.'**
  String get servicesMasterNoResults;

  /// No description provided for @servicesMasterRequired.
  ///
  /// In en, this message translates to:
  /// **'This field is required.'**
  String get servicesMasterRequired;

  /// No description provided for @servicesMasterDeactivate.
  ///
  /// In en, this message translates to:
  /// **'Deactivate'**
  String get servicesMasterDeactivate;

  /// No description provided for @servicesMasterActivate.
  ///
  /// In en, this message translates to:
  /// **'Activate'**
  String get servicesMasterActivate;

  /// No description provided for @servicesMasterSearch.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get servicesMasterSearch;

  /// No description provided for @servicesMasterGeneric.
  ///
  /// In en, this message translates to:
  /// **'General'**
  String get servicesMasterGeneric;

  /// No description provided for @servicesMasterNameRequired.
  ///
  /// In en, this message translates to:
  /// **'Name is required.'**
  String get servicesMasterNameRequired;

  /// No description provided for @servicesMasterCodeRequired.
  ///
  /// In en, this message translates to:
  /// **'Code is required.'**
  String get servicesMasterCodeRequired;

  /// No description provided for @servicesMasterDuplicateCode.
  ///
  /// In en, this message translates to:
  /// **'A record with this code already exists.'**
  String get servicesMasterDuplicateCode;

  /// No description provided for @servicesMasterDuplicateName.
  ///
  /// In en, this message translates to:
  /// **'A record with this name already exists.'**
  String get servicesMasterDuplicateName;

  /// No description provided for @servicesMasterBasicInformation.
  ///
  /// In en, this message translates to:
  /// **'Basic information'**
  String get servicesMasterBasicInformation;

  /// No description provided for @servicesMasterOrderingBehavior.
  ///
  /// In en, this message translates to:
  /// **'Ordering & behavior'**
  String get servicesMasterOrderingBehavior;

  /// No description provided for @servicesMasterOrderingSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Controls display order and default selection behavior.'**
  String get servicesMasterOrderingSubtitle;

  /// No description provided for @servicesMasterCodeHelper.
  ///
  /// In en, this message translates to:
  /// **'Used as a stable internal reference.'**
  String get servicesMasterCodeHelper;

  /// No description provided for @servicesMasterSortOrderHelper.
  ///
  /// In en, this message translates to:
  /// **'Lower values appear first.'**
  String get servicesMasterSortOrderHelper;

  /// No description provided for @servicesMasterDefaultPriorityLabel.
  ///
  /// In en, this message translates to:
  /// **'Default priority'**
  String get servicesMasterDefaultPriorityLabel;

  /// No description provided for @servicesMasterDefaultPriorityDescription.
  ///
  /// In en, this message translates to:
  /// **'Use this priority automatically when no other priority is explicitly selected.'**
  String get servicesMasterDefaultPriorityDescription;

  /// No description provided for @servicesMasterDefaultGenericDescription.
  ///
  /// In en, this message translates to:
  /// **'Use this record automatically when no other is explicitly selected.'**
  String get servicesMasterDefaultGenericDescription;

  /// No description provided for @servicesMasterAddName.
  ///
  /// In en, this message translates to:
  /// **'Add {name}'**
  String servicesMasterAddName(String name);

  /// No description provided for @servicesMasterEditName.
  ///
  /// In en, this message translates to:
  /// **'Edit {name}'**
  String servicesMasterEditName(String name);

  /// No description provided for @servicesServiceTypeSingular.
  ///
  /// In en, this message translates to:
  /// **'service type'**
  String get servicesServiceTypeSingular;

  /// No description provided for @servicesComplaintTypeSingular.
  ///
  /// In en, this message translates to:
  /// **'complaint type'**
  String get servicesComplaintTypeSingular;

  /// No description provided for @servicesPrioritySingular.
  ///
  /// In en, this message translates to:
  /// **'priority'**
  String get servicesPrioritySingular;

  /// No description provided for @servicesTicketTypeSingular.
  ///
  /// In en, this message translates to:
  /// **'ticket type'**
  String get servicesTicketTypeSingular;

  /// No description provided for @servicesRootCauseSingular.
  ///
  /// In en, this message translates to:
  /// **'root cause'**
  String get servicesRootCauseSingular;

  /// No description provided for @servicesChargeResponsibilitySingular.
  ///
  /// In en, this message translates to:
  /// **'charge responsibility'**
  String get servicesChargeResponsibilitySingular;

  /// No description provided for @servicesMaterialRequestPurposeSingular.
  ///
  /// In en, this message translates to:
  /// **'material request purpose'**
  String get servicesMaterialRequestPurposeSingular;

  /// No description provided for @servicesServiceTypeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Classification used across service enquiries.'**
  String get servicesServiceTypeSubtitle;

  /// No description provided for @servicesComplaintTypeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Complaint categories grouped under a service type.'**
  String get servicesComplaintTypeSubtitle;

  /// No description provided for @servicesPrioritySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Configure how service requests are prioritized.'**
  String get servicesPrioritySubtitle;

  /// No description provided for @servicesTicketTypeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Ticket categories used to route service work.'**
  String get servicesTicketTypeSubtitle;

  /// No description provided for @servicesRootCauseSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Diagnosis causes recorded during inspections.'**
  String get servicesRootCauseSubtitle;

  /// No description provided for @servicesChargeResponsibilitySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Who is responsible for covering service costs.'**
  String get servicesChargeResponsibilitySubtitle;

  /// No description provided for @servicesMaterialRequestPurposeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Reasons materials are requested for service work.'**
  String get servicesMaterialRequestPurposeSubtitle;

  /// No description provided for @servicesAuditInformation.
  ///
  /// In en, this message translates to:
  /// **'Audit information'**
  String get servicesAuditInformation;

  /// No description provided for @servicesCreatedBy.
  ///
  /// In en, this message translates to:
  /// **'Created by'**
  String get servicesCreatedBy;

  /// No description provided for @servicesCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get servicesCreatedAt;

  /// No description provided for @servicesUpdatedBy.
  ///
  /// In en, this message translates to:
  /// **'Updated by'**
  String get servicesUpdatedBy;

  /// No description provided for @servicesUpdatedAt.
  ///
  /// In en, this message translates to:
  /// **'Updated'**
  String get servicesUpdatedAt;

  /// No description provided for @servicesCustomerInformationSection.
  ///
  /// In en, this message translates to:
  /// **'Customer information'**
  String get servicesCustomerInformationSection;

  /// No description provided for @servicesCustomerAddressSection.
  ///
  /// In en, this message translates to:
  /// **'Address & business details'**
  String get servicesCustomerAddressSection;

  /// No description provided for @servicesSiteInformationSection.
  ///
  /// In en, this message translates to:
  /// **'Site information'**
  String get servicesSiteInformationSection;

  /// No description provided for @servicesSiteCustomerRelationship.
  ///
  /// In en, this message translates to:
  /// **'Customer relationship'**
  String get servicesSiteCustomerRelationship;

  /// No description provided for @servicesSiteTenantSection.
  ///
  /// In en, this message translates to:
  /// **'Tenant, building & unit'**
  String get servicesSiteTenantSection;

  /// No description provided for @servicesSiteCoordinates.
  ///
  /// In en, this message translates to:
  /// **'Coordinates'**
  String get servicesSiteCoordinates;

  /// No description provided for @servicesTeamInformationSection.
  ///
  /// In en, this message translates to:
  /// **'Team information'**
  String get servicesTeamInformationSection;

  /// No description provided for @servicesTeamMembersSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Add employees who work together on service jobs.'**
  String get servicesTeamMembersSubtitle;

  /// No description provided for @servicesTeamMemberRemove.
  ///
  /// In en, this message translates to:
  /// **'Remove member'**
  String get servicesTeamMemberRemove;

  /// No description provided for @servicesCustomerCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} customers'**
  String servicesCustomerCount(String filtered, String total);

  /// No description provided for @servicesSiteCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} sites'**
  String servicesSiteCount(String filtered, String total);

  /// No description provided for @servicesTeamCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} teams'**
  String servicesTeamCount(String filtered, String total);

  /// No description provided for @servicesActivityCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get servicesActivityCreated;

  /// No description provided for @servicesActivityUpdated.
  ///
  /// In en, this message translates to:
  /// **'Updated'**
  String get servicesActivityUpdated;

  /// No description provided for @servicesActivityActivated.
  ///
  /// In en, this message translates to:
  /// **'Activated'**
  String get servicesActivityActivated;

  /// No description provided for @servicesActivityDeactivated.
  ///
  /// In en, this message translates to:
  /// **'Deactivated'**
  String get servicesActivityDeactivated;

  /// No description provided for @servicesActivityMembersUpdated.
  ///
  /// In en, this message translates to:
  /// **'Team members updated'**
  String get servicesActivityMembersUpdated;

  /// No description provided for @servicesActivityUnknown.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesActivityUnknown;

  /// No description provided for @servicesCustomerContactSection.
  ///
  /// In en, this message translates to:
  /// **'Contact details'**
  String get servicesCustomerContactSection;

  /// No description provided for @servicesSiteAddressSection.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get servicesSiteAddressSection;

  /// No description provided for @servicesTeamLeadSection.
  ///
  /// In en, this message translates to:
  /// **'Team lead'**
  String get servicesTeamLeadSection;

  /// No description provided for @servicesTeamLeadNone.
  ///
  /// In en, this message translates to:
  /// **'No team lead assigned'**
  String get servicesTeamLeadNone;

  /// No description provided for @servicesCustomerNoSites.
  ///
  /// In en, this message translates to:
  /// **'No service sites yet.'**
  String get servicesCustomerNoSites;

  /// No description provided for @servicesDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to perform this action.'**
  String get servicesDenied;

  /// No description provided for @permissionServiceEnquiryView.
  ///
  /// In en, this message translates to:
  /// **'View enquiries'**
  String get permissionServiceEnquiryView;

  /// No description provided for @permissionServiceEnquiryCreate.
  ///
  /// In en, this message translates to:
  /// **'Create enquiry'**
  String get permissionServiceEnquiryCreate;

  /// No description provided for @permissionServiceEnquiryEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit enquiry'**
  String get permissionServiceEnquiryEdit;

  /// No description provided for @permissionServiceEnquiryCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel enquiry'**
  String get permissionServiceEnquiryCancel;

  /// No description provided for @servicesPermSubEnquiries.
  ///
  /// In en, this message translates to:
  /// **'Enquiries'**
  String get servicesPermSubEnquiries;

  /// No description provided for @servicesPermEnquiriesView.
  ///
  /// In en, this message translates to:
  /// **'View enquiries'**
  String get servicesPermEnquiriesView;

  /// No description provided for @servicesPermEnquiriesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View the company service enquiry queue and enquiry details.'**
  String get servicesPermEnquiriesViewDesc;

  /// No description provided for @servicesPermEnquiriesCreate.
  ///
  /// In en, this message translates to:
  /// **'Create enquiry'**
  String get servicesPermEnquiriesCreate;

  /// No description provided for @servicesPermEnquiriesCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Log a new service enquiry, including restricted customer and site reference lookup.'**
  String get servicesPermEnquiriesCreateDesc;

  /// No description provided for @servicesPermEnquiriesEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit enquiry'**
  String get servicesPermEnquiriesEdit;

  /// No description provided for @servicesPermEnquiriesEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Edit an open service enquiry.'**
  String get servicesPermEnquiriesEditDesc;

  /// No description provided for @servicesPermEnquiriesCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel enquiry'**
  String get servicesPermEnquiriesCancel;

  /// No description provided for @servicesPermEnquiriesCancelDesc.
  ///
  /// In en, this message translates to:
  /// **'Cancel an open service enquiry (kept historically).'**
  String get servicesPermEnquiriesCancelDesc;

  /// No description provided for @servicesNavEnquiries.
  ///
  /// In en, this message translates to:
  /// **'Enquiries'**
  String get servicesNavEnquiries;

  /// No description provided for @servicesEnquiriesTitle.
  ///
  /// In en, this message translates to:
  /// **'Service enquiries'**
  String get servicesEnquiriesTitle;

  /// No description provided for @servicesEnquiryCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} enquiries'**
  String servicesEnquiryCount(String filtered, String total);

  /// No description provided for @servicesEnquirySearch.
  ///
  /// In en, this message translates to:
  /// **'Search by number, customer, mobile, site, building or unit'**
  String get servicesEnquirySearch;

  /// No description provided for @servicesEnquiryAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get servicesEnquiryAllStatuses;

  /// No description provided for @servicesEnquiryEmpty.
  ///
  /// In en, this message translates to:
  /// **'No service enquiries yet.'**
  String get servicesEnquiryEmpty;

  /// No description provided for @servicesEnquiryEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Log the first service enquiry to start the operational queue.'**
  String get servicesEnquiryEmptyMessage;

  /// No description provided for @servicesEnquiryNoResults.
  ///
  /// In en, this message translates to:
  /// **'No enquiries match your filters.'**
  String get servicesEnquiryNoResults;

  /// No description provided for @servicesEnquiryAdd.
  ///
  /// In en, this message translates to:
  /// **'New enquiry'**
  String get servicesEnquiryAdd;

  /// No description provided for @servicesEnquiryColumnEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Enquiry'**
  String get servicesEnquiryColumnEnquiry;

  /// No description provided for @servicesEnquiryColumnCustomer.
  ///
  /// In en, this message translates to:
  /// **'Customer'**
  String get servicesEnquiryColumnCustomer;

  /// No description provided for @servicesEnquiryColumnSite.
  ///
  /// In en, this message translates to:
  /// **'Site'**
  String get servicesEnquiryColumnSite;

  /// No description provided for @servicesEnquiryColumnService.
  ///
  /// In en, this message translates to:
  /// **'Service / complaint'**
  String get servicesEnquiryColumnService;

  /// No description provided for @servicesEnquiryColumnPriority.
  ///
  /// In en, this message translates to:
  /// **'Priority'**
  String get servicesEnquiryColumnPriority;

  /// No description provided for @servicesEnquiryColumnTicket.
  ///
  /// In en, this message translates to:
  /// **'Ticket type'**
  String get servicesEnquiryColumnTicket;

  /// No description provided for @servicesEnquiryColumnStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesEnquiryColumnStatus;

  /// No description provided for @servicesEnquiryColumnCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get servicesEnquiryColumnCreated;

  /// No description provided for @servicesEnquiryStatusOpen.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get servicesEnquiryStatusOpen;

  /// No description provided for @servicesEnquiryStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get servicesEnquiryStatusCancelled;

  /// No description provided for @servicesEnquiryFilterTitle.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get servicesEnquiryFilterTitle;

  /// No description provided for @servicesEnquiryFilterStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesEnquiryFilterStatus;

  /// No description provided for @servicesEnquiryFilterServiceType.
  ///
  /// In en, this message translates to:
  /// **'Service type'**
  String get servicesEnquiryFilterServiceType;

  /// No description provided for @servicesEnquiryFilterComplaintType.
  ///
  /// In en, this message translates to:
  /// **'Complaint type'**
  String get servicesEnquiryFilterComplaintType;

  /// No description provided for @servicesEnquiryFilterPriority.
  ///
  /// In en, this message translates to:
  /// **'Priority'**
  String get servicesEnquiryFilterPriority;

  /// No description provided for @servicesEnquiryFilterTicketType.
  ///
  /// In en, this message translates to:
  /// **'Ticket type'**
  String get servicesEnquiryFilterTicketType;

  /// No description provided for @servicesEnquiryFilterCreatedFrom.
  ///
  /// In en, this message translates to:
  /// **'Created from'**
  String get servicesEnquiryFilterCreatedFrom;

  /// No description provided for @servicesEnquiryFilterCreatedTo.
  ///
  /// In en, this message translates to:
  /// **'Created to'**
  String get servicesEnquiryFilterCreatedTo;

  /// No description provided for @servicesEnquiryDetailCustomerSection.
  ///
  /// In en, this message translates to:
  /// **'Customer & location'**
  String get servicesEnquiryDetailCustomerSection;

  /// No description provided for @servicesEnquiryDetailServiceSection.
  ///
  /// In en, this message translates to:
  /// **'Service details'**
  String get servicesEnquiryDetailServiceSection;

  /// No description provided for @servicesEnquiryDetailComplaintSection.
  ///
  /// In en, this message translates to:
  /// **'Complaint'**
  String get servicesEnquiryDetailComplaintSection;

  /// No description provided for @servicesEnquiryDetailRecord.
  ///
  /// In en, this message translates to:
  /// **'Record'**
  String get servicesEnquiryDetailRecord;

  /// No description provided for @servicesEnquiryDetailActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesEnquiryDetailActivity;

  /// No description provided for @servicesEnquiryCustomerCode.
  ///
  /// In en, this message translates to:
  /// **'Customer code'**
  String get servicesEnquiryCustomerCode;

  /// No description provided for @servicesEnquiryCustomerName.
  ///
  /// In en, this message translates to:
  /// **'Customer'**
  String get servicesEnquiryCustomerName;

  /// No description provided for @servicesEnquiryCustomerMobile.
  ///
  /// In en, this message translates to:
  /// **'Customer mobile'**
  String get servicesEnquiryCustomerMobile;

  /// No description provided for @servicesEnquirySite.
  ///
  /// In en, this message translates to:
  /// **'Service site'**
  String get servicesEnquirySite;

  /// No description provided for @servicesEnquiryTenant.
  ///
  /// In en, this message translates to:
  /// **'Tenant'**
  String get servicesEnquiryTenant;

  /// No description provided for @servicesEnquiryBuilding.
  ///
  /// In en, this message translates to:
  /// **'Building'**
  String get servicesEnquiryBuilding;

  /// No description provided for @servicesEnquiryUnit.
  ///
  /// In en, this message translates to:
  /// **'Unit'**
  String get servicesEnquiryUnit;

  /// No description provided for @servicesEnquiryAddress.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get servicesEnquiryAddress;

  /// No description provided for @servicesEnquiryContact.
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get servicesEnquiryContact;

  /// No description provided for @servicesEnquiryServiceType.
  ///
  /// In en, this message translates to:
  /// **'Service type'**
  String get servicesEnquiryServiceType;

  /// No description provided for @servicesEnquiryComplaintType.
  ///
  /// In en, this message translates to:
  /// **'Complaint type'**
  String get servicesEnquiryComplaintType;

  /// No description provided for @servicesEnquiryPriority.
  ///
  /// In en, this message translates to:
  /// **'Priority'**
  String get servicesEnquiryPriority;

  /// No description provided for @servicesEnquiryTicketType.
  ///
  /// In en, this message translates to:
  /// **'Ticket type'**
  String get servicesEnquiryTicketType;

  /// No description provided for @servicesEnquiryDescription.
  ///
  /// In en, this message translates to:
  /// **'Complaint details'**
  String get servicesEnquiryDescription;

  /// No description provided for @servicesEnquiryCreatedBy.
  ///
  /// In en, this message translates to:
  /// **'Created by'**
  String get servicesEnquiryCreatedBy;

  /// No description provided for @servicesEnquiryCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Created at'**
  String get servicesEnquiryCreatedAt;

  /// No description provided for @servicesEnquiryUpdatedBy.
  ///
  /// In en, this message translates to:
  /// **'Updated by'**
  String get servicesEnquiryUpdatedBy;

  /// No description provided for @servicesEnquiryUpdatedAt.
  ///
  /// In en, this message translates to:
  /// **'Updated at'**
  String get servicesEnquiryUpdatedAt;

  /// No description provided for @servicesEnquiryVersion.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get servicesEnquiryVersion;

  /// No description provided for @servicesEnquiryCancelledAt.
  ///
  /// In en, this message translates to:
  /// **'Cancelled at'**
  String get servicesEnquiryCancelledAt;

  /// No description provided for @servicesEnquiryCancelReason.
  ///
  /// In en, this message translates to:
  /// **'Cancellation reason'**
  String get servicesEnquiryCancelReason;

  /// No description provided for @servicesEnquiryNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity yet.'**
  String get servicesEnquiryNoActivity;

  /// No description provided for @servicesEnquiryEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit enquiry'**
  String get servicesEnquiryEdit;

  /// No description provided for @servicesEnquiryCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel enquiry'**
  String get servicesEnquiryCancel;

  /// No description provided for @servicesEnquiryCreate.
  ///
  /// In en, this message translates to:
  /// **'Create enquiry'**
  String get servicesEnquiryCreate;

  /// No description provided for @servicesEnquiryCancelConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Cancel enquiry?'**
  String get servicesEnquiryCancelConfirmTitle;

  /// No description provided for @servicesEnquiryCancelConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'The cancelled enquiry stays available historically and cannot be edited afterwards.'**
  String get servicesEnquiryCancelConfirmMessage;

  /// No description provided for @servicesEnquiryCancelReasonHint.
  ///
  /// In en, this message translates to:
  /// **'Optional cancellation reason'**
  String get servicesEnquiryCancelReasonHint;

  /// No description provided for @servicesEnquiryCreated.
  ///
  /// In en, this message translates to:
  /// **'Enquiry created.'**
  String get servicesEnquiryCreated;

  /// No description provided for @servicesEnquiryUpdated.
  ///
  /// In en, this message translates to:
  /// **'Enquiry updated.'**
  String get servicesEnquiryUpdated;

  /// No description provided for @servicesEnquiryCancelled.
  ///
  /// In en, this message translates to:
  /// **'Enquiry cancelled.'**
  String get servicesEnquiryCancelled;

  /// No description provided for @servicesEnquiryFormNew.
  ///
  /// In en, this message translates to:
  /// **'New enquiry'**
  String get servicesEnquiryFormNew;

  /// No description provided for @servicesEnquiryFormEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit enquiry'**
  String get servicesEnquiryFormEdit;

  /// No description provided for @servicesEnquirySectionCustomerLocation.
  ///
  /// In en, this message translates to:
  /// **'Customer & location'**
  String get servicesEnquirySectionCustomerLocation;

  /// No description provided for @servicesEnquirySectionService.
  ///
  /// In en, this message translates to:
  /// **'Service details'**
  String get servicesEnquirySectionService;

  /// No description provided for @servicesEnquirySectionComplaint.
  ///
  /// In en, this message translates to:
  /// **'Complaint'**
  String get servicesEnquirySectionComplaint;

  /// No description provided for @servicesEnquirySectionSummary.
  ///
  /// In en, this message translates to:
  /// **'Summary'**
  String get servicesEnquirySectionSummary;

  /// No description provided for @servicesEnquirySelectCustomer.
  ///
  /// In en, this message translates to:
  /// **'Select a customer'**
  String get servicesEnquirySelectCustomer;

  /// No description provided for @servicesEnquirySelectSite.
  ///
  /// In en, this message translates to:
  /// **'Select a service site'**
  String get servicesEnquirySelectSite;

  /// No description provided for @servicesEnquiryChangeCustomer.
  ///
  /// In en, this message translates to:
  /// **'Change customer'**
  String get servicesEnquiryChangeCustomer;

  /// No description provided for @servicesEnquiryChangeSite.
  ///
  /// In en, this message translates to:
  /// **'Change site'**
  String get servicesEnquiryChangeSite;

  /// No description provided for @servicesEnquiryCreateCustomer.
  ///
  /// In en, this message translates to:
  /// **'Create customer'**
  String get servicesEnquiryCreateCustomer;

  /// No description provided for @servicesEnquiryCreateSite.
  ///
  /// In en, this message translates to:
  /// **'Add site'**
  String get servicesEnquiryCreateSite;

  /// No description provided for @servicesEnquiryNoSitesForCustomer.
  ///
  /// In en, this message translates to:
  /// **'No active sites for this customer.'**
  String get servicesEnquiryNoSitesForCustomer;

  /// No description provided for @servicesEnquiryNoComplaintTypes.
  ///
  /// In en, this message translates to:
  /// **'No complaint types are available for this service type.'**
  String get servicesEnquiryNoComplaintTypes;

  /// No description provided for @servicesEnquiryDescriptionHint.
  ///
  /// In en, this message translates to:
  /// **'Describe the complaint or service request'**
  String get servicesEnquiryDescriptionHint;

  /// No description provided for @servicesEnquiryCustomerRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a customer.'**
  String get servicesEnquiryCustomerRequired;

  /// No description provided for @servicesEnquirySiteRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a service site.'**
  String get servicesEnquirySiteRequired;

  /// No description provided for @servicesEnquiryServiceTypeRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a service type.'**
  String get servicesEnquiryServiceTypeRequired;

  /// No description provided for @servicesEnquiryComplaintTypeRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a complaint type.'**
  String get servicesEnquiryComplaintTypeRequired;

  /// No description provided for @servicesEnquiryPriorityRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a priority.'**
  String get servicesEnquiryPriorityRequired;

  /// No description provided for @servicesEnquiryTicketTypeRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a ticket type.'**
  String get servicesEnquiryTicketTypeRequired;

  /// No description provided for @servicesEnquiryDescriptionRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the complaint details.'**
  String get servicesEnquiryDescriptionRequired;

  /// No description provided for @servicesEnquiryDescriptionTooLong.
  ///
  /// In en, this message translates to:
  /// **'The complaint details are too long.'**
  String get servicesEnquiryDescriptionTooLong;

  /// No description provided for @servicesEnquiryDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to perform this action.'**
  String get servicesEnquiryDenied;

  /// No description provided for @servicesEnquiryNotFound.
  ///
  /// In en, this message translates to:
  /// **'Enquiry not found.'**
  String get servicesEnquiryNotFound;

  /// No description provided for @servicesEnquiryNotEditable.
  ///
  /// In en, this message translates to:
  /// **'Only open enquiries can be edited.'**
  String get servicesEnquiryNotEditable;

  /// No description provided for @servicesEnquiryAlreadyCancelled.
  ///
  /// In en, this message translates to:
  /// **'This enquiry is already cancelled.'**
  String get servicesEnquiryAlreadyCancelled;

  /// No description provided for @servicesEnquiryCustomerNotFound.
  ///
  /// In en, this message translates to:
  /// **'Customer not found.'**
  String get servicesEnquiryCustomerNotFound;

  /// No description provided for @servicesEnquiryCustomerInactive.
  ///
  /// In en, this message translates to:
  /// **'The selected customer is inactive.'**
  String get servicesEnquiryCustomerInactive;

  /// No description provided for @servicesEnquirySiteNotFound.
  ///
  /// In en, this message translates to:
  /// **'Service site not found.'**
  String get servicesEnquirySiteNotFound;

  /// No description provided for @servicesEnquirySiteInactive.
  ///
  /// In en, this message translates to:
  /// **'The selected service site is inactive.'**
  String get servicesEnquirySiteInactive;

  /// No description provided for @servicesEnquirySiteCustomerMismatch.
  ///
  /// In en, this message translates to:
  /// **'The selected site does not belong to the selected customer.'**
  String get servicesEnquirySiteCustomerMismatch;

  /// No description provided for @servicesEnquiryServiceTypeInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected service type is not available.'**
  String get servicesEnquiryServiceTypeInvalid;

  /// No description provided for @servicesEnquiryComplaintTypeInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected complaint type is not available.'**
  String get servicesEnquiryComplaintTypeInvalid;

  /// No description provided for @servicesEnquiryComplaintTypeMismatch.
  ///
  /// In en, this message translates to:
  /// **'The complaint type does not match the selected service type.'**
  String get servicesEnquiryComplaintTypeMismatch;

  /// No description provided for @servicesEnquiryPriorityInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected priority is not available.'**
  String get servicesEnquiryPriorityInvalid;

  /// No description provided for @servicesEnquiryTicketTypeInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected ticket type is not available.'**
  String get servicesEnquiryTicketTypeInvalid;

  /// No description provided for @servicesEnquirySequenceFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not allocate an enquiry number.'**
  String get servicesEnquirySequenceFailed;

  /// No description provided for @servicesEnquiryStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the enquiry. Please try again.'**
  String get servicesEnquiryStorageError;

  /// No description provided for @servicesActivityCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get servicesActivityCancelled;

  /// No description provided for @servicesOverviewEnquiriesOpen.
  ///
  /// In en, this message translates to:
  /// **'Open enquiries'**
  String get servicesOverviewEnquiriesOpen;

  /// No description provided for @servicesOverviewEnquiriesToday.
  ///
  /// In en, this message translates to:
  /// **'Enquiries today'**
  String get servicesOverviewEnquiriesToday;

  /// No description provided for @servicesOverviewEnquiriesHigh.
  ///
  /// In en, this message translates to:
  /// **'High / urgent open'**
  String get servicesOverviewEnquiriesHigh;

  /// No description provided for @servicesOverviewRecentEnquiries.
  ///
  /// In en, this message translates to:
  /// **'Recent enquiries'**
  String get servicesOverviewRecentEnquiries;

  /// No description provided for @servicesOverviewNewEnquiry.
  ///
  /// In en, this message translates to:
  /// **'New enquiry'**
  String get servicesOverviewNewEnquiry;

  /// No description provided for @servicesOverviewNoEnquiries.
  ///
  /// In en, this message translates to:
  /// **'No enquiries yet.'**
  String get servicesOverviewNoEnquiries;

  /// No description provided for @servicesEnquiryRecentForCustomer.
  ///
  /// In en, this message translates to:
  /// **'Recent enquiries'**
  String get servicesEnquiryRecentForCustomer;

  /// No description provided for @servicesEnquiryRecentForSite.
  ///
  /// In en, this message translates to:
  /// **'Recent enquiries'**
  String get servicesEnquiryRecentForSite;

  /// No description provided for @servicesEnquiryNoneForCustomer.
  ///
  /// In en, this message translates to:
  /// **'No enquiries for this customer yet.'**
  String get servicesEnquiryNoneForCustomer;

  /// No description provided for @servicesEnquiryNoneForSite.
  ///
  /// In en, this message translates to:
  /// **'No enquiries for this site yet.'**
  String get servicesEnquiryNoneForSite;

  /// No description provided for @servicesEnquiryDetailsSection.
  ///
  /// In en, this message translates to:
  /// **'Enquiry details'**
  String get servicesEnquiryDetailsSection;

  /// No description provided for @servicesEnquiryAddDetail.
  ///
  /// In en, this message translates to:
  /// **'Add another issue'**
  String get servicesEnquiryAddDetail;

  /// No description provided for @servicesEnquiryRemoveDetail.
  ///
  /// In en, this message translates to:
  /// **'Remove issue'**
  String get servicesEnquiryRemoveDetail;

  /// No description provided for @servicesEnquiryDetailLine.
  ///
  /// In en, this message translates to:
  /// **'Issue {index}'**
  String servicesEnquiryDetailLine(String index);

  /// No description provided for @servicesEnquiryDetailDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesEnquiryDetailDescription;

  /// No description provided for @servicesEnquiryDetailStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesEnquiryDetailStatus;

  /// No description provided for @servicesEnquiryDetailStatusOpen.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get servicesEnquiryDetailStatusOpen;

  /// No description provided for @servicesEnquiryDetailStatusClosed.
  ///
  /// In en, this message translates to:
  /// **'Closed'**
  String get servicesEnquiryDetailStatusClosed;

  /// No description provided for @servicesEnquiryPhotos.
  ///
  /// In en, this message translates to:
  /// **'Photos'**
  String get servicesEnquiryPhotos;

  /// No description provided for @servicesEnquiryAddPhotos.
  ///
  /// In en, this message translates to:
  /// **'Add photos'**
  String get servicesEnquiryAddPhotos;

  /// No description provided for @servicesEnquiryMaterialReceived.
  ///
  /// In en, this message translates to:
  /// **'Material received'**
  String get servicesEnquiryMaterialReceived;

  /// No description provided for @servicesEnquiryMaterialReceivedYes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get servicesEnquiryMaterialReceivedYes;

  /// No description provided for @servicesEnquiryMaterialReceivedNo.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get servicesEnquiryMaterialReceivedNo;

  /// No description provided for @servicesEnquiryNoDetails.
  ///
  /// In en, this message translates to:
  /// **'No details recorded.'**
  String get servicesEnquiryNoDetails;

  /// No description provided for @servicesEnquiryDetailsRequired.
  ///
  /// In en, this message translates to:
  /// **'Add at least one enquiry detail.'**
  String get servicesEnquiryDetailsRequired;

  /// No description provided for @servicesEnquiryDetailDescriptionRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter a description for each enquiry detail.'**
  String get servicesEnquiryDetailDescriptionRequired;

  /// No description provided for @servicesEnquiryAttachmentUnsupportedType.
  ///
  /// In en, this message translates to:
  /// **'Unsupported file type.'**
  String get servicesEnquiryAttachmentUnsupportedType;

  /// No description provided for @servicesEnquiryAttachmentTooLarge.
  ///
  /// In en, this message translates to:
  /// **'File is too large.'**
  String get servicesEnquiryAttachmentTooLarge;

  /// No description provided for @servicesEnquiryAttachmentLimitReached.
  ///
  /// In en, this message translates to:
  /// **'Attachment limit reached.'**
  String get servicesEnquiryAttachmentLimitReached;

  /// No description provided for @servicesEnquiryAttachmentFailure.
  ///
  /// In en, this message translates to:
  /// **'Could not attach the file.'**
  String get servicesEnquiryAttachmentFailure;

  /// No description provided for @attachmentUploaded.
  ///
  /// In en, this message translates to:
  /// **'Uploaded'**
  String get attachmentUploaded;

  /// No description provided for @attachmentLocalOnly.
  ///
  /// In en, this message translates to:
  /// **'Local'**
  String get attachmentLocalOnly;

  /// No description provided for @attachmentPendingUpload.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get attachmentPendingUpload;

  /// No description provided for @attachmentFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed'**
  String get attachmentFailed;

  /// No description provided for @attachmentPendingDelete.
  ///
  /// In en, this message translates to:
  /// **'Deleting'**
  String get attachmentPendingDelete;

  /// No description provided for @attachmentDeleted.
  ///
  /// In en, this message translates to:
  /// **'Deleted'**
  String get attachmentDeleted;

  /// No description provided for @servicesNavJobAssignments.
  ///
  /// In en, this message translates to:
  /// **'Job assignments'**
  String get servicesNavJobAssignments;

  /// No description provided for @servicesPermSubJobAssignments.
  ///
  /// In en, this message translates to:
  /// **'Job assignments'**
  String get servicesPermSubJobAssignments;

  /// No description provided for @servicesPermJobAssignmentsView.
  ///
  /// In en, this message translates to:
  /// **'View job assignments'**
  String get servicesPermJobAssignmentsView;

  /// No description provided for @servicesPermJobAssignmentsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View the company job assignment queue within your record scope.'**
  String get servicesPermJobAssignmentsViewDesc;

  /// No description provided for @servicesPermJobAssignmentsCreate.
  ///
  /// In en, this message translates to:
  /// **'Create job assignment'**
  String get servicesPermJobAssignmentsCreate;

  /// No description provided for @servicesPermJobAssignmentsCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Assign work from an eligible enquiry, including restricted enquiry, employee and team reference lookup.'**
  String get servicesPermJobAssignmentsCreateDesc;

  /// No description provided for @servicesPermJobAssignmentsEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit job assignment'**
  String get servicesPermJobAssignmentsEdit;

  /// No description provided for @servicesPermJobAssignmentsEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Edit or reassign an active job assignment.'**
  String get servicesPermJobAssignmentsEditDesc;

  /// No description provided for @servicesPermJobAssignmentsCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel job assignment'**
  String get servicesPermJobAssignmentsCancel;

  /// No description provided for @servicesPermJobAssignmentsCancelDesc.
  ///
  /// In en, this message translates to:
  /// **'Cancel an active job assignment (kept historically).'**
  String get servicesPermJobAssignmentsCancelDesc;

  /// No description provided for @permissionServiceJobAssignmentView.
  ///
  /// In en, this message translates to:
  /// **'View job assignments'**
  String get permissionServiceJobAssignmentView;

  /// No description provided for @permissionServiceJobAssignmentCreate.
  ///
  /// In en, this message translates to:
  /// **'Create job assignment'**
  String get permissionServiceJobAssignmentCreate;

  /// No description provided for @permissionServiceJobAssignmentEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit job assignment'**
  String get permissionServiceJobAssignmentEdit;

  /// No description provided for @permissionServiceJobAssignmentCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel job assignment'**
  String get permissionServiceJobAssignmentCancel;

  /// No description provided for @servicesJobAssignmentsTitle.
  ///
  /// In en, this message translates to:
  /// **'Job assignments'**
  String get servicesJobAssignmentsTitle;

  /// No description provided for @servicesJobAssignmentCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} job assignments'**
  String servicesJobAssignmentCount(String filtered, String total);

  /// No description provided for @servicesJobAssignmentSearch.
  ///
  /// In en, this message translates to:
  /// **'Search by assignment, enquiry, customer, mobile, site, employee or team'**
  String get servicesJobAssignmentSearch;

  /// No description provided for @servicesJobAssignmentAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get servicesJobAssignmentAllStatuses;

  /// No description provided for @servicesJobAssignmentStatusActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get servicesJobAssignmentStatusActive;

  /// No description provided for @servicesJobAssignmentStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get servicesJobAssignmentStatusCancelled;

  /// No description provided for @servicesJobAssignmentEmpty.
  ///
  /// In en, this message translates to:
  /// **'No job assignments yet.'**
  String get servicesJobAssignmentEmpty;

  /// No description provided for @servicesJobAssignmentEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Create a job assignment from an open service enquiry.'**
  String get servicesJobAssignmentEmptyMessage;

  /// No description provided for @servicesJobAssignmentNoResults.
  ///
  /// In en, this message translates to:
  /// **'No job assignments match your filters.'**
  String get servicesJobAssignmentNoResults;

  /// No description provided for @servicesJobAssignmentAdd.
  ///
  /// In en, this message translates to:
  /// **'New job assignment'**
  String get servicesJobAssignmentAdd;

  /// No description provided for @servicesJobAssignmentColumnAssignment.
  ///
  /// In en, this message translates to:
  /// **'Assignment'**
  String get servicesJobAssignmentColumnAssignment;

  /// No description provided for @servicesJobAssignmentColumnEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Enquiry'**
  String get servicesJobAssignmentColumnEnquiry;

  /// No description provided for @servicesJobAssignmentColumnCustomerSite.
  ///
  /// In en, this message translates to:
  /// **'Customer / site'**
  String get servicesJobAssignmentColumnCustomerSite;

  /// No description provided for @servicesJobAssignmentColumnVisitDate.
  ///
  /// In en, this message translates to:
  /// **'Visit date'**
  String get servicesJobAssignmentColumnVisitDate;

  /// No description provided for @servicesJobAssignmentColumnAssignedTo.
  ///
  /// In en, this message translates to:
  /// **'Assigned to'**
  String get servicesJobAssignmentColumnAssignedTo;

  /// No description provided for @servicesJobAssignmentColumnPriority.
  ///
  /// In en, this message translates to:
  /// **'Priority'**
  String get servicesJobAssignmentColumnPriority;

  /// No description provided for @servicesJobAssignmentColumnStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesJobAssignmentColumnStatus;

  /// No description provided for @servicesJobAssignmentColumnCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get servicesJobAssignmentColumnCreated;

  /// No description provided for @servicesJobAssignmentFilterTitle.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get servicesJobAssignmentFilterTitle;

  /// No description provided for @servicesJobAssignmentFilterStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesJobAssignmentFilterStatus;

  /// No description provided for @servicesJobAssignmentFilterPriority.
  ///
  /// In en, this message translates to:
  /// **'Priority'**
  String get servicesJobAssignmentFilterPriority;

  /// No description provided for @servicesJobAssignmentFilterVisitFrom.
  ///
  /// In en, this message translates to:
  /// **'Visit from'**
  String get servicesJobAssignmentFilterVisitFrom;

  /// No description provided for @servicesJobAssignmentFilterVisitTo.
  ///
  /// In en, this message translates to:
  /// **'Visit to'**
  String get servicesJobAssignmentFilterVisitTo;

  /// No description provided for @servicesJobAssignmentFormNew.
  ///
  /// In en, this message translates to:
  /// **'New job assignment'**
  String get servicesJobAssignmentFormNew;

  /// No description provided for @servicesJobAssignmentFormEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit job assignment'**
  String get servicesJobAssignmentFormEdit;

  /// No description provided for @servicesJobAssignmentCreate.
  ///
  /// In en, this message translates to:
  /// **'Create job assignment'**
  String get servicesJobAssignmentCreate;

  /// No description provided for @servicesJobAssignmentSectionJobContext.
  ///
  /// In en, this message translates to:
  /// **'Job context'**
  String get servicesJobAssignmentSectionJobContext;

  /// No description provided for @servicesJobAssignmentSectionSchedule.
  ///
  /// In en, this message translates to:
  /// **'Schedule'**
  String get servicesJobAssignmentSectionSchedule;

  /// No description provided for @servicesJobAssignmentSectionCustomerLocation.
  ///
  /// In en, this message translates to:
  /// **'Customer & location'**
  String get servicesJobAssignmentSectionCustomerLocation;

  /// No description provided for @servicesJobAssignmentSectionServiceContext.
  ///
  /// In en, this message translates to:
  /// **'Service context'**
  String get servicesJobAssignmentSectionServiceContext;

  /// No description provided for @servicesJobAssignmentSectionSourceIssues.
  ///
  /// In en, this message translates to:
  /// **'Source enquiry issues'**
  String get servicesJobAssignmentSectionSourceIssues;

  /// No description provided for @servicesJobAssignmentSectionWork.
  ///
  /// In en, this message translates to:
  /// **'Work assignment'**
  String get servicesJobAssignmentSectionWork;

  /// No description provided for @servicesJobAssignmentNo.
  ///
  /// In en, this message translates to:
  /// **'Assignment no'**
  String get servicesJobAssignmentNo;

  /// No description provided for @servicesJobAssignmentDate.
  ///
  /// In en, this message translates to:
  /// **'Assignment date'**
  String get servicesJobAssignmentDate;

  /// No description provided for @servicesJobAssignmentVisitDate.
  ///
  /// In en, this message translates to:
  /// **'Visit date'**
  String get servicesJobAssignmentVisitDate;

  /// No description provided for @servicesJobAssignmentEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Enquiry'**
  String get servicesJobAssignmentEnquiry;

  /// No description provided for @servicesJobAssignmentSelectEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Select an eligible enquiry'**
  String get servicesJobAssignmentSelectEnquiry;

  /// No description provided for @servicesJobAssignmentChangeEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Change enquiry'**
  String get servicesJobAssignmentChangeEnquiry;

  /// No description provided for @servicesJobAssignmentNoIssues.
  ///
  /// In en, this message translates to:
  /// **'No enquiry issues recorded.'**
  String get servicesJobAssignmentNoIssues;

  /// No description provided for @servicesJobAssignmentMaterialReceived.
  ///
  /// In en, this message translates to:
  /// **'Material received'**
  String get servicesJobAssignmentMaterialReceived;

  /// No description provided for @servicesJobAssignmentWork.
  ///
  /// In en, this message translates to:
  /// **'Work'**
  String get servicesJobAssignmentWork;

  /// No description provided for @servicesJobAssignmentTechnician.
  ///
  /// In en, this message translates to:
  /// **'Technician'**
  String get servicesJobAssignmentTechnician;

  /// No description provided for @servicesJobAssignmentServiceTeam.
  ///
  /// In en, this message translates to:
  /// **'Service team'**
  String get servicesJobAssignmentServiceTeam;

  /// No description provided for @servicesJobAssignmentLineStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesJobAssignmentLineStatus;

  /// No description provided for @servicesJobAssignmentLineStatusPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get servicesJobAssignmentLineStatusPending;

  /// No description provided for @servicesJobAssignmentDescriptionForWork.
  ///
  /// In en, this message translates to:
  /// **'Description for work'**
  String get servicesJobAssignmentDescriptionForWork;

  /// No description provided for @servicesJobAssignmentAddLine.
  ///
  /// In en, this message translates to:
  /// **'Add work item'**
  String get servicesJobAssignmentAddLine;

  /// No description provided for @servicesJobAssignmentRemoveLine.
  ///
  /// In en, this message translates to:
  /// **'Remove work item'**
  String get servicesJobAssignmentRemoveLine;

  /// No description provided for @servicesJobAssignmentLineTitle.
  ///
  /// In en, this message translates to:
  /// **'Work item {index}'**
  String servicesJobAssignmentLineTitle(String index);

  /// No description provided for @servicesJobAssignmentNoTargets.
  ///
  /// In en, this message translates to:
  /// **'Assign an employee, a service team, or both.'**
  String get servicesJobAssignmentNoTargets;

  /// No description provided for @servicesJobAssignmentDetailContext.
  ///
  /// In en, this message translates to:
  /// **'Enquiry context'**
  String get servicesJobAssignmentDetailContext;

  /// No description provided for @servicesJobAssignmentDetailWork.
  ///
  /// In en, this message translates to:
  /// **'Work items'**
  String get servicesJobAssignmentDetailWork;

  /// No description provided for @servicesJobAssignmentDetailAudit.
  ///
  /// In en, this message translates to:
  /// **'Record'**
  String get servicesJobAssignmentDetailAudit;

  /// No description provided for @servicesJobAssignmentDetailActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesJobAssignmentDetailActivity;

  /// No description provided for @servicesJobAssignmentEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit assignment'**
  String get servicesJobAssignmentEdit;

  /// No description provided for @servicesJobAssignmentCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel assignment'**
  String get servicesJobAssignmentCancel;

  /// No description provided for @servicesJobAssignmentCancelConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Cancel assignment?'**
  String get servicesJobAssignmentCancelConfirmTitle;

  /// No description provided for @servicesJobAssignmentCancelConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'The cancelled assignment stays available historically and cannot be edited afterwards.'**
  String get servicesJobAssignmentCancelConfirmMessage;

  /// No description provided for @servicesJobAssignmentCreated.
  ///
  /// In en, this message translates to:
  /// **'Job assignment created.'**
  String get servicesJobAssignmentCreated;

  /// No description provided for @servicesJobAssignmentUpdated.
  ///
  /// In en, this message translates to:
  /// **'Job assignment updated.'**
  String get servicesJobAssignmentUpdated;

  /// No description provided for @servicesJobAssignmentCancelled.
  ///
  /// In en, this message translates to:
  /// **'Job assignment cancelled.'**
  String get servicesJobAssignmentCancelled;

  /// No description provided for @servicesJobAssignmentNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity yet.'**
  String get servicesJobAssignmentNoActivity;

  /// No description provided for @servicesJobAssignmentCreatedBy.
  ///
  /// In en, this message translates to:
  /// **'Created by'**
  String get servicesJobAssignmentCreatedBy;

  /// No description provided for @servicesJobAssignmentCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Created at'**
  String get servicesJobAssignmentCreatedAt;

  /// No description provided for @servicesJobAssignmentUpdatedBy.
  ///
  /// In en, this message translates to:
  /// **'Updated by'**
  String get servicesJobAssignmentUpdatedBy;

  /// No description provided for @servicesJobAssignmentUpdatedAt.
  ///
  /// In en, this message translates to:
  /// **'Updated at'**
  String get servicesJobAssignmentUpdatedAt;

  /// No description provided for @servicesJobAssignmentVersion.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get servicesJobAssignmentVersion;

  /// No description provided for @servicesJobAssignmentCancelledAt.
  ///
  /// In en, this message translates to:
  /// **'Cancelled at'**
  String get servicesJobAssignmentCancelledAt;

  /// No description provided for @servicesJobAssignmentEnquiryRequired.
  ///
  /// In en, this message translates to:
  /// **'Select an enquiry.'**
  String get servicesJobAssignmentEnquiryRequired;

  /// No description provided for @servicesJobAssignmentVisitDateRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a visit date.'**
  String get servicesJobAssignmentVisitDateRequired;

  /// No description provided for @servicesJobAssignmentLinesRequired.
  ///
  /// In en, this message translates to:
  /// **'Add at least one work item.'**
  String get servicesJobAssignmentLinesRequired;

  /// No description provided for @servicesJobAssignmentWorkRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the work for each item.'**
  String get servicesJobAssignmentWorkRequired;

  /// No description provided for @servicesJobAssignmentWorkTooLong.
  ///
  /// In en, this message translates to:
  /// **'The work text is too long.'**
  String get servicesJobAssignmentWorkTooLong;

  /// No description provided for @servicesJobAssignmentDescriptionTooLong.
  ///
  /// In en, this message translates to:
  /// **'The description is too long.'**
  String get servicesJobAssignmentDescriptionTooLong;

  /// No description provided for @servicesJobAssignmentTargetRequired.
  ///
  /// In en, this message translates to:
  /// **'Assign an employee, a service team, or both.'**
  String get servicesJobAssignmentTargetRequired;

  /// No description provided for @servicesJobAssignmentEnquiryNotFound.
  ///
  /// In en, this message translates to:
  /// **'Enquiry not found.'**
  String get servicesJobAssignmentEnquiryNotFound;

  /// No description provided for @servicesJobAssignmentEnquiryNotOpen.
  ///
  /// In en, this message translates to:
  /// **'Only open enquiries can be assigned.'**
  String get servicesJobAssignmentEnquiryNotOpen;

  /// No description provided for @servicesJobAssignmentAlreadyActive.
  ///
  /// In en, this message translates to:
  /// **'This enquiry already has an active job assignment.'**
  String get servicesJobAssignmentAlreadyActive;

  /// No description provided for @servicesJobAssignmentNotFound.
  ///
  /// In en, this message translates to:
  /// **'Job assignment not found.'**
  String get servicesJobAssignmentNotFound;

  /// No description provided for @servicesJobAssignmentNotEditable.
  ///
  /// In en, this message translates to:
  /// **'Only active job assignments can be edited.'**
  String get servicesJobAssignmentNotEditable;

  /// No description provided for @servicesJobAssignmentAlreadyCancelled.
  ///
  /// In en, this message translates to:
  /// **'This job assignment is already cancelled.'**
  String get servicesJobAssignmentAlreadyCancelled;

  /// No description provided for @servicesJobAssignmentEmployeeInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected employee is not available.'**
  String get servicesJobAssignmentEmployeeInvalid;

  /// No description provided for @servicesJobAssignmentTeamInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected service team is not available.'**
  String get servicesJobAssignmentTeamInvalid;

  /// No description provided for @servicesJobAssignmentEmployeeNotInTeam.
  ///
  /// In en, this message translates to:
  /// **'The selected employee is not a member of the selected service team.'**
  String get servicesJobAssignmentEmployeeNotInTeam;

  /// No description provided for @servicesJobAssignmentSequenceFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not allocate an assignment number.'**
  String get servicesJobAssignmentSequenceFailed;

  /// No description provided for @servicesJobAssignmentDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to perform this action.'**
  String get servicesJobAssignmentDenied;

  /// No description provided for @servicesJobAssignmentStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the job assignment. Please try again.'**
  String get servicesJobAssignmentStorageError;

  /// No description provided for @servicesActivityAssigned.
  ///
  /// In en, this message translates to:
  /// **'Assigned'**
  String get servicesActivityAssigned;

  /// No description provided for @servicesActivityReopened.
  ///
  /// In en, this message translates to:
  /// **'Reopened'**
  String get servicesActivityReopened;

  /// No description provided for @servicesOverviewAssignmentsScheduled.
  ///
  /// In en, this message translates to:
  /// **'Scheduled assignments'**
  String get servicesOverviewAssignmentsScheduled;

  /// No description provided for @servicesOverviewAssignmentsToday.
  ///
  /// In en, this message translates to:
  /// **'Visits today'**
  String get servicesOverviewAssignmentsToday;

  /// No description provided for @servicesOverviewAssignmentsUpcoming.
  ///
  /// In en, this message translates to:
  /// **'Upcoming visits'**
  String get servicesOverviewAssignmentsUpcoming;

  /// No description provided for @servicesOverviewRecentAssignments.
  ///
  /// In en, this message translates to:
  /// **'Upcoming assignments'**
  String get servicesOverviewRecentAssignments;

  /// No description provided for @servicesOverviewNoAssignments.
  ///
  /// In en, this message translates to:
  /// **'No upcoming assignments.'**
  String get servicesOverviewNoAssignments;

  /// No description provided for @servicesEnquiryAssignmentSection.
  ///
  /// In en, this message translates to:
  /// **'Job assignment'**
  String get servicesEnquiryAssignmentSection;

  /// No description provided for @servicesEnquiryCreateAssignment.
  ///
  /// In en, this message translates to:
  /// **'Create job assignment'**
  String get servicesEnquiryCreateAssignment;

  /// No description provided for @servicesEnquiryViewAssignment.
  ///
  /// In en, this message translates to:
  /// **'View job assignment'**
  String get servicesEnquiryViewAssignment;

  /// No description provided for @servicesEnquiryStatusAssigned.
  ///
  /// In en, this message translates to:
  /// **'Assigned'**
  String get servicesEnquiryStatusAssigned;

  /// No description provided for @notifServiceWorkAssignedTitle.
  ///
  /// In en, this message translates to:
  /// **'Service work assigned'**
  String get notifServiceWorkAssignedTitle;

  /// No description provided for @notifServiceWorkAssignedBody.
  ///
  /// In en, this message translates to:
  /// **'You have been assigned service work.'**
  String get notifServiceWorkAssignedBody;

  /// No description provided for @servicesJobAssignmentGenerated.
  ///
  /// In en, this message translates to:
  /// **'Generated when saved'**
  String get servicesJobAssignmentGenerated;

  /// No description provided for @servicesPermSubInspections.
  ///
  /// In en, this message translates to:
  /// **'Inspections'**
  String get servicesPermSubInspections;

  /// No description provided for @servicesPermInspectionsView.
  ///
  /// In en, this message translates to:
  /// **'View inspections'**
  String get servicesPermInspectionsView;

  /// No description provided for @servicesPermInspectionsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View the company inspection queue within your record scope.'**
  String get servicesPermInspectionsViewDesc;

  /// No description provided for @servicesPermInspectionsCreate.
  ///
  /// In en, this message translates to:
  /// **'Create inspection'**
  String get servicesPermInspectionsCreate;

  /// No description provided for @servicesPermInspectionsCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Create an inspection from an eligible job assignment, including restricted reference lookup.'**
  String get servicesPermInspectionsCreateDesc;

  /// No description provided for @servicesPermInspectionsEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit inspection'**
  String get servicesPermInspectionsEdit;

  /// No description provided for @servicesPermInspectionsEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Edit a pending inspection.'**
  String get servicesPermInspectionsEditDesc;

  /// No description provided for @servicesPermInspectionsComplete.
  ///
  /// In en, this message translates to:
  /// **'Complete inspection'**
  String get servicesPermInspectionsComplete;

  /// No description provided for @servicesPermInspectionsCompleteDesc.
  ///
  /// In en, this message translates to:
  /// **'Finalize a pending inspection.'**
  String get servicesPermInspectionsCompleteDesc;

  /// No description provided for @servicesPermInspectionsCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel inspection'**
  String get servicesPermInspectionsCancel;

  /// No description provided for @servicesPermInspectionsCancelDesc.
  ///
  /// In en, this message translates to:
  /// **'Cancel a pending inspection (kept historically).'**
  String get servicesPermInspectionsCancelDesc;

  /// No description provided for @servicesPermRootCausesView.
  ///
  /// In en, this message translates to:
  /// **'View root causes'**
  String get servicesPermRootCausesView;

  /// No description provided for @servicesPermRootCausesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View the root cause configuration.'**
  String get servicesPermRootCausesViewDesc;

  /// No description provided for @servicesPermRootCausesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage root causes'**
  String get servicesPermRootCausesManage;

  /// No description provided for @servicesPermRootCausesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Add, edit and deactivate root causes.'**
  String get servicesPermRootCausesManageDesc;

  /// No description provided for @servicesPermChargeResponsibilitiesView.
  ///
  /// In en, this message translates to:
  /// **'View charge responsibility'**
  String get servicesPermChargeResponsibilitiesView;

  /// No description provided for @servicesPermChargeResponsibilitiesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View the charge responsibility configuration.'**
  String get servicesPermChargeResponsibilitiesViewDesc;

  /// No description provided for @servicesPermChargeResponsibilitiesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage charge responsibility'**
  String get servicesPermChargeResponsibilitiesManage;

  /// No description provided for @servicesPermChargeResponsibilitiesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Add, edit and deactivate charge responsibility values.'**
  String get servicesPermChargeResponsibilitiesManageDesc;

  /// No description provided for @permissionServiceInspectionView.
  ///
  /// In en, this message translates to:
  /// **'View inspections'**
  String get permissionServiceInspectionView;

  /// No description provided for @permissionServiceInspectionCreate.
  ///
  /// In en, this message translates to:
  /// **'Create inspection'**
  String get permissionServiceInspectionCreate;

  /// No description provided for @permissionServiceInspectionEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit inspection'**
  String get permissionServiceInspectionEdit;

  /// No description provided for @permissionServiceInspectionComplete.
  ///
  /// In en, this message translates to:
  /// **'Complete inspection'**
  String get permissionServiceInspectionComplete;

  /// No description provided for @permissionServiceInspectionCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel inspection'**
  String get permissionServiceInspectionCancel;

  /// No description provided for @servicesNavInspections.
  ///
  /// In en, this message translates to:
  /// **'Inspections'**
  String get servicesNavInspections;

  /// No description provided for @servicesRootCausesTitle.
  ///
  /// In en, this message translates to:
  /// **'Root causes'**
  String get servicesRootCausesTitle;

  /// No description provided for @servicesChargeResponsibilitiesTitle.
  ///
  /// In en, this message translates to:
  /// **'Charge responsibility'**
  String get servicesChargeResponsibilitiesTitle;

  /// No description provided for @servicesInspectionsTitle.
  ///
  /// In en, this message translates to:
  /// **'Inspections'**
  String get servicesInspectionsTitle;

  /// No description provided for @servicesInspectionCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} inspections'**
  String servicesInspectionCount(String filtered, String total);

  /// No description provided for @servicesInspectionSearch.
  ///
  /// In en, this message translates to:
  /// **'Search by inspection, assignment, enquiry, customer, mobile, site or technician'**
  String get servicesInspectionSearch;

  /// No description provided for @servicesInspectionAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get servicesInspectionAllStatuses;

  /// No description provided for @servicesInspectionStatusPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get servicesInspectionStatusPending;

  /// No description provided for @servicesInspectionStatusCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get servicesInspectionStatusCompleted;

  /// No description provided for @servicesInspectionStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get servicesInspectionStatusCancelled;

  /// No description provided for @servicesInspectionEmpty.
  ///
  /// In en, this message translates to:
  /// **'No inspections yet.'**
  String get servicesInspectionEmpty;

  /// No description provided for @servicesInspectionEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Create an inspection from an active job assignment.'**
  String get servicesInspectionEmptyMessage;

  /// No description provided for @servicesInspectionNoResults.
  ///
  /// In en, this message translates to:
  /// **'No inspections match your filters.'**
  String get servicesInspectionNoResults;

  /// No description provided for @servicesInspectionAdd.
  ///
  /// In en, this message translates to:
  /// **'New inspection'**
  String get servicesInspectionAdd;

  /// No description provided for @servicesInspectionColumnInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesInspectionColumnInspection;

  /// No description provided for @servicesInspectionColumnAssignment.
  ///
  /// In en, this message translates to:
  /// **'Job assignment'**
  String get servicesInspectionColumnAssignment;

  /// No description provided for @servicesInspectionColumnEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Enquiry'**
  String get servicesInspectionColumnEnquiry;

  /// No description provided for @servicesInspectionColumnCustomerSite.
  ///
  /// In en, this message translates to:
  /// **'Customer / site'**
  String get servicesInspectionColumnCustomerSite;

  /// No description provided for @servicesInspectionColumnVisit.
  ///
  /// In en, this message translates to:
  /// **'Visit'**
  String get servicesInspectionColumnVisit;

  /// No description provided for @servicesInspectionColumnTechnician.
  ///
  /// In en, this message translates to:
  /// **'Technician'**
  String get servicesInspectionColumnTechnician;

  /// No description provided for @servicesInspectionColumnRootCause.
  ///
  /// In en, this message translates to:
  /// **'Root cause'**
  String get servicesInspectionColumnRootCause;

  /// No description provided for @servicesInspectionColumnStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesInspectionColumnStatus;

  /// No description provided for @servicesInspectionColumnCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get servicesInspectionColumnCreated;

  /// No description provided for @servicesInspectionFilterTitle.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get servicesInspectionFilterTitle;

  /// No description provided for @servicesInspectionFilterStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesInspectionFilterStatus;

  /// No description provided for @servicesInspectionFilterTechnician.
  ///
  /// In en, this message translates to:
  /// **'Technician'**
  String get servicesInspectionFilterTechnician;

  /// No description provided for @servicesInspectionFilterRootCause.
  ///
  /// In en, this message translates to:
  /// **'Root cause'**
  String get servicesInspectionFilterRootCause;

  /// No description provided for @servicesInspectionFilterPriority.
  ///
  /// In en, this message translates to:
  /// **'Priority'**
  String get servicesInspectionFilterPriority;

  /// No description provided for @servicesInspectionFilterVisitFrom.
  ///
  /// In en, this message translates to:
  /// **'Visit from'**
  String get servicesInspectionFilterVisitFrom;

  /// No description provided for @servicesInspectionFilterVisitTo.
  ///
  /// In en, this message translates to:
  /// **'Visit to'**
  String get servicesInspectionFilterVisitTo;

  /// No description provided for @servicesInspectionFormNew.
  ///
  /// In en, this message translates to:
  /// **'New inspection'**
  String get servicesInspectionFormNew;

  /// No description provided for @servicesInspectionFormEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit inspection'**
  String get servicesInspectionFormEdit;

  /// No description provided for @servicesInspectionCreate.
  ///
  /// In en, this message translates to:
  /// **'Create inspection'**
  String get servicesInspectionCreate;

  /// No description provided for @servicesInspectionSectionContext.
  ///
  /// In en, this message translates to:
  /// **'Inspection context'**
  String get servicesInspectionSectionContext;

  /// No description provided for @servicesInspectionSectionCustomerService.
  ///
  /// In en, this message translates to:
  /// **'Customer & service context'**
  String get servicesInspectionSectionCustomerService;

  /// No description provided for @servicesInspectionSectionVisit.
  ///
  /// In en, this message translates to:
  /// **'Visit'**
  String get servicesInspectionSectionVisit;

  /// No description provided for @servicesInspectionSectionAssessment.
  ///
  /// In en, this message translates to:
  /// **'Assessment'**
  String get servicesInspectionSectionAssessment;

  /// No description provided for @servicesInspectionSectionChecklist.
  ///
  /// In en, this message translates to:
  /// **'Checklist'**
  String get servicesInspectionSectionChecklist;

  /// No description provided for @servicesInspectionSectionPoints.
  ///
  /// In en, this message translates to:
  /// **'Inspected points'**
  String get servicesInspectionSectionPoints;

  /// No description provided for @servicesInspectionSectionMaterials.
  ///
  /// In en, this message translates to:
  /// **'Material required'**
  String get servicesInspectionSectionMaterials;

  /// No description provided for @servicesInspectionNo.
  ///
  /// In en, this message translates to:
  /// **'Inspection no'**
  String get servicesInspectionNo;

  /// No description provided for @servicesInspectionDate.
  ///
  /// In en, this message translates to:
  /// **'Inspection date'**
  String get servicesInspectionDate;

  /// No description provided for @servicesInspectionJobAssignment.
  ///
  /// In en, this message translates to:
  /// **'Job assignment'**
  String get servicesInspectionJobAssignment;

  /// No description provided for @servicesInspectionSelectAssignment.
  ///
  /// In en, this message translates to:
  /// **'Select an eligible job assignment'**
  String get servicesInspectionSelectAssignment;

  /// No description provided for @servicesInspectionVisitDate.
  ///
  /// In en, this message translates to:
  /// **'Visit date'**
  String get servicesInspectionVisitDate;

  /// No description provided for @servicesInspectionVisitTime.
  ///
  /// In en, this message translates to:
  /// **'Visit time'**
  String get servicesInspectionVisitTime;

  /// No description provided for @servicesInspectionTechnician.
  ///
  /// In en, this message translates to:
  /// **'Technician'**
  String get servicesInspectionTechnician;

  /// No description provided for @servicesInspectionTechnicianOptional.
  ///
  /// In en, this message translates to:
  /// **'Not assigned'**
  String get servicesInspectionTechnicianOptional;

  /// No description provided for @servicesInspectionRootCause.
  ///
  /// In en, this message translates to:
  /// **'Root cause'**
  String get servicesInspectionRootCause;

  /// No description provided for @servicesInspectionChargeResponsibility.
  ///
  /// In en, this message translates to:
  /// **'Charge responsibility'**
  String get servicesInspectionChargeResponsibility;

  /// No description provided for @servicesInspectionChecklistItemTitle.
  ///
  /// In en, this message translates to:
  /// **'Checklist item {index}'**
  String servicesInspectionChecklistItemTitle(String index);

  /// No description provided for @servicesInspectionWorkType.
  ///
  /// In en, this message translates to:
  /// **'Work type'**
  String get servicesInspectionWorkType;

  /// No description provided for @servicesInspectionDescriptionForWork.
  ///
  /// In en, this message translates to:
  /// **'Description for work'**
  String get servicesInspectionDescriptionForWork;

  /// No description provided for @servicesInspectionChecklistStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesInspectionChecklistStatus;

  /// No description provided for @servicesInspectionChecklistStatusPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get servicesInspectionChecklistStatusPending;

  /// No description provided for @servicesInspectionBeforeWorkPhotos.
  ///
  /// In en, this message translates to:
  /// **'Before work photos'**
  String get servicesInspectionBeforeWorkPhotos;

  /// No description provided for @servicesInspectionAddPhotos.
  ///
  /// In en, this message translates to:
  /// **'Add photos'**
  String get servicesInspectionAddPhotos;

  /// No description provided for @servicesInspectionAddChecklist.
  ///
  /// In en, this message translates to:
  /// **'Add checklist item'**
  String get servicesInspectionAddChecklist;

  /// No description provided for @servicesInspectionRemoveChecklist.
  ///
  /// In en, this message translates to:
  /// **'Remove checklist item'**
  String get servicesInspectionRemoveChecklist;

  /// No description provided for @servicesInspectionPointTitle.
  ///
  /// In en, this message translates to:
  /// **'Point {index}'**
  String servicesInspectionPointTitle(String index);

  /// No description provided for @servicesInspectionPointDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesInspectionPointDescription;

  /// No description provided for @servicesInspectionAddPoint.
  ///
  /// In en, this message translates to:
  /// **'Add inspected point'**
  String get servicesInspectionAddPoint;

  /// No description provided for @servicesInspectionRemovePoint.
  ///
  /// In en, this message translates to:
  /// **'Remove inspected point'**
  String get servicesInspectionRemovePoint;

  /// No description provided for @servicesInspectionMaterialTitle.
  ///
  /// In en, this message translates to:
  /// **'Material {index}'**
  String servicesInspectionMaterialTitle(String index);

  /// No description provided for @servicesInspectionMaterialCode.
  ///
  /// In en, this message translates to:
  /// **'Code'**
  String get servicesInspectionMaterialCode;

  /// No description provided for @servicesInspectionMaterialDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesInspectionMaterialDescription;

  /// No description provided for @servicesInspectionMaterialStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesInspectionMaterialStatus;

  /// No description provided for @servicesInspectionMaterialStatusWaiting.
  ///
  /// In en, this message translates to:
  /// **'Waiting'**
  String get servicesInspectionMaterialStatusWaiting;

  /// No description provided for @servicesInspectionAddMaterial.
  ///
  /// In en, this message translates to:
  /// **'Add material requirement'**
  String get servicesInspectionAddMaterial;

  /// No description provided for @servicesInspectionRemoveMaterial.
  ///
  /// In en, this message translates to:
  /// **'Remove material requirement'**
  String get servicesInspectionRemoveMaterial;

  /// No description provided for @servicesInspectionDetailContext.
  ///
  /// In en, this message translates to:
  /// **'Source context'**
  String get servicesInspectionDetailContext;

  /// No description provided for @servicesInspectionDetailAssessment.
  ///
  /// In en, this message translates to:
  /// **'Assessment'**
  String get servicesInspectionDetailAssessment;

  /// No description provided for @servicesInspectionDetailChecklist.
  ///
  /// In en, this message translates to:
  /// **'Checklist'**
  String get servicesInspectionDetailChecklist;

  /// No description provided for @servicesInspectionDetailPoints.
  ///
  /// In en, this message translates to:
  /// **'Inspected points'**
  String get servicesInspectionDetailPoints;

  /// No description provided for @servicesInspectionDetailMaterials.
  ///
  /// In en, this message translates to:
  /// **'Material required'**
  String get servicesInspectionDetailMaterials;

  /// No description provided for @servicesInspectionDetailAudit.
  ///
  /// In en, this message translates to:
  /// **'Record'**
  String get servicesInspectionDetailAudit;

  /// No description provided for @servicesInspectionDetailActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesInspectionDetailActivity;

  /// No description provided for @servicesInspectionEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit inspection'**
  String get servicesInspectionEdit;

  /// No description provided for @servicesInspectionComplete.
  ///
  /// In en, this message translates to:
  /// **'Complete inspection'**
  String get servicesInspectionComplete;

  /// No description provided for @servicesInspectionCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel inspection'**
  String get servicesInspectionCancel;

  /// No description provided for @servicesInspectionCompleteConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Complete inspection?'**
  String get servicesInspectionCompleteConfirmTitle;

  /// No description provided for @servicesInspectionCompleteConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'The inspection becomes read-only and can be used by later workflow steps.'**
  String get servicesInspectionCompleteConfirmMessage;

  /// No description provided for @servicesInspectionCancelConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Cancel inspection?'**
  String get servicesInspectionCancelConfirmTitle;

  /// No description provided for @servicesInspectionCancelConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'The cancelled inspection stays available historically and cannot be edited afterwards.'**
  String get servicesInspectionCancelConfirmMessage;

  /// No description provided for @servicesInspectionCreated.
  ///
  /// In en, this message translates to:
  /// **'Inspection created.'**
  String get servicesInspectionCreated;

  /// No description provided for @servicesInspectionUpdated.
  ///
  /// In en, this message translates to:
  /// **'Inspection updated.'**
  String get servicesInspectionUpdated;

  /// No description provided for @servicesInspectionCompleted.
  ///
  /// In en, this message translates to:
  /// **'Inspection completed.'**
  String get servicesInspectionCompleted;

  /// No description provided for @servicesInspectionCancelled.
  ///
  /// In en, this message translates to:
  /// **'Inspection cancelled.'**
  String get servicesInspectionCancelled;

  /// No description provided for @servicesInspectionNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity yet.'**
  String get servicesInspectionNoActivity;

  /// No description provided for @servicesInspectionCreatedBy.
  ///
  /// In en, this message translates to:
  /// **'Created by'**
  String get servicesInspectionCreatedBy;

  /// No description provided for @servicesInspectionCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Created at'**
  String get servicesInspectionCreatedAt;

  /// No description provided for @servicesInspectionUpdatedBy.
  ///
  /// In en, this message translates to:
  /// **'Updated by'**
  String get servicesInspectionUpdatedBy;

  /// No description provided for @servicesInspectionUpdatedAt.
  ///
  /// In en, this message translates to:
  /// **'Updated at'**
  String get servicesInspectionUpdatedAt;

  /// No description provided for @servicesInspectionVersion.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get servicesInspectionVersion;

  /// No description provided for @servicesInspectionNoChecklist.
  ///
  /// In en, this message translates to:
  /// **'No checklist items.'**
  String get servicesInspectionNoChecklist;

  /// No description provided for @servicesInspectionNoPoints.
  ///
  /// In en, this message translates to:
  /// **'No inspected points.'**
  String get servicesInspectionNoPoints;

  /// No description provided for @servicesInspectionNoMaterials.
  ///
  /// In en, this message translates to:
  /// **'No material requirements.'**
  String get servicesInspectionNoMaterials;

  /// No description provided for @servicesInspectionDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to perform this action.'**
  String get servicesInspectionDenied;

  /// No description provided for @servicesInspectionNotFound.
  ///
  /// In en, this message translates to:
  /// **'Inspection not found.'**
  String get servicesInspectionNotFound;

  /// No description provided for @servicesInspectionNotEditable.
  ///
  /// In en, this message translates to:
  /// **'Only pending inspections can be edited.'**
  String get servicesInspectionNotEditable;

  /// No description provided for @servicesInspectionNotCompletable.
  ///
  /// In en, this message translates to:
  /// **'Only pending inspections can be completed.'**
  String get servicesInspectionNotCompletable;

  /// No description provided for @servicesInspectionAlreadyCancelled.
  ///
  /// In en, this message translates to:
  /// **'This inspection is already cancelled.'**
  String get servicesInspectionAlreadyCancelled;

  /// No description provided for @servicesInspectionNotCancellable.
  ///
  /// In en, this message translates to:
  /// **'A completed inspection cannot be cancelled.'**
  String get servicesInspectionNotCancellable;

  /// No description provided for @servicesInspectionAssignmentRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a job assignment.'**
  String get servicesInspectionAssignmentRequired;

  /// No description provided for @servicesInspectionAssignmentInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected job assignment is not eligible.'**
  String get servicesInspectionAssignmentInvalid;

  /// No description provided for @servicesInspectionAlreadyActive.
  ///
  /// In en, this message translates to:
  /// **'This job assignment already has an inspection.'**
  String get servicesInspectionAlreadyActive;

  /// No description provided for @servicesInspectionVisitDateRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a visit date.'**
  String get servicesInspectionVisitDateRequired;

  /// No description provided for @servicesInspectionVisitTimeRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a visit time.'**
  String get servicesInspectionVisitTimeRequired;

  /// No description provided for @servicesInspectionTechnicianRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a technician.'**
  String get servicesInspectionTechnicianRequired;

  /// No description provided for @servicesInspectionTechnicianInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected technician is not eligible for this assignment.'**
  String get servicesInspectionTechnicianInvalid;

  /// No description provided for @servicesInspectionRootCauseRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a root cause.'**
  String get servicesInspectionRootCauseRequired;

  /// No description provided for @servicesInspectionRootCauseInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected root cause is not available.'**
  String get servicesInspectionRootCauseInvalid;

  /// No description provided for @servicesInspectionChargeResponsibilityRequired.
  ///
  /// In en, this message translates to:
  /// **'Select a charge responsibility.'**
  String get servicesInspectionChargeResponsibilityRequired;

  /// No description provided for @servicesInspectionChargeResponsibilityInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected charge responsibility is not available.'**
  String get servicesInspectionChargeResponsibilityInvalid;

  /// No description provided for @servicesInspectionAssessmentRequired.
  ///
  /// In en, this message translates to:
  /// **'Add at least one checklist item or inspected point.'**
  String get servicesInspectionAssessmentRequired;

  /// No description provided for @servicesInspectionWorkTypeRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the work type for each checklist item.'**
  String get servicesInspectionWorkTypeRequired;

  /// No description provided for @servicesInspectionPointRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter a description for each inspected point.'**
  String get servicesInspectionPointRequired;

  /// No description provided for @servicesInspectionMaterialCodeRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the code for each material requirement.'**
  String get servicesInspectionMaterialCodeRequired;

  /// No description provided for @servicesInspectionMaterialDescriptionRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the description for each material requirement.'**
  String get servicesInspectionMaterialDescriptionRequired;

  /// No description provided for @servicesInspectionSequenceFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not allocate an inspection number.'**
  String get servicesInspectionSequenceFailed;

  /// No description provided for @servicesInspectionStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the inspection. Please try again.'**
  String get servicesInspectionStorageError;

  /// No description provided for @servicesActivityCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get servicesActivityCompleted;

  /// No description provided for @servicesOverviewInspectionsPending.
  ///
  /// In en, this message translates to:
  /// **'Pending inspections'**
  String get servicesOverviewInspectionsPending;

  /// No description provided for @servicesOverviewInspectionsToday.
  ///
  /// In en, this message translates to:
  /// **'Inspections today'**
  String get servicesOverviewInspectionsToday;

  /// No description provided for @servicesOverviewInspectionsCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed inspections'**
  String get servicesOverviewInspectionsCompleted;

  /// No description provided for @servicesOverviewRecentInspections.
  ///
  /// In en, this message translates to:
  /// **'Recent inspections'**
  String get servicesOverviewRecentInspections;

  /// No description provided for @servicesOverviewNoInspections.
  ///
  /// In en, this message translates to:
  /// **'No inspections yet.'**
  String get servicesOverviewNoInspections;

  /// No description provided for @servicesAssignmentInspectionSection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesAssignmentInspectionSection;

  /// No description provided for @servicesAssignmentCreateInspection.
  ///
  /// In en, this message translates to:
  /// **'Create inspection'**
  String get servicesAssignmentCreateInspection;

  /// No description provided for @servicesAssignmentViewInspection.
  ///
  /// In en, this message translates to:
  /// **'View inspection'**
  String get servicesAssignmentViewInspection;

  /// No description provided for @notifServiceInspectionAssignedTitle.
  ///
  /// In en, this message translates to:
  /// **'Inspection assigned'**
  String get notifServiceInspectionAssignedTitle;

  /// No description provided for @notifServiceInspectionAssignedBody.
  ///
  /// In en, this message translates to:
  /// **'You have been assigned a service inspection.'**
  String get notifServiceInspectionAssignedBody;

  /// No description provided for @servicesPermSubMaterialRequests.
  ///
  /// In en, this message translates to:
  /// **'Material requests'**
  String get servicesPermSubMaterialRequests;

  /// No description provided for @servicesPermMaterialRequestsView.
  ///
  /// In en, this message translates to:
  /// **'View material requests'**
  String get servicesPermMaterialRequestsView;

  /// No description provided for @servicesPermMaterialRequestsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View the company material request queue within your record scope.'**
  String get servicesPermMaterialRequestsViewDesc;

  /// No description provided for @servicesPermMaterialRequestsCreate.
  ///
  /// In en, this message translates to:
  /// **'Create material request'**
  String get servicesPermMaterialRequestsCreate;

  /// No description provided for @servicesPermMaterialRequestsCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Create a material request from an eligible completed inspection, including restricted inspection reference lookup.'**
  String get servicesPermMaterialRequestsCreateDesc;

  /// No description provided for @servicesPermMaterialRequestsEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit material request'**
  String get servicesPermMaterialRequestsEdit;

  /// No description provided for @servicesPermMaterialRequestsEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Edit an open material request.'**
  String get servicesPermMaterialRequestsEditDesc;

  /// No description provided for @servicesPermMaterialRequestsCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel material request'**
  String get servicesPermMaterialRequestsCancel;

  /// No description provided for @servicesPermMaterialRequestsCancelDesc.
  ///
  /// In en, this message translates to:
  /// **'Cancel an open material request (kept historically).'**
  String get servicesPermMaterialRequestsCancelDesc;

  /// No description provided for @servicesPermMaterialRequestsPrint.
  ///
  /// In en, this message translates to:
  /// **'Print material request'**
  String get servicesPermMaterialRequestsPrint;

  /// No description provided for @servicesPermMaterialRequestsPrintDesc.
  ///
  /// In en, this message translates to:
  /// **'Print a material request document.'**
  String get servicesPermMaterialRequestsPrintDesc;

  /// No description provided for @servicesPermMaterialRequestPurposesView.
  ///
  /// In en, this message translates to:
  /// **'View material request purposes'**
  String get servicesPermMaterialRequestPurposesView;

  /// No description provided for @servicesPermMaterialRequestPurposesViewDesc.
  ///
  /// In en, this message translates to:
  /// **'See configured material request purposes.'**
  String get servicesPermMaterialRequestPurposesViewDesc;

  /// No description provided for @servicesPermMaterialRequestPurposesManage.
  ///
  /// In en, this message translates to:
  /// **'Manage material request purposes'**
  String get servicesPermMaterialRequestPurposesManage;

  /// No description provided for @servicesPermMaterialRequestPurposesManageDesc.
  ///
  /// In en, this message translates to:
  /// **'Create and edit material request purposes.'**
  String get servicesPermMaterialRequestPurposesManageDesc;

  /// No description provided for @permissionServiceMaterialRequestView.
  ///
  /// In en, this message translates to:
  /// **'View material requests'**
  String get permissionServiceMaterialRequestView;

  /// No description provided for @permissionServiceMaterialRequestCreate.
  ///
  /// In en, this message translates to:
  /// **'Create material request'**
  String get permissionServiceMaterialRequestCreate;

  /// No description provided for @permissionServiceMaterialRequestEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit material request'**
  String get permissionServiceMaterialRequestEdit;

  /// No description provided for @permissionServiceMaterialRequestCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel material request'**
  String get permissionServiceMaterialRequestCancel;

  /// No description provided for @permissionServiceMaterialRequestPrint.
  ///
  /// In en, this message translates to:
  /// **'Print material request'**
  String get permissionServiceMaterialRequestPrint;

  /// No description provided for @servicesNavMaterialRequests.
  ///
  /// In en, this message translates to:
  /// **'Material Requests'**
  String get servicesNavMaterialRequests;

  /// No description provided for @servicesMaterialRequestPurposesTitle.
  ///
  /// In en, this message translates to:
  /// **'Material request purposes'**
  String get servicesMaterialRequestPurposesTitle;

  /// No description provided for @servicesMaterialRequestsTitle.
  ///
  /// In en, this message translates to:
  /// **'Material requests'**
  String get servicesMaterialRequestsTitle;

  /// No description provided for @servicesMaterialRequestCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} material requests'**
  String servicesMaterialRequestCount(String filtered, String total);

  /// No description provided for @servicesMaterialRequestSearch.
  ///
  /// In en, this message translates to:
  /// **'Search by request, inspection, job assignment, enquiry, job order, customer, code or description'**
  String get servicesMaterialRequestSearch;

  /// No description provided for @servicesMaterialRequestAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get servicesMaterialRequestAllStatuses;

  /// No description provided for @servicesMaterialRequestStatusOpen.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get servicesMaterialRequestStatusOpen;

  /// No description provided for @servicesMaterialRequestStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get servicesMaterialRequestStatusCancelled;

  /// No description provided for @servicesMaterialRequestEmpty.
  ///
  /// In en, this message translates to:
  /// **'No material requests yet.'**
  String get servicesMaterialRequestEmpty;

  /// No description provided for @servicesMaterialRequestEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Create a material request from a completed inspection.'**
  String get servicesMaterialRequestEmptyMessage;

  /// No description provided for @servicesMaterialRequestNoResults.
  ///
  /// In en, this message translates to:
  /// **'No material requests match your filters.'**
  String get servicesMaterialRequestNoResults;

  /// No description provided for @servicesMaterialRequestAdd.
  ///
  /// In en, this message translates to:
  /// **'New material request'**
  String get servicesMaterialRequestAdd;

  /// No description provided for @servicesMaterialRequestColumnRequest.
  ///
  /// In en, this message translates to:
  /// **'Request'**
  String get servicesMaterialRequestColumnRequest;

  /// No description provided for @servicesMaterialRequestColumnDate.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get servicesMaterialRequestColumnDate;

  /// No description provided for @servicesMaterialRequestColumnInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesMaterialRequestColumnInspection;

  /// No description provided for @servicesMaterialRequestColumnCustomerSite.
  ///
  /// In en, this message translates to:
  /// **'Customer / site'**
  String get servicesMaterialRequestColumnCustomerSite;

  /// No description provided for @servicesMaterialRequestColumnPurpose.
  ///
  /// In en, this message translates to:
  /// **'Purpose'**
  String get servicesMaterialRequestColumnPurpose;

  /// No description provided for @servicesMaterialRequestColumnItems.
  ///
  /// In en, this message translates to:
  /// **'Items'**
  String get servicesMaterialRequestColumnItems;

  /// No description provided for @servicesMaterialRequestColumnTotalQty.
  ///
  /// In en, this message translates to:
  /// **'Total qty'**
  String get servicesMaterialRequestColumnTotalQty;

  /// No description provided for @servicesMaterialRequestColumnStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesMaterialRequestColumnStatus;

  /// No description provided for @servicesMaterialRequestColumnPreparedBy.
  ///
  /// In en, this message translates to:
  /// **'Prepared by'**
  String get servicesMaterialRequestColumnPreparedBy;

  /// No description provided for @servicesMaterialRequestColumnCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get servicesMaterialRequestColumnCreated;

  /// No description provided for @servicesMaterialRequestFilterTitle.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get servicesMaterialRequestFilterTitle;

  /// No description provided for @servicesMaterialRequestFilterStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesMaterialRequestFilterStatus;

  /// No description provided for @servicesMaterialRequestFilterPurpose.
  ///
  /// In en, this message translates to:
  /// **'Purpose'**
  String get servicesMaterialRequestFilterPurpose;

  /// No description provided for @servicesMaterialRequestFilterInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesMaterialRequestFilterInspection;

  /// No description provided for @servicesMaterialRequestFilterFrom.
  ///
  /// In en, this message translates to:
  /// **'From date'**
  String get servicesMaterialRequestFilterFrom;

  /// No description provided for @servicesMaterialRequestFilterTo.
  ///
  /// In en, this message translates to:
  /// **'To date'**
  String get servicesMaterialRequestFilterTo;

  /// No description provided for @servicesMaterialRequestFormNew.
  ///
  /// In en, this message translates to:
  /// **'New material request'**
  String get servicesMaterialRequestFormNew;

  /// No description provided for @servicesMaterialRequestFormEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit material request'**
  String get servicesMaterialRequestFormEdit;

  /// No description provided for @servicesMaterialRequestCreate.
  ///
  /// In en, this message translates to:
  /// **'Create material request'**
  String get servicesMaterialRequestCreate;

  /// No description provided for @servicesMaterialRequestSaveChanges.
  ///
  /// In en, this message translates to:
  /// **'Save changes'**
  String get servicesMaterialRequestSaveChanges;

  /// No description provided for @servicesMaterialRequestSectionRequest.
  ///
  /// In en, this message translates to:
  /// **'Request'**
  String get servicesMaterialRequestSectionRequest;

  /// No description provided for @servicesMaterialRequestSectionContext.
  ///
  /// In en, this message translates to:
  /// **'Service context'**
  String get servicesMaterialRequestSectionContext;

  /// No description provided for @servicesMaterialRequestSectionInformation.
  ///
  /// In en, this message translates to:
  /// **'Request information'**
  String get servicesMaterialRequestSectionInformation;

  /// No description provided for @servicesMaterialRequestSectionMaterials.
  ///
  /// In en, this message translates to:
  /// **'Materials'**
  String get servicesMaterialRequestSectionMaterials;

  /// No description provided for @servicesMaterialRequestSectionAcknowledgement.
  ///
  /// In en, this message translates to:
  /// **'Acknowledgement'**
  String get servicesMaterialRequestSectionAcknowledgement;

  /// No description provided for @servicesMaterialRequestSectionSummary.
  ///
  /// In en, this message translates to:
  /// **'Summary'**
  String get servicesMaterialRequestSectionSummary;

  /// No description provided for @servicesMaterialRequestSectionAudit.
  ///
  /// In en, this message translates to:
  /// **'Record'**
  String get servicesMaterialRequestSectionAudit;

  /// No description provided for @servicesMaterialRequestSectionActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesMaterialRequestSectionActivity;

  /// No description provided for @servicesMaterialRequestNo.
  ///
  /// In en, this message translates to:
  /// **'Request no'**
  String get servicesMaterialRequestNo;

  /// No description provided for @servicesMaterialRequestDate.
  ///
  /// In en, this message translates to:
  /// **'Request date'**
  String get servicesMaterialRequestDate;

  /// No description provided for @servicesMaterialRequestSourceInspection.
  ///
  /// In en, this message translates to:
  /// **'Source inspection'**
  String get servicesMaterialRequestSourceInspection;

  /// No description provided for @servicesMaterialRequestSelectInspection.
  ///
  /// In en, this message translates to:
  /// **'Select an eligible completed inspection'**
  String get servicesMaterialRequestSelectInspection;

  /// No description provided for @servicesMaterialRequestInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesMaterialRequestInspection;

  /// No description provided for @servicesMaterialRequestJobAssignment.
  ///
  /// In en, this message translates to:
  /// **'Job assignment'**
  String get servicesMaterialRequestJobAssignment;

  /// No description provided for @servicesMaterialRequestEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Enquiry'**
  String get servicesMaterialRequestEnquiry;

  /// No description provided for @servicesMaterialRequestCustomer.
  ///
  /// In en, this message translates to:
  /// **'Customer'**
  String get servicesMaterialRequestCustomer;

  /// No description provided for @servicesMaterialRequestSite.
  ///
  /// In en, this message translates to:
  /// **'Site'**
  String get servicesMaterialRequestSite;

  /// No description provided for @servicesMaterialRequestTenant.
  ///
  /// In en, this message translates to:
  /// **'Tenant'**
  String get servicesMaterialRequestTenant;

  /// No description provided for @servicesMaterialRequestBuilding.
  ///
  /// In en, this message translates to:
  /// **'Building'**
  String get servicesMaterialRequestBuilding;

  /// No description provided for @servicesMaterialRequestUnit.
  ///
  /// In en, this message translates to:
  /// **'Unit'**
  String get servicesMaterialRequestUnit;

  /// No description provided for @servicesMaterialRequestMaterialReceived.
  ///
  /// In en, this message translates to:
  /// **'Material received'**
  String get servicesMaterialRequestMaterialReceived;

  /// No description provided for @servicesMaterialRequestJobOrderReference.
  ///
  /// In en, this message translates to:
  /// **'Job order reference'**
  String get servicesMaterialRequestJobOrderReference;

  /// No description provided for @servicesMaterialRequestJobOrderHint.
  ///
  /// In en, this message translates to:
  /// **'Optional external job order number'**
  String get servicesMaterialRequestJobOrderHint;

  /// No description provided for @servicesMaterialRequestPurpose.
  ///
  /// In en, this message translates to:
  /// **'Purpose'**
  String get servicesMaterialRequestPurpose;

  /// No description provided for @servicesMaterialRequestRemarks.
  ///
  /// In en, this message translates to:
  /// **'Remarks'**
  String get servicesMaterialRequestRemarks;

  /// No description provided for @servicesMaterialRequestAcknowledge.
  ///
  /// In en, this message translates to:
  /// **'Acknowledge'**
  String get servicesMaterialRequestAcknowledge;

  /// No description provided for @servicesMaterialRequestReceivedBy.
  ///
  /// In en, this message translates to:
  /// **'Received by'**
  String get servicesMaterialRequestReceivedBy;

  /// No description provided for @servicesMaterialRequestPreparedBy.
  ///
  /// In en, this message translates to:
  /// **'Prepared by'**
  String get servicesMaterialRequestPreparedBy;

  /// No description provided for @servicesMaterialRequestLineTitle.
  ///
  /// In en, this message translates to:
  /// **'Material {index}'**
  String servicesMaterialRequestLineTitle(String index);

  /// No description provided for @servicesMaterialRequestCode.
  ///
  /// In en, this message translates to:
  /// **'Code'**
  String get servicesMaterialRequestCode;

  /// No description provided for @servicesMaterialRequestDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesMaterialRequestDescription;

  /// No description provided for @servicesMaterialRequestBatchNumber.
  ///
  /// In en, this message translates to:
  /// **'Batch no'**
  String get servicesMaterialRequestBatchNumber;

  /// No description provided for @servicesMaterialRequestQuantity.
  ///
  /// In en, this message translates to:
  /// **'Quantity'**
  String get servicesMaterialRequestQuantity;

  /// No description provided for @servicesMaterialRequestRemark.
  ///
  /// In en, this message translates to:
  /// **'Remark'**
  String get servicesMaterialRequestRemark;

  /// No description provided for @servicesMaterialRequestAddMaterial.
  ///
  /// In en, this message translates to:
  /// **'Add material'**
  String get servicesMaterialRequestAddMaterial;

  /// No description provided for @servicesMaterialRequestRemoveMaterial.
  ///
  /// In en, this message translates to:
  /// **'Remove material'**
  String get servicesMaterialRequestRemoveMaterial;

  /// No description provided for @servicesMaterialRequestTotalQuantity.
  ///
  /// In en, this message translates to:
  /// **'Total quantity'**
  String get servicesMaterialRequestTotalQuantity;

  /// No description provided for @servicesMaterialRequestItemCount.
  ///
  /// In en, this message translates to:
  /// **'{count} items'**
  String servicesMaterialRequestItemCount(String count);

  /// No description provided for @servicesMaterialRequestEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit request'**
  String get servicesMaterialRequestEdit;

  /// No description provided for @servicesMaterialRequestPrint.
  ///
  /// In en, this message translates to:
  /// **'Print'**
  String get servicesMaterialRequestPrint;

  /// No description provided for @servicesMaterialRequestCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel material request'**
  String get servicesMaterialRequestCancel;

  /// No description provided for @servicesMaterialRequestCancelConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Cancel material request?'**
  String get servicesMaterialRequestCancelConfirmTitle;

  /// No description provided for @servicesMaterialRequestCancelConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'The cancelled request stays available historically and cannot be edited afterwards.'**
  String get servicesMaterialRequestCancelConfirmMessage;

  /// No description provided for @servicesMaterialRequestCreated.
  ///
  /// In en, this message translates to:
  /// **'Material request created.'**
  String get servicesMaterialRequestCreated;

  /// No description provided for @servicesMaterialRequestUpdated.
  ///
  /// In en, this message translates to:
  /// **'Material request updated.'**
  String get servicesMaterialRequestUpdated;

  /// No description provided for @servicesMaterialRequestCancelled.
  ///
  /// In en, this message translates to:
  /// **'Material request cancelled.'**
  String get servicesMaterialRequestCancelled;

  /// No description provided for @servicesMaterialRequestPrinted.
  ///
  /// In en, this message translates to:
  /// **'Material request prepared for printing.'**
  String get servicesMaterialRequestPrinted;

  /// No description provided for @servicesMaterialRequestNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity yet.'**
  String get servicesMaterialRequestNoActivity;

  /// No description provided for @servicesMaterialRequestNoMaterials.
  ///
  /// In en, this message translates to:
  /// **'No material lines.'**
  String get servicesMaterialRequestNoMaterials;

  /// No description provided for @servicesMaterialRequestCreatedBy.
  ///
  /// In en, this message translates to:
  /// **'Created by'**
  String get servicesMaterialRequestCreatedBy;

  /// No description provided for @servicesMaterialRequestCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Created at'**
  String get servicesMaterialRequestCreatedAt;

  /// No description provided for @servicesMaterialRequestUpdatedBy.
  ///
  /// In en, this message translates to:
  /// **'Updated by'**
  String get servicesMaterialRequestUpdatedBy;

  /// No description provided for @servicesMaterialRequestUpdatedAt.
  ///
  /// In en, this message translates to:
  /// **'Updated at'**
  String get servicesMaterialRequestUpdatedAt;

  /// No description provided for @servicesMaterialRequestVersion.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get servicesMaterialRequestVersion;

  /// No description provided for @servicesMaterialRequestDetailContext.
  ///
  /// In en, this message translates to:
  /// **'Source context'**
  String get servicesMaterialRequestDetailContext;

  /// No description provided for @servicesMaterialRequestDetailMaterials.
  ///
  /// In en, this message translates to:
  /// **'Material lines'**
  String get servicesMaterialRequestDetailMaterials;

  /// No description provided for @servicesMaterialRequestDetailAcknowledgement.
  ///
  /// In en, this message translates to:
  /// **'Acknowledgement'**
  String get servicesMaterialRequestDetailAcknowledgement;

  /// No description provided for @servicesMaterialRequestDetailAudit.
  ///
  /// In en, this message translates to:
  /// **'Record'**
  String get servicesMaterialRequestDetailAudit;

  /// No description provided for @servicesMaterialRequestDetailActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesMaterialRequestDetailActivity;

  /// No description provided for @servicesMaterialRequestResetForm.
  ///
  /// In en, this message translates to:
  /// **'Reset form'**
  String get servicesMaterialRequestResetForm;

  /// No description provided for @servicesMaterialRequestResetConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Reset form?'**
  String get servicesMaterialRequestResetConfirmTitle;

  /// No description provided for @servicesMaterialRequestResetConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'This clears the unsaved material request.'**
  String get servicesMaterialRequestResetConfirmMessage;

  /// No description provided for @servicesMaterialRequestDiscardChanges.
  ///
  /// In en, this message translates to:
  /// **'Discard changes'**
  String get servicesMaterialRequestDiscardChanges;

  /// No description provided for @servicesMaterialRequestCreateFromInspection.
  ///
  /// In en, this message translates to:
  /// **'Create material request'**
  String get servicesMaterialRequestCreateFromInspection;

  /// No description provided for @servicesMaterialRequestSectionForInspection.
  ///
  /// In en, this message translates to:
  /// **'Material requests'**
  String get servicesMaterialRequestSectionForInspection;

  /// No description provided for @servicesMaterialRequestNoneForInspection.
  ///
  /// In en, this message translates to:
  /// **'No material requests yet.'**
  String get servicesMaterialRequestNoneForInspection;

  /// No description provided for @servicesMaterialRequestInspectionRequired.
  ///
  /// In en, this message translates to:
  /// **'Select an inspection.'**
  String get servicesMaterialRequestInspectionRequired;

  /// No description provided for @servicesMaterialRequestInspectionInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected inspection is not eligible.'**
  String get servicesMaterialRequestInspectionInvalid;

  /// No description provided for @servicesMaterialRequestPurposeInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected purpose is not available.'**
  String get servicesMaterialRequestPurposeInvalid;

  /// No description provided for @servicesMaterialRequestLinesRequired.
  ///
  /// In en, this message translates to:
  /// **'Add at least one material line.'**
  String get servicesMaterialRequestLinesRequired;

  /// No description provided for @servicesMaterialRequestCodeRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the code for each material line.'**
  String get servicesMaterialRequestCodeRequired;

  /// No description provided for @servicesMaterialRequestDescriptionRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the description for each material line.'**
  String get servicesMaterialRequestDescriptionRequired;

  /// No description provided for @servicesMaterialRequestQuantityRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter a quantity greater than zero for each material line.'**
  String get servicesMaterialRequestQuantityRequired;

  /// No description provided for @servicesMaterialRequestNotFound.
  ///
  /// In en, this message translates to:
  /// **'Material request not found.'**
  String get servicesMaterialRequestNotFound;

  /// No description provided for @servicesMaterialRequestNotEditable.
  ///
  /// In en, this message translates to:
  /// **'Only open material requests can be edited.'**
  String get servicesMaterialRequestNotEditable;

  /// No description provided for @servicesMaterialRequestAlreadyCancelled.
  ///
  /// In en, this message translates to:
  /// **'This material request is already cancelled.'**
  String get servicesMaterialRequestAlreadyCancelled;

  /// No description provided for @servicesMaterialRequestRequirementLinked.
  ///
  /// In en, this message translates to:
  /// **'A selected material requirement is already linked to an active request.'**
  String get servicesMaterialRequestRequirementLinked;

  /// No description provided for @servicesMaterialRequestSequenceFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not allocate a request number.'**
  String get servicesMaterialRequestSequenceFailed;

  /// No description provided for @servicesMaterialRequestDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to perform this action.'**
  String get servicesMaterialRequestDenied;

  /// No description provided for @servicesMaterialRequestStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the material request. Please try again.'**
  String get servicesMaterialRequestStorageError;

  /// No description provided for @servicesMaterialRequestPrintFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not prepare the printable document.'**
  String get servicesMaterialRequestPrintFailed;

  /// No description provided for @servicesInspectionMaterialStatusRequested.
  ///
  /// In en, this message translates to:
  /// **'Requested'**
  String get servicesInspectionMaterialStatusRequested;

  /// No description provided for @servicesOverviewMaterialRequestsOpen.
  ///
  /// In en, this message translates to:
  /// **'Open material requests'**
  String get servicesOverviewMaterialRequestsOpen;

  /// No description provided for @servicesOverviewMaterialRequestsToday.
  ///
  /// In en, this message translates to:
  /// **'Material requests today'**
  String get servicesOverviewMaterialRequestsToday;

  /// No description provided for @servicesOverviewMaterialRequestsLines.
  ///
  /// In en, this message translates to:
  /// **'Requested material lines'**
  String get servicesOverviewMaterialRequestsLines;

  /// No description provided for @servicesOverviewRecentMaterialRequests.
  ///
  /// In en, this message translates to:
  /// **'Recent material requests'**
  String get servicesOverviewRecentMaterialRequests;

  /// No description provided for @servicesOverviewNoMaterialRequests.
  ///
  /// In en, this message translates to:
  /// **'No material requests yet.'**
  String get servicesOverviewNoMaterialRequests;

  /// No description provided for @servicesMaterialRequestPrintTitle.
  ///
  /// In en, this message translates to:
  /// **'Material request'**
  String get servicesMaterialRequestPrintTitle;

  /// No description provided for @servicesActivityLinesChanged.
  ///
  /// In en, this message translates to:
  /// **'Material lines changed'**
  String get servicesActivityLinesChanged;

  /// No description provided for @servicesNavWorkExecution.
  ///
  /// In en, this message translates to:
  /// **'Work Execution'**
  String get servicesNavWorkExecution;

  /// No description provided for @servicesPermSubWorkExecutions.
  ///
  /// In en, this message translates to:
  /// **'Work Execution'**
  String get servicesPermSubWorkExecutions;

  /// No description provided for @servicesPermWorkExecutionsView.
  ///
  /// In en, this message translates to:
  /// **'View Work Executions'**
  String get servicesPermWorkExecutionsView;

  /// No description provided for @servicesPermWorkExecutionsViewDesc.
  ///
  /// In en, this message translates to:
  /// **'View the Work Execution queue within your record scope.'**
  String get servicesPermWorkExecutionsViewDesc;

  /// No description provided for @servicesPermWorkExecutionsCreate.
  ///
  /// In en, this message translates to:
  /// **'Create Work Execution'**
  String get servicesPermWorkExecutionsCreate;

  /// No description provided for @servicesPermWorkExecutionsCreateDesc.
  ///
  /// In en, this message translates to:
  /// **'Create a Work Execution from a completed inspection, with a restricted eligible-inspection search.'**
  String get servicesPermWorkExecutionsCreateDesc;

  /// No description provided for @servicesPermWorkExecutionsEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit Work Execution'**
  String get servicesPermWorkExecutionsEdit;

  /// No description provided for @servicesPermWorkExecutionsEditDesc.
  ///
  /// In en, this message translates to:
  /// **'Modify header references and work lines while eligible.'**
  String get servicesPermWorkExecutionsEditDesc;

  /// No description provided for @servicesPermWorkExecutionsPerform.
  ///
  /// In en, this message translates to:
  /// **'Perform Work'**
  String get servicesPermWorkExecutionsPerform;

  /// No description provided for @servicesPermWorkExecutionsPerformDesc.
  ///
  /// In en, this message translates to:
  /// **'Start and end assigned work, record material used and add after-work photos.'**
  String get servicesPermWorkExecutionsPerformDesc;

  /// No description provided for @servicesPermWorkExecutionsComplete.
  ///
  /// In en, this message translates to:
  /// **'Complete Work Execution'**
  String get servicesPermWorkExecutionsComplete;

  /// No description provided for @servicesPermWorkExecutionsCompleteDesc.
  ///
  /// In en, this message translates to:
  /// **'Finalize a Work Execution once all required work is finished.'**
  String get servicesPermWorkExecutionsCompleteDesc;

  /// No description provided for @servicesPermWorkExecutionsCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel Work Execution'**
  String get servicesPermWorkExecutionsCancel;

  /// No description provided for @servicesPermWorkExecutionsCancelDesc.
  ///
  /// In en, this message translates to:
  /// **'Cancel a Work Execution (kept historically).'**
  String get servicesPermWorkExecutionsCancelDesc;

  /// No description provided for @permissionServiceWorkExecutionView.
  ///
  /// In en, this message translates to:
  /// **'View Work Executions'**
  String get permissionServiceWorkExecutionView;

  /// No description provided for @permissionServiceWorkExecutionCreate.
  ///
  /// In en, this message translates to:
  /// **'Create Work Execution'**
  String get permissionServiceWorkExecutionCreate;

  /// No description provided for @permissionServiceWorkExecutionEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit Work Execution'**
  String get permissionServiceWorkExecutionEdit;

  /// No description provided for @permissionServiceWorkExecutionPerform.
  ///
  /// In en, this message translates to:
  /// **'Perform Work'**
  String get permissionServiceWorkExecutionPerform;

  /// No description provided for @permissionServiceWorkExecutionComplete.
  ///
  /// In en, this message translates to:
  /// **'Complete Work Execution'**
  String get permissionServiceWorkExecutionComplete;

  /// No description provided for @permissionServiceWorkExecutionCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel Work Execution'**
  String get permissionServiceWorkExecutionCancel;

  /// No description provided for @servicesActivityWorkStarted.
  ///
  /// In en, this message translates to:
  /// **'Work started'**
  String get servicesActivityWorkStarted;

  /// No description provided for @servicesActivityWorkEnded.
  ///
  /// In en, this message translates to:
  /// **'Work ended'**
  String get servicesActivityWorkEnded;

  /// No description provided for @servicesActivityMaterialUsedAdded.
  ///
  /// In en, this message translates to:
  /// **'Material used added'**
  String get servicesActivityMaterialUsedAdded;

  /// No description provided for @servicesActivityMaterialUsedRemoved.
  ///
  /// In en, this message translates to:
  /// **'Material used removed'**
  String get servicesActivityMaterialUsedRemoved;

  /// No description provided for @servicesActivityPhotoAdded.
  ///
  /// In en, this message translates to:
  /// **'After-work photos added'**
  String get servicesActivityPhotoAdded;

  /// No description provided for @servicesActivityPhotoUpdated.
  ///
  /// In en, this message translates to:
  /// **'After-work photo updated'**
  String get servicesActivityPhotoUpdated;

  /// No description provided for @servicesActivityPhotoRemoved.
  ///
  /// In en, this message translates to:
  /// **'After-work photo removed'**
  String get servicesActivityPhotoRemoved;

  /// No description provided for @servicesWorkExecutionStatusPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get servicesWorkExecutionStatusPending;

  /// No description provided for @servicesWorkExecutionStatusInProgress.
  ///
  /// In en, this message translates to:
  /// **'In progress'**
  String get servicesWorkExecutionStatusInProgress;

  /// No description provided for @servicesWorkExecutionStatusCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get servicesWorkExecutionStatusCompleted;

  /// No description provided for @servicesWorkExecutionStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get servicesWorkExecutionStatusCancelled;

  /// No description provided for @servicesWorkExecutionLineStateNotStarted.
  ///
  /// In en, this message translates to:
  /// **'Not started'**
  String get servicesWorkExecutionLineStateNotStarted;

  /// No description provided for @servicesWorkExecutionLineStateInProgress.
  ///
  /// In en, this message translates to:
  /// **'In progress'**
  String get servicesWorkExecutionLineStateInProgress;

  /// No description provided for @servicesWorkExecutionLineStateFinished.
  ///
  /// In en, this message translates to:
  /// **'Finished'**
  String get servicesWorkExecutionLineStateFinished;

  /// No description provided for @servicesWorkExecutionsTitle.
  ///
  /// In en, this message translates to:
  /// **'Work Execution'**
  String get servicesWorkExecutionsTitle;

  /// No description provided for @servicesWorkExecutionCount.
  ///
  /// In en, this message translates to:
  /// **'{filtered} of {total} work executions'**
  String servicesWorkExecutionCount(String filtered, String total);

  /// No description provided for @servicesWorkExecutionAdd.
  ///
  /// In en, this message translates to:
  /// **'New work execution'**
  String get servicesWorkExecutionAdd;

  /// No description provided for @servicesWorkExecutionEmpty.
  ///
  /// In en, this message translates to:
  /// **'No work executions yet.'**
  String get servicesWorkExecutionEmpty;

  /// No description provided for @servicesWorkExecutionEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Create a work execution from a completed inspection.'**
  String get servicesWorkExecutionEmptyMessage;

  /// No description provided for @servicesWorkExecutionNoResults.
  ///
  /// In en, this message translates to:
  /// **'No work executions match your filters.'**
  String get servicesWorkExecutionNoResults;

  /// No description provided for @servicesWorkExecutionSearch.
  ///
  /// In en, this message translates to:
  /// **'Search by execution, inspection, assignment, enquiry, job order reference, quotation reference, customer, site, employee, team or material code'**
  String get servicesWorkExecutionSearch;

  /// No description provided for @servicesWorkExecutionFilterTitle.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get servicesWorkExecutionFilterTitle;

  /// No description provided for @servicesWorkExecutionFilterStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesWorkExecutionFilterStatus;

  /// No description provided for @servicesWorkExecutionFilterFrom.
  ///
  /// In en, this message translates to:
  /// **'From date'**
  String get servicesWorkExecutionFilterFrom;

  /// No description provided for @servicesWorkExecutionFilterTo.
  ///
  /// In en, this message translates to:
  /// **'To date'**
  String get servicesWorkExecutionFilterTo;

  /// No description provided for @servicesWorkExecutionAllStatuses.
  ///
  /// In en, this message translates to:
  /// **'All statuses'**
  String get servicesWorkExecutionAllStatuses;

  /// No description provided for @servicesWorkExecutionColumnExecution.
  ///
  /// In en, this message translates to:
  /// **'Execution'**
  String get servicesWorkExecutionColumnExecution;

  /// No description provided for @servicesWorkExecutionColumnInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesWorkExecutionColumnInspection;

  /// No description provided for @servicesWorkExecutionColumnCustomerSite.
  ///
  /// In en, this message translates to:
  /// **'Customer / site'**
  String get servicesWorkExecutionColumnCustomerSite;

  /// No description provided for @servicesWorkExecutionColumnAssignedTo.
  ///
  /// In en, this message translates to:
  /// **'Assigned to'**
  String get servicesWorkExecutionColumnAssignedTo;

  /// No description provided for @servicesWorkExecutionColumnState.
  ///
  /// In en, this message translates to:
  /// **'Execution state'**
  String get servicesWorkExecutionColumnState;

  /// No description provided for @servicesWorkExecutionColumnStarted.
  ///
  /// In en, this message translates to:
  /// **'Started'**
  String get servicesWorkExecutionColumnStarted;

  /// No description provided for @servicesWorkExecutionColumnCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get servicesWorkExecutionColumnCompleted;

  /// No description provided for @servicesWorkExecutionColumnStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get servicesWorkExecutionColumnStatus;

  /// No description provided for @servicesWorkExecutionColumnCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get servicesWorkExecutionColumnCreated;

  /// No description provided for @servicesWorkExecutionCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel work execution'**
  String get servicesWorkExecutionCancel;

  /// No description provided for @servicesWorkExecutionCancelConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Cancel work execution?'**
  String get servicesWorkExecutionCancelConfirmTitle;

  /// No description provided for @servicesWorkExecutionCancelConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'The cancelled work execution stays available historically and cannot be edited afterwards.'**
  String get servicesWorkExecutionCancelConfirmMessage;

  /// No description provided for @servicesWorkExecutionCancelled.
  ///
  /// In en, this message translates to:
  /// **'This work execution is cancelled.'**
  String get servicesWorkExecutionCancelled;

  /// No description provided for @servicesWorkExecutionStorageError.
  ///
  /// In en, this message translates to:
  /// **'Could not save the work execution. Please try again.'**
  String get servicesWorkExecutionStorageError;

  /// No description provided for @servicesWorkExecutionFormNew.
  ///
  /// In en, this message translates to:
  /// **'New work execution'**
  String get servicesWorkExecutionFormNew;

  /// No description provided for @servicesWorkExecutionFormEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit work execution'**
  String get servicesWorkExecutionFormEdit;

  /// No description provided for @servicesWorkExecutionCreate.
  ///
  /// In en, this message translates to:
  /// **'Create work execution'**
  String get servicesWorkExecutionCreate;

  /// No description provided for @servicesWorkExecutionSaveChanges.
  ///
  /// In en, this message translates to:
  /// **'Save changes'**
  String get servicesWorkExecutionSaveChanges;

  /// No description provided for @servicesWorkExecutionResetForm.
  ///
  /// In en, this message translates to:
  /// **'Reset form'**
  String get servicesWorkExecutionResetForm;

  /// No description provided for @servicesWorkExecutionResetConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Reset form?'**
  String get servicesWorkExecutionResetConfirmTitle;

  /// No description provided for @servicesWorkExecutionResetConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'This clears the unsaved work execution.'**
  String get servicesWorkExecutionResetConfirmMessage;

  /// No description provided for @servicesWorkExecutionSectionContext.
  ///
  /// In en, this message translates to:
  /// **'Work execution context'**
  String get servicesWorkExecutionSectionContext;

  /// No description provided for @servicesWorkExecutionSectionReferences.
  ///
  /// In en, this message translates to:
  /// **'Workflow references'**
  String get servicesWorkExecutionSectionReferences;

  /// No description provided for @servicesWorkExecutionSectionCustomer.
  ///
  /// In en, this message translates to:
  /// **'Customer & service context'**
  String get servicesWorkExecutionSectionCustomer;

  /// No description provided for @servicesWorkExecutionSectionInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection summary'**
  String get servicesWorkExecutionSectionInspection;

  /// No description provided for @servicesWorkExecutionSectionWork.
  ///
  /// In en, this message translates to:
  /// **'Work execution'**
  String get servicesWorkExecutionSectionWork;

  /// No description provided for @servicesWorkExecutionSectionMaterials.
  ///
  /// In en, this message translates to:
  /// **'Material used'**
  String get servicesWorkExecutionSectionMaterials;

  /// No description provided for @servicesWorkExecutionSectionPhotos.
  ///
  /// In en, this message translates to:
  /// **'Photos after work'**
  String get servicesWorkExecutionSectionPhotos;

  /// No description provided for @servicesWorkExecutionNo.
  ///
  /// In en, this message translates to:
  /// **'Execution no'**
  String get servicesWorkExecutionNo;

  /// No description provided for @servicesWorkExecutionDate.
  ///
  /// In en, this message translates to:
  /// **'Execution date'**
  String get servicesWorkExecutionDate;

  /// No description provided for @servicesWorkExecutionSourceInspection.
  ///
  /// In en, this message translates to:
  /// **'Source inspection'**
  String get servicesWorkExecutionSourceInspection;

  /// No description provided for @servicesWorkExecutionSelectInspection.
  ///
  /// In en, this message translates to:
  /// **'Select an eligible completed inspection'**
  String get servicesWorkExecutionSelectInspection;

  /// No description provided for @servicesWorkExecutionInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesWorkExecutionInspection;

  /// No description provided for @servicesWorkExecutionJobAssignment.
  ///
  /// In en, this message translates to:
  /// **'Job assignment'**
  String get servicesWorkExecutionJobAssignment;

  /// No description provided for @servicesWorkExecutionEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Enquiry'**
  String get servicesWorkExecutionEnquiry;

  /// No description provided for @servicesWorkExecutionJobOrderReference.
  ///
  /// In en, this message translates to:
  /// **'Job order reference'**
  String get servicesWorkExecutionJobOrderReference;

  /// No description provided for @servicesWorkExecutionSectionOrderReferences.
  ///
  /// In en, this message translates to:
  /// **'Order references'**
  String get servicesWorkExecutionSectionOrderReferences;

  /// No description provided for @servicesWorkExecutionQuotationReference.
  ///
  /// In en, this message translates to:
  /// **'Quotation reference'**
  String get servicesWorkExecutionQuotationReference;

  /// No description provided for @servicesWorkExecutionCustomer.
  ///
  /// In en, this message translates to:
  /// **'Customer'**
  String get servicesWorkExecutionCustomer;

  /// No description provided for @servicesWorkExecutionTenant.
  ///
  /// In en, this message translates to:
  /// **'Tenant'**
  String get servicesWorkExecutionTenant;

  /// No description provided for @servicesWorkExecutionBuilding.
  ///
  /// In en, this message translates to:
  /// **'Building'**
  String get servicesWorkExecutionBuilding;

  /// No description provided for @servicesWorkExecutionUnit.
  ///
  /// In en, this message translates to:
  /// **'Unit'**
  String get servicesWorkExecutionUnit;

  /// No description provided for @servicesWorkExecutionComplaint.
  ///
  /// In en, this message translates to:
  /// **'Complaint type'**
  String get servicesWorkExecutionComplaint;

  /// No description provided for @servicesWorkExecutionPriority.
  ///
  /// In en, this message translates to:
  /// **'Priority'**
  String get servicesWorkExecutionPriority;

  /// No description provided for @servicesWorkExecutionMaterialReceived.
  ///
  /// In en, this message translates to:
  /// **'Material received'**
  String get servicesWorkExecutionMaterialReceived;

  /// No description provided for @servicesWorkExecutionRootCause.
  ///
  /// In en, this message translates to:
  /// **'Root cause'**
  String get servicesWorkExecutionRootCause;

  /// No description provided for @servicesWorkExecutionChargeResponsibility.
  ///
  /// In en, this message translates to:
  /// **'Charge responsibility'**
  String get servicesWorkExecutionChargeResponsibility;

  /// No description provided for @servicesWorkExecutionTechnician.
  ///
  /// In en, this message translates to:
  /// **'Technician'**
  String get servicesWorkExecutionTechnician;

  /// No description provided for @servicesWorkExecutionChecklist.
  ///
  /// In en, this message translates to:
  /// **'Checklist'**
  String get servicesWorkExecutionChecklist;

  /// No description provided for @servicesWorkExecutionInspectedPoints.
  ///
  /// In en, this message translates to:
  /// **'Inspected points'**
  String get servicesWorkExecutionInspectedPoints;

  /// No description provided for @servicesWorkExecutionMaterialRequirements.
  ///
  /// In en, this message translates to:
  /// **'Material requirements'**
  String get servicesWorkExecutionMaterialRequirements;

  /// No description provided for @servicesWorkExecutionLinkedMaterialRequests.
  ///
  /// In en, this message translates to:
  /// **'Linked material requests'**
  String get servicesWorkExecutionLinkedMaterialRequests;

  /// No description provided for @servicesWorkExecutionMaterialRequestItems.
  ///
  /// In en, this message translates to:
  /// **'{count} items'**
  String servicesWorkExecutionMaterialRequestItems(String count);

  /// No description provided for @servicesWorkExecutionAddFromMaterialRequest.
  ///
  /// In en, this message translates to:
  /// **'Add from material request'**
  String get servicesWorkExecutionAddFromMaterialRequest;

  /// No description provided for @servicesWorkExecutionNoLinkedRequests.
  ///
  /// In en, this message translates to:
  /// **'No linked material requests.'**
  String get servicesWorkExecutionNoLinkedRequests;

  /// No description provided for @servicesWorkExecutionLineTitle.
  ///
  /// In en, this message translates to:
  /// **'Work item {index}'**
  String servicesWorkExecutionLineTitle(String index);

  /// No description provided for @servicesWorkExecutionMaterialTitle.
  ///
  /// In en, this message translates to:
  /// **'Material {index}'**
  String servicesWorkExecutionMaterialTitle(String index);

  /// No description provided for @servicesWorkExecutionPhotoTitle.
  ///
  /// In en, this message translates to:
  /// **'Photo evidence {index}'**
  String servicesWorkExecutionPhotoTitle(String index);

  /// No description provided for @servicesWorkExecutionWork.
  ///
  /// In en, this message translates to:
  /// **'Work'**
  String get servicesWorkExecutionWork;

  /// No description provided for @servicesWorkExecutionDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesWorkExecutionDescription;

  /// No description provided for @servicesWorkExecutionTeam.
  ///
  /// In en, this message translates to:
  /// **'Team'**
  String get servicesWorkExecutionTeam;

  /// No description provided for @servicesWorkExecutionEmployee.
  ///
  /// In en, this message translates to:
  /// **'Individual employee'**
  String get servicesWorkExecutionEmployee;

  /// No description provided for @servicesWorkExecutionStartTime.
  ///
  /// In en, this message translates to:
  /// **'Start time'**
  String get servicesWorkExecutionStartTime;

  /// No description provided for @servicesWorkExecutionEndTime.
  ///
  /// In en, this message translates to:
  /// **'End time'**
  String get servicesWorkExecutionEndTime;

  /// No description provided for @servicesWorkExecutionNoLines.
  ///
  /// In en, this message translates to:
  /// **'No work items.'**
  String get servicesWorkExecutionNoLines;

  /// No description provided for @servicesWorkExecutionAddLine.
  ///
  /// In en, this message translates to:
  /// **'Add work item'**
  String get servicesWorkExecutionAddLine;

  /// No description provided for @servicesWorkExecutionRemoveLine.
  ///
  /// In en, this message translates to:
  /// **'Remove work item'**
  String get servicesWorkExecutionRemoveLine;

  /// No description provided for @servicesWorkExecutionCode.
  ///
  /// In en, this message translates to:
  /// **'Code'**
  String get servicesWorkExecutionCode;

  /// No description provided for @servicesWorkExecutionNoMaterials.
  ///
  /// In en, this message translates to:
  /// **'No material used.'**
  String get servicesWorkExecutionNoMaterials;

  /// No description provided for @servicesWorkExecutionAddMaterial.
  ///
  /// In en, this message translates to:
  /// **'Add material used'**
  String get servicesWorkExecutionAddMaterial;

  /// No description provided for @servicesWorkExecutionRemoveMaterial.
  ///
  /// In en, this message translates to:
  /// **'Remove material used'**
  String get servicesWorkExecutionRemoveMaterial;

  /// No description provided for @servicesWorkExecutionPhotoDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get servicesWorkExecutionPhotoDescription;

  /// No description provided for @servicesWorkExecutionPhotos.
  ///
  /// In en, this message translates to:
  /// **'Photos'**
  String get servicesWorkExecutionPhotos;

  /// No description provided for @servicesWorkExecutionAddPhotos.
  ///
  /// In en, this message translates to:
  /// **'Add photos'**
  String get servicesWorkExecutionAddPhotos;

  /// No description provided for @servicesWorkExecutionNoPhotos.
  ///
  /// In en, this message translates to:
  /// **'No photos.'**
  String get servicesWorkExecutionNoPhotos;

  /// No description provided for @servicesWorkExecutionAddPhoto.
  ///
  /// In en, this message translates to:
  /// **'Add photo evidence'**
  String get servicesWorkExecutionAddPhoto;

  /// No description provided for @servicesWorkExecutionRemovePhoto.
  ///
  /// In en, this message translates to:
  /// **'Remove photo evidence'**
  String get servicesWorkExecutionRemovePhoto;

  /// No description provided for @servicesWorkExecutionCreated.
  ///
  /// In en, this message translates to:
  /// **'Work execution created.'**
  String get servicesWorkExecutionCreated;

  /// No description provided for @servicesWorkExecutionUpdated.
  ///
  /// In en, this message translates to:
  /// **'Work execution updated.'**
  String get servicesWorkExecutionUpdated;

  /// No description provided for @servicesWorkExecutionWorkRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the work for each line.'**
  String get servicesWorkExecutionWorkRequired;

  /// No description provided for @servicesWorkExecutionDetailReferences.
  ///
  /// In en, this message translates to:
  /// **'Workflow references'**
  String get servicesWorkExecutionDetailReferences;

  /// No description provided for @servicesWorkExecutionDetailContext.
  ///
  /// In en, this message translates to:
  /// **'Customer & service context'**
  String get servicesWorkExecutionDetailContext;

  /// No description provided for @servicesWorkExecutionDetailWork.
  ///
  /// In en, this message translates to:
  /// **'Work items'**
  String get servicesWorkExecutionDetailWork;

  /// No description provided for @servicesWorkExecutionDetailMaterials.
  ///
  /// In en, this message translates to:
  /// **'Material used'**
  String get servicesWorkExecutionDetailMaterials;

  /// No description provided for @servicesWorkExecutionDetailPhotos.
  ///
  /// In en, this message translates to:
  /// **'Photos'**
  String get servicesWorkExecutionDetailPhotos;

  /// No description provided for @servicesWorkExecutionDetailAudit.
  ///
  /// In en, this message translates to:
  /// **'Record'**
  String get servicesWorkExecutionDetailAudit;

  /// No description provided for @servicesWorkExecutionDetailActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get servicesWorkExecutionDetailActivity;

  /// No description provided for @servicesWorkExecutionStartWork.
  ///
  /// In en, this message translates to:
  /// **'Start work'**
  String get servicesWorkExecutionStartWork;

  /// No description provided for @servicesWorkExecutionEndWork.
  ///
  /// In en, this message translates to:
  /// **'End work'**
  String get servicesWorkExecutionEndWork;

  /// No description provided for @servicesWorkExecutionComplete.
  ///
  /// In en, this message translates to:
  /// **'Complete work execution'**
  String get servicesWorkExecutionComplete;

  /// No description provided for @servicesWorkExecutionCompleteConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Complete work execution?'**
  String get servicesWorkExecutionCompleteConfirmTitle;

  /// No description provided for @servicesWorkExecutionCompleteConfirmMessage.
  ///
  /// In en, this message translates to:
  /// **'The work execution becomes read-only and stays available historically.'**
  String get servicesWorkExecutionCompleteConfirmMessage;

  /// No description provided for @servicesWorkExecutionCompleted.
  ///
  /// In en, this message translates to:
  /// **'Work execution completed.'**
  String get servicesWorkExecutionCompleted;

  /// No description provided for @servicesWorkExecutionPreparedBy.
  ///
  /// In en, this message translates to:
  /// **'Prepared by'**
  String get servicesWorkExecutionPreparedBy;

  /// No description provided for @servicesWorkExecutionCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Created at'**
  String get servicesWorkExecutionCreatedAt;

  /// No description provided for @servicesWorkExecutionUpdatedBy.
  ///
  /// In en, this message translates to:
  /// **'Updated by'**
  String get servicesWorkExecutionUpdatedBy;

  /// No description provided for @servicesWorkExecutionUpdatedAt.
  ///
  /// In en, this message translates to:
  /// **'Updated at'**
  String get servicesWorkExecutionUpdatedAt;

  /// No description provided for @servicesWorkExecutionVersion.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get servicesWorkExecutionVersion;

  /// No description provided for @servicesWorkExecutionNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity yet.'**
  String get servicesWorkExecutionNoActivity;

  /// No description provided for @servicesWorkExecutionWorkStarted.
  ///
  /// In en, this message translates to:
  /// **'Work started.'**
  String get servicesWorkExecutionWorkStarted;

  /// No description provided for @servicesWorkExecutionWorkEnded.
  ///
  /// In en, this message translates to:
  /// **'Work ended.'**
  String get servicesWorkExecutionWorkEnded;

  /// No description provided for @servicesWorkExecutionMaterialAdded.
  ///
  /// In en, this message translates to:
  /// **'Material used added.'**
  String get servicesWorkExecutionMaterialAdded;

  /// No description provided for @servicesWorkExecutionMaterialRemoved.
  ///
  /// In en, this message translates to:
  /// **'Material used removed.'**
  String get servicesWorkExecutionMaterialRemoved;

  /// No description provided for @servicesWorkExecutionPhotoAdded.
  ///
  /// In en, this message translates to:
  /// **'Photo evidence added.'**
  String get servicesWorkExecutionPhotoAdded;

  /// No description provided for @servicesWorkExecutionPhotoRemoved.
  ///
  /// In en, this message translates to:
  /// **'Photo evidence removed.'**
  String get servicesWorkExecutionPhotoRemoved;

  /// No description provided for @servicesWorkExecutionBeforeWorkPhotos.
  ///
  /// In en, this message translates to:
  /// **'Before work photos'**
  String get servicesWorkExecutionBeforeWorkPhotos;

  /// No description provided for @servicesWorkExecutionAfterWorkPhotos.
  ///
  /// In en, this message translates to:
  /// **'After work photos'**
  String get servicesWorkExecutionAfterWorkPhotos;

  /// No description provided for @servicesWorkExecutionEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit work execution'**
  String get servicesWorkExecutionEdit;

  /// No description provided for @servicesWorkExecutionDenied.
  ///
  /// In en, this message translates to:
  /// **'You do not have permission to perform this action.'**
  String get servicesWorkExecutionDenied;

  /// No description provided for @servicesWorkExecutionNotFound.
  ///
  /// In en, this message translates to:
  /// **'Work execution not found.'**
  String get servicesWorkExecutionNotFound;

  /// No description provided for @servicesWorkExecutionNotEditable.
  ///
  /// In en, this message translates to:
  /// **'Only pending or in-progress work executions can be edited.'**
  String get servicesWorkExecutionNotEditable;

  /// No description provided for @servicesWorkExecutionNotCompletable.
  ///
  /// In en, this message translates to:
  /// **'All required work items must be started and ended before completion.'**
  String get servicesWorkExecutionNotCompletable;

  /// No description provided for @servicesWorkExecutionAlreadyCompleted.
  ///
  /// In en, this message translates to:
  /// **'This work execution is already completed.'**
  String get servicesWorkExecutionAlreadyCompleted;

  /// No description provided for @servicesWorkExecutionLineAlreadyStarted.
  ///
  /// In en, this message translates to:
  /// **'This work item is already started.'**
  String get servicesWorkExecutionLineAlreadyStarted;

  /// No description provided for @servicesWorkExecutionLineNotStarted.
  ///
  /// In en, this message translates to:
  /// **'Start the work item before ending it.'**
  String get servicesWorkExecutionLineNotStarted;

  /// No description provided for @servicesWorkExecutionLineAlreadyEnded.
  ///
  /// In en, this message translates to:
  /// **'This work item is already ended.'**
  String get servicesWorkExecutionLineAlreadyEnded;

  /// No description provided for @servicesWorkExecutionInvalidTimeRange.
  ///
  /// In en, this message translates to:
  /// **'The end time cannot be before the start time.'**
  String get servicesWorkExecutionInvalidTimeRange;

  /// No description provided for @servicesWorkExecutionInspectionRequired.
  ///
  /// In en, this message translates to:
  /// **'Select an inspection.'**
  String get servicesWorkExecutionInspectionRequired;

  /// No description provided for @servicesWorkExecutionInspectionNotEligible.
  ///
  /// In en, this message translates to:
  /// **'The selected inspection is not eligible.'**
  String get servicesWorkExecutionInspectionNotEligible;

  /// No description provided for @servicesWorkExecutionAlreadyActive.
  ///
  /// In en, this message translates to:
  /// **'An active work execution already exists for this inspection.'**
  String get servicesWorkExecutionAlreadyActive;

  /// No description provided for @servicesWorkExecutionSequenceFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not allocate a work execution number.'**
  String get servicesWorkExecutionSequenceFailed;

  /// No description provided for @servicesWorkExecutionLinesRequired.
  ///
  /// In en, this message translates to:
  /// **'Add at least one work item.'**
  String get servicesWorkExecutionLinesRequired;

  /// No description provided for @servicesWorkExecutionCodeRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the code for each material used line.'**
  String get servicesWorkExecutionCodeRequired;

  /// No description provided for @servicesWorkExecutionDescriptionRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter the description for each material used line.'**
  String get servicesWorkExecutionDescriptionRequired;

  /// No description provided for @servicesWorkExecutionPhotoDescriptionRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter a description for each photo entry.'**
  String get servicesWorkExecutionPhotoDescriptionRequired;

  /// No description provided for @servicesWorkExecutionTeamInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected team is not available.'**
  String get servicesWorkExecutionTeamInvalid;

  /// No description provided for @servicesWorkExecutionEmployeeInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected employee is not available.'**
  String get servicesWorkExecutionEmployeeInvalid;

  /// No description provided for @servicesWorkExecutionMaterialRequestLineInvalid.
  ///
  /// In en, this message translates to:
  /// **'The selected material request line is not available.'**
  String get servicesWorkExecutionMaterialRequestLineInvalid;

  /// No description provided for @servicesOverviewWorkExecutionsPending.
  ///
  /// In en, this message translates to:
  /// **'Pending work executions'**
  String get servicesOverviewWorkExecutionsPending;

  /// No description provided for @servicesOverviewWorkExecutionsInProgress.
  ///
  /// In en, this message translates to:
  /// **'Work in progress'**
  String get servicesOverviewWorkExecutionsInProgress;

  /// No description provided for @servicesOverviewWorkExecutionsCompletedToday.
  ///
  /// In en, this message translates to:
  /// **'Completed today'**
  String get servicesOverviewWorkExecutionsCompletedToday;

  /// No description provided for @servicesOverviewRecentWorkExecutions.
  ///
  /// In en, this message translates to:
  /// **'Recent work executions'**
  String get servicesOverviewRecentWorkExecutions;

  /// No description provided for @servicesOverviewNoWorkExecutions.
  ///
  /// In en, this message translates to:
  /// **'No work executions yet.'**
  String get servicesOverviewNoWorkExecutions;

  /// No description provided for @servicesInspectionWorkExecutionSection.
  ///
  /// In en, this message translates to:
  /// **'Work execution'**
  String get servicesInspectionWorkExecutionSection;

  /// No description provided for @servicesInspectionCreateWorkExecution.
  ///
  /// In en, this message translates to:
  /// **'Create work execution'**
  String get servicesInspectionCreateWorkExecution;

  /// No description provided for @servicesInspectionNoWorkExecution.
  ///
  /// In en, this message translates to:
  /// **'No work execution yet.'**
  String get servicesInspectionNoWorkExecution;

  /// No description provided for @servicesAssignmentWorkExecutionSection.
  ///
  /// In en, this message translates to:
  /// **'Work execution'**
  String get servicesAssignmentWorkExecutionSection;

  /// No description provided for @servicesEnquiryWorkExecutionSection.
  ///
  /// In en, this message translates to:
  /// **'Work execution'**
  String get servicesEnquiryWorkExecutionSection;

  /// No description provided for @servicesWorkflowTitle.
  ///
  /// In en, this message translates to:
  /// **'Workflow'**
  String get servicesWorkflowTitle;

  /// No description provided for @servicesWorkflowStageEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Service enquiry'**
  String get servicesWorkflowStageEnquiry;

  /// No description provided for @servicesWorkflowStageJobAssignment.
  ///
  /// In en, this message translates to:
  /// **'Job assignment'**
  String get servicesWorkflowStageJobAssignment;

  /// No description provided for @servicesWorkflowStageInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get servicesWorkflowStageInspection;

  /// No description provided for @servicesWorkflowStageMaterialRequest.
  ///
  /// In en, this message translates to:
  /// **'Material request'**
  String get servicesWorkflowStageMaterialRequest;

  /// No description provided for @servicesWorkflowStageWorkExecution.
  ///
  /// In en, this message translates to:
  /// **'Work execution'**
  String get servicesWorkflowStageWorkExecution;

  /// No description provided for @servicesWorkflowNotCreated.
  ///
  /// In en, this message translates to:
  /// **'Not required / none created'**
  String get servicesWorkflowNotCreated;

  /// No description provided for @servicesWorkflowNotAvailable.
  ///
  /// In en, this message translates to:
  /// **'Not available'**
  String get servicesWorkflowNotAvailable;

  /// No description provided for @servicesWorkflowOptional.
  ///
  /// In en, this message translates to:
  /// **'Optional'**
  String get servicesWorkflowOptional;

  /// No description provided for @servicesWorkflowStatusAwaitingAssignment.
  ///
  /// In en, this message translates to:
  /// **'Awaiting assignment'**
  String get servicesWorkflowStatusAwaitingAssignment;

  /// No description provided for @servicesWorkflowStatusScheduled.
  ///
  /// In en, this message translates to:
  /// **'Scheduled'**
  String get servicesWorkflowStatusScheduled;

  /// No description provided for @servicesWorkflowStatusInspectionPending.
  ///
  /// In en, this message translates to:
  /// **'Inspection pending'**
  String get servicesWorkflowStatusInspectionPending;

  /// No description provided for @servicesWorkflowStatusInspectionCompleted.
  ///
  /// In en, this message translates to:
  /// **'Inspection completed'**
  String get servicesWorkflowStatusInspectionCompleted;

  /// No description provided for @servicesWorkflowStatusMaterialsRequested.
  ///
  /// In en, this message translates to:
  /// **'Materials requested'**
  String get servicesWorkflowStatusMaterialsRequested;

  /// No description provided for @servicesWorkflowStatusWorkInProgress.
  ///
  /// In en, this message translates to:
  /// **'Work in progress'**
  String get servicesWorkflowStatusWorkInProgress;

  /// No description provided for @servicesWorkflowStatusWorkCompleted.
  ///
  /// In en, this message translates to:
  /// **'Work completed'**
  String get servicesWorkflowStatusWorkCompleted;

  /// No description provided for @servicesWorkflowStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get servicesWorkflowStatusCancelled;

  /// No description provided for @servicesWorkflowStatusUnknown.
  ///
  /// In en, this message translates to:
  /// **'In progress'**
  String get servicesWorkflowStatusUnknown;

  /// No description provided for @servicesWorkflowActivityTitle.
  ///
  /// In en, this message translates to:
  /// **'Workflow activity'**
  String get servicesWorkflowActivityTitle;

  /// No description provided for @servicesWorkflowNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No workflow activity yet.'**
  String get servicesWorkflowNoActivity;

  /// No description provided for @servicesWorkflowNextActions.
  ///
  /// In en, this message translates to:
  /// **'Next actions'**
  String get servicesWorkflowNextActions;

  /// No description provided for @servicesWorkflowMaterialWaiting.
  ///
  /// In en, this message translates to:
  /// **'{count} material requirement(s) waiting'**
  String servicesWorkflowMaterialWaiting(String count);

  /// No description provided for @servicesWorkflowActionCreateAssignment.
  ///
  /// In en, this message translates to:
  /// **'Create job assignment'**
  String get servicesWorkflowActionCreateAssignment;

  /// No description provided for @servicesWorkflowActionViewAssignment.
  ///
  /// In en, this message translates to:
  /// **'View job assignment'**
  String get servicesWorkflowActionViewAssignment;

  /// No description provided for @servicesWorkflowActionCreateInspection.
  ///
  /// In en, this message translates to:
  /// **'Create inspection'**
  String get servicesWorkflowActionCreateInspection;

  /// No description provided for @servicesWorkflowActionViewInspection.
  ///
  /// In en, this message translates to:
  /// **'View inspection'**
  String get servicesWorkflowActionViewInspection;

  /// No description provided for @servicesWorkflowActionCreateMaterialRequest.
  ///
  /// In en, this message translates to:
  /// **'Create material request'**
  String get servicesWorkflowActionCreateMaterialRequest;

  /// No description provided for @servicesWorkflowActionViewMaterialRequest.
  ///
  /// In en, this message translates to:
  /// **'View material request'**
  String get servicesWorkflowActionViewMaterialRequest;

  /// No description provided for @servicesWorkflowActionCreateWorkExecution.
  ///
  /// In en, this message translates to:
  /// **'Create work execution'**
  String get servicesWorkflowActionCreateWorkExecution;

  /// No description provided for @servicesWorkflowActionViewWorkExecution.
  ///
  /// In en, this message translates to:
  /// **'View work execution'**
  String get servicesWorkflowActionViewWorkExecution;

  /// No description provided for @servicesWorkflowActionPerform.
  ///
  /// In en, this message translates to:
  /// **'Start / end work'**
  String get servicesWorkflowActionPerform;

  /// No description provided for @servicesWorkflowActionComplete.
  ///
  /// In en, this message translates to:
  /// **'Complete'**
  String get servicesWorkflowActionComplete;

  /// No description provided for @servicesWorkflowActionCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get servicesWorkflowActionCancel;

  /// No description provided for @servicesWorkflowActionEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get servicesWorkflowActionEdit;

  /// No description provided for @servicesWorkflowActionPrint.
  ///
  /// In en, this message translates to:
  /// **'Print'**
  String get servicesWorkflowActionPrint;

  /// No description provided for @servicesWorkflowEvidenceTitle.
  ///
  /// In en, this message translates to:
  /// **'Work evidence'**
  String get servicesWorkflowEvidenceTitle;

  /// No description provided for @servicesWorkflowBeforeWork.
  ///
  /// In en, this message translates to:
  /// **'Before work'**
  String get servicesWorkflowBeforeWork;

  /// No description provided for @servicesWorkflowAfterWork.
  ///
  /// In en, this message translates to:
  /// **'After work'**
  String get servicesWorkflowAfterWork;

  /// No description provided for @servicesWorkflowNoBeforePhotos.
  ///
  /// In en, this message translates to:
  /// **'No before-work photos.'**
  String get servicesWorkflowNoBeforePhotos;

  /// No description provided for @servicesWorkflowNoAfterPhotos.
  ///
  /// In en, this message translates to:
  /// **'No after-work photos.'**
  String get servicesWorkflowNoAfterPhotos;

  /// No description provided for @servicesOverviewMyWork.
  ///
  /// In en, this message translates to:
  /// **'My work'**
  String get servicesOverviewMyWork;

  /// No description provided for @servicesOverviewMyWorkAssignments.
  ///
  /// In en, this message translates to:
  /// **'My assignments'**
  String get servicesOverviewMyWorkAssignments;

  /// No description provided for @servicesOverviewMyWorkInspections.
  ///
  /// In en, this message translates to:
  /// **'My pending inspections'**
  String get servicesOverviewMyWorkInspections;

  /// No description provided for @servicesOverviewMyWorkExecutions.
  ///
  /// In en, this message translates to:
  /// **'My active work'**
  String get servicesOverviewMyWorkExecutions;

  /// No description provided for @servicesOverviewNoMyWork.
  ///
  /// In en, this message translates to:
  /// **'No assigned work right now.'**
  String get servicesOverviewNoMyWork;

  /// No description provided for @servicesOverviewWorkflowTitle.
  ///
  /// In en, this message translates to:
  /// **'Operational workflow'**
  String get servicesOverviewWorkflowTitle;

  /// No description provided for @servicesDashboardSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Operational overview of your service workflow'**
  String get servicesDashboardSubtitle;

  /// No description provided for @servicesDashboardScopeAssigned.
  ///
  /// In en, this message translates to:
  /// **'Viewing: Assigned work'**
  String get servicesDashboardScopeAssigned;

  /// No description provided for @servicesDashboardScopeTeam.
  ///
  /// In en, this message translates to:
  /// **'Viewing: Team scope'**
  String get servicesDashboardScopeTeam;

  /// No description provided for @servicesDashboardScopeAll.
  ///
  /// In en, this message translates to:
  /// **'Viewing: All company services'**
  String get servicesDashboardScopeAll;

  /// No description provided for @servicesDashboardScopeNone.
  ///
  /// In en, this message translates to:
  /// **'Viewing: No service scope'**
  String get servicesDashboardScopeNone;

  /// No description provided for @servicesDashboardToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get servicesDashboardToday;

  /// No description provided for @servicesDashboardKpiOpenEnquiries.
  ///
  /// In en, this message translates to:
  /// **'Open enquiries'**
  String get servicesDashboardKpiOpenEnquiries;

  /// No description provided for @servicesDashboardKpiOpenEnquiriesContext.
  ///
  /// In en, this message translates to:
  /// **'Awaiting assignment'**
  String get servicesDashboardKpiOpenEnquiriesContext;

  /// No description provided for @servicesDashboardKpiScheduledJobs.
  ///
  /// In en, this message translates to:
  /// **'Scheduled jobs'**
  String get servicesDashboardKpiScheduledJobs;

  /// No description provided for @servicesDashboardKpiScheduledJobsContext.
  ///
  /// In en, this message translates to:
  /// **'Active field visits'**
  String get servicesDashboardKpiScheduledJobsContext;

  /// No description provided for @servicesDashboardKpiPendingInspections.
  ///
  /// In en, this message translates to:
  /// **'Pending inspections'**
  String get servicesDashboardKpiPendingInspections;

  /// No description provided for @servicesDashboardKpiPendingInspectionsContext.
  ///
  /// In en, this message translates to:
  /// **'Awaiting completion'**
  String get servicesDashboardKpiPendingInspectionsContext;

  /// No description provided for @servicesDashboardKpiOpenMaterialRequests.
  ///
  /// In en, this message translates to:
  /// **'Open material requests'**
  String get servicesDashboardKpiOpenMaterialRequests;

  /// No description provided for @servicesDashboardKpiOpenMaterialRequestsContext.
  ///
  /// In en, this message translates to:
  /// **'Optional workflow branch'**
  String get servicesDashboardKpiOpenMaterialRequestsContext;

  /// No description provided for @servicesDashboardKpiWorkInProgress.
  ///
  /// In en, this message translates to:
  /// **'Work in progress'**
  String get servicesDashboardKpiWorkInProgress;

  /// No description provided for @servicesDashboardKpiWorkInProgressContext.
  ///
  /// In en, this message translates to:
  /// **'Active on site'**
  String get servicesDashboardKpiWorkInProgressContext;

  /// No description provided for @servicesDashboardKpiCompletedToday.
  ///
  /// In en, this message translates to:
  /// **'Completed today'**
  String get servicesDashboardKpiCompletedToday;

  /// No description provided for @servicesDashboardKpiCompletedTodayContext.
  ///
  /// In en, this message translates to:
  /// **'Company-local day'**
  String get servicesDashboardKpiCompletedTodayContext;

  /// No description provided for @servicesDashboardNeedsAttention.
  ///
  /// In en, this message translates to:
  /// **'Needs attention'**
  String get servicesDashboardNeedsAttention;

  /// No description provided for @servicesDashboardTodaySchedule.
  ///
  /// In en, this message translates to:
  /// **'Today\'s schedule'**
  String get servicesDashboardTodaySchedule;

  /// No description provided for @servicesDashboardMyWork.
  ///
  /// In en, this message translates to:
  /// **'My work'**
  String get servicesDashboardMyWork;

  /// No description provided for @servicesDashboardTeamWorkload.
  ///
  /// In en, this message translates to:
  /// **'Team workload'**
  String get servicesDashboardTeamWorkload;

  /// No description provided for @servicesDashboardWorkflowOverview.
  ///
  /// In en, this message translates to:
  /// **'Workflow overview'**
  String get servicesDashboardWorkflowOverview;

  /// No description provided for @servicesDashboardRecentActivity.
  ///
  /// In en, this message translates to:
  /// **'Recent activity'**
  String get servicesDashboardRecentActivity;

  /// No description provided for @servicesDashboardQuickActions.
  ///
  /// In en, this message translates to:
  /// **'Quick actions'**
  String get servicesDashboardQuickActions;

  /// No description provided for @servicesDashboardAllCaughtUp.
  ///
  /// In en, this message translates to:
  /// **'You\'re all caught up.'**
  String get servicesDashboardAllCaughtUp;

  /// No description provided for @servicesDashboardNoSchedule.
  ///
  /// In en, this message translates to:
  /// **'No visits scheduled today.'**
  String get servicesDashboardNoSchedule;

  /// No description provided for @servicesDashboardNoMyWork.
  ///
  /// In en, this message translates to:
  /// **'Nothing currently assigned.'**
  String get servicesDashboardNoMyWork;

  /// No description provided for @servicesDashboardNoActivity.
  ///
  /// In en, this message translates to:
  /// **'No recent service activity.'**
  String get servicesDashboardNoActivity;

  /// No description provided for @servicesDashboardNoTeamWorkload.
  ///
  /// In en, this message translates to:
  /// **'No active team workload.'**
  String get servicesDashboardNoTeamWorkload;

  /// No description provided for @servicesDashboardEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No service activity yet'**
  String get servicesDashboardEmptyTitle;

  /// No description provided for @servicesDashboardEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'Create your first Service Enquiry to begin the workflow.'**
  String get servicesDashboardEmptyMessage;

  /// No description provided for @servicesDashboardEmptyAssignedTitle.
  ///
  /// In en, this message translates to:
  /// **'No work assigned to you right now.'**
  String get servicesDashboardEmptyAssignedTitle;

  /// No description provided for @servicesDashboardEmptyAssignedMessage.
  ///
  /// In en, this message translates to:
  /// **'New assignments and inspections will appear here automatically.'**
  String get servicesDashboardEmptyAssignedMessage;

  /// No description provided for @servicesDashboardError.
  ///
  /// In en, this message translates to:
  /// **'The services dashboard could not be loaded.'**
  String get servicesDashboardError;

  /// No description provided for @servicesDashboardAttentionOpenEnquiry.
  ///
  /// In en, this message translates to:
  /// **'Open enquiry with no active job assignment'**
  String get servicesDashboardAttentionOpenEnquiry;

  /// No description provided for @servicesDashboardAttentionVisitNoInspection.
  ///
  /// In en, this message translates to:
  /// **'Visit scheduled today without an inspection'**
  String get servicesDashboardAttentionVisitNoInspection;

  /// No description provided for @servicesDashboardAttentionInspectionToday.
  ///
  /// In en, this message translates to:
  /// **'Inspection scheduled for today'**
  String get servicesDashboardAttentionInspectionToday;

  /// No description provided for @servicesDashboardAttentionWaitingMaterials.
  ///
  /// In en, this message translates to:
  /// **'Inspection has waiting material requirements'**
  String get servicesDashboardAttentionWaitingMaterials;

  /// No description provided for @servicesDashboardAttentionOpenMaterialRequest.
  ///
  /// In en, this message translates to:
  /// **'Open material request'**
  String get servicesDashboardAttentionOpenMaterialRequest;

  /// No description provided for @servicesDashboardAttentionActiveWork.
  ///
  /// In en, this message translates to:
  /// **'Work execution has an active work line'**
  String get servicesDashboardAttentionActiveWork;

  /// No description provided for @servicesDashboardActionOpenInspection.
  ///
  /// In en, this message translates to:
  /// **'Open inspection'**
  String get servicesDashboardActionOpenInspection;

  /// No description provided for @servicesDashboardActionViewEnquiry.
  ///
  /// In en, this message translates to:
  /// **'View enquiry'**
  String get servicesDashboardActionViewEnquiry;

  /// No description provided for @servicesDashboardActionCreateAssignment.
  ///
  /// In en, this message translates to:
  /// **'Create job assignment'**
  String get servicesDashboardActionCreateAssignment;

  /// No description provided for @servicesDashboardActionOpenMaterialRequest.
  ///
  /// In en, this message translates to:
  /// **'Open material request'**
  String get servicesDashboardActionOpenMaterialRequest;

  /// No description provided for @servicesDashboardActionOpenWork.
  ///
  /// In en, this message translates to:
  /// **'Open work execution'**
  String get servicesDashboardActionOpenWork;

  /// No description provided for @servicesDashboardActionViewAssignment.
  ///
  /// In en, this message translates to:
  /// **'View assignment'**
  String get servicesDashboardActionViewAssignment;

  /// No description provided for @servicesDashboardActionStartWork.
  ///
  /// In en, this message translates to:
  /// **'Start work'**
  String get servicesDashboardActionStartWork;

  /// No description provided for @servicesDashboardActionContinueWork.
  ///
  /// In en, this message translates to:
  /// **'Continue work'**
  String get servicesDashboardActionContinueWork;

  /// No description provided for @servicesDashboardTeamActiveSuffix.
  ///
  /// In en, this message translates to:
  /// **'active'**
  String get servicesDashboardTeamActiveSuffix;

  /// No description provided for @servicesDashboardTeamTodaySuffix.
  ///
  /// In en, this message translates to:
  /// **'today'**
  String get servicesDashboardTeamTodaySuffix;

  /// No description provided for @servicesDashboardTeamInProgressSuffix.
  ///
  /// In en, this message translates to:
  /// **'in progress'**
  String get servicesDashboardTeamInProgressSuffix;

  /// No description provided for @servicesDashboardQuickCreateAssignment.
  ///
  /// In en, this message translates to:
  /// **'Create job assignment'**
  String get servicesDashboardQuickCreateAssignment;

  /// No description provided for @servicesDashboardQuickNewInspection.
  ///
  /// In en, this message translates to:
  /// **'New inspection'**
  String get servicesDashboardQuickNewInspection;

  /// No description provided for @servicesDashboardQuickNewMaterialRequest.
  ///
  /// In en, this message translates to:
  /// **'New material request'**
  String get servicesDashboardQuickNewMaterialRequest;

  /// No description provided for @servicesDashboardQuickNewWorkExecution.
  ///
  /// In en, this message translates to:
  /// **'New work execution'**
  String get servicesDashboardQuickNewWorkExecution;

  /// No description provided for @servicesDashboardDueToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get servicesDashboardDueToday;

  /// No description provided for @servicesDashboardWaitingMaterials.
  ///
  /// In en, this message translates to:
  /// **'waiting material requirements'**
  String get servicesDashboardWaitingMaterials;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar':
      return AppLocalizationsAr();
    case 'en':
      return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}

// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appName => 'بيت لوجيكس ERP';

  @override
  String get brandName => 'بيت لوجيكس';

  @override
  String get save => 'حفظ';

  @override
  String get cancel => 'إلغاء';

  @override
  String get close => 'إغلاق';

  @override
  String get confirm => 'تأكيد';

  @override
  String get delete => 'حذف';

  @override
  String get edit => 'تعديل';

  @override
  String get add => 'إضافة';

  @override
  String get search => 'بحث';

  @override
  String get filter => 'تصفية';

  @override
  String get clear => 'مسح';

  @override
  String get retry => 'إعادة المحاولة';

  @override
  String get refresh => 'تحديث';

  @override
  String get continueAction => 'متابعة';

  @override
  String get back => 'رجوع';

  @override
  String get next => 'التالي';

  @override
  String get done => 'تم';

  @override
  String get yes => 'نعم';

  @override
  String get no => 'لا';

  @override
  String get loading => 'جارٍ التحميل';

  @override
  String get error => 'خطأ';

  @override
  String get success => 'نجاح';

  @override
  String get warning => 'تنبيه';

  @override
  String get noData => 'لا توجد بيانات';

  @override
  String get somethingWentWrong => 'حدث خطأ غير متوقع';

  @override
  String get home => 'الرئيسية';

  @override
  String get more => 'المزيد';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get phone => 'الهاتف';

  @override
  String get emailOrPhone => 'البريد الإلكتروني أو الهاتف';

  @override
  String get password => 'كلمة المرور';

  @override
  String get language => 'اللغة';

  @override
  String get english => 'الإنجليزية';

  @override
  String get arabic => 'العربية';

  @override
  String get active => 'نشط';

  @override
  String get inactive => 'غير نشط';

  @override
  String get pending => 'قيد الانتظار';

  @override
  String get approved => 'مقبول';

  @override
  String get rejected => 'مرفوض';

  @override
  String get failed => 'فشل';

  @override
  String get synced => 'تمت المزامنة';

  @override
  String get draft => 'مسودة';

  @override
  String get scheduled => 'مجدول';

  @override
  String get actions => 'الإجراءات';

  @override
  String get primaryAction => 'الإجراء الرئيسي';

  @override
  String get previewActionComplete => 'اكتمل إجراء المعاينة';

  @override
  String get secondaryAction => 'إجراء ثانوي';

  @override
  String get textAction => 'إجراء نصي';

  @override
  String get moreOptions => 'خيارات إضافية';

  @override
  String get disabled => 'غير متاح';

  @override
  String get saving => 'جارٍ الحفظ';

  @override
  String get fullName => 'الاسم الكامل';

  @override
  String get enterName => 'أدخل الاسم';

  @override
  String get validationExample => 'مثال على التحقق';

  @override
  String get informationCard => 'بطاقة معلومات';

  @override
  String get informationCardMessage =>
      'استخدم شرحًا موجزًا لمساعدة المستخدمين على اتخاذ القرار.';

  @override
  String get statusAndFeedback => 'الحالة والملاحظات';

  @override
  String get localChangesAvailable => 'تغييراتك متاحة على هذا الجهاز.';

  @override
  String get recordsNeedAttention => 'بعض السجلات تحتاج إلى اهتمامك.';

  @override
  String get actionFailed => 'تعذر إكمال هذا الإجراء.';

  @override
  String get loadingRecords => 'جارٍ تحميل السجلات…';

  @override
  String get noRecordsYet => 'لا توجد سجلات بعد';

  @override
  String get noRecordsMessage => 'ستظهر السجلات هنا عندما يبدأ فريقك العمل.';

  @override
  String get retryWhenConnected => 'يرجى إعادة المحاولة عند توفر الاتصال.';

  @override
  String get filtersAndTable => 'الفلاتر والجدول';

  @override
  String get status => 'الحالة';

  @override
  String get pageNotFound => 'تعذر العثور على هذه الصفحة.';

  @override
  String get showPassword => 'إظهار كلمة المرور';

  @override
  String get hidePassword => 'إخفاء كلمة المرور';

  @override
  String get searchRecords => 'البحث في السجلات';

  @override
  String get selectDate => 'اختر التاريخ';

  @override
  String get selectTime => 'اختر الوقت';

  @override
  String get unableToLoadRecords => 'تعذر تحميل السجلات';

  @override
  String get noRecords => 'لا توجد سجلات';

  @override
  String get previousPage => 'الصفحة السابقة';

  @override
  String get nextPage => 'الصفحة التالية';

  @override
  String get fieldRequired => 'هذا الحقل مطلوب';

  @override
  String get emailRequired => 'البريد الإلكتروني مطلوب';

  @override
  String get emailInvalid => 'أدخل عنوان بريد إلكتروني صحيحًا';

  @override
  String get failureTimeout => 'انتهت مهلة الطلب. يرجى إعادة المحاولة.';

  @override
  String get failureOffline =>
      'الاتصال غير متاح. لا تزال بياناتك المحلية متاحة.';

  @override
  String get failureCancelled => 'تم إلغاء الطلب.';

  @override
  String get failureSessionExpired => 'انتهت صلاحية جلستك.';

  @override
  String get failureRequest => 'تعذر إكمال الطلب.';

  @override
  String get failureInvalidData => 'تعذر قراءة الاستجابة.';

  @override
  String get failureLocationDisabled => 'فعّل خدمات الموقع للمتابعة.';

  @override
  String get failureLocationPermission =>
      'يتطلب هذا الإجراء إذن الوصول إلى الموقع.';

  @override
  String get failureLocationUnavailable => 'تعذر تحديد موقعك.';

  @override
  String get failureStorageWrite => 'تعذر حفظ التغييرات على هذا الجهاز.';

  @override
  String get failureStorageUpdate => 'تعذر تحديث التغييرات المحلية.';

  @override
  String get failureSync => 'تعذرت مزامنة بعض التغييرات.';

  @override
  String get failurePreferencesWrite =>
      'تغيّرت لغة هذه الجلسة، لكن تعذر حفظ التفضيل.';

  @override
  String get failurePreferencesRead => 'تعذر استعادة اللغة المحفوظة.';

  @override
  String get formattingTitle => 'تنسيق حسب اللغة';

  @override
  String get date => 'التاريخ';

  @override
  String get time => 'الوقت';

  @override
  String get duration => 'المدة';

  @override
  String get number => 'العدد';

  @override
  String get percentage => 'النسبة المئوية';

  @override
  String get currency => 'العملة';

  @override
  String get month => 'الشهر';

  @override
  String paginationSummary(String start, String end, String total) {
    return '$start–$end من $total';
  }

  @override
  String get navSectionHr => 'الموارد البشرية';

  @override
  String get navSectionServices => 'الخدمات';

  @override
  String get navSectionSettings => 'الإعدادات';

  @override
  String get navSectionAccount => 'الحساب';

  @override
  String durationHoursMinutes(String hours, String minutes) {
    return '$hours س $minutes د';
  }

  @override
  String durationHoursOnly(String hours) {
    return '$hours س';
  }

  @override
  String get selectOption => 'اختر خيارًا';

  @override
  String get noSelection => 'غير محدد';

  @override
  String timeRange(String start, String end) {
    return '$start ← $end';
  }

  @override
  String dateTimeValue(String date, String time) {
    return '$date · $time';
  }

  @override
  String labeledValue(String label, String value) {
    return '$label: $value';
  }

  @override
  String get viewDetails => 'عرض التفاصيل';

  @override
  String get filters => 'الفلاتر';

  @override
  String get moreFilters => 'مزيد من الفلاتر';

  @override
  String get resetFilters => 'إعادة تعيين';

  @override
  String get periodLabel => 'الفترة';

  @override
  String get settings => 'الإعدادات';

  @override
  String get profile => 'الملف الشخصي';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get forgotPassword => 'نسيت كلمة المرور';

  @override
  String get changePassword => 'تغيير كلمة المرور';

  @override
  String get welcomeBack => 'مرحبًا بعودتك';

  @override
  String get workspace => 'مساحة العمل';

  @override
  String get overview => 'نظرة عامة';

  @override
  String get internal => 'داخلي';

  @override
  String get designSystem => 'نظام التصميم';

  @override
  String get erpWorkspace => 'مساحة عمل ERP';

  @override
  String get foundationPhase => 'الأساس / المرحلة صفر';

  @override
  String get designPreview => 'معاينة التصميم';

  @override
  String get designSystemSubtitle => 'اللغة البصرية الموحدة لمساحة عمل ERP.';

  @override
  String get internalPreview => 'معاينة داخلية';

  @override
  String get openDialog => 'فتح مربع الحوار';

  @override
  String get reviewChanges => 'مراجعة التغييرات';

  @override
  String get confirmationPreview => 'هذه معاينة لمربع حوار التأكيد الموحد.';

  @override
  String get looksGood => 'مناسب';

  @override
  String get consistencyNotice =>
      'تصميم متسق. تستخدم جميع الوحدات المستقبلية هذه الأسس.';

  @override
  String get designLanguage => 'اللغة البصرية';

  @override
  String get oneSystem => 'نظام موحد';

  @override
  String get sharedAcrossModules => 'مشترك بين جميع الوحدات';

  @override
  String get dataStrategy => 'استراتيجية البيانات';

  @override
  String get localFirst => 'التخزين المحلي أولًا';

  @override
  String get repositorySourceOfTruth => 'المستودعات هي المصدر المعتمد للبيانات';

  @override
  String get layout => 'التخطيط';

  @override
  String get adaptive => 'متكيف';

  @override
  String get adaptiveDetail => 'من الشاشات الصغيرة إلى مساحات العمل الكبيرة';

  @override
  String get typography => 'الخطوط';

  @override
  String get typographySubtitle => 'خطوط محلية / وضوح في جميع أحجام العرض';

  @override
  String get typographyDisplay => 'العرض الرئيسي';

  @override
  String get typographyPageTitle => 'عنوان الصفحة';

  @override
  String get typographySectionTitle => 'عنوان القسم';

  @override
  String get typographyCardTitle => 'عنوان البطاقة';

  @override
  String get typographyBodyLarge => 'النص الكبير';

  @override
  String get typographyBody => 'النص الأساسي';

  @override
  String get typographyBodySmall => 'النص الصغير';

  @override
  String get typographyLabel => 'التسمية';

  @override
  String get typographyCaption => 'النص التوضيحي';

  @override
  String get semanticPalette => 'ألوان ذات دلالات واضحة';

  @override
  String get colorBrand => 'العلامة التجارية';

  @override
  String get colorSurface => 'السطح';

  @override
  String get colorBackground => 'الخلفية';

  @override
  String get colorBorder => 'الحدود';

  @override
  String get colorTextPrimary => 'النص الأساسي';

  @override
  String get colorTextSecondary => 'النص الثانوي';

  @override
  String get colorTextMuted => 'النص الخافت';

  @override
  String get colorDanger => 'خطر';

  @override
  String get colorInfo => 'معلومات';

  @override
  String get formControls => 'عناصر النموذج';

  @override
  String get formControlsSubtitle =>
      'تنسيق موحد للحقول والتحقق وتسميات يسهل الوصول إليها.';

  @override
  String get illustrativeRecords =>
      'سجلات توضيحية / لا تتضمن بيانات موظفين فعلية';

  @override
  String get activeOnly => 'النشط فقط';

  @override
  String get clearFilters => 'مسح الفلاتر';

  @override
  String get sampleAlex => 'أليكس مورغان';

  @override
  String get sampleSam => 'سام تايلور';

  @override
  String get dialogsAndSheets => 'مربعات الحوار واللوحات';

  @override
  String get previewDialog => 'معاينة مربع الحوار';

  @override
  String get sharedDialog => 'مربع حوار موحد';

  @override
  String get sharedDialogMessage => 'محتوى موجز يساعد على اتخاذ قرار واضح.';

  @override
  String get previewBottomSheet => 'معاينة اللوحة السفلية';

  @override
  String get quickDetails => 'تفاصيل سريعة';

  @override
  String get quickDetailsSubtitle => 'نمط عرض موحد للأجهزة المحمولة.';

  @override
  String get foundationDetails => 'تفاصيل الأساس';

  @override
  String get architecture => 'البنية';

  @override
  String get featureFirst => 'تنظيم حسب الميزات';

  @override
  String get theme => 'المظهر';

  @override
  String get lightSemanticTokens => 'مظهر فاتح / رموز دلالية';

  @override
  String get persistence => 'التخزين الدائم';

  @override
  String get persistenceDetail => 'Drift وتخزين آمن للجلسة';

  @override
  String get internalPreviewPhase => 'معاينة داخلية / المرحلة صفر';

  @override
  String get workspaceTitle => 'أساس لما هو قادم';

  @override
  String get workspaceSubtitle => 'مساحة عمل واحدة لجميع وحدات ERP.';

  @override
  String get workspaceInfoTitle => 'نظام ERP يبدأ هنا';

  @override
  String get workspaceInfoMessage =>
      'البنية التي تعتمد التخزين المحلي أولًا ونظام التصميم الموحد جاهزان. ستُضاف وحدات الأعمال في المراحل القادمة.';

  @override
  String get phaseReady => 'المرحلة صفر / الأساس جاهز';

  @override
  String get languageSubtitle => 'تتغير اللغة واتجاه العرض فورًا.';

  @override
  String get englishNativeName => 'English';

  @override
  String get arabicNativeName => 'العربية';

  @override
  String typographySample(String level) {
    return '$level / مصمم للوضوح';
  }

  @override
  String get authWelcomeBack => 'مرحبًا بعودتك';

  @override
  String get authSignInSubtitle => 'سجّل الدخول إلى مساحة عمل Bitlogix.';

  @override
  String get authIdentifier => 'البريد الإلكتروني أو رقم الهاتف';

  @override
  String get authIdentifierHint => 'مثال: name@company.com';

  @override
  String get authIdentifierRequired => 'البريد الإلكتروني أو رقم الهاتف مطلوب';

  @override
  String get authIdentifierInvalid =>
      'أدخل بريدًا إلكترونيًا أو رقم هاتف صالحًا';

  @override
  String get authPasswordRequired => 'كلمة المرور مطلوبة';

  @override
  String get authInvalidCredentials =>
      'البريد الإلكتروني أو رقم الهاتف أو كلمة المرور غير صحيحة.';

  @override
  String get authLoggingIn => 'جارٍ تسجيل الدخول…';

  @override
  String get authBrandStatement => 'مساحة عمل مترابطة.\nويوم عمل أكثر وضوحًا.';

  @override
  String get authBrandDescription =>
      'مكان واحد لفريقك وعملياتك والأعمال القادمة.';

  @override
  String get authWorkspaceLabel => 'مساحة عمل الشركة';

  @override
  String get authSecureSession => 'تبقى جلستك آمنة على هذا الجهاز.';

  @override
  String get authSecureSessionLabel => 'جلسة آمنة';

  @override
  String get authWorkforce => 'القوى العاملة';

  @override
  String get authActiveEmployees => 'موظف نشط';

  @override
  String get authWorking => 'العمل';

  @override
  String get authAttendanceActive => 'الحضور نشط';

  @override
  String get authLive => 'مباشر';

  @override
  String get authDeveloperAccess => 'دخول المطوّر';

  @override
  String get productEyebrow => 'مساحة عمل أعمال معيارية';

  @override
  String get productHeadline => 'كل ما يديره عملك.\nمتصل في مكان واحد.';

  @override
  String get productWorkspaceTitle => 'مساحة عمل Bitlogix';

  @override
  String get productWorkspaceSubtitle => 'نظام أعمال موحّد';

  @override
  String get productWorkspaceFooter => 'متصل عبر مساحة عمل واحدة';

  @override
  String get modulePeople => 'الأفراد';

  @override
  String get moduleOperations => 'العمليات';

  @override
  String get moduleOperationsDesc => 'سير العمل';

  @override
  String get moduleCustomers => 'العملاء';

  @override
  String get moduleCustomersDesc => 'العلاقات';

  @override
  String get moduleFinance => 'المالية';

  @override
  String get moduleServices => 'الخدمات';

  @override
  String get moduleServicesDesc => 'طلبات الخدمة';

  @override
  String get moduleInventory => 'المخزون';

  @override
  String get moduleInventoryDesc => 'الأصول';

  @override
  String get moduleReports => 'التقارير';

  @override
  String get moduleReportsDesc => 'تصدير مجدول';

  @override
  String get moduleInsights => 'الرؤى';

  @override
  String get moduleInsightsDesc => 'نظرة عامة';

  @override
  String get authWorkdayTitle => 'يوم عملك،\nفي مكان واحد.';

  @override
  String get authWorkingDay => 'يوم العمل';

  @override
  String get authNow => 'الآن';

  @override
  String get authShiftGeneral => 'الدوام العام';

  @override
  String get authShiftToday => 'اليوم';

  @override
  String get authWorkLocationMain => 'المكتب الرئيسي';

  @override
  String authEmployeesActiveCount(int count) {
    return '$count موظفًا نشطًا';
  }

  @override
  String get authDemoUse => 'استخدام حساب تجريبي';

  @override
  String get authSessionNote =>
      'تبقى جلستك مفتوحة على هذا الجهاز حتى تسجّل الخروج أو تنتهي صلاحيتها.';

  @override
  String get authInitializing => 'جارٍ تجهيز مساحة عملك…';

  @override
  String get authDemoAccounts => 'حسابات تجريبية';

  @override
  String get authDemoNotice => 'عرض تجريبي محلي فقط. لا يوجد اتصال بخادم.';

  @override
  String get authDemoDisabled =>
      'المصادقة التجريبية غير مفعّلة في هذا الإعداد. لم يتم ربط خادم بعد.';

  @override
  String get authDemoPassword => 'كلمة المرور التجريبية';

  @override
  String get authSessionStorageError =>
      'تعذّر الوصول إلى الجلسة الآمنة. يُرجى المحاولة مجددًا.';

  @override
  String get authServerError =>
      'خدمة تسجيل الدخول غير متاحة مؤقتًا. يُرجى المحاولة مجددًا.';

  @override
  String get authForgotTitle => 'إعادة تعيين كلمة المرور';

  @override
  String get authForgotSubtitle =>
      'أدخل البريد الإلكتروني أو رقم الهاتف المرتبط بحسابك.';

  @override
  String get authResetInformation =>
      'إذا كان هناك حساب يطابق هذه البيانات، فسيتم إرسال تعليمات إعادة تعيين كلمة المرور.';

  @override
  String get authResetDemoNote =>
      'لا يتم إرسال بريد إلكتروني أو رسالة نصية في هذا العرض التجريبي.';

  @override
  String get authResetTitle => 'تم استلام الطلب';

  @override
  String get authBackToLogin => 'العودة إلى تسجيل الدخول';

  @override
  String get authSubmitting => 'يُرجى الانتظار…';

  @override
  String get authChangePassword => 'تغيير كلمة المرور';

  @override
  String get authChangeSubtitle => 'اختر كلمة مرور قوية لحسابك.';

  @override
  String get authCurrentPassword => 'كلمة المرور الحالية';

  @override
  String get authNewPassword => 'كلمة المرور الجديدة';

  @override
  String get authConfirmPassword => 'تأكيد كلمة المرور الجديدة';

  @override
  String get authPasswordConstraints =>
      'استخدم ٨ أحرف على الأقل، تتضمن حرفًا ورقمًا.';

  @override
  String get authPasswordsMismatch => 'كلمتا المرور غير متطابقتين';

  @override
  String get authPasswordMustDiffer =>
      'اختر كلمة مرور مختلفة عن كلمة مرورك الحالية';

  @override
  String get authCurrentPasswordInvalid => 'كلمة المرور الحالية غير صحيحة.';

  @override
  String get authPasswordChanged =>
      'تم تحديث كلمة المرور لهذه الجلسة التجريبية.';

  @override
  String get authPasswordDemoNote =>
      'تستمر تغييرات كلمة المرور التجريبية حتى إعادة تشغيل التطبيق. لا تُحفظ أي كلمة مرور على هذا الجهاز.';

  @override
  String get authBackToWorkspace => 'العودة إلى مساحة العمل';

  @override
  String get authConfirmLogout => 'هل تريد تسجيل الخروج من مساحة عملك؟';

  @override
  String get authLogoutMessage => 'ستتم إزالة جلستك الآمنة من هذا الجهاز.';

  @override
  String get authHomeTitle => 'مساحة عملك جاهزة';

  @override
  String get authHomeSubtitle =>
      'لقد سجّلت الدخول. ستُضاف وحدات الأعمال في المراحل القادمة.';

  @override
  String get authAccount => 'الحساب';

  @override
  String get authCompany => 'الشركة';

  @override
  String get authPermissions => 'الصلاحيات';

  @override
  String get authAccountStatus => 'حالة الحساب';

  @override
  String get authStatusActive => 'نشط';

  @override
  String get authStatusSuspended => 'موقوف';

  @override
  String get authStatusInactive => 'غير نشط';

  @override
  String get authPermissionViewer => 'الصلاحيات الممنوحة';

  @override
  String get authEmployeeLinked => 'سجل الموظف المرتبط';

  @override
  String get authEmployeeUnlinked => 'لا يوجد سجل موظف مرتبط';

  @override
  String authPermissionCount(String count) {
    return 'تم منح $count صلاحية';
  }

  @override
  String authGreeting(String name) {
    return 'مرحبًا، $name';
  }

  @override
  String get permissionCompanyManage => 'إدارة الشركة';

  @override
  String get permissionUserManage => 'إدارة حسابات المستخدمين';

  @override
  String get shellDashboard => 'لوحة التحكم';

  @override
  String get shellEmployees => 'الموظفون';

  @override
  String get shellAttendance => 'الحضور';

  @override
  String get shellReports => 'التقارير';

  @override
  String get shellSettings => 'الإعدادات';

  @override
  String get shellProfile => 'الملف الشخصي';

  @override
  String get shellMore => 'المزيد';

  @override
  String get shellGeneral => 'مساحة العمل';

  @override
  String get shellPeople => 'الأفراد';

  @override
  String get shellWorkforce => 'القوى العاملة';

  @override
  String get shellInsights => 'التحليلات';

  @override
  String get shellAdministration => 'الإدارة';

  @override
  String get shellAccount => 'الحساب';

  @override
  String get shellServices => 'الخدمات';

  @override
  String get shellFinance => 'الشؤون المالية';

  @override
  String get shellProfileDescription => 'حسابك وتفضيلاتك وإعدادات الحضور.';

  @override
  String get shellPlaceholderTitle => 'جاهز للمرحلة القادمة';

  @override
  String get shellPlaceholderMessage =>
      'هذه المساحة مخصّصة لوحدة أعمال مستقبلية. لا تتوفر بيانات أعمال بعد.';

  @override
  String get shellMoreDescription => 'استكشف المساحات الأخرى المتاحة لحسابك.';

  @override
  String get shellSearchTitle => 'البحث الشامل';

  @override
  String get shellSearchMessage =>
      'سيتوفر البحث الشامل عند إضافة وحدات الأعمال.';

  @override
  String get shellNotifications => 'الإشعارات';

  @override
  String get shellNoNotifications => 'لا توجد إشعارات';

  @override
  String get shellNotificationsMessage => 'لا توجد إشعارات لعرضها.';

  @override
  String get shellAccessRestricted => 'الوصول مقيّد';

  @override
  String get shellAccessMessage => 'ليس لديك صلاحية للوصول إلى هذه المساحة.';

  @override
  String get shellModuleUnavailable => 'الوحدة غير متاحة';

  @override
  String get shellModuleUnavailableMessage => 'هذه الوحدة غير مفعّلة لمؤسستك.';

  @override
  String get shellNotFound => 'الصفحة غير موجودة';

  @override
  String get shellNotFoundMessage => 'تعذّر العثور على الصفحة التي طلبتها.';

  @override
  String get shellReturnToWorkspace => 'العودة إلى مساحة العمل';

  @override
  String get shellGoBack => 'العودة';

  @override
  String get shellCollapseSidebar => 'طيّ القائمة الجانبية';

  @override
  String get shellExpandSidebar => 'توسيع القائمة الجانبية';

  @override
  String get shellCompanyInformation => 'معلومات الشركة';

  @override
  String get shellTimezone => 'المنطقة الزمنية';

  @override
  String get shellCompanyCode => 'رمز الشركة';

  @override
  String get shellAccountMenu => 'فتح قائمة الحساب';

  @override
  String get shellBreadcrumbs => 'مسار التنقل';

  @override
  String get shellNoDestinations => 'لا توجد وجهات متاحة';

  @override
  String get shellNoDestinationsMessage =>
      'لا تتوفر مساحات عمل لهذا الحساب. تواصل مع المسؤول.';

  @override
  String get syncOfflineTitle => 'أنت غير متصل';

  @override
  String get syncOfflineMessage => 'ستتم المزامنة عند عودة الاتصال.';

  @override
  String get syncServiceUnavailable => 'الخدمة غير متاحة مؤقتاً';

  @override
  String get syncSyncing => 'جارٍ المزامنة';

  @override
  String get syncAllChangesSynced => 'تمت مزامنة كل التغييرات';

  @override
  String get syncPending => 'بانتظار المزامنة';

  @override
  String get syncFailed => 'فشلت المزامنة';

  @override
  String get syncNeedsAttention => 'المزامنة تحتاج إلى مراجعة';

  @override
  String get syncRetry => 'إعادة المحاولة';

  @override
  String get syncRetryNow => 'إعادة المحاولة الآن';

  @override
  String get syncNow => 'المزامنة الآن';

  @override
  String get syncLastSync => 'آخر مزامنة';

  @override
  String get syncNever => 'لم تتم المزامنة بعد';

  @override
  String get syncChangesWaiting => 'تغييرات بانتظار المزامنة';

  @override
  String get syncDataAndSync => 'البيانات والمزامنة';

  @override
  String get syncNoPendingChanges => 'لا توجد تغييرات معلقة';

  @override
  String get syncSyncSucceeded => 'اكتملت المزامنة';

  @override
  String get syncStatusTitle => 'حالة المزامنة';

  @override
  String get syncPendingOperations => 'العمليات المعلقة';

  @override
  String get syncFailedOperations => 'العمليات الفاشلة';

  @override
  String get syncSwitchAccount => 'سجّل الدخول للمزامنة';

  @override
  String get notificationsTitle => 'الإشعارات';

  @override
  String get notificationsNoItems => 'لا توجد إشعارات';

  @override
  String get notificationsNoItemsMessage => 'لا يوجد جديد لديك.';

  @override
  String get notificationsMarkAllRead => 'تحديد الكل كمقروء';

  @override
  String get notificationsToday => 'اليوم';

  @override
  String get notificationsEarlier => 'سابقاً';

  @override
  String get notificationsUnread => 'غير مقروء';

  @override
  String get notificationsReminders => 'الإشعارات والتذكيرات';

  @override
  String get notificationsOpen => 'فتح الإشعارات';

  @override
  String get reminderAttendanceSection => 'تذكيرات الحضور';

  @override
  String get reminderShift => 'تذكير الوردية';

  @override
  String get reminderPunchOut => 'تذكير تسجيل الانصراف';

  @override
  String get reminderNotifyBefore => 'التنبيه قبل الوردية';

  @override
  String get reminderMinutesBefore => 'دقائق قبل';

  @override
  String get reminderNotificationPermission => 'إذن الإشعارات';

  @override
  String get reminderPermissionRequired => 'مطلوب إذن الإشعارات';

  @override
  String get reminderNotificationsDisabled => 'الإشعارات معطلة';

  @override
  String get reminderNotificationsEnabled => 'التذكيرات مفعلة في التطبيق';

  @override
  String get reminderOpenSettings => 'فتح الإعدادات';

  @override
  String get reminderSaved => 'تم حفظ إعدادات التذكير';

  @override
  String get reminderSaveFailed => 'تعذر حفظ إعدادات التذكير';

  @override
  String get reminderPermissionHint => 'فعّل التذكيرات لتلقي تنبيهات الوردية.';

  @override
  String get notifShiftSoonTitle => 'ورديتك تبدأ قريباً';

  @override
  String get notifShiftSoonBody =>
      'ورديتك على وشك البدء. افتح الحضور لتسجيل الدخول.';

  @override
  String get notifPunchOutTitle => 'تذكّر تسجيل الانصراف';

  @override
  String get notifPunchOutBody => 'انتهت ورديتك. تذكّر تسجيل الانصراف.';

  @override
  String get notifShiftEndingOnBreakBody =>
      'ورديتك تنتهي. راجع حضورك قبل المغادرة.';

  @override
  String get notifCorrectionApprovedTitle => 'تمت الموافقة على تصحيح الحضور';

  @override
  String get notifCorrectionApprovedBody =>
      'تمت الموافقة على تصحيح حضورك وتطبيقه.';

  @override
  String get notifCorrectionRejectedTitle => 'تم رفض تصحيح الحضور';

  @override
  String get notifCorrectionRejectedBody =>
      'لم تتم الموافقة على طلب تصحيح حضورك.';

  @override
  String get notifSyncFailedTitle => 'الحضور يحتاج إلى انتباه';

  @override
  String get notifSyncFailedBody => 'تعذرت مزامنة بعض تغييرات الحضور.';

  @override
  String get notifConflictTitle => 'الحضور يحتاج إلى مراجعة';

  @override
  String get notifConflictBody => 'لا يطابق حضورك المحلي أحدث سجل على الخادم.';

  @override
  String get notifPendingReviewTitle => 'طلب تصحيح حضور جديد';

  @override
  String get notifPendingReviewBody => 'يوجد طلب تصحيح بانتظار المراجعة.';

  @override
  String get notifLeaveSubmittedTitle => 'تم إرسال طلب الإجازة';

  @override
  String get notifLeaveSubmittedBody =>
      'تم إرسال طلب الإجازة الخاص بك للموافقة.';

  @override
  String get notifLeaveApprovedTitle => 'تمت الموافقة على طلب الإجازة';

  @override
  String get notifLeaveApprovedBody => 'تمت الموافقة على طلب الإجازة الخاص بك.';

  @override
  String get notifLeaveRejectedTitle => 'تم رفض طلب الإجازة';

  @override
  String get notifLeaveRejectedBody =>
      'لم تتم الموافقة على طلب الإجازة الخاص بك.';

  @override
  String get notifLeaveCancelledTitle => 'تم إلغاء طلب الإجازة';

  @override
  String get notifLeaveCancelledBody => 'تم إلغاء طلب إجازة.';

  @override
  String get notifLeaveApprovalRequiredTitle => 'مطلوب موافقة على إجازة';

  @override
  String get notifLeaveApprovalRequiredBody =>
      'يوجد طلب إجازة لفريقك بانتظار مراجعتك.';

  @override
  String get notifUnknownTitle => 'إشعار';

  @override
  String get notifUnknownBody => 'لديك إشعار جديد.';

  @override
  String get timeJustNow => 'الآن';

  @override
  String timeMinutesAgo(Object count) {
    return 'قبل $count دقيقة';
  }

  @override
  String timeHoursAgo(Object count) {
    return 'قبل $count ساعة';
  }

  @override
  String get timeYesterday => 'أمس';

  @override
  String get profileMyProfile => 'ملفي الشخصي';

  @override
  String get profileOverview => 'نظرة عامة';

  @override
  String get profileWorkInformation => 'معلومات العمل';

  @override
  String get profileAccountAccess => 'الحساب والصلاحيات';

  @override
  String get profileSecurity => 'الأمان';

  @override
  String get profilePreferences => 'التفضيلات';

  @override
  String get profileAccess => 'الصلاحيات';

  @override
  String get profileAdministrativeAccess => 'صلاحيات إدارية';

  @override
  String get profileEmploymentStatus => 'حالة التوظيف';

  @override
  String get profileLoginEmail => 'بريد تسجيل الدخول';

  @override
  String get profileWorkEmail => 'بريد العمل';

  @override
  String get profileMyAttendance => 'حضوري';

  @override
  String get profileViewEmployeeRecord => 'عرض تفاصيل التوظيف';

  @override
  String get profileNoEmployeeLinked => 'لا يوجد ملف موظف مرتبط بهذا الحساب.';

  @override
  String get profileTeamUnavailable => 'تعذر تحديد نطاق الفريق.';

  @override
  String get profileEmploymentUnavailable =>
      'معلومات التوظيف غير متاحة حالياً.';

  @override
  String get profileCurrentCompany => 'الشركة الحالية';

  @override
  String get profileManage => 'إدارة';

  @override
  String get settingsIntro => 'إدارة مؤسستك وإعدادات الحضور والتفضيلات.';

  @override
  String get settingsAttendanceCategory => 'إعدادات الحضور';

  @override
  String get settingsAttendanceCategoryDesc =>
      'ضبط كيفية عمل الموظفين وتسجيلهم للحضور.';

  @override
  String get settingsPreferencesCategory => 'التفضيلات الشخصية';

  @override
  String get settingsPreferencesCategoryDesc =>
      'عدّل تفضيلات التطبيق الخاصة بك.';

  @override
  String get settingsSystemCategory => 'النظام';

  @override
  String get settingsSystemCategoryDesc => 'حالة المزامنة والتطبيق.';

  @override
  String get settingsShiftDesc =>
      'حدد ساعات العمل وأيام العمل والاستراحات الافتراضية.';

  @override
  String get settingsLocationDesc => 'أدر أماكن العمل وقواعد التحقق من الموقع.';

  @override
  String get settingsPolicyDesc => 'حدد قواعد الحضور والاستراحة والتصحيح.';

  @override
  String get settingsLanguageDesc => 'اختر لغة التطبيق المفضلة لديك.';

  @override
  String get settingsNotificationsDesc => 'تحكم في تذكيرات الحضور لحسابك.';

  @override
  String get settingsSyncDesc =>
      'اعرض حالة المزامنة وأعد محاولة التغييرات الفاشلة.';

  @override
  String get shellLeave => 'الإجازات';

  @override
  String get settingsLeaveCategory => 'الإجازات والعطلات';

  @override
  String get settingsLeaveCategoryDesc =>
      'اضبط أنواع الإجازات وسياساتها والعطلات.';

  @override
  String get permissionAccessUsersView => 'عرض المستخدمين والوصول';

  @override
  String get permissionAccessPermissionsManage => 'إدارة وصول المستخدمين';

  @override
  String get permissionCompanyModulesView => 'عرض وحدات الشركة';

  @override
  String get permissionPlatformModulesManage => 'إدارة وحدات المنصة';

  @override
  String get accessModulePlatform => 'الإدارة';

  @override
  String get accessSubAccess => 'الوصول والوحدات';

  @override
  String get accessUsersView => 'عرض المستخدمين والوصول';

  @override
  String get accessUsersViewDesc => 'فتح منطقة إدارة المستخدمين والوصول.';

  @override
  String get accessPermissionsManage => 'إدارة وصول المستخدمين';

  @override
  String get accessPermissionsManageDesc =>
      'منح وإلغاء صلاحيات ونطاقات النظام.';

  @override
  String get accessModulesView => 'عرض وحدات الشركة';

  @override
  String get accessModulesViewDesc =>
      'الاطلاع على وحدات النظام المفعّلة للشركة.';

  @override
  String get accessCompanyUsersManage => 'إدارة مستخدمي الشركة';

  @override
  String get accessCompanyUsersManageDesc => 'إدارة حسابات مستخدمي الشركة.';

  @override
  String get accessPlatformCompaniesManage => 'إدارة شركات المنصة';

  @override
  String get accessPlatformCompaniesManageDesc =>
      'خاص بالمنصة: إدارة الشركات على مستوى المنصة.';

  @override
  String get accessPlatformModulesManage => 'إدارة وحدات المنصة';

  @override
  String get accessPlatformModulesManageDesc =>
      'خاص بالمنصة: تفعيل أو تعطيل الوحدات للشركات.';

  @override
  String get usersAccessTitle => 'المستخدمون والوصول';

  @override
  String get usersAccessSubtitle =>
      'تحكم في ما يمكن لكل مستخدم الوصول إليه والسجلات التي يعمل عليها.';

  @override
  String get accessCompanyModules => 'وحدات الشركة';

  @override
  String get accessCompanyModulesSubtitle =>
      'وحدات النظام المفعّلة لهذه الشركة.';

  @override
  String get accessManage => 'إدارة الوصول';

  @override
  String get accessNoLogin => 'لا يوجد تسجيل دخول';

  @override
  String get accessNoBusinessAccess => 'لم يتم تعيين وصول وظيفي.';

  @override
  String get accessModuleHr => 'الموارد البشرية';

  @override
  String get accessModuleServices => 'الخدمات';

  @override
  String get accessScopeNone => 'لا وصول';

  @override
  String get accessScopeSelf => 'ذاتي (سجلاتي)';

  @override
  String get accessScopeAssigned => 'المُسند إليّ';

  @override
  String get accessScopeTeam => 'الفريق (فريقي)';

  @override
  String get accessScopeAll => 'الشركة (الكل)';

  @override
  String get accessSaveChanges => 'حفظ التغييرات';

  @override
  String get accessResetChanges => 'إعادة تعيين';

  @override
  String get accessSaved => 'تم تحديث الوصول.';

  @override
  String get accessSaveFailed => 'تعذّر تحديث الوصول.';

  @override
  String get accessConfirmTitle => 'تحديث الوصول؟';

  @override
  String get accessConfirmMessage =>
      'هل تريد تطبيق تغييرات الوصول لهذا المستخدم؟';

  @override
  String get accessAdded => 'تمت الإضافة';

  @override
  String get accessRemoved => 'تمت الإزالة';

  @override
  String get accessChanged => 'تم التغيير';

  @override
  String get accessNoChanges => 'لا تغييرات';

  @override
  String get accessSummary => 'ملخص الوصول';

  @override
  String get accessGrantedPermissions => 'الصلاحيات الممنوحة';

  @override
  String get accessEmployeeLinked => 'مرتبط بموظف';

  @override
  String get accessEmployeeNotLinked => 'لا يوجد موظف مرتبط';

  @override
  String get accessEmployeeLinkRequired =>
      'يتطلب هذا الوصول سجل موظف نشط مرتبط.';

  @override
  String get accessSelfEscalation => 'لا يمكنك تغيير وصولك الخاص.';

  @override
  String get accessLastAdmin => 'لا يمكن إزالة آخر مسؤول وصول.';

  @override
  String get accessNotPermitted => 'ليس لديك صلاحية للقيام بذلك.';

  @override
  String get accessModuleDisabled => 'هذه الوحدة غير مفعّلة للشركة.';

  @override
  String get accessPlatformOnly => 'يمكن لمسؤول المنصة فقط منح هذا.';

  @override
  String get accessHistory => 'سجل الوصول';

  @override
  String get accessNoHistory => 'لا توجد تغييرات وصول بعد.';

  @override
  String get accessSearchUsers => 'البحث عن مستخدمين';

  @override
  String get accessFilterAll => 'الكل';

  @override
  String get accessEnabled => 'مفعّل';

  @override
  String get accessDisabled => 'معطّل';

  @override
  String get accessModulesReadOnly =>
      'تتم إدارة توفر الوحدات على مستوى المنصة في هذا العرض.';

  @override
  String get accessStatusActive => 'نشط';

  @override
  String get accessStatusInactive => 'غير نشط';

  @override
  String get accessLogin => 'تسجيل الدخول';

  @override
  String get accessEmployee => 'الموظف';

  @override
  String get accessDesignation => 'المسمى الوظيفي';

  @override
  String get accessDepartment => 'القسم';

  @override
  String get accessClearModule => 'مسح وصول الوحدة';

  @override
  String get accessNoAccessAssigned => 'لا وصول';

  @override
  String get accessPlatformOnlyBadge => 'خاص بالمنصة';

  @override
  String get accessEmployeeRequiredBadge => 'يتطلب موظفًا';

  @override
  String get accessGrantView => 'منح العرض';

  @override
  String get accessGrantFull => 'منح الكل';

  @override
  String get accessClear => 'مسح';

  @override
  String get accessHasAccess => 'تم ضبط الوصول';

  @override
  String get accessFullConfirmTitle => 'منح وصول كامل للوحدة؟';

  @override
  String get accessFullConfirmMessage =>
      'يمنح هذا كل صلاحية قابلة للتفويض لهذه الوحدة. يمكنك تعديل النطاقات لاحقًا.';

  @override
  String get accessModuleAccess => 'وصول الوحدات';

  @override
  String get accessGranted => 'ممنوح';

  @override
  String get accessNotGranted => 'غير ممنوح';

  @override
  String get accessExpandAll => 'توسيع الكل';

  @override
  String get accessCollapseAll => 'طي الكل';

  @override
  String accessUsersSummary(Object count, Object withAccess) {
    return 'عرض $count مستخدمًا · $withAccess لديهم وصول';
  }

  @override
  String get accessScopeHint =>
      'يحدد النطاق السجلات التي تنطبق عليها الصلاحية: ذاتي = سجلات المستخدم نفسه، الفريق = فريقه، الشركة = كل سجلات الشركة.';

  @override
  String get accessScopeLabel => 'النطاق';

  @override
  String get accessSelfRequiresEmployee =>
      'تتطلب الصلاحيات الشخصية موظفًا مرتبطًا. لا يوجد موظف مرتبط بهذا المستخدم، لذا تبقى معطّلة.';

  @override
  String get accessNoLinkedEmployeeTitle => 'لا يوجد موظف مرتبط';

  @override
  String get accessLinkEmployeeHint =>
      'تنطبق الصلاحيات الشخصية (تسجيل الحضور، حضوري، إجازاتي) على سجل موظف. لتفعيلها، اربط هذا المستخدم بموظف من الموارد البشرية ← الموظفون ← فتح الموظف ← وصول الحساب.';

  @override
  String get accessLinkedEmployee => 'موظف مرتبط';

  @override
  String get accessNotLinked => 'غير مرتبط';

  @override
  String get demoPersonaPlatformAdmin => 'مدير المنصة';

  @override
  String get demoPersonaCompanyAdmin => 'مدير الشركة';

  @override
  String get demoPersonaHr => 'الموارد البشرية';

  @override
  String get demoPersonaManager => 'المدير';

  @override
  String get demoPersonaEmployee => 'الموظف';

  @override
  String get demoAccessPlatformAdmin =>
      'إدارة المنصة · كل الوحدات وكل الصلاحيات';

  @override
  String get demoAccessCompanyAdmin => 'كل وحدات الشركة وصلاحياتها';

  @override
  String get demoAccessHr =>
      'الموارد البشرية: الموظفون والحضور والإجازات والتقارير والإعدادات';

  @override
  String get demoAccessManager => 'حضور الفريق والموافقة على إجازات الفريق';

  @override
  String get demoAccessEmployee => 'الحضور الذاتي والإجازات الذاتية';

  @override
  String get authDemoSignIn => 'تسجيل الدخول';

  @override
  String get universalDashboardSubtitle => 'عملك ونشاط الشركة في لمحة واحدة';

  @override
  String get universalDashboardMyDay => 'يومي';

  @override
  String get universalDashboardNeedsAttention => 'يحتاج إلى انتباه';

  @override
  String get universalDashboardMetrics => 'مؤشرات رئيسية';

  @override
  String get universalDashboardSchedule => 'جدول اليوم';

  @override
  String get universalDashboardMyWork => 'عملي';

  @override
  String get universalDashboardTeam => 'الفريق والشركة';

  @override
  String get universalDashboardRecentActivity => 'النشاط الأخير';

  @override
  String get universalDashboardQuickActions => 'إجراءات سريعة';

  @override
  String get universalDashboardAllClear => 'لا توجد مهام تتطلب انتباهك الآن.';

  @override
  String get universalDashboardNoSchedule => 'لا يوجد شيء مجدول اليوم.';

  @override
  String get universalDashboardNoWork => 'لا يوجد عمل مُسند إليك الآن.';

  @override
  String get universalDashboardNoActivity => 'لا يوجد نشاط حديث.';

  @override
  String get universalDashboardEmptyTitle => 'لا شيء معلّق لديك';

  @override
  String get universalDashboardError =>
      'تعذّر تحميل لوحة التحكم. حاول مرة أخرى.';

  @override
  String get universalDashboardPartial => 'تعذّر تحميل بعض أقسام لوحة التحكم.';

  @override
  String get universalDashboardRefresh => 'تحديث';

  @override
  String get universalDashboardRefreshing => 'جارٍ تحديث لوحة التحكم';

  @override
  String get universalDashboardViewAll => 'عرض الكل';

  @override
  String get universalDashboardToday => 'اليوم';

  @override
  String get universalDashboardOpen => 'فتح';

  @override
  String get dashboard => 'لوحة المعلومات';

  @override
  String get employees => 'الموظفون';

  @override
  String get attendance => 'الحضور';

  @override
  String get requests => 'الطلبات';

  @override
  String get reports => 'التقارير';

  @override
  String get workLocation => 'موقع العمل';

  @override
  String get office => 'المكتب';

  @override
  String get remote => 'عن بُعد';

  @override
  String get effectiveDate => 'تاريخ السريان';

  @override
  String get startTime => 'وقت البدء';

  @override
  String get employee => 'الموظف';

  @override
  String get location => 'الموقع';

  @override
  String get permissionEmployeeViewSelf => 'عرض سجل الموظف الخاص بك';

  @override
  String get permissionEmployeeViewTeam => 'عرض موظفي الفريق';

  @override
  String get permissionEmployeeViewAll => 'عرض جميع الموظفين';

  @override
  String get permissionEmployeeCreate => 'إضافة موظفين';

  @override
  String get permissionEmployeeUpdate => 'تحديث بيانات الموظفين';

  @override
  String get permissionEmployeeDeactivate => 'إيقاف حسابات الموظفين';

  @override
  String get permissionAttendanceViewSelf => 'عرض حضورك';

  @override
  String get permissionAttendanceViewTeam => 'عرض حضور الفريق';

  @override
  String get permissionAttendanceViewAll => 'عرض جميع سجلات الحضور';

  @override
  String get permissionAttendancePunchIn => 'تسجيل بدء العمل';

  @override
  String get permissionAttendancePunchOut => 'تسجيل انتهاء العمل';

  @override
  String get permissionAttendanceBreak => 'إدارة استراحاتك';

  @override
  String get permissionAttendanceRequestCorrection => 'طلب تصحيح الحضور';

  @override
  String get permissionAttendanceCorrect => 'تصحيح الحضور';

  @override
  String get permissionAttendanceApprove => 'اعتماد الحضور';

  @override
  String get permissionShiftView => 'عرض الورديات';

  @override
  String get permissionShiftManage => 'إدارة الورديات';

  @override
  String get permissionWorkLocationView => 'عرض مواقع العمل';

  @override
  String get permissionWorkLocationManage => 'إدارة مواقع العمل';

  @override
  String get permissionAttendancePolicyView => 'عرض سياسات الحضور';

  @override
  String get permissionAttendancePolicyManage => 'إدارة سياسات الحضور';

  @override
  String get permissionAttendanceReportView => 'عرض تقارير الحضور';

  @override
  String dashboardMorning(String name) {
    return 'صباح الخير، $name';
  }

  @override
  String dashboardAfternoon(String name) {
    return 'طاب يومك، $name';
  }

  @override
  String dashboardEvening(String name) {
    return 'مساء الخير، $name';
  }

  @override
  String dashboardDemo(String date) {
    return 'معاينة تجريبية · $date';
  }

  @override
  String get dashboardSelfContext => 'نظرة على يوم عملك';

  @override
  String get dashboardNoShiftTitle => 'جدول العمل غير مُهيأ';

  @override
  String get dashboardNoShiftMessage =>
      'لم يتم تعيين دوام لملفك الوظيفي بعد. تواصل مع الموارد البشرية لإكمال إعداد الحضور.';

  @override
  String get dashboardThisWeek => 'هذا الأسبوع';

  @override
  String get dashboardRecentAttendance => 'الحضور الأخير';

  @override
  String get dashboardViewFullHistory => 'عرض السجل الكامل';

  @override
  String get dashboardNoRecentAttendance => 'لا يوجد حضور سابق بعد.';

  @override
  String get dashboardNoRecentAttendanceMessage =>
      'ستظهر أيام عملك المكتملة هنا.';

  @override
  String get dashboardNoWeek => 'لا يوجد حضور مسجّل هذا الأسبوع.';

  @override
  String get dashboardWeekOff => 'يوم راحة';

  @override
  String get dashboardTeamContext => 'لمحة عن فريقك';

  @override
  String get dashboardCompanyContext => 'لمحة عن القوى العاملة في شركتك';

  @override
  String get dashboardNoScope => 'مساحة عملك';

  @override
  String get dashboardToday => 'اليوم';

  @override
  String get dashboardMonth => 'هذا الشهر';

  @override
  String get dashboardEmployees => 'إجمالي الموظفين';

  @override
  String get dashboardTeamSize => 'عدد أعضاء الفريق';

  @override
  String get dashboardPresent => 'الحاضرون';

  @override
  String get dashboardLate => 'المتأخرون';

  @override
  String get dashboardAbsent => 'الغائبون';

  @override
  String get dashboardLeave => 'في إجازة';

  @override
  String get dashboardWorking => 'يعملون الآن';

  @override
  String get dashboardBreak => 'في استراحة';

  @override
  String get dashboardCorrections => 'تصحيحات معلّقة';

  @override
  String get dashboardHours => 'ساعات العمل';

  @override
  String get dashboardRate => 'نسبة الحضور';

  @override
  String get dashboardLocations => 'مواقع العمل';

  @override
  String get dashboardUsers => 'المستخدمون النشطون';

  @override
  String get dashboardShift => 'الوردية';

  @override
  String get dashboardLocation => 'موقع العمل';

  @override
  String get dashboardOffice => 'مكتب حيدر آباد · تجريبي';

  @override
  String get dashboardNotStarted => 'لم يبدأ · معاينة';

  @override
  String get dashboardAttendance => 'حالة الحضور';

  @override
  String get dashboardAttention => 'يحتاج إلى متابعة';

  @override
  String get dashboardActivity => 'النشاط الأخير';

  @override
  String get dashboardQuickActions => 'وصول سريع';

  @override
  String get dashboardStatus => 'ملخص الحضور';

  @override
  String get dashboardOnTime => 'في الموعد';

  @override
  String get dashboardPresentDetail => 'يشمل المتأخرين';

  @override
  String dashboardLateAlert(String count) {
    return '$count حالات تأخر للمراجعة';
  }

  @override
  String dashboardCorrectionsAlert(String count) {
    return '$count تصحيحات تنتظر المراجعة';
  }

  @override
  String get dashboardLateAlertDetail => 'مراجعة الحضور';

  @override
  String get dashboardCorrectionsAlertDetail => 'بانتظار المراجعة';

  @override
  String get dashboardSelfCheckedIn => 'تسجيل الدخول';

  @override
  String get dashboardSelfBreakStarted => 'بدء استراحة';

  @override
  String get dashboardSelfCorrectionSubmitted => 'إرسال تصحيح';

  @override
  String dashboardCheckedIn(String name) {
    return 'سجّل $name الحضور';
  }

  @override
  String dashboardBreakStarted(String name) {
    return 'بدأ $name استراحة';
  }

  @override
  String dashboardCorrectionSubmitted(String name) {
    return 'قدّم $name طلب تصحيح';
  }

  @override
  String get dashboardActivityDetail => 'نشاط حضور تجريبي';

  @override
  String get dashboardNoActivity => 'لا يوجد نشاط حديث';

  @override
  String get dashboardNoAttention => 'لا توجد أمور تحتاج إلى متابعة';

  @override
  String get dashboardEmptyTitle => 'لا توجد بيانات للقوى العاملة بعد';

  @override
  String get dashboardEmptyMessage =>
      'ستظهر معلومات القوى العاملة هنا عندما تتوفر البيانات والصلاحيات.';

  @override
  String get dashboardError => 'تعذّر تحميل لوحة التحكم. يرجى المحاولة مجددًا.';

  @override
  String get dashboardRefreshError =>
      'تعذّر التحديث. لا يزال الملخص السابق متاحًا.';

  @override
  String get dashboardRefresh => 'تحديث';

  @override
  String get dashboardRefreshing => 'جارٍ تحديث لوحة التحكم';

  @override
  String dashboardTimeRange(String start, String end) {
    return 'من $start إلى $end';
  }

  @override
  String get empAdd => 'إضافة موظف';

  @override
  String get empEdit => 'تعديل الموظف';

  @override
  String get empDetails => 'تفاصيل الموظف';

  @override
  String get empPersonal => 'المعلومات الشخصية';

  @override
  String get empEmployment => 'معلومات التوظيف';

  @override
  String get empAttendanceConfig => 'إعدادات الحضور';

  @override
  String get empAccountAccess => 'الوصول إلى الحساب';

  @override
  String get empCode => 'رمز الموظف';

  @override
  String get empFirst => 'الاسم الأول *';

  @override
  String get empMiddle => 'الاسم الأوسط';

  @override
  String get empLast => 'اسم العائلة (اختياري)';

  @override
  String get empDepartment => 'القسم';

  @override
  String get empDesignation => 'المسمى الوظيفي';

  @override
  String get empManager => 'المدير';

  @override
  String get empJoined => 'تاريخ الانضمام';

  @override
  String get empType => 'نوع التوظيف';

  @override
  String get empPolicy => 'سياسة الحضور';

  @override
  String get empLogin => 'تمكين تسجيل الدخول للتطبيق';

  @override
  String get empGenerated => 'يُنشأ تلقائيًا عند الحفظ';

  @override
  String get empUnassigned => 'غير معيّن';

  @override
  String get empLoginNotice =>
      'إعداد محلي للحساب. لا تُصدر بيانات دخول جديدة أو دعوات في هذه المرحلة.';

  @override
  String get empCredentialPending => 'إعداد بيانات الدخول معلّق';

  @override
  String get empNoLogin => 'لا يوجد حساب مرتبط';

  @override
  String get empActive => 'نشط';

  @override
  String get empInactive => 'غير نشط';

  @override
  String get empFullTime => 'دوام كامل';

  @override
  String get empPartTime => 'دوام جزئي';

  @override
  String get empContract => 'عقد';

  @override
  String get empIntern => 'متدرّب';

  @override
  String get empTemporary => 'مؤقت';

  @override
  String get empFilters => 'عوامل التصفية';

  @override
  String get empClear => 'مسح التصفية';

  @override
  String get empApply => 'تطبيق';

  @override
  String get empReset => 'إعادة تعيين';

  @override
  String get empAll => 'الكل';

  @override
  String get empSort => 'ترتيب';

  @override
  String get empNameAsc => 'الاسم تصاعديًا';

  @override
  String get empNameDesc => 'الاسم تنازليًا';

  @override
  String get empNewest => 'الأحدث انضمامًا';

  @override
  String get empOldest => 'الأقدم انضمامًا';

  @override
  String get empEmpty => 'لا يوجد موظفون بعد';

  @override
  String get empEmptyMessage => 'أضف أول موظف لبدء إدارة القوى العاملة.';

  @override
  String get empNoResults => 'لم يتم العثور على موظفين';

  @override
  String get empNoResultsMessage => 'جرّب تغيير البحث أو عوامل التصفية.';

  @override
  String get empNotFound => 'لم يتم العثور على الموظف';

  @override
  String get empNotFoundMessage => 'هذا الموظف غير متاح.';

  @override
  String get empView => 'عرض';

  @override
  String get empActivate => 'تنشيط الموظف';

  @override
  String get empDeactivate => 'إيقاف الموظف';

  @override
  String get empStatusConfirm => 'تغيير حالة الموظف؟';

  @override
  String get empStatusMessage =>
      'سيؤدي ذلك إلى تغيير حالة الموظف وإمكانية دخول الحساب المرتبط. ويمكن التراجع عن ذلك.';

  @override
  String get empCreated => 'تم إنشاء الموظف بنجاح';

  @override
  String get empUpdated => 'تم تحديث الموظف بنجاح';

  @override
  String get empStatusSaved => 'تم تحديث حالة الموظف';

  @override
  String get empSave => 'حفظ الموظف';

  @override
  String get empDiscard => 'تجاهل التغييرات؟';

  @override
  String get empDiscardMessage =>
      'لديك تغييرات غير محفوظة. هل تريد تجاهلها ومغادرة النموذج؟';

  @override
  String get empDiscardAction => 'تجاهل';

  @override
  String get empRequired => 'أكمل الحقول المطلوبة واختر تاريخ انضمام صالحًا.';

  @override
  String get empInvalidEmail => 'أدخل عنوان بريد إلكتروني صالحًا.';

  @override
  String get empInvalidPhone => 'أدخل رقم هاتف يتكون من ٧ إلى ١٥ رقمًا.';

  @override
  String get empDuplicateEmail => 'هذا البريد الإلكتروني مرتبط بموظف آخر.';

  @override
  String get empDuplicatePhone => 'رقم الهاتف هذا مرتبط بموظف آخر.';

  @override
  String get empInvalidManager =>
      'اختر مديرًا نشطًا دون إنشاء علاقة إدارية دائرية.';

  @override
  String get empInvalidReference => 'اختر قسمًا ومسمى وظيفيًا نشطين.';

  @override
  String get empStorageError =>
      'تعذّر إكمال هذه العملية المحلية. يرجى المحاولة مجددًا.';

  @override
  String get empPending => 'المزامنة معلّقة';

  @override
  String get empBack => 'العودة إلى الموظفين';

  @override
  String get empSelfProfile => 'عرض الملف الوظيفي';

  @override
  String get empRelated => 'السجلات المرتبطة';

  @override
  String get empPreview => 'معاينة الحضور';

  @override
  String get empSelect => 'اختر خيارًا';

  @override
  String get empActions => 'إجراءات الموظف';

  @override
  String empCount(String filtered, String total) {
    return '$filtered من $total موظفًا';
  }

  @override
  String empFilterCount(String count) {
    return 'عوامل التصفية ($count)';
  }

  @override
  String get cfgConfiguration => 'الإعدادات';

  @override
  String get cfgShifts => 'الورديات';

  @override
  String get cfgShift => 'الوردية';

  @override
  String get cfgPolicy => 'سياسة الحضور';

  @override
  String get cfgLocations => 'مواقع العمل';

  @override
  String get cfgPolicies => 'سياسات الحضور';

  @override
  String get cfgIntro => 'حدد أوقات عمل الموظفين ومواقعهم وقواعد الحضور.';

  @override
  String get cfgShiftIntro => 'ساعات العمل وأيامه والاستراحات المخططة.';

  @override
  String get cfgLocationIntro => 'عناوين العمل وإعدادات التحقق من الموقع.';

  @override
  String get cfgPolicyIntro => 'قواعد جاهزة لإجراءات الحضور المستقبلية.';

  @override
  String get cfgNew => 'إنشاء سجل';

  @override
  String get cfgEdit => 'تعديل السجل';

  @override
  String get cfgSaved => 'تم حفظ الإعدادات محليًا.';

  @override
  String get cfgStatusSaved => 'تم تحديث الحالة محليًا.';

  @override
  String get cfgName => 'الاسم';

  @override
  String get cfgCode => 'الرمز (اختياري)';

  @override
  String get cfgDescription => 'الوصف';

  @override
  String get cfgAll => 'جميع الحالات';

  @override
  String get cfgActive => 'نشط';

  @override
  String get cfgInactive => 'غير نشط';

  @override
  String get cfgActivate => 'تفعيل';

  @override
  String get cfgDeactivate => 'إلغاء التفعيل';

  @override
  String get cfgStatus => 'الحالة';

  @override
  String get cfgAssigned => 'الموظفون المعيّنون';

  @override
  String get cfgDeactivateMessage =>
      'ستبقى التعيينات الحالية محفوظة، ولن يتاح هذا السجل للتعيينات الجديدة.';

  @override
  String get cfgActivateMessage => 'إتاحة هذا السجل لتعيينات الموظفين الجديدة.';

  @override
  String get cfgEmpty => 'لا توجد سجلات إعدادات بعد';

  @override
  String get cfgEmptyMessage => 'أنشئ سجلًا لتجهيز تعيينات حضور الموظفين.';

  @override
  String get cfgNoResults => 'لا توجد سجلات مطابقة';

  @override
  String get cfgNoResultsMessage => 'جرّب بحثًا آخر أو غيّر فلتر الحالة.';

  @override
  String get cfgNotFound => 'لم يتم العثور على السجل';

  @override
  String get cfgNotFoundMessage => 'هذا السجل غير متاح في الشركة الحالية.';

  @override
  String get cfgRequired => 'هذا الحقل مطلوب.';

  @override
  String get cfgDuplicateName => 'يوجد بالفعل سجل نشط بهذا الاسم.';

  @override
  String get cfgInvalidTime => 'اختر وقت بداية ونهاية صحيحين ومختلفين.';

  @override
  String get cfgWorkingDaysError => 'اختر يوم عمل واحدًا على الأقل.';

  @override
  String get cfgInvalidGrace =>
      'يجب ألا تكون فترة السماح سالبة وأن تكون أقصر من الوردية.';

  @override
  String get cfgInvalidBreak =>
      'يجب أن تكون الاستراحة الثابتة أقصر من الوردية.';

  @override
  String get cfgInvalidMinimum =>
      'يجب ألا يتجاوز الحد الأدنى للعمل الوقت المتوقع.';

  @override
  String get cfgInvalidCoordinates =>
      'أدخل إحداثيات ضمن نطاقات خط العرض والطول الصحيحة.';

  @override
  String get cfgInvalidRadius => 'أدخل نصف قطر موجبًا ومحدودًا.';

  @override
  String get cfgInvalidAccuracy => 'أدخل حد دقة موجبًا ومحدودًا.';

  @override
  String get cfgCountryError => 'أدخل رمز البلد المكوّن من حرفين.';

  @override
  String get cfgPolicyError => 'اشترط الموقع لإجراء حضور واحد على الأقل.';

  @override
  String get cfgEarlyError => 'أدخل حد الحضور المبكر من ٠ إلى ١٤٤٠ دقيقة.';

  @override
  String get cfgAssignmentError => 'اختر سجلًا نشطًا من الشركة الحالية.';

  @override
  String get cfgStorageError =>
      'تعذرت قراءة الإعدادات المحلية أو حفظها. حاول مجددًا.';

  @override
  String get cfgStart => 'وقت البداية';

  @override
  String get cfgEnd => 'وقت النهاية';

  @override
  String get cfgDays => 'أيام العمل';

  @override
  String get cfgGrace => 'فترة السماح';

  @override
  String get cfgBreakMode => 'نوع الاستراحة';

  @override
  String get cfgManualBreak => 'استراحات يدوية';

  @override
  String get cfgFixedBreak => 'استراحة مخططة ثابتة';

  @override
  String get cfgNoBreak => 'بدون استراحات';

  @override
  String get cfgBreakMinutes => 'مدة الاستراحة المخططة';

  @override
  String get cfgMinimumWork => 'الحد الأدنى لمدة العمل (اختياري)';

  @override
  String get cfgDuration => 'مدة الوردية';

  @override
  String get cfgExpectedWork => 'وقت العمل المتوقع';

  @override
  String get cfgOvernight => 'وردية ليلية تمتد لليوم التالي';

  @override
  String get cfgSchedule => 'جدول العمل';

  @override
  String get cfgMinutes => 'دقيقة';

  @override
  String get cfgMeters => 'متر';

  @override
  String get cfgAddress => 'العنوان';

  @override
  String get cfgAddress1 => 'سطر العنوان الأول';

  @override
  String get cfgAddress2 => 'سطر العنوان الثاني (اختياري)';

  @override
  String get cfgCity => 'المدينة';

  @override
  String get cfgState => 'الولاية / المنطقة';

  @override
  String get cfgPostal => 'الرمز البريدي';

  @override
  String get cfgCountry => 'رمز البلد';

  @override
  String get cfgLatitude => 'خط العرض';

  @override
  String get cfgLongitude => 'خط الطول';

  @override
  String get cfgRadius => 'نصف القطر المسموح';

  @override
  String get cfgAccuracy => 'أقصى هامش خطأ مقبول';

  @override
  String get cfgValidationMode => 'التحقق من الموقع';

  @override
  String get cfgGeofenceRequired => 'النطاق الجغرافي إلزامي';

  @override
  String get cfgGeofencePreferred => 'النطاق الجغرافي مفضّل';

  @override
  String get cfgCaptureOnly => 'تسجيل الموقع فقط';

  @override
  String get cfgNoLocation => 'بدون تحقق من الموقع';

  @override
  String get cfgPreview => 'معاينة الموقع';

  @override
  String get cfgPreviewNote =>
      'معاينة الإحداثيات ونصف القطر. يمكن إضافة مزوّد خرائط لاحقًا.';

  @override
  String get cfgCurrentLocation => 'استخدام الموقع الحالي';

  @override
  String get cfgLocating => 'جارٍ تحديد الموقع…';

  @override
  String get cfgOpenSettings => 'فتح الإعدادات';

  @override
  String get cfgLocationDenied =>
      'تم رفض إذن الموقع. يمكنك إدخال الإحداثيات يدويًا.';

  @override
  String get cfgLocationPermanent =>
      'إذن الموقع محظور. فعّله في إعدادات التطبيق.';

  @override
  String get cfgLocationDisabled =>
      'خدمات الموقع متوقفة. فعّلها في إعدادات الجهاز.';

  @override
  String get cfgLocationTimeout =>
      'انتهت مهلة طلب الموقع. حاول مجددًا أو أدخل الإحداثيات يدويًا.';

  @override
  String get cfgLocationUnavailable =>
      'الموقع الحالي غير متاح. يمكنك إدخال الإحداثيات يدويًا.';

  @override
  String get cfgPoorAccuracy =>
      'دقة الموقع المسجّل منخفضة. راجع الإحداثيات قبل الحفظ.';

  @override
  String get cfgCapturedAccuracy => 'دقة الموقع المسجّل';

  @override
  String get cfgLocationRules => 'قواعد الموقع';

  @override
  String get cfgBreakRules => 'قواعد الاستراحات';

  @override
  String get cfgTimingRules => 'قواعد التوقيت';

  @override
  String get cfgOfflineRules => 'السلوك دون اتصال';

  @override
  String get cfgGeneralRules => 'القواعد العامة';

  @override
  String get cfgRequireLocation => 'اشتراط الموقع';

  @override
  String get cfgOutside => 'السماح بالحضور خارج الموقع المعيّن';

  @override
  String get cfgRemote => 'السماح بالحضور عن بُعد';

  @override
  String get cfgLocationIn => 'اشتراط الموقع عند بدء العمل';

  @override
  String get cfgLocationOut => 'اشتراط الموقع عند إنهاء العمل';

  @override
  String get cfgLocationBreak => 'اشتراط الموقع للاستراحات';

  @override
  String get cfgRequireAccuracy => 'اشتراط دقة موقع مقبولة';

  @override
  String get cfgTrackBreaks => 'تسجيل الاستراحات';

  @override
  String get cfgMultipleBreaks => 'السماح باستراحات متعددة';

  @override
  String get cfgOutDuringBreak => 'السماح بإنهاء العمل أثناء الاستراحة';

  @override
  String get cfgCorrections => 'السماح بطلبات تصحيح الموظفين';

  @override
  String get cfgEarlyIn => 'السماح ببدء العمل مبكرًا';

  @override
  String get cfgEarlyLimit => 'حد الحضور المبكر';

  @override
  String get cfgLateIn => 'السماح ببدء العمل متأخرًا';

  @override
  String get cfgEarlyOut => 'السماح بإنهاء العمل مبكرًا';

  @override
  String get cfgOfflineMode => 'وضع الحضور دون اتصال';

  @override
  String get cfgOfflineNo => 'غير مسموح';

  @override
  String get cfgOfflinePending => 'السماح بانتظار التحقق';

  @override
  String get cfgOfflineWarning => 'السماح مع تنبيه';

  @override
  String get cfgYes => 'مسموح';

  @override
  String get cfgNo => 'غير مسموح';

  @override
  String get cfgFoundationNote =>
      'هذه إعدادات فقط. ستُنفّذ إجراءات الحضور وتقييم القواعد في المرحلة السادسة.';

  @override
  String get cfgInactiveAssignment => 'غير نشط • التعيين الحالي محفوظ';

  @override
  String get cfgMon => 'الاثنين';

  @override
  String get cfgTue => 'الثلاثاء';

  @override
  String get cfgWed => 'الأربعاء';

  @override
  String get cfgThu => 'الخميس';

  @override
  String get cfgFri => 'الجمعة';

  @override
  String get cfgSat => 'السبت';

  @override
  String get cfgSun => 'الأحد';

  @override
  String get cfgActions => 'الإجراءات';

  @override
  String get cfgValidation => 'راجع الحقول الموضّحة قبل الحفظ.';

  @override
  String get cfgPending => 'بانتظار المزامنة';

  @override
  String get cfgView => 'عرض';

  @override
  String get cfgKeepEditing => 'متابعة التعديل';

  @override
  String get cfgDiscard => 'تجاهل التغييرات؟';

  @override
  String get cfgDiscardMessage =>
      'لديك تغييرات غير محفوظة. هل تريد تجاهلها ومغادرة النموذج؟';

  @override
  String get cfgDiscardAction => 'تجاهل التغييرات';

  @override
  String get attendanceNotLinkedToEmployee =>
      'لا يوجد ملف موظف مرتبط بهذا الحساب';

  @override
  String get attendanceEmployeeInactive => 'حساب الموظف غير نشط';

  @override
  String get attendanceAccountInactive => 'حسابك غير نشط أو انتهت جلستك';

  @override
  String get attendancePermissionDenied =>
      'ليس لديك إذن لتنفيذ إجراء الحضور هذا';

  @override
  String get attendanceShiftNotAssigned => 'لم يتم تعيين وردية';

  @override
  String get attendancePolicyNotAssigned => 'لم يتم تعيين سياسة حضور';

  @override
  String get attendanceWorkLocationRequiredButMissing =>
      'لم يتم تعيين موقع عمل';

  @override
  String get attendanceLocationRequired => 'الموقع مطلوب';

  @override
  String get attendanceLocationUnavailable => 'موقعك غير متاح';

  @override
  String get attendanceLocationPermissionDenied =>
      'يلزم منح إذن الوصول إلى الموقع';

  @override
  String get attendanceLocationServicesDisabled => 'خدمات الموقع معطلة';

  @override
  String get attendanceLocationAccuracyTooLow => 'دقة الموقع غير كافية';

  @override
  String get attendanceOutsideAllowedLocation =>
      'أنت خارج موقع العمل المسموح به';

  @override
  String get attendanceAlreadyPunchedIn => 'لقد سجلت الحضور بالفعل';

  @override
  String get attendanceNotPunchedIn => 'لم يتم تسجيل الحضور';

  @override
  String get attendanceAlreadyOnBreak => 'أنت في استراحة بالفعل';

  @override
  String get attendanceNotOnBreak => 'لا توجد استراحة نشطة';

  @override
  String get attendanceBreakTrackingDisabled => 'تتبع الاستراحات معطل';

  @override
  String get attendanceMultipleBreaksNotAllowed => 'لا يُسمح باستراحات متعددة';

  @override
  String get attendancePunchOutDuringBreakNotAllowed =>
      'لا يُسمح بتسجيل الانصراف أثناء الاستراحة';

  @override
  String get attendanceAlreadyCompleted => 'انتهى يوم عملك بالفعل';

  @override
  String get attendanceTooEarlyToPunchIn => 'الوقت مبكر جداً لتسجيل الحضور';

  @override
  String get attendanceLatePunchInNotAllowed =>
      'لا يُسمح بتسجيل الحضور المتأخر';

  @override
  String get attendanceEarlyPunchOutNotAllowed =>
      'لا يُسمح بتسجيل الانصراف المبكر';

  @override
  String get attendanceUnscheduledDay => 'هذا اليوم غير مدرج ضمن أيام العمل';

  @override
  String get attendanceOfflineAttendanceNotAllowed =>
      'لا يُسمح بتسجيل الحضور دون اتصال';

  @override
  String get attendanceInvalidAttendanceState => 'سجل أحداث الحضور غير متسق';

  @override
  String get attendancePersistenceFailure =>
      'تعذر حفظ الحضور. يرجى إعادة المحاولة';

  @override
  String get attendanceInvalidLocationEvidence =>
      'بيانات إثبات الموقع غير صالحة';

  @override
  String get attendanceStaleLocationEvidence => 'يرجى تحديد موقعك مرة أخرى';

  @override
  String get attendanceRemoteAttendanceNotAllowed =>
      'لا يُسمح بتسجيل الحضور عن بُعد';

  @override
  String get attendanceInvalidTimestamp => 'وقت حدث الحضور غير صالح';

  @override
  String get attendanceDuplicateRequestId => 'تم إرسال طلب الحضور هذا بالفعل';

  @override
  String get attendanceOperationNotFound => 'لم يتم العثور على عملية الحضور';

  @override
  String get attendanceSyncUnavailable => 'مزامنة الحضور غير مهيأة';

  @override
  String get attendanceSynchronizationFailed => 'فشلت مزامنة الحضور';

  @override
  String get attendanceUnsupportedTimezone =>
      'المنطقة الزمنية للشركة غير مدعومة بعد';

  @override
  String get attendanceCompanyUnavailable => 'الحضور غير متاح لهذه الشركة';

  @override
  String get attendanceWarningOutsideAllowedLocation =>
      'أنت خارج موقع المكتب؛ يُسمح بتسجيل الحضور';

  @override
  String get attendanceWarningOfflinePending =>
      'تم حفظ الحضور بانتظار المزامنة';

  @override
  String get attendanceWarningLatePunchIn => 'تسجيل حضور متأخر';

  @override
  String get attendanceWarningEarlyPunchOut => 'تسجيل انصراف مبكر';

  @override
  String get attendanceWarningUnscheduledDay => 'حضور في يوم غير مجدول';

  @override
  String get attendanceNotStarted => 'لم يبدأ';

  @override
  String get attendanceWorking => 'يعمل';

  @override
  String get attendanceOnBreak => 'في استراحة';

  @override
  String get attendanceCompleted => 'مكتمل';

  @override
  String get attendanceLate => 'متأخر';

  @override
  String get attendancePending => 'بانتظار المزامنة';

  @override
  String get attendanceSynced => 'تمت المزامنة';

  @override
  String get attendanceFailed => 'فشلت المزامنة';

  @override
  String get attendanceRejected => 'مرفوض';

  @override
  String get attendancePunchIn => 'تسجيل الحضور';

  @override
  String get attendanceBreakStart => 'بدء الاستراحة';

  @override
  String get attendanceBreakEnd => 'استئناف العمل';

  @override
  String get attendancePunchOut => 'تسجيل الانصراف';

  @override
  String get attendancePunchInNotAllowed => 'لا يُسمح بتسجيل الحضور';

  @override
  String get attendanceTodayTitle => 'حضور اليوم';

  @override
  String get attendanceWorkday => 'يوم عملك';

  @override
  String get attendanceCompleteTitle => 'اكتمل يوم العمل';

  @override
  String get attendancePunchingIn => 'جارٍ تسجيل الحضور…';

  @override
  String get attendancePunchingOut => 'جارٍ تسجيل الانصراف…';

  @override
  String get attendanceTakeBreak => 'بدء استراحة';

  @override
  String get attendanceStartingBreak => 'جارٍ بدء الاستراحة…';

  @override
  String get attendanceResumeWork => 'استئناف العمل';

  @override
  String get attendanceResumingWork => 'جارٍ استئناف العمل…';

  @override
  String get attendanceWorkTime => 'وقت العمل الحالي';

  @override
  String get attendanceCurrentLoggedWorkTime =>
      'وقت العمل المسجّل الحالي (اليوم)';

  @override
  String attendanceInsideGeofence(String name, String distance) {
    return 'داخل نطاق $name ($distance)';
  }

  @override
  String get attendanceCurrentBreak => 'الاستراحة الحالية';

  @override
  String get attendanceTotalBreak => 'إجمالي الاستراحات';

  @override
  String get attendanceElapsedTime => 'الوقت المنقضي';

  @override
  String get attendanceWorkedTime => 'وقت العمل';

  @override
  String get attendanceBreakTime => 'وقت الاستراحة';

  @override
  String get attendanceTodayShift => 'وردية اليوم';

  @override
  String get attendanceWorkLocation => 'موقع العمل';

  @override
  String get attendanceLocationChecking => 'جارٍ التحقق من موقعك…';

  @override
  String get attendanceLocationReady => 'الموقع جاهز';

  @override
  String get attendanceInsideLocation => 'داخل موقع العمل';

  @override
  String get attendanceOutsideLocation => 'خارج موقع العمل';

  @override
  String get attendanceLocationNotRequired => 'التحقق من الموقع غير مطلوب';

  @override
  String get attendanceLocationRequiredNote =>
      'سيتم التحقق من موقعك عند تنفيذ هذا الإجراء.';

  @override
  String get attendanceAccuracy => 'دقة الموقع';

  @override
  String get attendanceRadius => 'النطاق المسموح به';

  @override
  String get attendanceRefreshLocation => 'تحديث الموقع';

  @override
  String get attendanceAllowLocation => 'السماح بالوصول إلى الموقع';

  @override
  String get attendanceOpenSettings => 'فتح الإعدادات';

  @override
  String get attendancePermissionSettings =>
      'إذن الوصول إلى الموقع معطل في إعدادات النظام.';

  @override
  String get attendanceServicesNote => 'شغّل خدمات الموقع للمتابعة.';

  @override
  String get attendanceNoActivity => 'لا يوجد نشاط بعد';

  @override
  String get attendanceActivityNote => 'ستظهر هنا أحداث حضورك واستراحاتك.';

  @override
  String get attendanceTodayActivity => 'نشاط اليوم';

  @override
  String get attendancePunchInTime => 'وقت تسجيل الحضور';

  @override
  String get attendancePunchOutTime => 'وقت الخروج';

  @override
  String get attendanceCurrentTime => 'الوقت الحالي';

  @override
  String get attendanceBreakStartedLabel => 'بدأت الاستراحة';

  @override
  String get attendanceWorkResumedLabel => 'تم استئناف العمل';

  @override
  String get attendanceEndWorkday => 'هل تريد إنهاء يوم عملك؟';

  @override
  String get attendanceConfirmAction => 'تأكيد إجراء الحضور';

  @override
  String get attendanceContinue => 'متابعة';

  @override
  String get attendanceCloseBreakNote =>
      'ستنتهي استراحتك الحالية عند تسجيل الانصراف.';

  @override
  String get attendancePendingTitle => 'بانتظار المزامنة';

  @override
  String get attendancePendingNote =>
      'تم الحفظ على هذا الجهاز بانتظار التحقق عند توفر المزامنة.';

  @override
  String get attendanceFailedTitle => 'مزامنة الحضور تحتاج إلى مراجعة';

  @override
  String get attendanceFailedNote =>
      'تم حفظ حضورك محلياً ولكن تعذر التحقق منه.';

  @override
  String get attendanceRejectedTitle => 'تعذر التحقق من الحضور';

  @override
  String get attendanceRejectedNote =>
      'تم الاحتفاظ بأحداث الحضور المسجلة. تواصل مع الموارد البشرية لحل المشكلة.';

  @override
  String get attendanceRetrySync => 'إعادة محاولة المزامنة';

  @override
  String get attendanceRequeuedNote =>
      'تم وضع الحضور في قائمة انتظار المزامنة. خدمة المزامنة غير مهيأة بعد.';

  @override
  String get attendanceNotConfigured => 'لم يتم إعداد الحضور بعد';

  @override
  String get attendanceContactHr =>
      'تواصل مع الموارد البشرية لإكمال إعداد الحضور.';

  @override
  String get attendanceUnavailableTitle => 'الحضور غير متاح';

  @override
  String get attendanceStartNote => 'سجّل الحضور لبدء يوم عملك.';

  @override
  String get attendanceWorkingNote => 'يُحسب وقت عملك من الأحداث المسجلة.';

  @override
  String get attendanceBreakNote => 'يتوقف احتساب وقت العمل أثناء الاستراحة.';

  @override
  String get attendanceCompleteNote =>
      'تم تسجيل إجمالياتك النهائية ونشاطك أدناه.';

  @override
  String get attendanceExpectedHours => 'العمل المتوقع';

  @override
  String get attendanceGrace => 'فترة السماح';

  @override
  String get attendanceOnTime => 'في الوقت';

  @override
  String get attendanceTarget => 'المستهدف';

  @override
  String get attendanceShiftRemaining => 'المتبقي من الوردية';

  @override
  String get attendanceOpenAttendance => 'فتح الحضور';

  @override
  String get attendanceViewAttendance => 'عرض الحضور';

  @override
  String get attendanceStartsAt => 'يبدأ عند';

  @override
  String get attendanceWorked => 'العمل';

  @override
  String get attendanceBreak => 'استراحة';

  @override
  String get attendanceLastCheck => 'آخر تحقق من الموقع';

  @override
  String get attendanceCheckingSetup => 'جارٍ تحميل إعداد الحضور';

  @override
  String get attendanceWarningNote => 'راجع هذه التفاصيل قبل تسجيل حضورك.';

  @override
  String get attendanceDistance => 'المسافة من موقع العمل';

  @override
  String get attendanceTryAgain => 'إعادة المحاولة';

  @override
  String get attendanceLocationCaptureReady => 'تم تحديد الموقع';

  @override
  String get attendanceAccuracyLimit => 'الدقة المطلوبة';

  @override
  String get attendanceNoLocation => 'لم يتم تعيين موقع عمل';

  @override
  String get attendanceGoodMorning => 'صباح الخير';

  @override
  String get attendanceGoodAfternoon => 'طاب يومك';

  @override
  String get attendanceGoodEvening => 'مساء الخير';

  @override
  String attendanceMeters(String value) {
    return '$value م';
  }

  @override
  String get historyTitle => 'سجل الحضور';

  @override
  String get historyNav => 'السجل';

  @override
  String get historyMonthlySummary => 'الملخص الشهري';

  @override
  String get historyPreviousMonth => 'الشهر السابق';

  @override
  String get historyNextMonth => 'الشهر التالي';

  @override
  String get historyPresent => 'حاضر';

  @override
  String get historyLate => 'متأخر';

  @override
  String get historyIncomplete => 'غير مكتمل';

  @override
  String get historyCompletedOnly =>
      'تشمل إجماليات العمل والاستراحة السجلات المكتملة فقط.';

  @override
  String get historyEmpty => 'لا توجد سجلات حضور';

  @override
  String get historyFilteredEmpty => 'لا توجد سجلات حضور مطابقة';

  @override
  String get historyEmptyNote => 'لم يُسجّل أي نشاط في هذا الشهر.';

  @override
  String get historyFilteredNote => 'جرّب حالة أخرى أو امسح عوامل التصفية.';

  @override
  String get historyClearFilters => 'مسح عوامل التصفية';

  @override
  String get historyAllStatuses => 'كل الحالات';

  @override
  String get historyFilters => 'تصفية الحالات';

  @override
  String get historyApply => 'تطبيق التصفية';

  @override
  String get historyReset => 'إعادة تعيين';

  @override
  String get historyDetails => 'تفاصيل الحضور';

  @override
  String get historyDailySummary => 'الملخص اليومي';

  @override
  String get historyTimeline => 'التسلسل الزمني';

  @override
  String get historyBreaks => 'الاستراحات';

  @override
  String get historyMissingOut => 'لم يُسجّل الخروج';

  @override
  String get historyOpenBreak => 'استراحة غير مكتملة';

  @override
  String get historyNotRecorded => 'غير مسجّل';

  @override
  String get historyNeedsAttention => 'يحتاج إلى مراجعة';

  @override
  String get historyIncompleteNote =>
      'لا يحتوي هذا السجل على خروج. إجماليات العمل والاستراحة النهائية غير متاحة.';

  @override
  String get historyOpenBreakNote =>
      'لم تُسجّل العودة للعمل. لا توجد مدة نهائية لهذه الاستراحة.';

  @override
  String get historyGoToday => 'فتح حضور اليوم';

  @override
  String get historyActiveNote =>
      'هذا السجل ما زال مفتوحاً. استخدم اليوم للإجماليات المباشرة وإجراءات الحضور.';

  @override
  String get historyNotFound => 'سجل الحضور غير متاح';

  @override
  String get historyNotFoundNote => 'لم يتم العثور على هذا السجل في سجل حضورك.';

  @override
  String get historyOvernight => 'وردية ليلية';

  @override
  String get historyExpected => 'المدة المتوقعة';

  @override
  String get historyGrace => 'فترة السماح';

  @override
  String get historyWithinArea => 'داخل المنطقة المحددة';

  @override
  String get historyOutsideAllowed =>
      'خارج المنطقة المحددة · مسموح وفق السياسة';

  @override
  String get historyVerificationIssue => 'مشكلة في التحقق';

  @override
  String get historyContactHr =>
      'تم الاحتفاظ بالسجل الأصلي. تواصل مع الموارد البشرية بشأن مشكلة التحقق.';

  @override
  String get historyDate => 'التاريخ';

  @override
  String get historyStatus => 'الحالة';

  @override
  String get historyNow => 'الآن';

  @override
  String get historyRetry => 'تحديث';

  @override
  String get historyAverageWork => 'متوسط العمل لكل يوم مكتمل';

  @override
  String get historyNoBreaks => 'لا توجد استراحات مسجّلة';

  @override
  String historyFilterCount(String count) {
    return 'تصفية الحالات ($count)';
  }

  @override
  String get correctionRequest => 'طلب تصحيح';

  @override
  String get correctionMyRequests => 'طلباتي';

  @override
  String get correctionReviewQueue => 'طلبات التصحيح';

  @override
  String get correctionType => 'نوع التصحيح';

  @override
  String get correctionRequestedTime => 'التاريخ والوقت المطلوبان';

  @override
  String get correctionReason => 'السبب';

  @override
  String get correctionReviewNote => 'ملاحظة المراجعة';

  @override
  String get correctionSubmit => 'إرسال الطلب';

  @override
  String get correctionCancel => 'إلغاء الطلب';

  @override
  String get correctionApprove => 'موافقة';

  @override
  String get correctionReject => 'رفض';

  @override
  String get correctionPending => 'قيد المراجعة';

  @override
  String get correctionApproved => 'تمت الموافقة';

  @override
  String get correctionRejected => 'مرفوض';

  @override
  String get correctionCancelled => 'ملغى';

  @override
  String get correctionOriginal => 'الأصل';

  @override
  String get correctionRequested => 'المطلوب';

  @override
  String get correctionNoRequests => 'لا توجد طلبات تصحيح';

  @override
  String get correctionMissingPunchIn => 'تسجيل دخول مفقود';

  @override
  String get correctionMissingPunchOut => 'تسجيل خروج مفقود';

  @override
  String get correctionChangePunchIn => 'تعديل وقت الدخول';

  @override
  String get correctionChangePunchOut => 'تعديل وقت الخروج';

  @override
  String get correctionMissingBreakStart => 'بداية استراحة مفقودة';

  @override
  String get correctionMissingBreakEnd => 'نهاية استراحة مفقودة';

  @override
  String get correctionChangeBreakStart => 'تعديل بداية الاستراحة';

  @override
  String get correctionChangeBreakEnd => 'تعديل نهاية الاستراحة';

  @override
  String get correctionPreview => 'معاينة النتيجة الفعلية';

  @override
  String get correctionInvalid => 'تحقق من الوقت المطلوب وترتيب الأحداث.';

  @override
  String get correctionSaved => 'تم إرسال طلب التصحيح';

  @override
  String get correctionReviewSaved => 'تم حفظ المراجعة';

  @override
  String get correctionReasonRequired => 'أدخل السبب';

  @override
  String get workforceTeam => 'حضور الفريق';

  @override
  String get workforceAll => 'حضور جميع الموظفين';

  @override
  String get workforceNotStarted => 'لم يبدأ';

  @override
  String get workforceWorking => 'يعمل الآن';

  @override
  String get workforceOnBreak => 'في استراحة';

  @override
  String get workforceCompleted => 'مكتمل';

  @override
  String get workforceIncomplete => 'غير مكتمل';

  @override
  String get workforceNoSchedule => 'لا توجد مناوبة';

  @override
  String get workforceNoRecord => 'لا يوجد سجل';

  @override
  String get workforceSearch => 'ابحث عن موظف';

  @override
  String get workforceNoEmployees => 'لا يوجد موظفون مطابقون';

  @override
  String get workforceDepartment => 'القسم';

  @override
  String get workforceShift => 'المناوبة';

  @override
  String get workforceLocation => 'موقع العمل';

  @override
  String get workforceDate => 'تاريخ الحضور';

  @override
  String get workforceToday => 'اليوم';

  @override
  String get workforcePrevious => 'اليوم السابق';

  @override
  String get workforceNext => 'اليوم التالي';

  @override
  String get workforcePendingCorrection => 'تصحيح قيد المراجعة';

  @override
  String get workforceSort => 'ترتيب حسب';

  @override
  String get workforceName => 'الاسم';

  @override
  String get workforceNameDescending => 'الاسم (تنازليًا)';

  @override
  String get workforceCode => 'رمز الموظف';

  @override
  String get workforceAllFilter => 'الكل';

  @override
  String get reportTitle => 'تقارير الحضور';

  @override
  String get reportOverview => 'نظرة عامة';

  @override
  String get reportWorkHours => 'ساعات العمل';

  @override
  String get reportLate => 'التأخر عن الحضور';

  @override
  String get reportBreaks => 'تحليل الاستراحات';

  @override
  String get reportIssues => 'مشكلات الحضور';

  @override
  String get reportEmployees => 'ملخص الموظفين';

  @override
  String get reportToday => 'اليوم';

  @override
  String get reportThisWeek => 'هذا الأسبوع';

  @override
  String get reportThisMonth => 'هذا الشهر';

  @override
  String get reportLastMonth => 'الشهر الماضي';

  @override
  String get reportCustom => 'فترة مخصصة';

  @override
  String get reportFrom => 'من';

  @override
  String get reportTo => 'إلى';

  @override
  String get reportScopeTeam => 'فريقي';

  @override
  String get reportScopeCompany => 'الشركة';

  @override
  String get reportRecordedDays => 'أيام العمل المسجلة';

  @override
  String get reportCompletedDays => 'أيام العمل المكتملة';

  @override
  String get reportLateDays => 'سجلات التأخر';

  @override
  String get reportIncompleteDays => 'سجلات غير مكتملة';

  @override
  String get reportWorkTotal => 'مدة العمل';

  @override
  String get reportBreakTotal => 'مدة الاستراحة';

  @override
  String get reportAverageWork => 'المتوسط لكل يوم مسجل';

  @override
  String get reportPendingCorrections => 'تصحيحات معلقة';

  @override
  String get reportIssueDays => 'أيام بها مشكلات';

  @override
  String get reportTrend => 'أيام العمل المسجلة حسب التاريخ';

  @override
  String get reportDaily => 'يومي';

  @override
  String get reportWeekly => 'أسبوعي';

  @override
  String get reportMonthly => 'شهري';

  @override
  String get reportGroupBy => 'تجميع حسب';

  @override
  String get reportNoData =>
      'لا توجد سجلات حضور تطابق الفترة والمرشحات المحددة.';

  @override
  String get reportInProgress => 'حضور اليوم الجاري مؤقت حتى تسجيل الانصراف.';

  @override
  String get reportFilter => 'المرشحات';

  @override
  String get reportClearFilters => 'مسح المرشحات';

  @override
  String get reportEmployee => 'الموظف';

  @override
  String get reportStatus => 'الحالة';

  @override
  String get reportCorrections => 'التصحيحات';

  @override
  String get reportAny => 'الكل';

  @override
  String get reportYes => 'نعم';

  @override
  String get reportNo => 'لا';

  @override
  String get reportApply => 'تطبيق';

  @override
  String get reportExport => 'تصدير';

  @override
  String get reportCsv => 'تصدير CSV';

  @override
  String get reportPdf => 'تصدير PDF';

  @override
  String get reportExported => 'تم حفظ التقرير';

  @override
  String get reportExportFailed => 'تعذر تصدير التقرير';

  @override
  String get reportLoading => 'جارٍ تحميل التقرير';

  @override
  String get reportRefreshFailed => 'تعذر تحديث التقرير';

  @override
  String get reportUnavailable => 'تقارير الحضور غير متاحة.';

  @override
  String get reportDate => 'التاريخ';

  @override
  String get reportWorked => 'العمل';

  @override
  String get reportBreak => 'الاستراحة';

  @override
  String get reportLateBy => 'مدة التأخر';

  @override
  String get reportRecorded => 'الأيام المسجلة';

  @override
  String get reportCompleted => 'مكتمل';

  @override
  String get reportLateCount => 'متأخر';

  @override
  String get reportIssuesCount => 'المشكلات';

  @override
  String get reportPending => 'معلق';

  @override
  String get reportShiftStart => 'بداية الوردية';

  @override
  String get reportPunchIn => 'تسجيل الحضور';

  @override
  String get reportDepartment => 'القسم';

  @override
  String get reportLocation => 'الموقع';

  @override
  String get reportPeriod => 'الفترة';

  @override
  String get reportGenerated => 'تاريخ الإنشاء';

  @override
  String get reportPage => 'الصفحة';

  @override
  String get reportSortNewest => 'الأحدث أولاً';

  @override
  String get reportSortOldest => 'الأقدم أولاً';

  @override
  String get reportSortEmployee => 'اسم الموظف';

  @override
  String get reportSortWork => 'أطول مدة عمل';

  @override
  String get reportSortBreak => 'أطول مدة استراحة';

  @override
  String get reportFiltersApplied => 'المرشحات المطبقة';

  @override
  String get attendanceNeedsReview => 'الحضور يحتاج إلى مراجعة';

  @override
  String get attendanceConflict => 'تعارض في الحضور';

  @override
  String get attendanceConflictMessage =>
      'لا يطابق حضورك المحلي أحدث سجل على الخادم.';

  @override
  String get attendanceCouldNotBeVerified => 'تعذر التحقق من الحضور';

  @override
  String get attendanceNeedsAttention => 'الحضور يحتاج إلى انتباه';

  @override
  String get reportSubtitle =>
      'تحليل نشاط الحضور وساعات العمل والتوقيت وجودة السجلات.';

  @override
  String get reportActivityTrend => 'نشاط الحضور';

  @override
  String get reportActivityTrendDesc => 'السجلات المسجلة حسب التاريخ.';

  @override
  String get reportStatusDistribution => 'حالة الحضور';

  @override
  String get reportStatusDistributionDesc => 'تكوين السجلات المسجلة.';

  @override
  String get reportWorkHoursTrend => 'ساعات العمل المسجلة';

  @override
  String get reportWorkHoursTrendDesc => 'إجمالي وقت العمل المسجل حسب التاريخ.';

  @override
  String get reportLateTrend => 'التأخر في الحضور';

  @override
  String get reportLateTrendDesc => 'السجلات المتأخرة حسب التاريخ.';

  @override
  String get reportBreakTrend => 'وقت الاستراحة';

  @override
  String get reportBreakTrendDesc => 'وقت الاستراحة المسجل حسب التاريخ.';

  @override
  String get reportIssuesByType => 'المشكلات حسب النوع';

  @override
  String get reportIssuesByTypeDesc => 'ما يحتاج إلى انتباه خلال هذه الفترة.';

  @override
  String get reportNeedsAttention => 'يحتاج إلى انتباه';

  @override
  String get reportDetailedRecords => 'السجلات التفصيلية';

  @override
  String get reportStatusWorking => 'قيد العمل';

  @override
  String get reportStatusCompleted => 'مكتمل';

  @override
  String get reportStatusLate => 'متأخر';

  @override
  String get reportStatusIssues => 'مشكلات';

  @override
  String get reportIssueRejected => 'حضور مرفوض';

  @override
  String get reportIssueSyncFailure => 'فشل المزامنة';

  @override
  String get reportIssuePendingCorrection => 'تصحيح معلّق';

  @override
  String get reportIssueMissingPunchOut => 'انصراف مفقود';

  @override
  String get reportViewTeam => 'عرض الفريق';

  @override
  String get reportViewCompany => 'عرض الشركة';

  @override
  String get reportRecordedEmployees => 'الموظفون المسجلون';

  @override
  String get permissionLeaveViewSelf => 'عرض إجازتي';

  @override
  String get permissionLeaveRequest => 'طلب إجازة';

  @override
  String get permissionLeaveCancelSelf => 'إلغاء إجازتي';

  @override
  String get permissionLeaveViewTeam => 'عرض إجازات الفريق';

  @override
  String get permissionLeaveApproveTeam => 'اعتماد إجازات الفريق';

  @override
  String get permissionLeaveViewAll => 'عرض إجازات الشركة';

  @override
  String get permissionLeaveApproveAll => 'اعتماد إجازات الشركة';

  @override
  String get permissionLeaveManage => 'إدارة الإجازات';

  @override
  String get permissionLeaveBalanceViewSelf => 'عرض رصيد إجازتي';

  @override
  String get permissionLeaveBalanceViewTeam => 'عرض أرصدة الفريق';

  @override
  String get permissionLeaveBalanceViewAll => 'عرض أرصدة الشركة';

  @override
  String get permissionLeaveBalanceAdjust => 'تعديل أرصدة الإجازات';

  @override
  String get permissionLeaveTypeView => 'عرض أنواع الإجازات';

  @override
  String get permissionLeaveTypeManage => 'إدارة أنواع الإجازات';

  @override
  String get permissionLeavePolicyView => 'عرض سياسات الإجازات';

  @override
  String get permissionLeavePolicyManage => 'إدارة سياسات الإجازات';

  @override
  String get permissionHolidayView => 'عرض العطلات';

  @override
  String get permissionHolidayManage => 'إدارة العطلات';

  @override
  String get permissionLeaveReportView => 'عرض تقارير الإجازات';

  @override
  String get leaveMyLeave => 'إجازاتي';

  @override
  String get leaveNewRequest => 'طلب جديد';

  @override
  String get leaveMyRequests => 'طلباتي';

  @override
  String get leaveApprovals => 'الاعتمادات';

  @override
  String get leaveTeam => 'إجازات الفريق';

  @override
  String get leaveAllNav => 'كل الإجازات';

  @override
  String get leaveBalancesNav => 'الأرصدة';

  @override
  String get leaveCalendarNav => 'التقويم';

  @override
  String get leaveTypesNav => 'أنواع الإجازات';

  @override
  String get leavePoliciesNav => 'سياسات الإجازات';

  @override
  String get holidaysNav => 'العطلات';

  @override
  String get leaveTypeIntro => 'اضبط أنواع الإجازات التي يمكن للموظفين طلبها.';

  @override
  String get leavePolicyIntro => 'حدد الاستحقاق وقواعد الطلب لكل نوع إجازة.';

  @override
  String get holidayIntro =>
      'اضبط العطلات الرسمية وعطلات الشركة والعطلات الاختيارية.';

  @override
  String get leaveType => 'نوع الإجازة';

  @override
  String get leaveCompensation => 'التعويض';

  @override
  String get leaveRequiresApproval => 'يتطلب موافقة';

  @override
  String get leaveAllowsHalfDay => 'يسمح بنصف يوم';

  @override
  String get leaveRequiresReason => 'السبب مطلوب';

  @override
  String get leaveRequiresAttachment => 'المرفق مطلوب';

  @override
  String get leaveCompensationPaid => 'مدفوعة';

  @override
  String get leaveCompensationUnpaid => 'غير مدفوعة';

  @override
  String get leaveCompensationInformational => 'إعلامية';

  @override
  String get leavePolicy => 'سياسة الإجازة';

  @override
  String get leavePolicyLeaveType => 'نوع الإجازة';

  @override
  String get leavePolicyEntitlement => 'الاستحقاق السنوي';

  @override
  String get leavePolicyMinDays => 'الحد الأدنى للطلب';

  @override
  String get leavePolicyMaxConsecutive => 'أقصى عدد أيام متتالية';

  @override
  String get leavePolicyAdvanceNotice => 'الإشعار المسبق';

  @override
  String get leavePolicyAllowPast => 'السماح بالطلبات السابقة';

  @override
  String get leavePolicyPastWindow => 'نافذة الطلبات السابقة';

  @override
  String get leavePolicyNegative => 'السماح بالرصيد السالب';

  @override
  String get leavePolicyCarryForward => 'ترحيل الرصيد';

  @override
  String get leavePolicyCarryLimit => 'حد الترحيل';

  @override
  String get leavePolicyEmployment => 'أنواع التوظيف المطبقة';

  @override
  String get days => 'يوم';

  @override
  String get holiday => 'عطلة';

  @override
  String get holidayDate => 'التاريخ';

  @override
  String get holidayEndDate => 'تاريخ الانتهاء';

  @override
  String get holidayTypeField => 'النوع';

  @override
  String get holidayScopeField => 'النطاق';

  @override
  String get holidayWorkLocations => 'أماكن العمل';

  @override
  String get holidayOptional => 'عطلة اختيارية';

  @override
  String get holidayTypePublic => 'عطلة رسمية';

  @override
  String get holidayTypeCompany => 'عطلة الشركة';

  @override
  String get holidayTypeOptional => 'عطلة اختيارية';

  @override
  String get holidayTypeSpecial => 'إغلاق خاص';

  @override
  String get holidayScopeCompanyWide => 'الشركة بأكملها';

  @override
  String get holidayScopeSpecific => 'أماكن عمل محددة';

  @override
  String get leaveRequestTitle => 'طلب إجازة';

  @override
  String get leaveStartDate => 'تاريخ البداية';

  @override
  String get leaveEndDate => 'تاريخ النهاية';

  @override
  String get leaveStartPortion => 'اليوم الأول';

  @override
  String get leaveEndPortion => 'اليوم الأخير';

  @override
  String get leaveDayFull => 'يوم كامل';

  @override
  String get leaveDayFirstHalf => 'النصف الأول';

  @override
  String get leaveDaySecondHalf => 'النصف الثاني';

  @override
  String get leaveReasonLabel => 'السبب';

  @override
  String get leaveAttachmentLabel => 'المرفق';

  @override
  String get leavePreviewTitle => 'الملخص';

  @override
  String get leaveRequestedDays => 'الأيام المطلوبة';

  @override
  String get leaveAvailableDays => 'المتاح';

  @override
  String get leaveAfterApproval => 'بعد الموافقة';

  @override
  String get leaveExcludedWeekends => 'عطلات نهاية الأسبوع المستثناة';

  @override
  String get leaveExcludedHolidays => 'العطلات المستثناة';

  @override
  String get leaveSubmitRequest => 'إرسال الطلب';

  @override
  String get leaveNoTypes => 'لا توجد أنواع إجازات متاحة.';

  @override
  String get leaveSelectType => 'اختر نوع الإجازة';

  @override
  String get leaveStatusPending => 'معلّق';

  @override
  String get leaveStatusApproved => 'معتمد';

  @override
  String get leaveStatusRejected => 'مرفوض';

  @override
  String get leaveStatusCancelled => 'ملغى';

  @override
  String get leaveApprove => 'اعتماد';

  @override
  String get leaveReject => 'رفض';

  @override
  String get leaveCancelRequest => 'إلغاء الطلب';

  @override
  String get leaveReviewNote => 'ملاحظة';

  @override
  String get leaveCancelReason => 'سبب الإلغاء';

  @override
  String get leaveEmployee => 'الموظف';

  @override
  String get leaveDepartment => 'القسم';

  @override
  String get leaveDateRange => 'التواريخ';

  @override
  String get leaveApprovedBy => 'راجعه';

  @override
  String get leaveSubmittedOn => 'تم الإرسال';

  @override
  String get leaveViewDetails => 'عرض التفاصيل';

  @override
  String get leaveApply => 'تطبيق';

  @override
  String get leaveBalancesTitle => 'أرصدة الإجازات';

  @override
  String get leaveEntitlement => 'الاستحقاق';

  @override
  String get leaveUsed => 'المستخدم';

  @override
  String get leavePendingBalance => 'المعلّق';

  @override
  String get leaveAvailable => 'المتاح';

  @override
  String get leaveAdjustBalance => 'تعديل الرصيد';

  @override
  String get leaveAdjustAdd => 'إضافة أيام';

  @override
  String get leaveAdjustRemove => 'خصم أيام';

  @override
  String get leaveAdjustQuantity => 'الأيام';

  @override
  String get leaveAdjustReason => 'السبب';

  @override
  String get leaveLedger => 'سجل الرصيد';

  @override
  String get leaveNoBalance => 'لا توجد سجلات رصيد.';

  @override
  String get leaveSelectEmployee => 'الموظف';

  @override
  String get leaveEmployeeFilter => 'الموظف';

  @override
  String get leaveCalendarTitle => 'تقويم الإجازات';

  @override
  String get leaveCalendarLegendLeave => 'إجازة';

  @override
  String get leaveCalendarLegendHoliday => 'عطلة';

  @override
  String get leaveCalendarEmpty => 'لا توجد إجازات أو عطلات في هذه الفترة.';

  @override
  String get leaveFrom => 'من';

  @override
  String get leaveTo => 'إلى';

  @override
  String get leaveRequestsEmpty => 'لا توجد طلبات إجازة.';

  @override
  String get leaveApprovalsEmpty => 'لا توجد طلبات بانتظار المراجعة.';

  @override
  String get leaveNoPendingRequests => 'لا توجد لديك طلبات إجازة معلّقة.';

  @override
  String get leaveOnLeaveToday => 'في إجازة اليوم';

  @override
  String get workdayScheduled => 'مجدول';

  @override
  String get workdayWorking => 'قيد العمل';

  @override
  String get workdayOnBreak => 'في استراحة';

  @override
  String get workdayCompleted => 'مكتمل';

  @override
  String get workdayIncomplete => 'غير مكتمل';

  @override
  String get workdayOnLeave => 'في إجازة';

  @override
  String get workdayHoliday => 'عطلة';

  @override
  String get workdayNonWorking => 'غير يوم عمل';

  @override
  String get workdayIssue => 'مشكلة';

  @override
  String get leavePermissionDenied => 'ليس لديك صلاحية الوصول إلى الإجازات.';

  @override
  String get leaveStorageError => 'تعذر تحميل بيانات الإجازات.';

  @override
  String get leaveUnavailable => 'الإجازات غير متاحة.';

  @override
  String get leaveTypeInactive => 'نوع الإجازة المحدد غير متاح.';

  @override
  String get leaveNoEmployee => 'حسابك غير مرتبط بموظف.';

  @override
  String get leaveInvalidDateRange =>
      'يجب أن يكون تاريخ النهاية بعد تاريخ البداية.';

  @override
  String get leaveReasonRequired => 'السبب مطلوب.';

  @override
  String get leaveNoWorkingDays => 'النطاق المحدد لا يحتوي على أيام عمل.';

  @override
  String get leaveMinimumDays => 'الطلب أقصر من الحد الأدنى للسياسة.';

  @override
  String get leaveOverlapping => 'هذا الطلب يتداخل مع طلب موجود.';

  @override
  String get leaveInsufficientBalance => 'لا يوجد رصيد إجازات كافٍ.';

  @override
  String get leavePastRequestNotAllowed =>
      'غير مسموح بطلبات الإجازة بأثر رجعي.';

  @override
  String get leaveAdvanceNoticeRequired =>
      'هذا الطلب لا يستوفي شرط الإشعار المسبق.';

  @override
  String get leaveInvalidQuantity => 'أدخل كمية صحيحة.';

  @override
  String get leaveRequestNotFound => 'لم يتم العثور على طلب الإجازة.';

  @override
  String get leaveAlreadyReviewed => 'تمت مراجعة هذا الطلب بالفعل.';

  @override
  String get leaveCannotCancelApproved =>
      'الإجازة المعتمدة يمكن إلغاؤها فقط من قبل مدير.';

  @override
  String get leaveReviewNoteRequired => 'الملاحظة مطلوبة.';

  @override
  String get leaveSelfApprovalNotAllowed => 'لا يمكنك اعتماد إجازتك الخاصة.';

  @override
  String get leaveSaved => 'تم حفظ الإجازة.';

  @override
  String get leaveRequestSubmitted => 'تم إرسال طلب الإجازة.';

  @override
  String get leaveIncludeInactive => 'تضمين غير النشط';

  @override
  String get leaveUpcoming => 'القادمة';

  @override
  String get leavePendingApproval => 'بانتظار الاعتماد';

  @override
  String get leaveApprovedThisMonth => 'المعتمدة هذا الشهر';

  @override
  String get leaveTeamMembers => 'أعضاء الفريق';

  @override
  String get leaveNoEmployeesOnLeave => 'لا يوجد موظفون في إجازة اليوم.';

  @override
  String get leaveNoUpcoming => 'لا توجد إجازات قادمة.';

  @override
  String get leaveHalfDay => 'نصف يوم';

  @override
  String get leaveFullDay => 'يوم كامل';

  @override
  String get leaveReturnDate => 'تاريخ العودة';

  @override
  String get leaveStatusField => 'الحالة';

  @override
  String get leaveReviewRequest => 'مراجعة الطلب';

  @override
  String get leaveCompanyLeave => 'إجازات الشركة';

  @override
  String get leaveApprovalsTitle => 'اعتمادات الإجازات';

  @override
  String get leaveApprovalsSubtitle =>
      'راجع طلبات إجازات الموظفين التي تتطلب إجراءك.';

  @override
  String get leaveTeamSubtitle =>
      'اعرض الإجازات القادمة وتوفر الفريق والطلبات.';

  @override
  String get leaveAllSubtitle => 'راقب إجازات الشركة والتوفر والطلبات.';

  @override
  String get leaveOverviewSubtitle => 'إجازاتك وتوفر الفريق والطلبات.';

  @override
  String get leavePendingRequests => 'الطلبات المعلّقة';

  @override
  String get leaveStartingSoon => 'تبدأ قريباً';

  @override
  String get leaveTeamRequests => 'طلبات الفريق';

  @override
  String get leaveCompanyRequests => 'طلبات الشركة';

  @override
  String get leaveAvailableBalance => 'الرصيد المتاح';

  @override
  String get leaveBalanceAfterApproval => 'الرصيد بعد الموافقة';

  @override
  String get leaveViewEmployeeLeave => 'عرض إجازات الموظف';

  @override
  String get leaveEmployeeLeave => 'إجازات الموظف';

  @override
  String get leaveNoPendingApprovals => 'لا توجد طلبات تتطلب اعتمادك.';

  @override
  String get leaveSearchEmployee => 'بحث عن موظف';

  @override
  String get leavePeriodAll => 'الكل';

  @override
  String get leavePeriodToday => 'اليوم';

  @override
  String get leavePeriodThisWeek => 'هذا الأسبوع';

  @override
  String get leavePeriodThisMonth => 'هذا الشهر';

  @override
  String get leavePeriodNext30 => 'الأيام الثلاثون القادمة';

  @override
  String get leavePeriodCustom => 'مخصص';

  @override
  String get leaveClearFilters => 'مسح الفلاتر';

  @override
  String get leaveActiveFilters => 'الفلاتر النشطة';

  @override
  String get leaveManageSettings => 'إدارة إعدادات الإجازات';

  @override
  String get leaveViewAllLeave => 'عرض كل الإجازات';

  @override
  String get leaveReviewQueue => 'قائمة المراجعة';

  @override
  String get leaveNoBalanceForFilters => 'لا يوجد رصيد إجازات للفلاتر المحددة.';

  @override
  String get leaveRequestSection => 'الطلب';

  @override
  String get leaveEmployeeSection => 'الموظف';

  @override
  String get leaveBalanceSection => 'الرصيد';

  @override
  String get leaveDecisionSection => 'القرار';

  @override
  String get leaveWorkingDays => 'أيام العمل للإجازة';

  @override
  String get leavePortion => 'الجزء';

  @override
  String get leaveStart => 'البداية';

  @override
  String get leaveReturn => 'العودة';

  @override
  String get leaveOnLeave => 'في إجازة';

  @override
  String get leaveUpcomingHoliday => 'العطلة القادمة';

  @override
  String get leaveUpcomingTeamLeave => 'إجازات الفريق القادمة';

  @override
  String get leavePendingApprovals => 'الاعتمادات المعلّقة';

  @override
  String get leaveMyLeaveOverview => 'إجازاتي';

  @override
  String get leaveTeamOverview => 'إجازات الفريق';

  @override
  String get leaveCompanyOverview => 'إجازات الشركة';

  @override
  String get leaveEmployeeUnavailable => 'معلومات إجازات هذا الموظف غير متاحة.';

  @override
  String get leaveScopeDenied =>
      'ليس لديك صلاحية الوصول إلى نطاق الإجازات هذا.';

  @override
  String get leaveRecentRequests => 'الطلبات الأخيرة';

  @override
  String get leaveBalanceLedger => 'سجل الرصيد';

  @override
  String get leaveAdjustmentAdded => 'أُضيف إلى الرصيد';

  @override
  String get leaveAdjustmentDeducted => 'خُصم من الرصيد';

  @override
  String get leaveEffectiveDate => 'تاريخ السريان';

  @override
  String get leaveCurrentAvailable => 'المتاح الحالي';

  @override
  String get leavePreviewNewAvailable => 'الرصيد المتاح الجديد';

  @override
  String get leaveNoTeam => 'لا يوجد فريق متاح لهذا الحساب.';

  @override
  String get leaveApprovalsEmptyQueue => 'لا توجد طلبات بانتظار مراجعتك.';

  @override
  String get leaveRequestedPeriod => 'الفترة المطلوبة';

  @override
  String get holidayTypeFestival => 'عطلة مهرجان';

  @override
  String get holidayTypeRegional => 'عطلة إقليمية';

  @override
  String get holidaySourceManual => 'يدوي';

  @override
  String get holidaySourceCopied => 'منسوخ من العام السابق';

  @override
  String get holidaySourceImported => 'مستورد';

  @override
  String get holidaySourceTemplate => 'قالب الشركة';

  @override
  String get holidayCalendarTitle => 'تقويم العطلات';

  @override
  String get holidayCalendarSubtitle =>
      'أدر العطلات الرسمية والمهرجانات والإقليمية وعطلات الشركة.';

  @override
  String get holidayYearLabel => 'سنة العطلات';

  @override
  String get addHoliday => 'إضافة عطلة';

  @override
  String get editHoliday => 'تعديل العطلة';

  @override
  String get manageHolidays => 'إدارة العطلات';

  @override
  String get copyPreviousYear => 'نسخ العام السابق';

  @override
  String get importHolidays => 'استيراد العطلات';

  @override
  String get setUpHolidayCalendar => 'إعداد تقويم العطلات';

  @override
  String get startBlank => 'البدء فارغاً';

  @override
  String get holidayCalendarStatus => 'حالة تقويم العطلات';

  @override
  String get activeHolidays => 'العطلات النشطة';

  @override
  String get nextHoliday => 'العطلة القادمة';

  @override
  String get holidayNotConfigured => 'غير مُعد';

  @override
  String get noHolidaysConfigured => 'لا توجد عطلات مُعدة لهذه السنة.';

  @override
  String get holidayPublishedEmpty => 'لم تُنشر أي عطلات للشركة في هذه الفترة.';

  @override
  String get applyTo => 'تنطبق على';

  @override
  String get holidayMultiDay => 'عطلة متعددة الأيام';

  @override
  String get holidayBasicInfo => 'المعلومات الأساسية';

  @override
  String get holidayApplicability => 'النطاق';

  @override
  String get holidayOptionality => 'الاختيارية';

  @override
  String get holidaySourceField => 'المصدر';

  @override
  String get holidayDuplicateWarning =>
      'توجد عطلة بنفس الاسم والتاريخ والنطاق بالفعل.';

  @override
  String get holidayImportPreview => 'معاينة الاستيراد';

  @override
  String get holidayImportPaste => 'لصق CSV';

  @override
  String get holidayImportHint =>
      'الأعمدة: name, date, endDate, type, optional, scope, workLocations, description';

  @override
  String get holidayImportConfirm => 'استيراد';

  @override
  String get holidayImportImported => 'تم استيرادها';

  @override
  String get holidayImportSkipped => 'تم تخطيها';

  @override
  String get holidayCopyNote =>
      'تحتفظ الإدخالات المنسوخة بالشهر واليوم — تحقق من تواريخ المهرجانات قبل التأكيد.';

  @override
  String get verifyFestivalDates =>
      'منسوخ من العام السابق — تحقق من تواريخ المهرجانات.';

  @override
  String get holidaySelectLocations => 'اختر أماكن العمل';

  @override
  String get holidaySearchLocations => 'بحث في أماكن العمل';

  @override
  String get holidayTypeHelperPublic => 'العطلات الرسمية/الحكومية';

  @override
  String get holidayTypeHelperFestival => 'العطلات الدينية أو المهرجانات';

  @override
  String get holidayTypeHelperRegional => 'العطلات المحلية/الإقليمية';

  @override
  String get holidayTypeHelperCompany => 'العطلات التي تعلنها الشركة';

  @override
  String get holidayTypeHelperClosure => 'الإغلاقات الخاصة';

  @override
  String get nextHolidayDaysAway => 'يوم متبقٍ';

  @override
  String get upcomingLeave => 'الإجازات القادمة';

  @override
  String get pendingRequest => 'طلب معلّق';

  @override
  String get teamCalendar => 'تقويم الفريق';

  @override
  String get reviewRequests => 'مراجعة الطلبات';

  @override
  String get viewRequests => 'الطلبات';

  @override
  String get viewUpcoming => 'القادمة';

  @override
  String get viewToday => 'اليوم';

  @override
  String get selectedDay => 'اليوم المحدد';

  @override
  String get dayAgenda => 'جدول اليوم';

  @override
  String get noEventsOnDay => 'لا توجد إجازات أو عطلات في هذا اليوم.';

  @override
  String get leaveAndHolidayCalendar => 'تقويم الإجازات والعطلات';

  @override
  String get leaveViewMode => 'العرض';

  @override
  String get leaveBalanceAvailableLabel => 'متاح';

  @override
  String get leaveBalanceUsedLabel => 'مستخدم';

  @override
  String get leaveBalancePendingLabel => 'معلّق';

  @override
  String get leaveBalanceEntitlementLabel => 'الاستحقاق';

  @override
  String get leaveHolidayThisYear => 'عطلات هذه السنة';

  @override
  String get leaveManageHolidaysHint =>
      'أدر تقويم العطلات الرسمية والمهرجانات وعطلات الشركة السنوي.';

  @override
  String get leaveSearchOrFilter => 'بحث';

  @override
  String get leaveAllTypes => 'كل الأنواع';

  @override
  String get leaveAllStatuses => 'كل الحالات';

  @override
  String get leaveAllPeriods => 'كل الفترات';

  @override
  String get leaveDayOne => 'يوم';

  @override
  String get hrPermModuleHr => 'الموارد البشرية';

  @override
  String get hrPermSubEmployees => 'الموظفون';

  @override
  String get hrPermSubAttendance => 'الحضور';

  @override
  String get hrPermSubLeave => 'الإجازات والعطلات';

  @override
  String get hrPermSubReports => 'التقارير';

  @override
  String get hrPermSubConfiguration => 'الإعدادات';

  @override
  String get hrPermEmployeesView => 'عرض سجلات الموظفين';

  @override
  String get hrPermEmployeesViewDesc =>
      'الاطلاع على سجلات الموظفين ضمن النطاق المحدد.';

  @override
  String get hrPermEmployeesCreate => 'إضافة موظف';

  @override
  String get hrPermEmployeesCreateDesc => 'إضافة موظفين جدد إلى الشركة.';

  @override
  String get hrPermEmployeesEdit => 'تعديل موظف';

  @override
  String get hrPermEmployeesEditDesc => 'تحديث بيانات الموظف وإسناداته.';

  @override
  String get hrPermEmployeesDeactivate => 'إيقاف موظف';

  @override
  String get hrPermEmployeesDeactivateDesc =>
      'إيقاف أو إعادة تنشيط سجلات الموظفين.';

  @override
  String get hrPermAttendanceSelfView => 'عرض حضوري';

  @override
  String get hrPermAttendanceSelfViewDesc => 'عرض الحضور والسجل الشخصي.';

  @override
  String get hrPermAttendanceSelfPunch => 'تسجيل الحضور';

  @override
  String get hrPermAttendanceSelfPunchDesc => 'بدء يوم العمل.';

  @override
  String get hrPermAttendanceSelfPunchOut => 'تسجيل الانصراف';

  @override
  String get hrPermAttendanceSelfPunchOutDesc => 'إنهاء يوم العمل.';

  @override
  String get hrPermAttendanceSelfBreak => 'أخذ استراحة';

  @override
  String get hrPermAttendanceSelfBreakDesc => 'بدء وإنهاء الاستراحات.';

  @override
  String get hrPermAttendanceSelfCorrection => 'طلب تصحيح الحضور';

  @override
  String get hrPermAttendanceSelfCorrectionDesc => 'إرسال طلبات تصحيح الحضور.';

  @override
  String get hrPermAttendanceRecordsView => 'عرض سجلات الحضور';

  @override
  String get hrPermAttendanceRecordsViewDesc =>
      'الاطلاع على حضور الفريق ضمن النطاق المحدد.';

  @override
  String get hrPermAttendanceCorrectionsReview => 'مراجعة تصحيحات الحضور';

  @override
  String get hrPermAttendanceCorrectionsReviewDesc =>
      'الموافقة على طلبات تصحيح الحضور أو رفضها.';

  @override
  String get hrPermAttendanceCorrectionsApply => 'تطبيق تصحيحات الحضور';

  @override
  String get hrPermAttendanceCorrectionsApplyDesc =>
      'تصحيح سجلات الحضور مباشرة.';

  @override
  String get hrPermAttendanceReportsView => 'عرض تقارير الحضور';

  @override
  String get hrPermAttendanceReportsViewDesc =>
      'الاطلاع على تقارير وتحليلات الحضور.';

  @override
  String get hrPermLeaveSelfView => 'عرض إجازاتي';

  @override
  String get hrPermLeaveSelfViewDesc => 'عرض طلبات الإجازة الشخصية.';

  @override
  String get hrPermLeaveSelfRequest => 'طلب إجازة';

  @override
  String get hrPermLeaveSelfRequestDesc => 'تقديم طلبات إجازة جديدة.';

  @override
  String get hrPermLeaveSelfCancel => 'إلغاء إجازتي';

  @override
  String get hrPermLeaveSelfCancelDesc =>
      'إلغاء طلبات الإجازة الشخصية المعلقة.';

  @override
  String get hrPermLeaveSelfBalance => 'عرض رصيدي';

  @override
  String get hrPermLeaveSelfBalanceDesc => 'عرض أرصدة الإجازات الشخصية.';

  @override
  String get hrPermLeaveRecordsView => 'عرض سجلات الإجازات';

  @override
  String get hrPermLeaveRecordsViewDesc =>
      'الاطلاع على سجلات الإجازات ضمن النطاق المحدد.';

  @override
  String get hrPermLeaveRequestsReview => 'مراجعة طلبات الإجازة';

  @override
  String get hrPermLeaveRequestsReviewDesc =>
      'الموافقة على طلبات الإجازة أو رفضها ضمن النطاق المحدد.';

  @override
  String get hrPermLeaveBalancesView => 'عرض أرصدة الإجازات';

  @override
  String get hrPermLeaveBalancesViewDesc =>
      'الاطلاع على أرصدة الإجازات ضمن النطاق المحدد.';

  @override
  String get hrPermLeaveBalancesAdjust => 'تعديل أرصدة الإجازات';

  @override
  String get hrPermLeaveBalancesAdjustDesc =>
      'إضافة أو خصم رصيد الإجازات للموظفين.';

  @override
  String get hrPermLeaveSettingsManage => 'إدارة إعدادات الإجازات';

  @override
  String get hrPermLeaveSettingsManageDesc =>
      'إدارة إعدادات الإجازات بشكل عام.';

  @override
  String get hrPermLeaveTypesView => 'عرض أنواع الإجازات';

  @override
  String get hrPermLeaveTypesViewDesc => 'الاطلاع على أنواع الإجازات.';

  @override
  String get hrPermLeaveTypesManage => 'إدارة أنواع الإجازات';

  @override
  String get hrPermLeaveTypesManageDesc => 'إنشاء وتعديل أنواع الإجازات.';

  @override
  String get hrPermLeavePoliciesView => 'عرض سياسات الإجازات';

  @override
  String get hrPermLeavePoliciesViewDesc => 'الاطلاع على سياسات الإجازات.';

  @override
  String get hrPermLeavePoliciesManage => 'إدارة سياسات الإجازات';

  @override
  String get hrPermLeavePoliciesManageDesc => 'إنشاء وتعديل سياسات الإجازات.';

  @override
  String get hrPermHolidaysView => 'عرض العطلات';

  @override
  String get hrPermHolidaysViewDesc => 'الاطلاع على تقويم العطلات.';

  @override
  String get hrPermHolidaysManage => 'إدارة العطلات';

  @override
  String get hrPermHolidaysManageDesc => 'إعداد العطلات والتقاويم.';

  @override
  String get hrPermReportsLeaveView => 'عرض تقارير الإجازات';

  @override
  String get hrPermReportsLeaveViewDesc =>
      'الاطلاع على تقارير وتحليلات الإجازات.';

  @override
  String get hrPermShiftsView => 'عرض الورديات';

  @override
  String get hrPermShiftsViewDesc => 'الاطلاع على إعدادات الورديات.';

  @override
  String get hrPermShiftsManage => 'إدارة الورديات';

  @override
  String get hrPermShiftsManageDesc => 'إنشاء وتعديل الورديات.';

  @override
  String get hrPermLocationsView => 'عرض مواقع العمل';

  @override
  String get hrPermLocationsViewDesc => 'الاطلاع على إعدادات مواقع العمل.';

  @override
  String get hrPermLocationsManage => 'إدارة مواقع العمل';

  @override
  String get hrPermLocationsManageDesc => 'إنشاء وتعديل مواقع العمل.';

  @override
  String get hrPermPoliciesView => 'عرض سياسات الحضور';

  @override
  String get hrPermPoliciesViewDesc => 'الاطلاع على إعدادات سياسات الحضور.';

  @override
  String get hrPermPoliciesManage => 'إدارة سياسات الحضور';

  @override
  String get hrPermPoliciesManageDesc => 'إنشاء وتعديل سياسات الحضور.';

  @override
  String get servicesPermModuleServices => 'الخدمات';

  @override
  String get servicesPermSubCustomers => 'العملاء';

  @override
  String get servicesPermSubSites => 'مواقع الخدمة';

  @override
  String get servicesPermSubTeams => 'فرق الخدمة';

  @override
  String get servicesPermSubConfiguration => 'الإعدادات';

  @override
  String get servicesPermCustomersView => 'عرض العملاء';

  @override
  String get servicesPermCustomersViewDesc => 'الاطلاع على دليل عملاء الخدمة.';

  @override
  String get servicesPermCustomersCreate => 'إضافة عميل';

  @override
  String get servicesPermCustomersCreateDesc => 'إضافة عملاء خدمة جدد.';

  @override
  String get servicesPermCustomersEdit => 'تعديل عميل';

  @override
  String get servicesPermCustomersEditDesc => 'تحديث بيانات العميل.';

  @override
  String get servicesPermCustomersDeactivate => 'إيقاف عميل';

  @override
  String get servicesPermCustomersDeactivateDesc =>
      'إيقاف أو إعادة تنشيط العملاء.';

  @override
  String get servicesPermSitesView => 'عرض مواقع الخدمة';

  @override
  String get servicesPermSitesViewDesc => 'الاطلاع على مواقع الخدمة.';

  @override
  String get servicesPermSitesCreate => 'إضافة موقع';

  @override
  String get servicesPermSitesCreateDesc => 'إضافة مواقع خدمة للعملاء.';

  @override
  String get servicesPermSitesEdit => 'تعديل موقع';

  @override
  String get servicesPermSitesEditDesc => 'تحديث بيانات الموقع.';

  @override
  String get servicesPermSitesDeactivate => 'إيقاف موقع';

  @override
  String get servicesPermSitesDeactivateDesc => 'إيقاف أو إعادة تنشيط المواقع.';

  @override
  String get servicesPermTeamsView => 'عرض فرق الخدمة';

  @override
  String get servicesPermTeamsViewDesc => 'الاطلاع على فرق الخدمة وأعضائها.';

  @override
  String get servicesPermTeamsManage => 'إدارة فرق الخدمة';

  @override
  String get servicesPermTeamsManageDesc => 'إنشاء الفرق وإدارة العضوية.';

  @override
  String get servicesPermServiceTypesView => 'عرض أنواع الخدمة';

  @override
  String get servicesPermServiceTypesViewDesc => 'الاطلاع على أنواع الخدمة.';

  @override
  String get servicesPermServiceTypesManage => 'إدارة أنواع الخدمة';

  @override
  String get servicesPermServiceTypesManageDesc => 'إنشاء وتعديل أنواع الخدمة.';

  @override
  String get servicesPermComplaintTypesView => 'عرض أنواع الشكاوى';

  @override
  String get servicesPermComplaintTypesViewDesc => 'الاطلاع على أنواع الشكاوى.';

  @override
  String get servicesPermComplaintTypesManage => 'إدارة أنواع الشكاوى';

  @override
  String get servicesPermComplaintTypesManageDesc =>
      'إنشاء وتعديل أنواع الشكاوى.';

  @override
  String get servicesPermPrioritiesView => 'عرض الأولويات';

  @override
  String get servicesPermPrioritiesViewDesc => 'الاطلاع على أولويات الخدمة.';

  @override
  String get servicesPermPrioritiesManage => 'إدارة الأولويات';

  @override
  String get servicesPermPrioritiesManageDesc => 'إنشاء وتعديل أولويات الخدمة.';

  @override
  String get servicesPermTicketTypesView => 'عرض أنواع التذاكر';

  @override
  String get servicesPermTicketTypesViewDesc => 'الاطلاع على أنواع التذاكر.';

  @override
  String get servicesPermTicketTypesManage => 'إدارة أنواع التذاكر';

  @override
  String get servicesPermTicketTypesManageDesc => 'إنشاء وتعديل أنواع التذاكر.';

  @override
  String get permissionServiceCustomerView => 'عرض العملاء';

  @override
  String get permissionServiceCustomerCreate => 'إضافة عميل';

  @override
  String get permissionServiceCustomerEdit => 'تعديل عميل';

  @override
  String get permissionServiceCustomerDeactivate => 'إيقاف عميل';

  @override
  String get permissionServiceSiteView => 'عرض مواقع الخدمة';

  @override
  String get permissionServiceSiteCreate => 'إضافة موقع';

  @override
  String get permissionServiceSiteEdit => 'تعديل موقع';

  @override
  String get permissionServiceSiteDeactivate => 'إيقاف موقع';

  @override
  String get permissionServiceTeamView => 'عرض فرق الخدمة';

  @override
  String get permissionServiceTeamManage => 'إدارة فرق الخدمة';

  @override
  String get permissionServiceTypeView => 'عرض أنواع الخدمة';

  @override
  String get permissionServiceTypeManage => 'إدارة أنواع الخدمة';

  @override
  String get permissionComplaintTypeView => 'عرض أنواع الشكاوى';

  @override
  String get permissionComplaintTypeManage => 'إدارة أنواع الشكاوى';

  @override
  String get permissionServicePriorityView => 'عرض الأولويات';

  @override
  String get permissionServicePriorityManage => 'إدارة الأولويات';

  @override
  String get permissionServiceTicketTypeView => 'عرض أنواع التذاكر';

  @override
  String get permissionServiceTicketTypeManage => 'إدارة أنواع التذاكر';

  @override
  String get servicesNavOverview => 'نظرة عامة';

  @override
  String get servicesNavCustomers => 'العملاء';

  @override
  String get servicesNavSites => 'المواقع';

  @override
  String get servicesNavTeams => 'الفرق';

  @override
  String get servicesNavSettings => 'إعدادات الخدمات';

  @override
  String get servicesOverviewSubtitle =>
      'أدر دليل الخدمة والفرق والإعدادات التشغيلية.';

  @override
  String get servicesSummaryCustomers => 'العملاء';

  @override
  String get servicesSummarySites => 'المواقع النشطة';

  @override
  String get servicesSummaryTeams => 'فرق الخدمة';

  @override
  String get servicesSetupTitle => 'الإعداد';

  @override
  String get servicesSetupServiceTypes => 'أنواع الخدمة';

  @override
  String get servicesSetupPriorities => 'الأولويات';

  @override
  String get servicesSetupReady => 'مُهيّأ';

  @override
  String get servicesSetupMissing => 'غير مُهيّأ';

  @override
  String get servicesDirectoryTitle => 'دليل العملاء';

  @override
  String get servicesRecentCustomers => 'أحدث العملاء';

  @override
  String get servicesNoCustomersYet => 'لا يوجد عملاء بعد';

  @override
  String get servicesCustomersTitle => 'العملاء';

  @override
  String get servicesCustomerAdd => 'إضافة عميل';

  @override
  String get servicesCustomerEdit => 'تعديل العميل';

  @override
  String get servicesCustomerCode => 'الرمز';

  @override
  String get servicesCustomerName => 'الاسم';

  @override
  String get servicesCustomerKind => 'النوع';

  @override
  String get servicesCustomerKindIndividual => 'فرد';

  @override
  String get servicesCustomerKindOrganization => 'منشأة';

  @override
  String get servicesCustomerMobile => 'الجوال';

  @override
  String get servicesCustomerAlternateMobile => 'جوال بديل';

  @override
  String get servicesCustomerEmail => 'البريد الإلكتروني';

  @override
  String get servicesCustomerNotes => 'ملاحظات';

  @override
  String get servicesCustomerSites => 'المواقع';

  @override
  String get servicesCustomerContact => 'معلومات التواصل';

  @override
  String get servicesCustomerLastUpdated => 'آخر تحديث';

  @override
  String get servicesCustomerSaved => 'تم حفظ العميل.';

  @override
  String get servicesCustomerStorageError => 'تعذّر حفظ العميل.';

  @override
  String get servicesCustomerNotFound => 'لم يتم العثور على العميل.';

  @override
  String get servicesCustomerEmpty => 'لا يوجد عملاء بعد';

  @override
  String get servicesCustomerEmptyMessage => 'أضف أول عميل للبدء.';

  @override
  String get servicesCustomerNoResults => 'لا يوجد عملاء مطابقون لبحثك.';

  @override
  String get servicesCustomerRequired => 'هذا الحقل مطلوب.';

  @override
  String get servicesCustomerInvalidMobile => 'أدخل رقم جوال صالح.';

  @override
  String get servicesCustomerInvalidEmail => 'أدخل بريدًا إلكترونيًا صالحًا.';

  @override
  String get servicesCustomerDuplicateMobile => 'يوجد عميل بهذا الجوال بالفعل.';

  @override
  String get servicesCustomerDuplicateEmail =>
      'يوجد عميل بهذا البريد الإلكتروني بالفعل.';

  @override
  String get servicesCustomerDeactivate => 'إيقاف';

  @override
  String get servicesCustomerActivate => 'تنشيط';

  @override
  String get servicesCustomerSearch => 'البحث عن العملاء';

  @override
  String get servicesCustomerAllStatuses => 'كل الحالات';

  @override
  String get servicesCustomerActivity => 'النشاط';

  @override
  String get servicesCustomerNoActivity => 'لا يوجد نشاط بعد.';

  @override
  String get servicesCustomerSelect => 'اختر عميلًا';

  @override
  String get servicesCustomerStatus => 'الحالة';

  @override
  String get servicesCustomerDiscardMessage => 'لديك تغييرات غير محفوظة.';

  @override
  String get servicesCustomerDiscardAction => 'تجاهل';

  @override
  String get servicesSitesTitle => 'مواقع الخدمة';

  @override
  String get servicesSiteAdd => 'إضافة موقع';

  @override
  String get servicesSiteEdit => 'تعديل الموقع';

  @override
  String get servicesSiteCode => 'الرمز';

  @override
  String get servicesSiteName => 'اسم الموقع';

  @override
  String get servicesSiteCustomer => 'العميل';

  @override
  String get servicesSiteTenant => 'المستأجر';

  @override
  String get servicesSiteBuilding => 'المبنى';

  @override
  String get servicesSiteUnit => 'الوحدة';

  @override
  String get servicesSiteContactName => 'اسم جهة الاتصال';

  @override
  String get servicesSiteContactMobile => 'جوال جهة الاتصال';

  @override
  String get servicesSiteContactEmail => 'بريد جهة الاتصال';

  @override
  String get servicesSiteAddress1 => 'العنوان';

  @override
  String get servicesSiteAddress2 => 'العنوان 2';

  @override
  String get servicesSiteArea => 'المنطقة';

  @override
  String get servicesSiteCity => 'المدينة';

  @override
  String get servicesSiteState => 'الولاية/المنطقة';

  @override
  String get servicesSitePostalCode => 'الرمز البريدي';

  @override
  String get servicesSiteCountry => 'الدولة';

  @override
  String get servicesSiteLatitude => 'خط العرض';

  @override
  String get servicesSiteLongitude => 'خط الطول';

  @override
  String get servicesSiteNotes => 'ملاحظات';

  @override
  String get servicesSiteBuildingUnit => 'المبنى / الوحدة';

  @override
  String get servicesSiteSaved => 'تم حفظ الموقع.';

  @override
  String get servicesSiteStorageError => 'تعذّر حفظ الموقع.';

  @override
  String get servicesSiteNotFound => 'لم يتم العثور على الموقع.';

  @override
  String get servicesSiteEmpty => 'لا توجد مواقع بعد';

  @override
  String get servicesSiteEmptyMessage => 'أضف موقعًا لعميل لجدولة العمل.';

  @override
  String get servicesSiteNoResults => 'لا توجد مواقع مطابقة لبحثك.';

  @override
  String get servicesSiteRequired => 'هذا الحقل مطلوب.';

  @override
  String get servicesSiteDeactivate => 'إيقاف';

  @override
  String get servicesSiteActivate => 'تنشيط';

  @override
  String get servicesSiteSearch => 'البحث عن المواقع';

  @override
  String get servicesSiteDetails => 'الموقع';

  @override
  String get servicesSiteActivity => 'النشاط';

  @override
  String get servicesSiteLocation => 'الموقع الجغرافي';

  @override
  String get servicesSiteIdentity => 'هوية الموقع';

  @override
  String get servicesSiteAddress => 'العنوان';

  @override
  String get servicesSiteContact => 'معلومات التواصل';

  @override
  String get servicesSiteCustomerRequired => 'اختر عميلًا.';

  @override
  String get servicesSiteSelectCustomer => 'اختر عميلًا';

  @override
  String get servicesTeamsTitle => 'فرق الخدمة';

  @override
  String get servicesTeamAdd => 'إضافة فريق';

  @override
  String get servicesTeamEdit => 'تعديل الفريق';

  @override
  String get servicesTeamCode => 'الرمز';

  @override
  String get servicesTeamName => 'اسم الفريق';

  @override
  String get servicesTeamDescription => 'الوصف';

  @override
  String get servicesTeamLead => 'قائد الفريق';

  @override
  String get servicesTeamMembers => 'الأعضاء';

  @override
  String get servicesTeamMemberAdd => 'إضافة عضو';

  @override
  String get servicesTeamMemberSearch => 'البحث عن الموظفين';

  @override
  String get servicesTeamNoMembers => 'لا يوجد أعضاء بعد';

  @override
  String get servicesTeamSaved => 'تم حفظ الفريق.';

  @override
  String get servicesTeamStorageError => 'تعذّر حفظ الفريق.';

  @override
  String get servicesTeamNotFound => 'لم يتم العثور على الفريق.';

  @override
  String get servicesTeamEmpty => 'لا توجد فرق بعد';

  @override
  String get servicesTeamEmptyMessage =>
      'أنشئ فريقًا لتجميع الموظفين لأعمال الخدمة.';

  @override
  String get servicesTeamNoResults => 'لا توجد فرق مطابقة لبحثك.';

  @override
  String get servicesTeamRequired => 'هذا الحقل مطلوب.';

  @override
  String get servicesTeamDeactivate => 'إيقاف';

  @override
  String get servicesTeamActivate => 'تنشيط';

  @override
  String get servicesTeamSearch => 'البحث عن الفرق';

  @override
  String get servicesTeamDetails => 'الفريق';

  @override
  String get servicesTeamActivity => 'النشاط';

  @override
  String get servicesTeamLeadOptional => 'بلا قائد';

  @override
  String get servicesTeamSelectLead => 'اختر قائدًا';

  @override
  String get servicesTeamMembersCount => 'الأعضاء';

  @override
  String get servicesSettingsTitle => 'إعدادات الخدمات';

  @override
  String get servicesSettingsSubtitle =>
      'هيّئ البيانات الأساسية المستخدمة في عمليات الخدمة.';

  @override
  String get servicesServiceTypesTitle => 'أنواع الخدمة';

  @override
  String get servicesComplaintTypesTitle => 'أنواع الشكاوى';

  @override
  String get servicesPrioritiesTitle => 'الأولويات';

  @override
  String get servicesTicketTypesTitle => 'أنواع التذاكر';

  @override
  String get servicesAddMaster => 'إضافة';

  @override
  String get servicesEditMaster => 'تعديل';

  @override
  String get servicesMasterCode => 'الرمز';

  @override
  String get servicesMasterName => 'الاسم';

  @override
  String get servicesMasterDescription => 'الوصف';

  @override
  String get servicesMasterSortOrder => 'ترتيب العرض';

  @override
  String get servicesMasterRank => 'الرتبة';

  @override
  String get servicesMasterDefault => 'افتراضي';

  @override
  String get servicesMasterServiceType => 'نوع الخدمة';

  @override
  String get servicesMasterSaved => 'تم الحفظ.';

  @override
  String get servicesMasterStorageError => 'تعذّر الحفظ.';

  @override
  String get servicesMasterNotFound => 'لم يتم العثور على السجل.';

  @override
  String get servicesMasterEmpty => 'لا يوجد شيء مُهيّأ بعد';

  @override
  String get servicesMasterNoResults => 'لا توجد سجلات مطابقة لبحثك.';

  @override
  String get servicesMasterRequired => 'هذا الحقل مطلوب.';

  @override
  String get servicesMasterDeactivate => 'إيقاف';

  @override
  String get servicesMasterActivate => 'تنشيط';

  @override
  String get servicesMasterSearch => 'بحث';

  @override
  String get servicesMasterGeneric => 'عام';

  @override
  String get servicesMasterNameRequired => 'الاسم مطلوب.';

  @override
  String get servicesMasterCodeRequired => 'الرمز مطلوب.';

  @override
  String get servicesMasterDuplicateCode => 'يوجد سجل بهذا الرمز بالفعل.';

  @override
  String get servicesMasterDuplicateName => 'يوجد سجل بهذا الاسم بالفعل.';

  @override
  String get servicesMasterBasicInformation => 'المعلومات الأساسية';

  @override
  String get servicesMasterOrderingBehavior => 'الترتيب والسلوك';

  @override
  String get servicesMasterOrderingSubtitle =>
      'يتحكم في ترتيب العرض وسلوك التحديد الافتراضي.';

  @override
  String get servicesMasterCodeHelper => 'يُستخدم كمرجع داخلي ثابت.';

  @override
  String get servicesMasterSortOrderHelper => 'تظهر القيم الأقل أولاً.';

  @override
  String get servicesMasterDefaultPriorityLabel => 'الأولوية الافتراضية';

  @override
  String get servicesMasterDefaultPriorityDescription =>
      'تُستخدم هذه الأولوية تلقائياً عند عدم تحديد أولوية أخرى.';

  @override
  String get servicesMasterDefaultGenericDescription =>
      'يُستخدم هذا السجل تلقائياً عند عدم تحديد سجل آخر.';

  @override
  String servicesMasterAddName(String name) {
    return 'إضافة $name';
  }

  @override
  String servicesMasterEditName(String name) {
    return 'تعديل $name';
  }

  @override
  String get servicesServiceTypeSingular => 'نوع خدمة';

  @override
  String get servicesComplaintTypeSingular => 'نوع شكوى';

  @override
  String get servicesPrioritySingular => 'أولوية';

  @override
  String get servicesTicketTypeSingular => 'نوع تذكرة';

  @override
  String get servicesRootCauseSingular => 'السبب الجذري';

  @override
  String get servicesChargeResponsibilitySingular => 'مسؤولية التكلفة';

  @override
  String get servicesMaterialRequestPurposeSingular => 'غرض طلب المواد';

  @override
  String get servicesServiceTypeSubtitle => 'تصنيف يُستخدم في طلبات الخدمة.';

  @override
  String get servicesComplaintTypeSubtitle => 'فئات الشكاوى ضمن نوع خدمة.';

  @override
  String get servicesPrioritySubtitle =>
      'هيّئ كيفية ترتيب أولويات طلبات الخدمة.';

  @override
  String get servicesTicketTypeSubtitle =>
      'فئات التذاكر المستخدمة لتوجيه أعمال الخدمة.';

  @override
  String get servicesRootCauseSubtitle =>
      'أسباب التشخيص المسجلة أثناء الفحوصات.';

  @override
  String get servicesChargeResponsibilitySubtitle =>
      'من المسؤول عن تغطية تكاليف الخدمة.';

  @override
  String get servicesMaterialRequestPurposeSubtitle =>
      'أسباب طلب المواد لأعمال الخدمة.';

  @override
  String get servicesAuditInformation => 'معلومات التدقيق';

  @override
  String get servicesCreatedBy => 'أنشأه';

  @override
  String get servicesCreatedAt => 'تاريخ الإنشاء';

  @override
  String get servicesUpdatedBy => 'حدّثه';

  @override
  String get servicesUpdatedAt => 'تاريخ التحديث';

  @override
  String get servicesCustomerInformationSection => 'معلومات العميل';

  @override
  String get servicesCustomerAddressSection => 'العنوان وبيانات النشاط';

  @override
  String get servicesSiteInformationSection => 'معلومات الموقع';

  @override
  String get servicesSiteCustomerRelationship => 'علاقة العميل';

  @override
  String get servicesSiteTenantSection => 'المستأجر والمبنى والوحدة';

  @override
  String get servicesSiteCoordinates => 'الإحداثيات';

  @override
  String get servicesTeamInformationSection => 'معلومات الفريق';

  @override
  String get servicesTeamMembersSubtitle =>
      'أضف الموظفين الذين يعملون معاً في مهام الخدمة.';

  @override
  String get servicesTeamMemberRemove => 'إزالة عضو';

  @override
  String servicesCustomerCount(String filtered, String total) {
    return '$filtered من $total عميل';
  }

  @override
  String servicesSiteCount(String filtered, String total) {
    return '$filtered من $total موقع';
  }

  @override
  String servicesTeamCount(String filtered, String total) {
    return '$filtered من $total فريق';
  }

  @override
  String get servicesActivityCreated => 'إنشاء';

  @override
  String get servicesActivityUpdated => 'تحديث';

  @override
  String get servicesActivityActivated => 'تنشيط';

  @override
  String get servicesActivityDeactivated => 'إلغاء تنشيط';

  @override
  String get servicesActivityMembersUpdated => 'تحديث أعضاء الفريق';

  @override
  String get servicesActivityUnknown => 'نشاط';

  @override
  String get servicesCustomerContactSection => 'بيانات التواصل';

  @override
  String get servicesSiteAddressSection => 'العنوان';

  @override
  String get servicesTeamLeadSection => 'قائد الفريق';

  @override
  String get servicesTeamLeadNone => 'لا يوجد قائد فريق معيّن';

  @override
  String get servicesCustomerNoSites => 'لا توجد مواقع خدمة بعد.';

  @override
  String get servicesDenied => 'ليس لديك صلاحية لتنفيذ هذا الإجراء.';

  @override
  String get permissionServiceEnquiryView => 'عرض الاستفسارات';

  @override
  String get permissionServiceEnquiryCreate => 'إنشاء استفسار';

  @override
  String get permissionServiceEnquiryEdit => 'تعديل استفسار';

  @override
  String get permissionServiceEnquiryCancel => 'إلغاء استفسار';

  @override
  String get servicesPermSubEnquiries => 'الاستفسارات';

  @override
  String get servicesPermEnquiriesView => 'عرض الاستفسارات';

  @override
  String get servicesPermEnquiriesViewDesc =>
      'عرض قائمة استفسارات الخدمة وبياناتها.';

  @override
  String get servicesPermEnquiriesCreate => 'إنشاء استفسار';

  @override
  String get servicesPermEnquiriesCreateDesc =>
      'تسجيل استفسار خدمة جديد مع البحث المقيّد عن العميل والموقع.';

  @override
  String get servicesPermEnquiriesEdit => 'تعديل استفسار';

  @override
  String get servicesPermEnquiriesEditDesc => 'تعديل استفسار خدمة مفتوح.';

  @override
  String get servicesPermEnquiriesCancel => 'إلغاء استفسار';

  @override
  String get servicesPermEnquiriesCancelDesc =>
      'إلغاء استفسار خدمة مفتوح (يُحفظ تاريخيًا).';

  @override
  String get servicesNavEnquiries => 'الاستفسارات';

  @override
  String get servicesEnquiriesTitle => 'استفسارات الخدمة';

  @override
  String servicesEnquiryCount(String filtered, String total) {
    return '$filtered من $total استفسار';
  }

  @override
  String get servicesEnquirySearch =>
      'ابحث برقم الاستفسار أو العميل أو الجوال أو الموقع أو المبنى أو الوحدة';

  @override
  String get servicesEnquiryAllStatuses => 'كل الحالات';

  @override
  String get servicesEnquiryEmpty => 'لا توجد استفسارات خدمة بعد.';

  @override
  String get servicesEnquiryEmptyMessage =>
      'سجّل أول استفسار خدمة لبدء قائمة العمل.';

  @override
  String get servicesEnquiryNoResults => 'لا توجد استفسارات مطابقة للمرشحات.';

  @override
  String get servicesEnquiryAdd => 'استفسار جديد';

  @override
  String get servicesEnquiryColumnEnquiry => 'الاستفسار';

  @override
  String get servicesEnquiryColumnCustomer => 'العميل';

  @override
  String get servicesEnquiryColumnSite => 'الموقع';

  @override
  String get servicesEnquiryColumnService => 'الخدمة / الشكوى';

  @override
  String get servicesEnquiryColumnPriority => 'الأولوية';

  @override
  String get servicesEnquiryColumnTicket => 'نوع التذكرة';

  @override
  String get servicesEnquiryColumnStatus => 'الحالة';

  @override
  String get servicesEnquiryColumnCreated => 'تاريخ الإنشاء';

  @override
  String get servicesEnquiryStatusOpen => 'مفتوح';

  @override
  String get servicesEnquiryStatusCancelled => 'ملغى';

  @override
  String get servicesEnquiryFilterTitle => 'المرشحات';

  @override
  String get servicesEnquiryFilterStatus => 'الحالة';

  @override
  String get servicesEnquiryFilterServiceType => 'نوع الخدمة';

  @override
  String get servicesEnquiryFilterComplaintType => 'نوع الشكوى';

  @override
  String get servicesEnquiryFilterPriority => 'الأولوية';

  @override
  String get servicesEnquiryFilterTicketType => 'نوع التذكرة';

  @override
  String get servicesEnquiryFilterCreatedFrom => 'من تاريخ';

  @override
  String get servicesEnquiryFilterCreatedTo => 'إلى تاريخ';

  @override
  String get servicesEnquiryDetailCustomerSection => 'العميل والموقع';

  @override
  String get servicesEnquiryDetailServiceSection => 'تفاصيل الخدمة';

  @override
  String get servicesEnquiryDetailComplaintSection => 'الشكوى';

  @override
  String get servicesEnquiryDetailRecord => 'السجل';

  @override
  String get servicesEnquiryDetailActivity => 'النشاط';

  @override
  String get servicesEnquiryCustomerCode => 'رمز العميل';

  @override
  String get servicesEnquiryCustomerName => 'العميل';

  @override
  String get servicesEnquiryCustomerMobile => 'جوال العميل';

  @override
  String get servicesEnquirySite => 'موقع الخدمة';

  @override
  String get servicesEnquiryTenant => 'المستأجر';

  @override
  String get servicesEnquiryBuilding => 'المبنى';

  @override
  String get servicesEnquiryUnit => 'الوحدة';

  @override
  String get servicesEnquiryAddress => 'العنوان';

  @override
  String get servicesEnquiryContact => 'جهة الاتصال';

  @override
  String get servicesEnquiryServiceType => 'نوع الخدمة';

  @override
  String get servicesEnquiryComplaintType => 'نوع الشكوى';

  @override
  String get servicesEnquiryPriority => 'الأولوية';

  @override
  String get servicesEnquiryTicketType => 'نوع التذكرة';

  @override
  String get servicesEnquiryDescription => 'تفاصيل الشكوى';

  @override
  String get servicesEnquiryCreatedBy => 'أنشأه';

  @override
  String get servicesEnquiryCreatedAt => 'تاريخ الإنشاء';

  @override
  String get servicesEnquiryUpdatedBy => 'حدّثه';

  @override
  String get servicesEnquiryUpdatedAt => 'تاريخ التحديث';

  @override
  String get servicesEnquiryVersion => 'الإصدار';

  @override
  String get servicesEnquiryCancelledAt => 'تاريخ الإلغاء';

  @override
  String get servicesEnquiryCancelReason => 'سبب الإلغاء';

  @override
  String get servicesEnquiryNoActivity => 'لا يوجد نشاط بعد.';

  @override
  String get servicesEnquiryEdit => 'تعديل الاستفسار';

  @override
  String get servicesEnquiryCancel => 'إلغاء الاستفسار';

  @override
  String get servicesEnquiryCreate => 'إنشاء استفسار';

  @override
  String get servicesEnquiryCancelConfirmTitle => 'إلغاء الاستفسار؟';

  @override
  String get servicesEnquiryCancelConfirmMessage =>
      'يبقى الاستفسار الملغى متاحًا تاريخيًا ولا يمكن تعديله بعد ذلك.';

  @override
  String get servicesEnquiryCancelReasonHint => 'سبب الإلغاء (اختياري)';

  @override
  String get servicesEnquiryCreated => 'تم إنشاء الاستفسار.';

  @override
  String get servicesEnquiryUpdated => 'تم تحديث الاستفسار.';

  @override
  String get servicesEnquiryCancelled => 'تم إلغاء الاستفسار.';

  @override
  String get servicesEnquiryFormNew => 'استفسار جديد';

  @override
  String get servicesEnquiryFormEdit => 'تعديل الاستفسار';

  @override
  String get servicesEnquirySectionCustomerLocation => 'العميل والموقع';

  @override
  String get servicesEnquirySectionService => 'تفاصيل الخدمة';

  @override
  String get servicesEnquirySectionComplaint => 'الشكوى';

  @override
  String get servicesEnquirySectionSummary => 'الملخص';

  @override
  String get servicesEnquirySelectCustomer => 'اختر عميلًا';

  @override
  String get servicesEnquirySelectSite => 'اختر موقع خدمة';

  @override
  String get servicesEnquiryChangeCustomer => 'تغيير العميل';

  @override
  String get servicesEnquiryChangeSite => 'تغيير الموقع';

  @override
  String get servicesEnquiryCreateCustomer => 'إنشاء عميل';

  @override
  String get servicesEnquiryCreateSite => 'إضافة موقع';

  @override
  String get servicesEnquiryNoSitesForCustomer =>
      'لا توجد مواقع نشطة لهذا العميل.';

  @override
  String get servicesEnquiryNoComplaintTypes =>
      'لا توجد أنواع شكاوى متاحة لنوع الخدمة هذا.';

  @override
  String get servicesEnquiryDescriptionHint => 'صف الشكوى أو طلب الخدمة';

  @override
  String get servicesEnquiryCustomerRequired => 'اختر عميلًا.';

  @override
  String get servicesEnquirySiteRequired => 'اختر موقع خدمة.';

  @override
  String get servicesEnquiryServiceTypeRequired => 'اختر نوع الخدمة.';

  @override
  String get servicesEnquiryComplaintTypeRequired => 'اختر نوع الشكوى.';

  @override
  String get servicesEnquiryPriorityRequired => 'اختر الأولوية.';

  @override
  String get servicesEnquiryTicketTypeRequired => 'اختر نوع التذكرة.';

  @override
  String get servicesEnquiryDescriptionRequired => 'أدخل تفاصيل الشكوى.';

  @override
  String get servicesEnquiryDescriptionTooLong => 'تفاصيل الشكوى طويلة جدًا.';

  @override
  String get servicesEnquiryDenied => 'ليس لديك صلاحية لتنفيذ هذا الإجراء.';

  @override
  String get servicesEnquiryNotFound => 'الاستفسار غير موجود.';

  @override
  String get servicesEnquiryNotEditable =>
      'يمكن تعديل الاستفسارات المفتوحة فقط.';

  @override
  String get servicesEnquiryAlreadyCancelled => 'هذا الاستفسار ملغى بالفعل.';

  @override
  String get servicesEnquiryCustomerNotFound => 'العميل غير موجود.';

  @override
  String get servicesEnquiryCustomerInactive => 'العميل المحدد غير نشط.';

  @override
  String get servicesEnquirySiteNotFound => 'موقع الخدمة غير موجود.';

  @override
  String get servicesEnquirySiteInactive => 'موقع الخدمة المحدد غير نشط.';

  @override
  String get servicesEnquirySiteCustomerMismatch =>
      'الموقع المحدد لا يتبع العميل المحدد.';

  @override
  String get servicesEnquiryServiceTypeInvalid => 'نوع الخدمة المحدد غير متاح.';

  @override
  String get servicesEnquiryComplaintTypeInvalid =>
      'نوع الشكوى المحدد غير متاح.';

  @override
  String get servicesEnquiryComplaintTypeMismatch =>
      'نوع الشكوى لا يطابق نوع الخدمة المحدد.';

  @override
  String get servicesEnquiryPriorityInvalid => 'الأولوية المحددة غير متاحة.';

  @override
  String get servicesEnquiryTicketTypeInvalid => 'نوع التذكرة المحدد غير متاح.';

  @override
  String get servicesEnquirySequenceFailed => 'تعذّر تخصيص رقم للاستفسار.';

  @override
  String get servicesEnquiryStorageError =>
      'تعذّر حفظ الاستفسار. حاول مرة أخرى.';

  @override
  String get servicesActivityCancelled => 'إلغاء';

  @override
  String get servicesOverviewEnquiriesOpen => 'الاستفسارات المفتوحة';

  @override
  String get servicesOverviewEnquiriesToday => 'استفسارات اليوم';

  @override
  String get servicesOverviewEnquiriesHigh => 'عالية / عاجلة مفتوحة';

  @override
  String get servicesOverviewRecentEnquiries => 'أحدث الاستفسارات';

  @override
  String get servicesOverviewNewEnquiry => 'استفسار جديد';

  @override
  String get servicesOverviewNoEnquiries => 'لا توجد استفسارات بعد.';

  @override
  String get servicesEnquiryRecentForCustomer => 'أحدث الاستفسارات';

  @override
  String get servicesEnquiryRecentForSite => 'أحدث الاستفسارات';

  @override
  String get servicesEnquiryNoneForCustomer =>
      'لا توجد استفسارات لهذا العميل بعد.';

  @override
  String get servicesEnquiryNoneForSite => 'لا توجد استفسارات لهذا الموقع بعد.';

  @override
  String get servicesEnquiryDetailsSection => 'تفاصيل الاستفسار';

  @override
  String get servicesEnquiryAddDetail => 'إضافة مشكلة أخرى';

  @override
  String get servicesEnquiryRemoveDetail => 'إزالة المشكلة';

  @override
  String servicesEnquiryDetailLine(String index) {
    return 'المشكلة $index';
  }

  @override
  String get servicesEnquiryDetailDescription => 'الوصف';

  @override
  String get servicesEnquiryDetailStatus => 'الحالة';

  @override
  String get servicesEnquiryDetailStatusOpen => 'مفتوح';

  @override
  String get servicesEnquiryDetailStatusClosed => 'مغلق';

  @override
  String get servicesEnquiryPhotos => 'الصور';

  @override
  String get servicesEnquiryAddPhotos => 'إضافة صور';

  @override
  String get servicesEnquiryMaterialReceived => 'استلام المواد';

  @override
  String get servicesEnquiryMaterialReceivedYes => 'نعم';

  @override
  String get servicesEnquiryMaterialReceivedNo => 'لا';

  @override
  String get servicesEnquiryNoDetails => 'لا توجد تفاصيل مسجلة.';

  @override
  String get servicesEnquiryDetailsRequired =>
      'أضف تفصيلًا واحدًا على الأقل للاستفسار.';

  @override
  String get servicesEnquiryDetailDescriptionRequired =>
      'أدخل وصفًا لكل تفصيل في الاستفسار.';

  @override
  String get servicesEnquiryAttachmentUnsupportedType => 'نوع الملف غير مدعوم.';

  @override
  String get servicesEnquiryAttachmentTooLarge => 'الملف كبير جدًا.';

  @override
  String get servicesEnquiryAttachmentLimitReached =>
      'تم الوصول إلى الحد الأقصى للمرفقات.';

  @override
  String get servicesEnquiryAttachmentFailure => 'تعذّر إرفاق الملف.';

  @override
  String get attachmentUploaded => 'تم الرفع';

  @override
  String get attachmentLocalOnly => 'محلي';

  @override
  String get attachmentPendingUpload => 'قيد الرفع';

  @override
  String get attachmentFailed => 'فشل';

  @override
  String get attachmentPendingDelete => 'قيد الحذف';

  @override
  String get attachmentDeleted => 'محذوف';

  @override
  String get servicesNavJobAssignments => 'تكليفات العمل';

  @override
  String get servicesPermSubJobAssignments => 'تكليفات العمل';

  @override
  String get servicesPermJobAssignmentsView => 'عرض تكليفات العمل';

  @override
  String get servicesPermJobAssignmentsViewDesc =>
      'عرض قائمة تكليفات العمل ضمن نطاق سجلاتك.';

  @override
  String get servicesPermJobAssignmentsCreate => 'إنشاء تكليف عمل';

  @override
  String get servicesPermJobAssignmentsCreateDesc =>
      'تكليف العمل من استفسار مؤهل، مع البحث المقيّد عن الاستفسار والموظف والفريق.';

  @override
  String get servicesPermJobAssignmentsEdit => 'تعديل تكليف العمل';

  @override
  String get servicesPermJobAssignmentsEditDesc =>
      'تعديل أو إعادة تكليف تكليف عمل نشط.';

  @override
  String get servicesPermJobAssignmentsCancel => 'إلغاء تكليف العمل';

  @override
  String get servicesPermJobAssignmentsCancelDesc =>
      'إلغاء تكليف عمل نشط (يُحفظ تاريخيًا).';

  @override
  String get permissionServiceJobAssignmentView => 'عرض تكليفات العمل';

  @override
  String get permissionServiceJobAssignmentCreate => 'إنشاء تكليف عمل';

  @override
  String get permissionServiceJobAssignmentEdit => 'تعديل تكليف العمل';

  @override
  String get permissionServiceJobAssignmentCancel => 'إلغاء تكليف العمل';

  @override
  String get servicesJobAssignmentsTitle => 'تكليفات العمل';

  @override
  String servicesJobAssignmentCount(String filtered, String total) {
    return '$filtered من $total تكليف عمل';
  }

  @override
  String get servicesJobAssignmentSearch =>
      'ابحث برقم التكليف أو الاستفسار أو العميل أو الجوال أو الموقع أو الموظف أو الفريق';

  @override
  String get servicesJobAssignmentAllStatuses => 'كل الحالات';

  @override
  String get servicesJobAssignmentStatusActive => 'نشط';

  @override
  String get servicesJobAssignmentStatusCancelled => 'ملغى';

  @override
  String get servicesJobAssignmentEmpty => 'لا توجد تكليفات عمل بعد.';

  @override
  String get servicesJobAssignmentEmptyMessage =>
      'أنشئ تكليف عمل من استفسار خدمة مفتوح.';

  @override
  String get servicesJobAssignmentNoResults =>
      'لا توجد تكليفات عمل مطابقة للمرشحات.';

  @override
  String get servicesJobAssignmentAdd => 'تكليف عمل جديد';

  @override
  String get servicesJobAssignmentColumnAssignment => 'التكليف';

  @override
  String get servicesJobAssignmentColumnEnquiry => 'الاستفسار';

  @override
  String get servicesJobAssignmentColumnCustomerSite => 'العميل / الموقع';

  @override
  String get servicesJobAssignmentColumnVisitDate => 'تاريخ الزيارة';

  @override
  String get servicesJobAssignmentColumnAssignedTo => 'مُكلَّف إلى';

  @override
  String get servicesJobAssignmentColumnPriority => 'الأولوية';

  @override
  String get servicesJobAssignmentColumnStatus => 'الحالة';

  @override
  String get servicesJobAssignmentColumnCreated => 'تاريخ الإنشاء';

  @override
  String get servicesJobAssignmentFilterTitle => 'المرشحات';

  @override
  String get servicesJobAssignmentFilterStatus => 'الحالة';

  @override
  String get servicesJobAssignmentFilterPriority => 'الأولوية';

  @override
  String get servicesJobAssignmentFilterVisitFrom => 'الزيارة من';

  @override
  String get servicesJobAssignmentFilterVisitTo => 'الزيارة إلى';

  @override
  String get servicesJobAssignmentFormNew => 'تكليف عمل جديد';

  @override
  String get servicesJobAssignmentFormEdit => 'تعديل تكليف العمل';

  @override
  String get servicesJobAssignmentCreate => 'إنشاء تكليف عمل';

  @override
  String get servicesJobAssignmentSectionJobContext => 'سياق التكليف';

  @override
  String get servicesJobAssignmentSectionSchedule => 'الجدولة';

  @override
  String get servicesJobAssignmentSectionCustomerLocation => 'العميل والموقع';

  @override
  String get servicesJobAssignmentSectionServiceContext => 'سياق الخدمة';

  @override
  String get servicesJobAssignmentSectionSourceIssues =>
      'مشكلات الاستفسار المصدر';

  @override
  String get servicesJobAssignmentSectionWork => 'تكليف العمل';

  @override
  String get servicesJobAssignmentNo => 'رقم التكليف';

  @override
  String get servicesJobAssignmentDate => 'تاريخ التكليف';

  @override
  String get servicesJobAssignmentVisitDate => 'تاريخ الزيارة';

  @override
  String get servicesJobAssignmentEnquiry => 'الاستفسار';

  @override
  String get servicesJobAssignmentSelectEnquiry => 'اختر استفسارًا مؤهلًا';

  @override
  String get servicesJobAssignmentChangeEnquiry => 'تغيير الاستفسار';

  @override
  String get servicesJobAssignmentNoIssues =>
      'لا توجد مشكلات مسجلة في الاستفسار.';

  @override
  String get servicesJobAssignmentMaterialReceived => 'استلام المواد';

  @override
  String get servicesJobAssignmentWork => 'العمل';

  @override
  String get servicesJobAssignmentTechnician => 'الفني';

  @override
  String get servicesJobAssignmentServiceTeam => 'فريق الخدمة';

  @override
  String get servicesJobAssignmentLineStatus => 'الحالة';

  @override
  String get servicesJobAssignmentLineStatusPending => 'قيد الانتظار';

  @override
  String get servicesJobAssignmentDescriptionForWork => 'وصف العمل';

  @override
  String get servicesJobAssignmentAddLine => 'إضافة بند عمل';

  @override
  String get servicesJobAssignmentRemoveLine => 'إزالة بند العمل';

  @override
  String servicesJobAssignmentLineTitle(String index) {
    return 'بند العمل $index';
  }

  @override
  String get servicesJobAssignmentNoTargets =>
      'عيّن موظفًا أو فريق خدمة أو كليهما.';

  @override
  String get servicesJobAssignmentDetailContext => 'سياق الاستفسار';

  @override
  String get servicesJobAssignmentDetailWork => 'بنود العمل';

  @override
  String get servicesJobAssignmentDetailAudit => 'السجل';

  @override
  String get servicesJobAssignmentDetailActivity => 'النشاط';

  @override
  String get servicesJobAssignmentEdit => 'تعديل التكليف';

  @override
  String get servicesJobAssignmentCancel => 'إلغاء التكليف';

  @override
  String get servicesJobAssignmentCancelConfirmTitle => 'إلغاء التكليف؟';

  @override
  String get servicesJobAssignmentCancelConfirmMessage =>
      'يبقى التكليف الملغى متاحًا تاريخيًا ولا يمكن تعديله بعد ذلك.';

  @override
  String get servicesJobAssignmentCreated => 'تم إنشاء تكليف العمل.';

  @override
  String get servicesJobAssignmentUpdated => 'تم تحديث تكليف العمل.';

  @override
  String get servicesJobAssignmentCancelled => 'تم إلغاء تكليف العمل.';

  @override
  String get servicesJobAssignmentNoActivity => 'لا يوجد نشاط بعد.';

  @override
  String get servicesJobAssignmentCreatedBy => 'أنشأه';

  @override
  String get servicesJobAssignmentCreatedAt => 'تاريخ الإنشاء';

  @override
  String get servicesJobAssignmentUpdatedBy => 'حدّثه';

  @override
  String get servicesJobAssignmentUpdatedAt => 'تاريخ التحديث';

  @override
  String get servicesJobAssignmentVersion => 'الإصدار';

  @override
  String get servicesJobAssignmentCancelledAt => 'تاريخ الإلغاء';

  @override
  String get servicesJobAssignmentEnquiryRequired => 'اختر استفسارًا.';

  @override
  String get servicesJobAssignmentVisitDateRequired => 'اختر تاريخ الزيارة.';

  @override
  String get servicesJobAssignmentLinesRequired =>
      'أضف بند عمل واحدًا على الأقل.';

  @override
  String get servicesJobAssignmentWorkRequired => 'أدخل العمل لكل بند.';

  @override
  String get servicesJobAssignmentWorkTooLong => 'نص العمل طويل جدًا.';

  @override
  String get servicesJobAssignmentDescriptionTooLong => 'الوصف طويل جدًا.';

  @override
  String get servicesJobAssignmentTargetRequired =>
      'عيّن موظفًا أو فريق خدمة أو كليهما.';

  @override
  String get servicesJobAssignmentEnquiryNotFound => 'الاستفسار غير موجود.';

  @override
  String get servicesJobAssignmentEnquiryNotOpen =>
      'يمكن تكليف الاستفسارات المفتوحة فقط.';

  @override
  String get servicesJobAssignmentAlreadyActive =>
      'يوجد تكليف عمل نشط لهذا الاستفسار بالفعل.';

  @override
  String get servicesJobAssignmentNotFound => 'تكليف العمل غير موجود.';

  @override
  String get servicesJobAssignmentNotEditable =>
      'يمكن تعديل تكليفات العمل النشطة فقط.';

  @override
  String get servicesJobAssignmentAlreadyCancelled =>
      'تكليف العمل ملغى بالفعل.';

  @override
  String get servicesJobAssignmentEmployeeInvalid => 'الموظف المحدد غير متاح.';

  @override
  String get servicesJobAssignmentTeamInvalid => 'فريق الخدمة المحدد غير متاح.';

  @override
  String get servicesJobAssignmentEmployeeNotInTeam =>
      'الموظف المحدد ليس عضوًا في فريق الخدمة المحدد.';

  @override
  String get servicesJobAssignmentSequenceFailed => 'تعذّر تخصيص رقم للتكليف.';

  @override
  String get servicesJobAssignmentDenied =>
      'ليس لديك صلاحية لتنفيذ هذا الإجراء.';

  @override
  String get servicesJobAssignmentStorageError =>
      'تعذّر حفظ تكليف العمل. حاول مرة أخرى.';

  @override
  String get servicesActivityAssigned => 'تكليف';

  @override
  String get servicesActivityReopened => 'إعادة فتح';

  @override
  String get servicesOverviewAssignmentsScheduled => 'التكليفات المجدولة';

  @override
  String get servicesOverviewAssignmentsToday => 'زيارات اليوم';

  @override
  String get servicesOverviewAssignmentsUpcoming => 'الزيارات القادمة';

  @override
  String get servicesOverviewRecentAssignments => 'التكليفات القادمة';

  @override
  String get servicesOverviewNoAssignments => 'لا توجد تكليفات قادمة.';

  @override
  String get servicesEnquiryAssignmentSection => 'تكليف العمل';

  @override
  String get servicesEnquiryCreateAssignment => 'إنشاء تكليف عمل';

  @override
  String get servicesEnquiryViewAssignment => 'عرض تكليف العمل';

  @override
  String get servicesEnquiryStatusAssigned => 'مُكلَّف';

  @override
  String get notifServiceWorkAssignedTitle => 'تم تكليفك بعمل خدمة';

  @override
  String get notifServiceWorkAssignedBody => 'تم تكليفك بعمل خدمة.';

  @override
  String get servicesJobAssignmentGenerated => 'يُولَّد عند الحفظ';

  @override
  String get servicesPermSubInspections => 'الفحوصات';

  @override
  String get servicesPermInspectionsView => 'عرض الفحوصات';

  @override
  String get servicesPermInspectionsViewDesc =>
      'عرض قائمة الفحوصات ضمن نطاق سجلاتك.';

  @override
  String get servicesPermInspectionsCreate => 'إنشاء فحص';

  @override
  String get servicesPermInspectionsCreateDesc =>
      'إنشاء فحص من تكليف عمل مؤهل، مع البحث المقيّد عن المراجع.';

  @override
  String get servicesPermInspectionsEdit => 'تعديل الفحص';

  @override
  String get servicesPermInspectionsEditDesc => 'تعديل فحص قيد الانتظار.';

  @override
  String get servicesPermInspectionsComplete => 'إكمال الفحص';

  @override
  String get servicesPermInspectionsCompleteDesc => 'إنهاء فحص قيد الانتظار.';

  @override
  String get servicesPermInspectionsCancel => 'إلغاء الفحص';

  @override
  String get servicesPermInspectionsCancelDesc =>
      'إلغاء فحص قيد الانتظار (يُحفظ تاريخيًا).';

  @override
  String get servicesPermRootCausesView => 'عرض الأسباب الجذرية';

  @override
  String get servicesPermRootCausesViewDesc => 'عرض إعدادات الأسباب الجذرية.';

  @override
  String get servicesPermRootCausesManage => 'إدارة الأسباب الجذرية';

  @override
  String get servicesPermRootCausesManageDesc =>
      'إضافة وتعديل وإلغاء تنشيط الأسباب الجذرية.';

  @override
  String get servicesPermChargeResponsibilitiesView => 'عرض جهة التحميل';

  @override
  String get servicesPermChargeResponsibilitiesViewDesc =>
      'عرض إعدادات جهة التحميل.';

  @override
  String get servicesPermChargeResponsibilitiesManage => 'إدارة جهة التحميل';

  @override
  String get servicesPermChargeResponsibilitiesManageDesc =>
      'إضافة وتعديل وإلغاء تنشيط قيم جهة التحميل.';

  @override
  String get permissionServiceInspectionView => 'عرض الفحوصات';

  @override
  String get permissionServiceInspectionCreate => 'إنشاء فحص';

  @override
  String get permissionServiceInspectionEdit => 'تعديل الفحص';

  @override
  String get permissionServiceInspectionComplete => 'إكمال الفحص';

  @override
  String get permissionServiceInspectionCancel => 'إلغاء الفحص';

  @override
  String get servicesNavInspections => 'الفحوصات';

  @override
  String get servicesRootCausesTitle => 'الأسباب الجذرية';

  @override
  String get servicesChargeResponsibilitiesTitle => 'جهة التحميل';

  @override
  String get servicesInspectionsTitle => 'الفحوصات';

  @override
  String servicesInspectionCount(String filtered, String total) {
    return '$filtered من $total فحص';
  }

  @override
  String get servicesInspectionSearch =>
      'ابحث برقم الفحص أو التكليف أو الاستفسار أو العميل أو الجوال أو الموقع أو الفني';

  @override
  String get servicesInspectionAllStatuses => 'كل الحالات';

  @override
  String get servicesInspectionStatusPending => 'قيد الانتظار';

  @override
  String get servicesInspectionStatusCompleted => 'مكتمل';

  @override
  String get servicesInspectionStatusCancelled => 'ملغى';

  @override
  String get servicesInspectionEmpty => 'لا توجد فحوصات بعد.';

  @override
  String get servicesInspectionEmptyMessage => 'أنشئ فحصًا من تكليف عمل نشط.';

  @override
  String get servicesInspectionNoResults => 'لا توجد فحوصات مطابقة للمرشحات.';

  @override
  String get servicesInspectionAdd => 'فحص جديد';

  @override
  String get servicesInspectionColumnInspection => 'الفحص';

  @override
  String get servicesInspectionColumnAssignment => 'تكليف العمل';

  @override
  String get servicesInspectionColumnEnquiry => 'الاستفسار';

  @override
  String get servicesInspectionColumnCustomerSite => 'العميل / الموقع';

  @override
  String get servicesInspectionColumnVisit => 'الزيارة';

  @override
  String get servicesInspectionColumnTechnician => 'الفني';

  @override
  String get servicesInspectionColumnRootCause => 'السبب الجذري';

  @override
  String get servicesInspectionColumnStatus => 'الحالة';

  @override
  String get servicesInspectionColumnCreated => 'تاريخ الإنشاء';

  @override
  String get servicesInspectionFilterTitle => 'المرشحات';

  @override
  String get servicesInspectionFilterStatus => 'الحالة';

  @override
  String get servicesInspectionFilterTechnician => 'الفني';

  @override
  String get servicesInspectionFilterRootCause => 'السبب الجذري';

  @override
  String get servicesInspectionFilterPriority => 'الأولوية';

  @override
  String get servicesInspectionFilterVisitFrom => 'الزيارة من';

  @override
  String get servicesInspectionFilterVisitTo => 'الزيارة إلى';

  @override
  String get servicesInspectionFormNew => 'فحص جديد';

  @override
  String get servicesInspectionFormEdit => 'تعديل الفحص';

  @override
  String get servicesInspectionCreate => 'إنشاء فحص';

  @override
  String get servicesInspectionSectionContext => 'سياق الفحص';

  @override
  String get servicesInspectionSectionCustomerService => 'سياق العميل والخدمة';

  @override
  String get servicesInspectionSectionVisit => 'الزيارة';

  @override
  String get servicesInspectionSectionAssessment => 'التقييم';

  @override
  String get servicesInspectionSectionChecklist => 'قائمة التحقق';

  @override
  String get servicesInspectionSectionPoints => 'النقاط المفحوصة';

  @override
  String get servicesInspectionSectionMaterials => 'المواد المطلوبة';

  @override
  String get servicesInspectionNo => 'رقم الفحص';

  @override
  String get servicesInspectionDate => 'تاريخ الفحص';

  @override
  String get servicesInspectionJobAssignment => 'تكليف العمل';

  @override
  String get servicesInspectionSelectAssignment => 'اختر تكليف عمل مؤهلًا';

  @override
  String get servicesInspectionVisitDate => 'تاريخ الزيارة';

  @override
  String get servicesInspectionVisitTime => 'وقت الزيارة';

  @override
  String get servicesInspectionTechnician => 'الفني';

  @override
  String get servicesInspectionTechnicianOptional => 'غير معيّن';

  @override
  String get servicesInspectionRootCause => 'السبب الجذري';

  @override
  String get servicesInspectionChargeResponsibility => 'جهة التحميل';

  @override
  String servicesInspectionChecklistItemTitle(String index) {
    return 'بند التحقق $index';
  }

  @override
  String get servicesInspectionWorkType => 'نوع العمل';

  @override
  String get servicesInspectionDescriptionForWork => 'وصف العمل';

  @override
  String get servicesInspectionChecklistStatus => 'الحالة';

  @override
  String get servicesInspectionChecklistStatusPending => 'قيد الانتظار';

  @override
  String get servicesInspectionBeforeWorkPhotos => 'صور قبل العمل';

  @override
  String get servicesInspectionAddPhotos => 'إضافة صور';

  @override
  String get servicesInspectionAddChecklist => 'إضافة بند تحقق';

  @override
  String get servicesInspectionRemoveChecklist => 'إزالة بند التحقق';

  @override
  String servicesInspectionPointTitle(String index) {
    return 'نقطة $index';
  }

  @override
  String get servicesInspectionPointDescription => 'الوصف';

  @override
  String get servicesInspectionAddPoint => 'إضافة نقطة مفحوصة';

  @override
  String get servicesInspectionRemovePoint => 'إزالة النقطة المفحوصة';

  @override
  String servicesInspectionMaterialTitle(String index) {
    return 'مادة $index';
  }

  @override
  String get servicesInspectionMaterialCode => 'الرمز';

  @override
  String get servicesInspectionMaterialDescription => 'الوصف';

  @override
  String get servicesInspectionMaterialStatus => 'الحالة';

  @override
  String get servicesInspectionMaterialStatusWaiting => 'بالانتظار';

  @override
  String get servicesInspectionAddMaterial => 'إضافة مادة مطلوبة';

  @override
  String get servicesInspectionRemoveMaterial => 'إزالة المادة المطلوبة';

  @override
  String get servicesInspectionDetailContext => 'السياق المصدر';

  @override
  String get servicesInspectionDetailAssessment => 'التقييم';

  @override
  String get servicesInspectionDetailChecklist => 'قائمة التحقق';

  @override
  String get servicesInspectionDetailPoints => 'النقاط المفحوصة';

  @override
  String get servicesInspectionDetailMaterials => 'المواد المطلوبة';

  @override
  String get servicesInspectionDetailAudit => 'السجل';

  @override
  String get servicesInspectionDetailActivity => 'النشاط';

  @override
  String get servicesInspectionEdit => 'تعديل الفحص';

  @override
  String get servicesInspectionComplete => 'إكمال الفحص';

  @override
  String get servicesInspectionCancel => 'إلغاء الفحص';

  @override
  String get servicesInspectionCompleteConfirmTitle => 'إكمال الفحص؟';

  @override
  String get servicesInspectionCompleteConfirmMessage =>
      'يصبح الفحص للقراءة فقط ويمكن استخدامه في خطوات سير العمل اللاحقة.';

  @override
  String get servicesInspectionCancelConfirmTitle => 'إلغاء الفحص؟';

  @override
  String get servicesInspectionCancelConfirmMessage =>
      'يبقى الفحص الملغى متاحًا تاريخيًا ولا يمكن تعديله بعد ذلك.';

  @override
  String get servicesInspectionCreated => 'تم إنشاء الفحص.';

  @override
  String get servicesInspectionUpdated => 'تم تحديث الفحص.';

  @override
  String get servicesInspectionCompleted => 'تم إكمال الفحص.';

  @override
  String get servicesInspectionCancelled => 'تم إلغاء الفحص.';

  @override
  String get servicesInspectionNoActivity => 'لا يوجد نشاط بعد.';

  @override
  String get servicesInspectionCreatedBy => 'أنشأه';

  @override
  String get servicesInspectionCreatedAt => 'تاريخ الإنشاء';

  @override
  String get servicesInspectionUpdatedBy => 'حدّثه';

  @override
  String get servicesInspectionUpdatedAt => 'تاريخ التحديث';

  @override
  String get servicesInspectionVersion => 'الإصدار';

  @override
  String get servicesInspectionNoChecklist => 'لا توجد بنود تحقق.';

  @override
  String get servicesInspectionNoPoints => 'لا توجد نقاط مفحوصة.';

  @override
  String get servicesInspectionNoMaterials => 'لا توجد مواد مطلوبة.';

  @override
  String get servicesInspectionDenied => 'ليس لديك صلاحية لتنفيذ هذا الإجراء.';

  @override
  String get servicesInspectionNotFound => 'الفحص غير موجود.';

  @override
  String get servicesInspectionNotEditable =>
      'يمكن تعديل الفحوصات قيد الانتظار فقط.';

  @override
  String get servicesInspectionNotCompletable =>
      'يمكن إكمال الفحوصات قيد الانتظار فقط.';

  @override
  String get servicesInspectionAlreadyCancelled => 'هذا الفحص ملغى بالفعل.';

  @override
  String get servicesInspectionNotCancellable => 'لا يمكن إلغاء فحص مكتمل.';

  @override
  String get servicesInspectionAssignmentRequired => 'اختر تكليف عمل.';

  @override
  String get servicesInspectionAssignmentInvalid =>
      'تكليف العمل المحدد غير مؤهل.';

  @override
  String get servicesInspectionAlreadyActive => 'يوجد فحص لهذا التكليف بالفعل.';

  @override
  String get servicesInspectionVisitDateRequired => 'اختر تاريخ الزيارة.';

  @override
  String get servicesInspectionVisitTimeRequired => 'اختر وقت الزيارة.';

  @override
  String get servicesInspectionTechnicianRequired => 'اختر فنيًا.';

  @override
  String get servicesInspectionTechnicianInvalid =>
      'الفني المحدد غير مؤهل لهذا التكليف.';

  @override
  String get servicesInspectionRootCauseRequired => 'اختر السبب الجذري.';

  @override
  String get servicesInspectionRootCauseInvalid =>
      'السبب الجذري المحدد غير متاح.';

  @override
  String get servicesInspectionChargeResponsibilityRequired =>
      'اختر جهة التحميل.';

  @override
  String get servicesInspectionChargeResponsibilityInvalid =>
      'جهة التحميل المحددة غير متاحة.';

  @override
  String get servicesInspectionAssessmentRequired =>
      'أضف بند تحقق واحدًا على الأقل أو نقطة مفحوصة.';

  @override
  String get servicesInspectionWorkTypeRequired =>
      'أدخل نوع العمل لكل بند تحقق.';

  @override
  String get servicesInspectionPointRequired => 'أدخل وصفًا لكل نقطة مفحوصة.';

  @override
  String get servicesInspectionMaterialCodeRequired =>
      'أدخل الرمز لكل مادة مطلوبة.';

  @override
  String get servicesInspectionMaterialDescriptionRequired =>
      'أدخل الوصف لكل مادة مطلوبة.';

  @override
  String get servicesInspectionSequenceFailed => 'تعذّر تخصيص رقم للفحص.';

  @override
  String get servicesInspectionStorageError =>
      'تعذّر حفظ الفحص. حاول مرة أخرى.';

  @override
  String get servicesActivityCompleted => 'إكمال';

  @override
  String get servicesOverviewInspectionsPending => 'الفحوصات قيد الانتظار';

  @override
  String get servicesOverviewInspectionsToday => 'فحوصات اليوم';

  @override
  String get servicesOverviewInspectionsCompleted => 'الفحوصات المكتملة';

  @override
  String get servicesOverviewRecentInspections => 'أحدث الفحوصات';

  @override
  String get servicesOverviewNoInspections => 'لا توجد فحوصات بعد.';

  @override
  String get servicesAssignmentInspectionSection => 'الفحص';

  @override
  String get servicesAssignmentCreateInspection => 'إنشاء فحص';

  @override
  String get servicesAssignmentViewInspection => 'عرض الفحص';

  @override
  String get notifServiceInspectionAssignedTitle => 'تم تكليفك بفحص';

  @override
  String get notifServiceInspectionAssignedBody => 'تم تكليفك بفحص خدمة.';

  @override
  String get servicesPermSubMaterialRequests => 'طلبات المواد';

  @override
  String get servicesPermMaterialRequestsView => 'عرض طلبات المواد';

  @override
  String get servicesPermMaterialRequestsViewDesc =>
      'عرض قائمة طلبات المواد ضمن نطاق سجلاتك.';

  @override
  String get servicesPermMaterialRequestsCreate => 'إنشاء طلب مواد';

  @override
  String get servicesPermMaterialRequestsCreateDesc =>
      'إنشاء طلب مواد من فحص مكتمل مؤهل، مع البحث المقيّد عن الفحص.';

  @override
  String get servicesPermMaterialRequestsEdit => 'تعديل طلب المواد';

  @override
  String get servicesPermMaterialRequestsEditDesc => 'تعديل طلب مواد مفتوح.';

  @override
  String get servicesPermMaterialRequestsCancel => 'إلغاء طلب المواد';

  @override
  String get servicesPermMaterialRequestsCancelDesc =>
      'إلغاء طلب مواد مفتوح (يُحفظ تاريخيًا).';

  @override
  String get servicesPermMaterialRequestsPrint => 'طباعة طلب المواد';

  @override
  String get servicesPermMaterialRequestsPrintDesc => 'طباعة مستند طلب المواد.';

  @override
  String get servicesPermMaterialRequestPurposesView => 'عرض أغراض طلب المواد';

  @override
  String get servicesPermMaterialRequestPurposesViewDesc =>
      'عرض أغراض طلب المواد المُعدَّة.';

  @override
  String get servicesPermMaterialRequestPurposesManage =>
      'إدارة أغراض طلب المواد';

  @override
  String get servicesPermMaterialRequestPurposesManageDesc =>
      'إنشاء وتعديل أغراض طلب المواد.';

  @override
  String get permissionServiceMaterialRequestView => 'عرض طلبات المواد';

  @override
  String get permissionServiceMaterialRequestCreate => 'إنشاء طلب مواد';

  @override
  String get permissionServiceMaterialRequestEdit => 'تعديل طلب المواد';

  @override
  String get permissionServiceMaterialRequestCancel => 'إلغاء طلب المواد';

  @override
  String get permissionServiceMaterialRequestPrint => 'طباعة طلب المواد';

  @override
  String get servicesNavMaterialRequests => 'طلبات المواد';

  @override
  String get servicesMaterialRequestPurposesTitle => 'أغراض طلب المواد';

  @override
  String get servicesMaterialRequestsTitle => 'طلبات المواد';

  @override
  String servicesMaterialRequestCount(String filtered, String total) {
    return '$filtered من $total طلب مواد';
  }

  @override
  String get servicesMaterialRequestSearch =>
      'ابحث برقم الطلب أو الفحص أو التكليف أو الاستفسار أو أمر العمل أو العميل أو الرمز أو الوصف';

  @override
  String get servicesMaterialRequestAllStatuses => 'كل الحالات';

  @override
  String get servicesMaterialRequestStatusOpen => 'مفتوح';

  @override
  String get servicesMaterialRequestStatusCancelled => 'ملغى';

  @override
  String get servicesMaterialRequestEmpty => 'لا توجد طلبات مواد بعد.';

  @override
  String get servicesMaterialRequestEmptyMessage =>
      'أنشئ طلب مواد من فحص مكتمل.';

  @override
  String get servicesMaterialRequestNoResults =>
      'لا توجد طلبات مواد مطابقة للمرشحات.';

  @override
  String get servicesMaterialRequestAdd => 'طلب مواد جديد';

  @override
  String get servicesMaterialRequestColumnRequest => 'الطلب';

  @override
  String get servicesMaterialRequestColumnDate => 'التاريخ';

  @override
  String get servicesMaterialRequestColumnInspection => 'الفحص';

  @override
  String get servicesMaterialRequestColumnCustomerSite => 'العميل / الموقع';

  @override
  String get servicesMaterialRequestColumnPurpose => 'الغرض';

  @override
  String get servicesMaterialRequestColumnItems => 'الأصناف';

  @override
  String get servicesMaterialRequestColumnTotalQty => 'إجمالي الكمية';

  @override
  String get servicesMaterialRequestColumnStatus => 'الحالة';

  @override
  String get servicesMaterialRequestColumnPreparedBy => 'أعدّه';

  @override
  String get servicesMaterialRequestColumnCreated => 'تاريخ الإنشاء';

  @override
  String get servicesMaterialRequestFilterTitle => 'المرشحات';

  @override
  String get servicesMaterialRequestFilterStatus => 'الحالة';

  @override
  String get servicesMaterialRequestFilterPurpose => 'الغرض';

  @override
  String get servicesMaterialRequestFilterInspection => 'الفحص';

  @override
  String get servicesMaterialRequestFilterFrom => 'من تاريخ';

  @override
  String get servicesMaterialRequestFilterTo => 'إلى تاريخ';

  @override
  String get servicesMaterialRequestFormNew => 'طلب مواد جديد';

  @override
  String get servicesMaterialRequestFormEdit => 'تعديل طلب المواد';

  @override
  String get servicesMaterialRequestCreate => 'إنشاء طلب مواد';

  @override
  String get servicesMaterialRequestSaveChanges => 'حفظ التغييرات';

  @override
  String get servicesMaterialRequestSectionRequest => 'الطلب';

  @override
  String get servicesMaterialRequestSectionContext => 'سياق الخدمة';

  @override
  String get servicesMaterialRequestSectionInformation => 'معلومات الطلب';

  @override
  String get servicesMaterialRequestSectionMaterials => 'المواد';

  @override
  String get servicesMaterialRequestSectionAcknowledgement => 'الإقرار';

  @override
  String get servicesMaterialRequestSectionSummary => 'الملخص';

  @override
  String get servicesMaterialRequestSectionAudit => 'السجل';

  @override
  String get servicesMaterialRequestSectionActivity => 'النشاط';

  @override
  String get servicesMaterialRequestNo => 'رقم الطلب';

  @override
  String get servicesMaterialRequestDate => 'تاريخ الطلب';

  @override
  String get servicesMaterialRequestSourceInspection => 'الفحص المصدر';

  @override
  String get servicesMaterialRequestSelectInspection =>
      'اختر فحصًا مكتملًا مؤهلًا';

  @override
  String get servicesMaterialRequestInspection => 'الفحص';

  @override
  String get servicesMaterialRequestJobAssignment => 'تكليف العمل';

  @override
  String get servicesMaterialRequestEnquiry => 'الاستفسار';

  @override
  String get servicesMaterialRequestCustomer => 'العميل';

  @override
  String get servicesMaterialRequestSite => 'الموقع';

  @override
  String get servicesMaterialRequestTenant => 'المستأجر';

  @override
  String get servicesMaterialRequestBuilding => 'المبنى';

  @override
  String get servicesMaterialRequestUnit => 'الوحدة';

  @override
  String get servicesMaterialRequestMaterialReceived => 'المواد المستلمة';

  @override
  String get servicesMaterialRequestJobOrderReference => 'مرجع أمر العمل';

  @override
  String get servicesMaterialRequestJobOrderHint => 'رقم أمر عمل خارجي اختياري';

  @override
  String get servicesMaterialRequestPurpose => 'الغرض';

  @override
  String get servicesMaterialRequestRemarks => 'ملاحظات';

  @override
  String get servicesMaterialRequestAcknowledge => 'الإقرار';

  @override
  String get servicesMaterialRequestReceivedBy => 'استلمها';

  @override
  String get servicesMaterialRequestPreparedBy => 'أعدّه';

  @override
  String servicesMaterialRequestLineTitle(String index) {
    return 'مادة $index';
  }

  @override
  String get servicesMaterialRequestCode => 'الرمز';

  @override
  String get servicesMaterialRequestDescription => 'الوصف';

  @override
  String get servicesMaterialRequestBatchNumber => 'رقم الدفعة';

  @override
  String get servicesMaterialRequestQuantity => 'الكمية';

  @override
  String get servicesMaterialRequestRemark => 'ملاحظة';

  @override
  String get servicesMaterialRequestAddMaterial => 'إضافة مادة';

  @override
  String get servicesMaterialRequestRemoveMaterial => 'إزالة المادة';

  @override
  String get servicesMaterialRequestTotalQuantity => 'إجمالي الكمية';

  @override
  String servicesMaterialRequestItemCount(String count) {
    return '$count صنف';
  }

  @override
  String get servicesMaterialRequestEdit => 'تعديل الطلب';

  @override
  String get servicesMaterialRequestPrint => 'طباعة';

  @override
  String get servicesMaterialRequestCancel => 'إلغاء طلب المواد';

  @override
  String get servicesMaterialRequestCancelConfirmTitle => 'إلغاء طلب المواد؟';

  @override
  String get servicesMaterialRequestCancelConfirmMessage =>
      'يبقى الطلب الملغى متاحًا تاريخيًا ولا يمكن تعديله بعد ذلك.';

  @override
  String get servicesMaterialRequestCreated => 'تم إنشاء طلب المواد.';

  @override
  String get servicesMaterialRequestUpdated => 'تم تحديث طلب المواد.';

  @override
  String get servicesMaterialRequestCancelled => 'تم إلغاء طلب المواد.';

  @override
  String get servicesMaterialRequestPrinted => 'تم تجهيز طلب المواد للطباعة.';

  @override
  String get servicesMaterialRequestNoActivity => 'لا يوجد نشاط بعد.';

  @override
  String get servicesMaterialRequestNoMaterials => 'لا توجد بنود مواد.';

  @override
  String get servicesMaterialRequestCreatedBy => 'أنشأه';

  @override
  String get servicesMaterialRequestCreatedAt => 'تاريخ الإنشاء';

  @override
  String get servicesMaterialRequestUpdatedBy => 'حدّثه';

  @override
  String get servicesMaterialRequestUpdatedAt => 'تاريخ التحديث';

  @override
  String get servicesMaterialRequestVersion => 'الإصدار';

  @override
  String get servicesMaterialRequestDetailContext => 'السياق المصدر';

  @override
  String get servicesMaterialRequestDetailMaterials => 'بنود المواد';

  @override
  String get servicesMaterialRequestDetailAcknowledgement => 'الإقرار';

  @override
  String get servicesMaterialRequestDetailAudit => 'السجل';

  @override
  String get servicesMaterialRequestDetailActivity => 'النشاط';

  @override
  String get servicesMaterialRequestResetForm => 'إعادة تعيين النموذج';

  @override
  String get servicesMaterialRequestResetConfirmTitle => 'إعادة تعيين النموذج؟';

  @override
  String get servicesMaterialRequestResetConfirmMessage =>
      'سيؤدي هذا إلى مسح طلب المواد غير المحفوظ.';

  @override
  String get servicesMaterialRequestDiscardChanges => 'تجاهل التغييرات';

  @override
  String get servicesMaterialRequestCreateFromInspection => 'إنشاء طلب مواد';

  @override
  String get servicesMaterialRequestSectionForInspection => 'طلبات المواد';

  @override
  String get servicesMaterialRequestNoneForInspection =>
      'لا توجد طلبات مواد بعد.';

  @override
  String get servicesMaterialRequestInspectionRequired => 'اختر فحصًا.';

  @override
  String get servicesMaterialRequestInspectionInvalid =>
      'الفحص المحدد غير مؤهل.';

  @override
  String get servicesMaterialRequestPurposeInvalid => 'الغرض المحدد غير متاح.';

  @override
  String get servicesMaterialRequestLinesRequired =>
      'أضف بند مادة واحدًا على الأقل.';

  @override
  String get servicesMaterialRequestCodeRequired => 'أدخل الرمز لكل بند مادة.';

  @override
  String get servicesMaterialRequestDescriptionRequired =>
      'أدخل الوصف لكل بند مادة.';

  @override
  String get servicesMaterialRequestQuantityRequired =>
      'أدخل كمية أكبر من صفر لكل بند مادة.';

  @override
  String get servicesMaterialRequestNotFound => 'طلب المواد غير موجود.';

  @override
  String get servicesMaterialRequestNotEditable =>
      'يمكن تعديل طلبات المواد المفتوحة فقط.';

  @override
  String get servicesMaterialRequestAlreadyCancelled =>
      'طلب المواد هذا ملغى بالفعل.';

  @override
  String get servicesMaterialRequestRequirementLinked =>
      'بند مادة محدد مرتبط بالفعل بطلب نشط.';

  @override
  String get servicesMaterialRequestSequenceFailed => 'تعذّر تخصيص رقم للطلب.';

  @override
  String get servicesMaterialRequestDenied =>
      'ليس لديك صلاحية لتنفيذ هذا الإجراء.';

  @override
  String get servicesMaterialRequestStorageError =>
      'تعذّر حفظ طلب المواد. حاول مرة أخرى.';

  @override
  String get servicesMaterialRequestPrintFailed =>
      'تعذّر تجهيز المستند القابل للطباعة.';

  @override
  String get servicesInspectionMaterialStatusRequested => 'مطلوب';

  @override
  String get servicesOverviewMaterialRequestsOpen => 'طلبات المواد المفتوحة';

  @override
  String get servicesOverviewMaterialRequestsToday => 'طلبات المواد اليوم';

  @override
  String get servicesOverviewMaterialRequestsLines => 'بنود المواد المطلوبة';

  @override
  String get servicesOverviewRecentMaterialRequests => 'أحدث طلبات المواد';

  @override
  String get servicesOverviewNoMaterialRequests => 'لا توجد طلبات مواد بعد.';

  @override
  String get servicesMaterialRequestPrintTitle => 'طلب مواد';

  @override
  String get servicesActivityLinesChanged => 'تم تغيير بنود المواد';

  @override
  String get servicesNavWorkExecution => 'تنفيذ العمل';

  @override
  String get servicesPermSubWorkExecutions => 'تنفيذ العمل';

  @override
  String get servicesPermWorkExecutionsView => 'عرض تنفيذ العمل';

  @override
  String get servicesPermWorkExecutionsViewDesc =>
      'عرض قائمة تنفيذ العمل ضمن نطاق سجلاتك.';

  @override
  String get servicesPermWorkExecutionsCreate => 'إنشاء تنفيذ عمل';

  @override
  String get servicesPermWorkExecutionsCreateDesc =>
      'إنشاء تنفيذ عمل من فحص مكتمل، مع بحث مقيّد عن الفحص المؤهل.';

  @override
  String get servicesPermWorkExecutionsEdit => 'تعديل تنفيذ العمل';

  @override
  String get servicesPermWorkExecutionsEditDesc =>
      'تعديل مراجع الرأس وبنود العمل أثناء صلاحية السجل.';

  @override
  String get servicesPermWorkExecutionsPerform => 'تنفيذ العمل';

  @override
  String get servicesPermWorkExecutionsPerformDesc =>
      'بدء وإنهاء العمل المكلّف، وتسجيل المواد المستخدمة وإضافة صور بعد العمل.';

  @override
  String get servicesPermWorkExecutionsComplete => 'إكمال تنفيذ العمل';

  @override
  String get servicesPermWorkExecutionsCompleteDesc =>
      'إنهاء تنفيذ العمل بعد اكتمال كل العمل المطلوب.';

  @override
  String get servicesPermWorkExecutionsCancel => 'إلغاء تنفيذ العمل';

  @override
  String get servicesPermWorkExecutionsCancelDesc =>
      'إلغاء تنفيذ العمل (يُحفظ تاريخيًا).';

  @override
  String get permissionServiceWorkExecutionView => 'عرض تنفيذ العمل';

  @override
  String get permissionServiceWorkExecutionCreate => 'إنشاء تنفيذ عمل';

  @override
  String get permissionServiceWorkExecutionEdit => 'تعديل تنفيذ العمل';

  @override
  String get permissionServiceWorkExecutionPerform => 'تنفيذ العمل';

  @override
  String get permissionServiceWorkExecutionComplete => 'إكمال تنفيذ العمل';

  @override
  String get permissionServiceWorkExecutionCancel => 'إلغاء تنفيذ العمل';

  @override
  String get servicesActivityWorkStarted => 'بدء العمل';

  @override
  String get servicesActivityWorkEnded => 'إنهاء العمل';

  @override
  String get servicesActivityMaterialUsedAdded => 'إضافة مادة مستخدمة';

  @override
  String get servicesActivityMaterialUsedRemoved => 'إزالة مادة مستخدمة';

  @override
  String get servicesActivityPhotoAdded => 'إضافة صور بعد العمل';

  @override
  String get servicesActivityPhotoUpdated => 'تحديث صورة بعد العمل';

  @override
  String get servicesActivityPhotoRemoved => 'إزالة صورة بعد العمل';

  @override
  String get servicesWorkExecutionStatusPending => 'قيد الانتظار';

  @override
  String get servicesWorkExecutionStatusInProgress => 'قيد التنفيذ';

  @override
  String get servicesWorkExecutionStatusCompleted => 'مكتمل';

  @override
  String get servicesWorkExecutionStatusCancelled => 'ملغى';

  @override
  String get servicesWorkExecutionLineStateNotStarted => 'لم يبدأ';

  @override
  String get servicesWorkExecutionLineStateInProgress => 'قيد التنفيذ';

  @override
  String get servicesWorkExecutionLineStateFinished => 'منتهٍ';

  @override
  String get servicesWorkExecutionsTitle => 'تنفيذ العمل';

  @override
  String servicesWorkExecutionCount(String filtered, String total) {
    return '$filtered من $total تنفيذ عمل';
  }

  @override
  String get servicesWorkExecutionAdd => 'تنفيذ عمل جديد';

  @override
  String get servicesWorkExecutionEmpty => 'لا يوجد تنفيذ عمل بعد.';

  @override
  String get servicesWorkExecutionEmptyMessage =>
      'أنشئ تنفيذ عمل من فحص مكتمل.';

  @override
  String get servicesWorkExecutionNoResults =>
      'لا يوجد تنفيذ عمل مطابق للمرشحات.';

  @override
  String get servicesWorkExecutionSearch =>
      'ابحث برقم التنفيذ أو الفحص أو التكليف أو الاستفسار أو مرجع أمر العمل أو مرجع عرض السعر أو العميل أو الموقع أو الموظف أو الفريق أو رمز المادة';

  @override
  String get servicesWorkExecutionFilterTitle => 'المرشحات';

  @override
  String get servicesWorkExecutionFilterStatus => 'الحالة';

  @override
  String get servicesWorkExecutionFilterFrom => 'من تاريخ';

  @override
  String get servicesWorkExecutionFilterTo => 'إلى تاريخ';

  @override
  String get servicesWorkExecutionAllStatuses => 'كل الحالات';

  @override
  String get servicesWorkExecutionColumnExecution => 'التنفيذ';

  @override
  String get servicesWorkExecutionColumnInspection => 'الفحص';

  @override
  String get servicesWorkExecutionColumnCustomerSite => 'العميل / الموقع';

  @override
  String get servicesWorkExecutionColumnAssignedTo => 'مُكلَّف إلى';

  @override
  String get servicesWorkExecutionColumnState => 'حالة التنفيذ';

  @override
  String get servicesWorkExecutionColumnStarted => 'البدء';

  @override
  String get servicesWorkExecutionColumnCompleted => 'الاكتمال';

  @override
  String get servicesWorkExecutionColumnStatus => 'الحالة';

  @override
  String get servicesWorkExecutionColumnCreated => 'تاريخ الإنشاء';

  @override
  String get servicesWorkExecutionCancel => 'إلغاء تنفيذ العمل';

  @override
  String get servicesWorkExecutionCancelConfirmTitle => 'إلغاء تنفيذ العمل؟';

  @override
  String get servicesWorkExecutionCancelConfirmMessage =>
      'يبقى تنفيذ العمل الملغى متاحًا تاريخيًا ولا يمكن تعديله بعد ذلك.';

  @override
  String get servicesWorkExecutionCancelled => 'تنفيذ العمل هذا ملغى.';

  @override
  String get servicesWorkExecutionStorageError =>
      'تعذّر حفظ تنفيذ العمل. حاول مرة أخرى.';

  @override
  String get servicesWorkExecutionFormNew => 'تنفيذ عمل جديد';

  @override
  String get servicesWorkExecutionFormEdit => 'تعديل تنفيذ العمل';

  @override
  String get servicesWorkExecutionCreate => 'إنشاء تنفيذ عمل';

  @override
  String get servicesWorkExecutionSaveChanges => 'حفظ التغييرات';

  @override
  String get servicesWorkExecutionResetForm => 'إعادة تعيين النموذج';

  @override
  String get servicesWorkExecutionResetConfirmTitle => 'إعادة تعيين النموذج؟';

  @override
  String get servicesWorkExecutionResetConfirmMessage =>
      'سيؤدي هذا إلى مسح تنفيذ العمل غير المحفوظ.';

  @override
  String get servicesWorkExecutionSectionContext => 'سياق تنفيذ العمل';

  @override
  String get servicesWorkExecutionSectionReferences => 'مراجع سير العمل';

  @override
  String get servicesWorkExecutionSectionCustomer => 'سياق العميل والخدمة';

  @override
  String get servicesWorkExecutionSectionInspection => 'ملخص الفحص';

  @override
  String get servicesWorkExecutionSectionWork => 'تنفيذ العمل';

  @override
  String get servicesWorkExecutionSectionMaterials => 'المواد المستخدمة';

  @override
  String get servicesWorkExecutionSectionPhotos => 'صور بعد العمل';

  @override
  String get servicesWorkExecutionNo => 'رقم التنفيذ';

  @override
  String get servicesWorkExecutionDate => 'تاريخ التنفيذ';

  @override
  String get servicesWorkExecutionSourceInspection => 'الفحص المصدر';

  @override
  String get servicesWorkExecutionSelectInspection =>
      'اختر فحصًا مكتملًا مؤهلًا';

  @override
  String get servicesWorkExecutionInspection => 'الفحص';

  @override
  String get servicesWorkExecutionJobAssignment => 'تكليف العمل';

  @override
  String get servicesWorkExecutionEnquiry => 'الاستفسار';

  @override
  String get servicesWorkExecutionJobOrderReference => 'مرجع أمر العمل';

  @override
  String get servicesWorkExecutionSectionOrderReferences => 'مراجع أمر العمل';

  @override
  String get servicesWorkExecutionQuotationReference => 'مرجع عرض السعر';

  @override
  String get servicesWorkExecutionCustomer => 'العميل';

  @override
  String get servicesWorkExecutionTenant => 'المستأجر';

  @override
  String get servicesWorkExecutionBuilding => 'المبنى';

  @override
  String get servicesWorkExecutionUnit => 'الوحدة';

  @override
  String get servicesWorkExecutionComplaint => 'نوع الشكوى';

  @override
  String get servicesWorkExecutionPriority => 'الأولوية';

  @override
  String get servicesWorkExecutionMaterialReceived => 'المواد المستلمة';

  @override
  String get servicesWorkExecutionRootCause => 'السبب الجذري';

  @override
  String get servicesWorkExecutionChargeResponsibility => 'جهة التحميل';

  @override
  String get servicesWorkExecutionTechnician => 'الفني';

  @override
  String get servicesWorkExecutionChecklist => 'قائمة التحقق';

  @override
  String get servicesWorkExecutionInspectedPoints => 'النقاط المفحوصة';

  @override
  String get servicesWorkExecutionMaterialRequirements => 'المواد المطلوبة';

  @override
  String get servicesWorkExecutionLinkedMaterialRequests =>
      'طلبات المواد المرتبطة';

  @override
  String servicesWorkExecutionMaterialRequestItems(String count) {
    return '$count صنف';
  }

  @override
  String get servicesWorkExecutionAddFromMaterialRequest => 'إضافة من طلب مواد';

  @override
  String get servicesWorkExecutionNoLinkedRequests =>
      'لا توجد طلبات مواد مرتبطة.';

  @override
  String servicesWorkExecutionLineTitle(String index) {
    return 'بند العمل $index';
  }

  @override
  String servicesWorkExecutionMaterialTitle(String index) {
    return 'مادة $index';
  }

  @override
  String servicesWorkExecutionPhotoTitle(String index) {
    return 'دليل مصوّر $index';
  }

  @override
  String get servicesWorkExecutionWork => 'العمل';

  @override
  String get servicesWorkExecutionDescription => 'الوصف';

  @override
  String get servicesWorkExecutionTeam => 'الفريق';

  @override
  String get servicesWorkExecutionEmployee => 'الموظف';

  @override
  String get servicesWorkExecutionStartTime => 'وقت البدء';

  @override
  String get servicesWorkExecutionEndTime => 'وقت الانتهاء';

  @override
  String get servicesWorkExecutionNoLines => 'لا توجد بنود عمل.';

  @override
  String get servicesWorkExecutionAddLine => 'إضافة بند عمل';

  @override
  String get servicesWorkExecutionRemoveLine => 'إزالة بند العمل';

  @override
  String get servicesWorkExecutionCode => 'الرمز';

  @override
  String get servicesWorkExecutionNoMaterials => 'لا توجد مواد مستخدمة.';

  @override
  String get servicesWorkExecutionAddMaterial => 'إضافة مادة مستخدمة';

  @override
  String get servicesWorkExecutionRemoveMaterial => 'إزالة المادة المستخدمة';

  @override
  String get servicesWorkExecutionPhotoDescription => 'الوصف';

  @override
  String get servicesWorkExecutionPhotos => 'الصور';

  @override
  String get servicesWorkExecutionAddPhotos => 'إضافة صور';

  @override
  String get servicesWorkExecutionNoPhotos => 'لا توجد صور.';

  @override
  String get servicesWorkExecutionAddPhoto => 'إضافة دليل مصوّر';

  @override
  String get servicesWorkExecutionRemovePhoto => 'إزالة الدليل المصوّر';

  @override
  String get servicesWorkExecutionCreated => 'تم إنشاء تنفيذ العمل.';

  @override
  String get servicesWorkExecutionUpdated => 'تم تحديث تنفيذ العمل.';

  @override
  String get servicesWorkExecutionWorkRequired => 'أدخل العمل لكل بند.';

  @override
  String get servicesWorkExecutionDetailReferences => 'مراجع سير العمل';

  @override
  String get servicesWorkExecutionDetailContext => 'سياق العميل والخدمة';

  @override
  String get servicesWorkExecutionDetailWork => 'بنود العمل';

  @override
  String get servicesWorkExecutionDetailMaterials => 'المواد المستخدمة';

  @override
  String get servicesWorkExecutionDetailPhotos => 'الصور';

  @override
  String get servicesWorkExecutionDetailAudit => 'السجل';

  @override
  String get servicesWorkExecutionDetailActivity => 'النشاط';

  @override
  String get servicesWorkExecutionStartWork => 'بدء العمل';

  @override
  String get servicesWorkExecutionEndWork => 'إنهاء العمل';

  @override
  String get servicesWorkExecutionComplete => 'إكمال تنفيذ العمل';

  @override
  String get servicesWorkExecutionCompleteConfirmTitle => 'إكمال تنفيذ العمل؟';

  @override
  String get servicesWorkExecutionCompleteConfirmMessage =>
      'يصبح تنفيذ العمل للقراءة فقط ويبقى متاحًا تاريخيًا.';

  @override
  String get servicesWorkExecutionCompleted => 'تم إكمال تنفيذ العمل.';

  @override
  String get servicesWorkExecutionPreparedBy => 'أنشأه';

  @override
  String get servicesWorkExecutionCreatedAt => 'تاريخ الإنشاء';

  @override
  String get servicesWorkExecutionUpdatedBy => 'حدّثه';

  @override
  String get servicesWorkExecutionUpdatedAt => 'تاريخ التحديث';

  @override
  String get servicesWorkExecutionVersion => 'الإصدار';

  @override
  String get servicesWorkExecutionNoActivity => 'لا يوجد نشاط بعد.';

  @override
  String get servicesWorkExecutionWorkStarted => 'تم بدء العمل.';

  @override
  String get servicesWorkExecutionWorkEnded => 'تم إنهاء العمل.';

  @override
  String get servicesWorkExecutionMaterialAdded => 'تمت إضافة مادة مستخدمة.';

  @override
  String get servicesWorkExecutionMaterialRemoved =>
      'تمت إزالة المادة المستخدمة.';

  @override
  String get servicesWorkExecutionPhotoAdded => 'تمت إضافة دليل مصوّر.';

  @override
  String get servicesWorkExecutionPhotoRemoved => 'تمت إزالة الدليل المصوّر.';

  @override
  String get servicesWorkExecutionBeforeWorkPhotos => 'صور قبل العمل';

  @override
  String get servicesWorkExecutionAfterWorkPhotos => 'صور بعد العمل';

  @override
  String get servicesWorkExecutionEdit => 'تعديل تنفيذ العمل';

  @override
  String get servicesWorkExecutionDenied =>
      'ليس لديك صلاحية لتنفيذ هذا الإجراء.';

  @override
  String get servicesWorkExecutionNotFound => 'تنفيذ العمل غير موجود.';

  @override
  String get servicesWorkExecutionNotEditable =>
      'يمكن تعديل تنفيذ العمل قيد الانتظار أو قيد التنفيذ فقط.';

  @override
  String get servicesWorkExecutionNotCompletable =>
      'يجب بدء وإنهاء كل بنود العمل المطلوبة قبل الإكمال.';

  @override
  String get servicesWorkExecutionAlreadyCompleted =>
      'تنفيذ العمل هذا مكتمل بالفعل.';

  @override
  String get servicesWorkExecutionLineAlreadyStarted =>
      'بند العمل هذا بدأ بالفعل.';

  @override
  String get servicesWorkExecutionLineNotStarted =>
      'ابدأ بند العمل قبل إنهائه.';

  @override
  String get servicesWorkExecutionLineAlreadyEnded =>
      'بند العمل هذا منتهٍ بالفعل.';

  @override
  String get servicesWorkExecutionInvalidTimeRange =>
      'لا يمكن أن يكون وقت الانتهاء قبل وقت البدء.';

  @override
  String get servicesWorkExecutionInspectionRequired => 'اختر فحصًا.';

  @override
  String get servicesWorkExecutionInspectionNotEligible =>
      'الفحص المحدد غير مؤهل.';

  @override
  String get servicesWorkExecutionAlreadyActive =>
      'يوجد تنفيذ عمل نشط لهذا الفحص بالفعل.';

  @override
  String get servicesWorkExecutionSequenceFailed =>
      'تعذّر تخصيص رقم لتنفيذ العمل.';

  @override
  String get servicesWorkExecutionLinesRequired =>
      'أضف بند عمل واحدًا على الأقل.';

  @override
  String get servicesWorkExecutionCodeRequired =>
      'أدخل الرمز لكل بند مادة مستخدمة.';

  @override
  String get servicesWorkExecutionDescriptionRequired =>
      'أدخل الوصف لكل بند مادة مستخدمة.';

  @override
  String get servicesWorkExecutionPhotoDescriptionRequired =>
      'أدخل وصفًا لكل دليل مصوّر.';

  @override
  String get servicesWorkExecutionTeamInvalid => 'الفريق المحدد غير متاح.';

  @override
  String get servicesWorkExecutionEmployeeInvalid => 'الموظف المحدد غير متاح.';

  @override
  String get servicesWorkExecutionMaterialRequestLineInvalid =>
      'بند طلب المواد المحدد غير متاح.';

  @override
  String get servicesOverviewWorkExecutionsPending => 'تنفيذ عمل قيد الانتظار';

  @override
  String get servicesOverviewWorkExecutionsInProgress => 'عمل قيد التنفيذ';

  @override
  String get servicesOverviewWorkExecutionsCompletedToday => 'المكتمل اليوم';

  @override
  String get servicesOverviewRecentWorkExecutions => 'أحدث تنفيذ العمل';

  @override
  String get servicesOverviewNoWorkExecutions => 'لا يوجد تنفيذ عمل بعد.';

  @override
  String get servicesInspectionWorkExecutionSection => 'تنفيذ العمل';

  @override
  String get servicesInspectionCreateWorkExecution => 'إنشاء تنفيذ عمل';

  @override
  String get servicesInspectionNoWorkExecution => 'لا يوجد تنفيذ عمل بعد.';

  @override
  String get servicesAssignmentWorkExecutionSection => 'تنفيذ العمل';

  @override
  String get servicesEnquiryWorkExecutionSection => 'تنفيذ العمل';

  @override
  String get servicesWorkflowTitle => 'سير العمل';

  @override
  String get servicesWorkflowStageEnquiry => 'استفسار الخدمة';

  @override
  String get servicesWorkflowStageJobAssignment => 'إسناد العمل';

  @override
  String get servicesWorkflowStageInspection => 'الفحص';

  @override
  String get servicesWorkflowStageMaterialRequest => 'طلب المواد';

  @override
  String get servicesWorkflowStageWorkExecution => 'تنفيذ العمل';

  @override
  String get servicesWorkflowNotCreated => 'غير مطلوب / لم يتم الإنشاء';

  @override
  String get servicesWorkflowNotAvailable => 'غير متاح';

  @override
  String get servicesWorkflowOptional => 'اختياري';

  @override
  String get servicesWorkflowStatusAwaitingAssignment => 'بانتظار الإسناد';

  @override
  String get servicesWorkflowStatusScheduled => 'مجدول';

  @override
  String get servicesWorkflowStatusInspectionPending => 'الفحص معلّق';

  @override
  String get servicesWorkflowStatusInspectionCompleted => 'اكتمل الفحص';

  @override
  String get servicesWorkflowStatusMaterialsRequested => 'تم طلب المواد';

  @override
  String get servicesWorkflowStatusWorkInProgress => 'العمل قيد التنفيذ';

  @override
  String get servicesWorkflowStatusWorkCompleted => 'اكتمل العمل';

  @override
  String get servicesWorkflowStatusCancelled => 'ملغى';

  @override
  String get servicesWorkflowStatusUnknown => 'قيد المعالجة';

  @override
  String get servicesWorkflowActivityTitle => 'نشاط سير العمل';

  @override
  String get servicesWorkflowNoActivity => 'لا يوجد نشاط لسير العمل بعد.';

  @override
  String get servicesWorkflowNextActions => 'الإجراءات التالية';

  @override
  String servicesWorkflowMaterialWaiting(String count) {
    return '$count متطلبات مواد بانتظار';
  }

  @override
  String get servicesWorkflowActionCreateAssignment => 'إنشاء إسناد عمل';

  @override
  String get servicesWorkflowActionViewAssignment => 'عرض إسناد العمل';

  @override
  String get servicesWorkflowActionCreateInspection => 'إنشاء فحص';

  @override
  String get servicesWorkflowActionViewInspection => 'عرض الفحص';

  @override
  String get servicesWorkflowActionCreateMaterialRequest => 'إنشاء طلب مواد';

  @override
  String get servicesWorkflowActionViewMaterialRequest => 'عرض طلب المواد';

  @override
  String get servicesWorkflowActionCreateWorkExecution => 'إنشاء تنفيذ عمل';

  @override
  String get servicesWorkflowActionViewWorkExecution => 'عرض تنفيذ العمل';

  @override
  String get servicesWorkflowActionPerform => 'بدء / إنهاء العمل';

  @override
  String get servicesWorkflowActionComplete => 'إكمال';

  @override
  String get servicesWorkflowActionCancel => 'إلغاء';

  @override
  String get servicesWorkflowActionEdit => 'تعديل';

  @override
  String get servicesWorkflowActionPrint => 'طباعة';

  @override
  String get servicesWorkflowEvidenceTitle => 'أدلة العمل';

  @override
  String get servicesWorkflowBeforeWork => 'قبل العمل';

  @override
  String get servicesWorkflowAfterWork => 'بعد العمل';

  @override
  String get servicesWorkflowNoBeforePhotos => 'لا توجد صور قبل العمل.';

  @override
  String get servicesWorkflowNoAfterPhotos => 'لا توجد صور بعد العمل.';

  @override
  String get servicesOverviewMyWork => 'عملي';

  @override
  String get servicesOverviewMyWorkAssignments => 'إسناداتي';

  @override
  String get servicesOverviewMyWorkInspections => 'فحوصاتي المعلّقة';

  @override
  String get servicesOverviewMyWorkExecutions => 'عملي النشط';

  @override
  String get servicesOverviewNoMyWork => 'لا يوجد عمل مُسند حالياً.';

  @override
  String get servicesOverviewWorkflowTitle => 'سير العمل التشغيلي';

  @override
  String get servicesDashboardSubtitle =>
      'نظرة تشغيلية شاملة على سير عمل خدماتك';

  @override
  String get servicesDashboardScopeAssigned => 'عرض: العمل المُسند';

  @override
  String get servicesDashboardScopeTeam => 'عرض: نطاق الفريق';

  @override
  String get servicesDashboardScopeAll => 'عرض: جميع خدمات الشركة';

  @override
  String get servicesDashboardScopeNone => 'عرض: بدون نطاق خدمات';

  @override
  String get servicesDashboardToday => 'اليوم';

  @override
  String get servicesDashboardKpiOpenEnquiries => 'الاستفسارات المفتوحة';

  @override
  String get servicesDashboardKpiOpenEnquiriesContext => 'بانتظار الإسناد';

  @override
  String get servicesDashboardKpiScheduledJobs => 'المهام المجدولة';

  @override
  String get servicesDashboardKpiScheduledJobsContext => 'زيارات ميدانية نشطة';

  @override
  String get servicesDashboardKpiPendingInspections => 'الفحوصات المعلّقة';

  @override
  String get servicesDashboardKpiPendingInspectionsContext => 'بانتظار الإكمال';

  @override
  String get servicesDashboardKpiOpenMaterialRequests =>
      'طلبات المواد المفتوحة';

  @override
  String get servicesDashboardKpiOpenMaterialRequestsContext =>
      'فرع اختياري من سير العمل';

  @override
  String get servicesDashboardKpiWorkInProgress => 'عمل قيد التنفيذ';

  @override
  String get servicesDashboardKpiWorkInProgressContext => 'نشط في الموقع';

  @override
  String get servicesDashboardKpiCompletedToday => 'المكتمل اليوم';

  @override
  String get servicesDashboardKpiCompletedTodayContext => 'اليوم بتوقيت الشركة';

  @override
  String get servicesDashboardNeedsAttention => 'يتطلب الانتباه';

  @override
  String get servicesDashboardTodaySchedule => 'جدول اليوم';

  @override
  String get servicesDashboardMyWork => 'عملي';

  @override
  String get servicesDashboardTeamWorkload => 'عبء عمل الفريق';

  @override
  String get servicesDashboardWorkflowOverview => 'نظرة عامة على سير العمل';

  @override
  String get servicesDashboardRecentActivity => 'النشاط الأخير';

  @override
  String get servicesDashboardQuickActions => 'إجراءات سريعة';

  @override
  String get servicesDashboardAllCaughtUp => 'لا توجد مهام معلّقة.';

  @override
  String get servicesDashboardNoSchedule => 'لا توجد زيارات مجدولة اليوم.';

  @override
  String get servicesDashboardNoMyWork => 'لا يوجد عمل مُسند حالياً.';

  @override
  String get servicesDashboardNoActivity => 'لا يوجد نشاط خدمة حديث.';

  @override
  String get servicesDashboardNoTeamWorkload => 'لا يوجد عبء عمل نشط للفريق.';

  @override
  String get servicesDashboardEmptyTitle => 'لا يوجد نشاط خدمة بعد';

  @override
  String get servicesDashboardEmptyMessage =>
      'أنشئ أول استفسار خدمة لبدء سير العمل.';

  @override
  String get servicesDashboardEmptyAssignedTitle =>
      'لا يوجد عمل مُسند إليك حالياً.';

  @override
  String get servicesDashboardEmptyAssignedMessage =>
      'ستظهر الإسنادات والفحوصات الجديدة هنا تلقائياً.';

  @override
  String get servicesDashboardError => 'تعذّر تحميل لوحة معلومات الخدمات.';

  @override
  String get servicesDashboardAttentionOpenEnquiry =>
      'استفسار مفتوح بدون إسناد عمل نشط';

  @override
  String get servicesDashboardAttentionVisitNoInspection =>
      'زيارة مجدولة اليوم بدون فحص';

  @override
  String get servicesDashboardAttentionInspectionToday => 'فحص مجدول اليوم';

  @override
  String get servicesDashboardAttentionWaitingMaterials =>
      'الفحص لديه متطلبات مواد بانتظار';

  @override
  String get servicesDashboardAttentionOpenMaterialRequest => 'طلب مواد مفتوح';

  @override
  String get servicesDashboardAttentionActiveWork =>
      'تنفيذ العمل لديه بند عمل نشط';

  @override
  String get servicesDashboardActionOpenInspection => 'فتح الفحص';

  @override
  String get servicesDashboardActionViewEnquiry => 'عرض الاستفسار';

  @override
  String get servicesDashboardActionCreateAssignment => 'إنشاء إسناد عمل';

  @override
  String get servicesDashboardActionOpenMaterialRequest => 'فتح طلب المواد';

  @override
  String get servicesDashboardActionOpenWork => 'فتح تنفيذ العمل';

  @override
  String get servicesDashboardActionViewAssignment => 'عرض الإسناد';

  @override
  String get servicesDashboardActionStartWork => 'بدء العمل';

  @override
  String get servicesDashboardActionContinueWork => 'متابعة العمل';

  @override
  String get servicesDashboardTeamActiveSuffix => 'نشط';

  @override
  String get servicesDashboardTeamTodaySuffix => 'اليوم';

  @override
  String get servicesDashboardTeamInProgressSuffix => 'قيد التنفيذ';

  @override
  String get servicesDashboardQuickCreateAssignment => 'إنشاء إسناد عمل';

  @override
  String get servicesDashboardQuickNewInspection => 'فحص جديد';

  @override
  String get servicesDashboardQuickNewMaterialRequest => 'طلب مواد جديد';

  @override
  String get servicesDashboardQuickNewWorkExecution => 'تنفيذ عمل جديد';

  @override
  String get servicesDashboardDueToday => 'اليوم';

  @override
  String get servicesDashboardWaitingMaterials => 'متطلبات مواد بانتظار';
}

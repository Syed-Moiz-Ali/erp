import 'package:flutter/foundation.dart';

/// Explicit, deterministic authentication source selection.
enum AuthMode {
  /// Local demo fixtures. Only ever selected intentionally.
  demo,

  /// Real MassERP backend authentication.
  backend,

  /// No authentication configured: login fails with an explicit safe error.
  disabled,
}

abstract final class AppConfig {
  /// Release builds disable fixtures unless deliberately opted into demo mode.
  static const demoAuthEnabled = bool.fromEnvironment(
    'DEMO_AUTH',
    defaultValue: !kReleaseMode,
  );

  /// Backend base URL, e.g. `--dart-define=API_BASE_URL=https://api.example.com`.
  /// Empty means no remote backend is configured.
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL');

  /// Real backend mode is active when a base URL is supplied at build time.
  static const realApiEnabled = apiBaseUrl != '';

  /// Explicit, environment-restricted development exception that permits a
  /// plain-HTTP base URL for loopback hosts in debug builds only. Defaults off;
  /// release builds always require HTTPS (see `ApiBaseUrl.parse`).
  static const allowInsecureHttp = bool.fromEnvironment(
    'ALLOW_INSECURE_HTTP',
    defaultValue: false,
  );

  /// A configured backend always wins. Otherwise demo is used only when
  /// explicitly available; a release build with neither setting becomes
  /// [AuthMode.disabled] and can never authenticate through demo fallback.
  static const AuthMode authMode = realApiEnabled
      ? AuthMode.backend
      : (demoAuthEnabled ? AuthMode.demo : AuthMode.disabled);

  /// True only when the selected mode is demo. Gates demo fixtures, seeds and
  /// local-authoritative behavior so a real backend build never mixes in demo
  /// records or demo-local authority.
  static const bool demoMode = authMode == AuthMode.demo;
}

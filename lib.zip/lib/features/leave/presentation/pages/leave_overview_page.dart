import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/router/app_routes.dart';
import '../../../../core/security/app_permission.dart';
import '../../../../design_system/design_system.dart';
import '../../../../l10n/l10n.dart';
import '../../../../shared/presentation/configuration_localization.dart';
import '../../../auth/domain/policies/user_capability.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../bloc/leave_operations_blocs.dart';
import '../widgets/leave_operations_widgets.dart';

/// Persona-aware Leave landing. Organizational capabilities get a company/team
/// workspace; everyone else gets the self overview.
class LeaveOverviewPage extends StatelessWidget {
  const LeaveOverviewPage({super.key, required this.company});
  final bool company;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final account = context.read<AuthBloc>().state.context;
    if (account == null) return const SizedBox.shrink();
    final capabilities = const UserCapabilityResolver().forAuthContext(account);
    final p = PermissionChecker(account.user.permissions);
    final links = <({IconData icon, String label, String route})>[
      if (capabilities.has(UserCapability.viewMyLeave))
        (
          icon: Icons.person_outline,
          label: l.leaveMyLeave,
          route: AppRoutes.leaveMyRequests,
        ),
      if (capabilities.has(UserCapability.viewTeamLeave))
        (
          icon: Icons.groups_outlined,
          label: l.leaveTeam,
          route: AppRoutes.leaveTeam,
        ),
      if (capabilities.has(UserCapability.viewCompanyLeave))
        (
          icon: Icons.badge_outlined,
          label: l.leaveAllNav,
          route: AppRoutes.leaveAll,
        ),
      if (capabilities.has(UserCapability.approveTeamLeave) ||
          capabilities.has(UserCapability.approveCompanyLeave))
        (
          icon: Icons.fact_check_outlined,
          label: l.leaveApprovals,
          route: AppRoutes.leaveApprovals,
        ),
      if (capabilities.has(UserCapability.viewMyLeaveBalance) ||
          p.canAny([
            AppPermission.leaveBalanceViewTeam,
            AppPermission.leaveBalanceViewAll,
          ]))
        (
          icon: Icons.account_balance_wallet_outlined,
          label: l.leaveBalancesNav,
          route: AppRoutes.leaveBalances,
        ),
      (
        icon: Icons.calendar_month_outlined,
        label: l.leaveCalendarNav,
        route: AppRoutes.leaveCalendar,
      ),
    ];
    return AppPage(
      header: AppPageHeader(
        title: company ? l.leaveCompanyOverview : l.leaveTeamOverview,
        subtitle: l.leaveOverviewSubtitle,
        actions: [
          if (capabilities.has(UserCapability.requestLeave))
            AppPrimaryButton(
              icon: Icons.add_rounded,
              label: l.leaveNewRequest,
              onPressed: () => context.push(AppRoutes.leaveRequest),
            ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          BlocBuilder<LeaveOperationsBloc, LeaveOperationsState>(
            builder: (c, s) {
              if (s.loading) return const AppLoadingState();
              if (s.failure != null) {
                return AppErrorState(
                  message: configurationFailure(s.failure!, c.l10n),
                  onRetry: () => c.read<LeaveOperationsBloc>().add(
                    const LeaveOperationsStarted(),
                  ),
                );
              }
              final data = s.data;
              if (data == null) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  LeaveSummaryMetrics(
                    summary: data.summary,
                    showTeamMembers: !company,
                  ),
                  const SizedBox(height: AppSpacing.xl),
                  Text(
                    l.leaveOnLeaveToday,
                    style: AppTypography.of(c).sectionTitle,
                  ),
                  const SizedBox(height: AppSpacing.md),
                  LeaveTodaySection(items: data.today),
                ],
              );
            },
          ),
          const SizedBox(height: AppSpacing.xl),
          Wrap(
            spacing: AppSpacing.lg,
            runSpacing: AppSpacing.lg,
            children: [
              for (final link in links)
                SizedBox(
                  width: 210,
                  child: AppCard(
                    variant: AppCardVariant.interactive,
                    onTap: () => context.push(link.route),
                    child: Row(
                      children: [
                        Icon(link.icon, color: AppColors.brandPrimary),
                        const SizedBox(width: AppSpacing.md),
                        Expanded(
                          child: Text(
                            link.label,
                            style: AppTypography.of(context).body,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/router/app_routes.dart';
import '../../../../core/errors/result.dart';
import '../../../../core/security/app_permission.dart';
import '../../../../design_system/design_system.dart';
import '../../../../l10n/l10n.dart';
import '../../../../shared/presentation/configuration_localization.dart';
import '../../domain/leave_models.dart';
import '../bloc/leave_operations_blocs.dart';
import '../leave_localization.dart';
import '../widgets/leave_operations_widgets.dart';

class TeamLeavePage extends StatelessWidget {
  const TeamLeavePage({super.key});
  @override
  Widget build(BuildContext context) =>
      const LeaveOperationsPage(company: false);
}

class AllLeavePage extends StatelessWidget {
  const AllLeavePage({super.key});
  @override
  Widget build(BuildContext context) =>
      const LeaveOperationsPage(company: true);
}

enum _LeaveViewMode { requests, today, upcoming }

class LeaveOperationsPage extends StatefulWidget {
  const LeaveOperationsPage({super.key, required this.company});
  final bool company;
  @override
  State<LeaveOperationsPage> createState() => _LeaveOperationsPageState();
}

class _LeaveOperationsPageState extends State<LeaveOperationsPage> {
  _LeaveViewMode _mode = _LeaveViewMode.requests;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final bloc = context.read<LeaveOperationsBloc>();
    final p = PermissionChecker(bloc.context.user.permissions);
    final canApprove =
        p.can(AppPermission.leaveApproveTeam) ||
        p.can(AppPermission.leaveApproveAll);
    final canBalances = p.canAny([
      AppPermission.leaveBalanceViewTeam,
      AppPermission.leaveBalanceViewAll,
    ]);
    return AppPage(
      header: AppPageHeader(
        title: widget.company ? l.leaveAllNav : l.leaveTeam,
        subtitle: widget.company ? l.leaveAllSubtitle : l.leaveTeamSubtitle,
        actions: [
          AppSecondaryButton(
            icon: Icons.calendar_month_outlined,
            label: l.leaveCalendarNav,
            onPressed: () => context.push(AppRoutes.leaveCalendar),
          ),
          if (canApprove)
            AppSecondaryButton(
              icon: Icons.fact_check_outlined,
              label: l.leaveApprovals,
              onPressed: () => context.push(AppRoutes.leaveApprovals),
            ),
          if (canBalances)
            AppSecondaryButton(
              icon: Icons.account_balance_wallet_outlined,
              label: l.leaveBalancesNav,
              onPressed: () => context.push(AppRoutes.leaveBalances),
            ),
        ],
      ),
      child: BlocBuilder<LeaveOperationsBloc, LeaveOperationsState>(
        builder: (c, s) {
          if (s.loading) return const AppLoadingState();
          if (s.failure != null) {
            return AppErrorState(
              message: configurationFailure(s.failure!, c.l10n),
              onRetry: () => bloc.add(const LeaveOperationsStarted()),
            );
          }
          final data = s.data;
          if (data == null) {
            return AppEmptyState(
              title: l.leaveRequestsEmpty,
              message: l.leaveRequestsEmpty,
            );
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              LeaveSummaryMetrics(
                summary: data.summary,
                showTeamMembers: !widget.company,
              ),
              const SizedBox(height: AppSpacing.xl),
              _FilterBar(
                company: widget.company,
                filter: s.filter,
                onChanged: (f) => bloc.add(LeaveOperationsFilterChanged(f)),
              ),
              const SizedBox(height: AppSpacing.lg),
              Wrap(
                spacing: AppSpacing.sm,
                children: [
                  AppFilterChip(
                    label: l.leaveTeamRequests,
                    selected: _mode == _LeaveViewMode.requests,
                    onSelected: (_) =>
                        setState(() => _mode = _LeaveViewMode.requests),
                  ),
                  AppFilterChip(
                    label: l.leaveOnLeaveToday,
                    selected: _mode == _LeaveViewMode.today,
                    onSelected: (_) =>
                        setState(() => _mode = _LeaveViewMode.today),
                  ),
                  AppFilterChip(
                    label: l.leaveUpcoming,
                    selected: _mode == _LeaveViewMode.upcoming,
                    onSelected: (_) =>
                        setState(() => _mode = _LeaveViewMode.upcoming),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.lg),
              switch (_mode) {
                _LeaveViewMode.requests => LeaveRequestTable(
                  rows: data.requests,
                  canReview: canApprove,
                ),
                _LeaveViewMode.today => LeaveTodaySection(items: data.today),
                _LeaveViewMode.upcoming => LeaveUpcomingSection(
                  items: data.upcoming,
                ),
              },
            ],
          );
        },
      ),
    );
  }
}

class _FilterBar extends StatelessWidget {
  const _FilterBar({
    required this.company,
    required this.filter,
    required this.onChanged,
  });
  final bool company;
  final LeaveRequestFilter filter;
  final ValueChanged<LeaveRequestFilter> onChanged;
  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final bloc = context.read<LeaveOperationsBloc>();
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppTextField(
            label: l.leaveSearchEmployee,
            hint: l.leaveSearchEmployee,
            initialValue: filter.search,
            prefixIcon: Icons.search_rounded,
            onChanged: (v) => onChanged(filter.copyWith(search: v)),
          ),
          const SizedBox(height: AppSpacing.md),
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: [
              for (final status in <LeaveRequestStatus?>[
                null,
                ...LeaveRequestStatus.values,
              ])
                AppFilterChip(
                  label: status == null
                      ? l.leavePeriodAll
                      : leaveRequestStatusLabel(status, l),
                  selected: filter.status == status,
                  onSelected: (_) => onChanged(
                    status == null
                        ? filter.copyWith(clearStatus: true)
                        : filter.copyWith(status: status),
                  ),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: [
              for (final period in const [
                ('all', 'leavePeriodAll'),
                ('today', 'leavePeriodToday'),
                ('week', 'leavePeriodThisWeek'),
                ('month', 'leavePeriodThisMonth'),
                ('next30', 'leavePeriodNext30'),
              ])
                AppFilterChip(
                  label: _periodLabel(period.$2, l),
                  selected: _isPeriodActive(period.$1),
                  onSelected: (_) => onChanged(_applyPeriod(period.$1, filter)),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          AppFormGrid(
            children: [
              StreamBuilder<Result<List<LeaveType>>>(
                stream: bloc.repository.watchLeaveTypes(bloc.context),
                builder: (c, snapshot) {
                  final types = snapshot.data is Success<List<LeaveType>>
                      ? (snapshot.data as Success<List<LeaveType>>).value
                      : const <LeaveType>[];
                  return AppSelectField<String>(
                    label: l.leaveType,
                    value: filter.leaveTypeId,
                    hint: l.leavePeriodAll,
                    options: [
                      for (final type in types)
                        AppSelectOption(type.id, type.name),
                    ],
                    onChanged: (v) => onChanged(
                      v == null
                          ? filter.copyWith(clearLeaveType: true)
                          : filter.copyWith(leaveTypeId: v),
                    ),
                  );
                },
              ),
              if (company)
                StreamBuilder<Result<List<LeaveDepartmentOption>>>(
                  stream: bloc.repository.watchDepartments(bloc.context),
                  builder: (c, snapshot) {
                    final departments =
                        snapshot.data is Success<List<LeaveDepartmentOption>>
                        ? (snapshot.data
                                  as Success<List<LeaveDepartmentOption>>)
                              .value
                        : const <LeaveDepartmentOption>[];
                    return AppSelectField<String>(
                      label: l.leaveDepartment,
                      value: filter.departmentId,
                      hint: l.leavePeriodAll,
                      options: [
                        for (final department in departments)
                          AppSelectOption(department.id, department.name),
                      ],
                      onChanged: (v) => onChanged(
                        v == null
                            ? filter.copyWith(clearDepartment: true)
                            : filter.copyWith(departmentId: v),
                      ),
                    );
                  },
                ),
            ],
          ),
        ],
      ),
    );
  }

  String _periodLabel(String key, AppLocalizations l) => switch (key) {
    'today' => l.leavePeriodToday,
    'week' => l.leavePeriodThisWeek,
    'month' => l.leavePeriodThisMonth,
    'next30' => l.leavePeriodNext30,
    _ => l.leavePeriodAll,
  };

  bool _isPeriodActive(String key) {
    if (key == 'all') return filter.from == null && filter.to == null;
    final preset = _applyPeriod(key, const LeaveRequestFilter());
    return filter.from == preset.from && filter.to == preset.to;
  }

  LeaveRequestFilter _applyPeriod(String key, LeaveRequestFilter f) {
    final now = DateTime.now().toUtc();
    final today = DateTime.utc(now.year, now.month, now.day);
    switch (key) {
      case 'today':
        return f.copyWith(from: today, to: today);
      case 'week':
        return f.copyWith(
          from: today.subtract(Duration(days: today.weekday - 1)),
          to: today.add(Duration(days: 7 - today.weekday)),
        );
      case 'month':
        return f.copyWith(
          from: DateTime.utc(today.year, today.month, 1),
          to: DateTime.utc(today.year, today.month + 1, 0),
        );
      case 'next30':
        return f.copyWith(from: today, to: today.add(const Duration(days: 30)));
      default:
        return f.copyWith(clearFrom: true, clearTo: true);
    }
  }
}

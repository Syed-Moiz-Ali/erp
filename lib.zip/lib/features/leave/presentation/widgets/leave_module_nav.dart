import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/router/app_routes.dart';
import '../../../../core/security/app_permission.dart';
import '../../../../design_system/design_system.dart';
import '../../../../design_system/theme/app_breakpoints.dart';
import '../../../../l10n/l10n.dart';
import '../../../auth/domain/entities/auth_context.dart';
import '../../../auth/domain/policies/user_capability.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';

/// Leave is one primary module; this renders its internal sub-navigation for
/// the destinations the current capabilities allow. Presentation only — routes
/// remain the source of truth.
class LeaveModuleScaffold extends StatelessWidget {
  const LeaveModuleScaffold({super.key, required this.child, this.banner});
  final Widget child;
  final Widget? banner;

  List<(String, String)> _items(BuildContext context, AuthContext account) {
    final l = context.l10n;
    final capabilities = const UserCapabilityResolver().forAuthContext(account);
    final p = PermissionChecker(account.user.permissions);
    final balanceVisible =
        capabilities.has(UserCapability.viewMyLeaveBalance) ||
        p.canAny([
          AppPermission.leaveBalanceViewTeam,
          AppPermission.leaveBalanceViewAll,
        ]);
    return [
      (AppRoutes.leave, l.shellLeave),
      if (capabilities.has(UserCapability.viewMyLeave))
        (AppRoutes.leaveMyRequests, l.leaveMyRequests),
      if (capabilities.has(UserCapability.viewTeamLeave))
        (AppRoutes.leaveTeam, l.leaveTeam),
      if (capabilities.has(UserCapability.viewCompanyLeave))
        (AppRoutes.leaveAll, l.leaveAllNav),
      if (capabilities.has(UserCapability.approveTeamLeave) ||
          capabilities.has(UserCapability.approveCompanyLeave))
        (AppRoutes.leaveApprovals, l.leaveApprovals),
      if (balanceVisible) (AppRoutes.leaveBalances, l.leaveBalancesNav),
      (AppRoutes.leaveCalendar, l.leaveCalendarNav),
    ];
  }

  @override
  Widget build(BuildContext context) =>
      BlocSelector<AuthBloc, AuthState, AuthContext?>(
        selector: (state) => state.context,
        builder: (context, account) {
          if (account == null) return child;
          final items = _items(context, account);
          if (items.length <= 1) return _body();
          final path = GoRouterState.of(context).uri.path;
          final selected = _match(path, items);
          final padding = AppBreakpoints.of(context) == AppSize.compact
              ? AppSpacing.lg
              : AppSpacing.section;
          return Column(
            children: [
              Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  border: Border(bottom: BorderSide(color: AppColors.border)),
                ),
                padding: EdgeInsetsDirectional.fromSTEB(
                  padding,
                  AppSpacing.sm,
                  padding,
                  AppSpacing.sm,
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final (route, label) in items)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(
                            end: AppSpacing.sm,
                          ),
                          child: AppFilterChip(
                            label: label,
                            selected: route == selected,
                            onSelected: (_) => context.go(route),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              Expanded(child: _body()),
            ],
          );
        },
      );

  Widget _body() {
    final placeholder = banner;
    if (placeholder == null) return child;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(
            AppSpacing.section,
            AppSpacing.md,
            AppSpacing.section,
            0,
          ),
          child: placeholder,
        ),
        Expanded(child: child),
      ],
    );
  }

  String _match(String path, List<(String, String)> items) {
    String? best;
    for (final (route, _) in items) {
      if (path == route || path.startsWith('$route/')) {
        if (best == null || route.length > best.length) best = route;
      }
    }
    return best ?? items.first.$1;
  }
}

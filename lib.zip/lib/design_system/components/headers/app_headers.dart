import 'package:flutter/material.dart';
import 'package:modular_erp/design_system/theme/app_typography.dart';
import 'package:modular_erp/design_system/theme/app_breakpoints.dart';
import 'package:modular_erp/design_system/theme/app_spacing.dart';

class AppPageHeader extends StatelessWidget {
  const AppPageHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.actions = const [],
    this.breadcrumbs,
    this.overflowActions = const [],
    this.compactActionsInline = false,
  });
  final String title;
  final String? subtitle;
  final List<Widget> actions;
  final Widget? breadcrumbs;
  final List<AppPageOverflowAction> overflowActions;
  final bool compactActionsInline;
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final heading = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (breadcrumbs != null) ...[
            breadcrumbs!,
            const SizedBox(height: AppSpacing.xs),
          ],
          Text(title, style: AppTypography.of(context).pageTitle),
          if (subtitle != null) ...[
            const SizedBox(height: AppSpacing.xs + 2),
            Text(subtitle!, style: AppTypography.of(context).caption),
          ],
        ],
      );
      final controls = Wrap(
        alignment: WrapAlignment.end,
        spacing: AppSpacing.sm,
        runSpacing: AppSpacing.sm,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          ...actions,
          if (overflowActions.isNotEmpty)
            PopupMenuButton<int>(
              tooltip: MaterialLocalizations.of(context).moreButtonTooltip,
              onSelected: (index) => overflowActions[index].onPressed(),
              itemBuilder: (context) => [
                for (var i = 0; i < overflowActions.length; i++)
                  PopupMenuItem(
                    value: i,
                    child: Text(overflowActions[i].label),
                  ),
              ],
            ),
        ],
      );
      if (AppBreakpoints.classify(constraints.maxWidth) == AppSize.compact) {
        if (compactActionsInline) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: heading),
              const SizedBox(width: AppSpacing.sm),
              controls,
            ],
          );
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            heading,
            if (actions.isNotEmpty || overflowActions.isNotEmpty) ...[
              const SizedBox(height: AppSpacing.lg),
              controls,
            ],
          ],
        );
      }
      return Row(
        children: [
          Expanded(child: heading),
          if (actions.isNotEmpty || overflowActions.isNotEmpty) ...[
            const SizedBox(width: AppSpacing.xxl),
            Expanded(
              child: Align(
                alignment: AlignmentDirectional.centerEnd,
                child: controls,
              ),
            ),
          ],
        ],
      );
    },
  );
}

class AppSectionHeader extends StatelessWidget {
  const AppSectionHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.action,
    this.upperCase = false,
  });
  final String title;
  final String? subtitle;
  final Widget? action;

  /// Small uppercase section label (used by the dashboard cards).
  final bool upperCase;

  @override
  Widget build(BuildContext context) {
    final typography = AppTypography.of(context);
    final textColumn = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          upperCase ? title.toUpperCase() : title,
          style: upperCase
              ? typography.caption.copyWith(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                )
              : typography.sectionTitle,
        ),
        if (subtitle != null) ...[
          const SizedBox(height: AppSpacing.xxs),
          Text(subtitle!, style: typography.caption),
        ],
      ],
    );

    if (action == null) return textColumn;

    // Compact widths stack the action under the title so a labelled action can
    // never overflow the section header.
    if (AppBreakpoints.of(context) == AppSize.compact) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          textColumn,
          const SizedBox(height: AppSpacing.sm),
          action!,
        ],
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(child: textColumn),
        const SizedBox(width: AppSpacing.sm),
        Flexible(
          child: Align(
            alignment: AlignmentDirectional.centerEnd,
            child: action!,
          ),
        ),
      ],
    );
  }
}

class AppPageOverflowAction {
  const AppPageOverflowAction({required this.label, required this.onPressed});
  final String label;
  final VoidCallback onPressed;
}

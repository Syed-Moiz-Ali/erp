import 'package:flutter/material.dart';
import '../../theme/app_borders.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_dimensions.dart';
import '../../theme/app_motion.dart';
import '../../theme/app_radius.dart';
import '../../theme/app_spacing.dart';
import '../../theme/app_typography.dart';

enum AppButtonSize { small, medium, large }

class AppPrimaryButton extends StatefulWidget {
  const AppPrimaryButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.loading = false,
    this.size = AppButtonSize.medium,
    this.fullWidth = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final AppButtonSize size;
  final bool fullWidth;

  @override
  State<AppPrimaryButton> createState() => _AppPrimaryButtonState();
}

class _AppPrimaryButtonState extends State<AppPrimaryButton> {
  bool _hovered = false;
  bool _pressed = false;
  bool _focused = false;

  void _setPressed(bool value) {
    if (_pressed != value) setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final (height, padding, iconSize, textStyle) = _buttonSizeProps(
      context,
      widget.size,
    );
    final isEnabled = widget.onPressed != null && !widget.loading;
    final borderRadius = BorderRadius.circular(AppRadius.button);
    final background = !isEnabled
        ? AppColors.brandPrimary.withValues(alpha: .5)
        : _pressed
        ? AppColors.brandPressed
        : _hovered
        ? AppColors.brandHover
        : AppColors.brandPrimary;
    final button = Focus(
      canRequestFocus: false,
      onFocusChange: (value) => setState(() => _focused = value),
      child: MouseRegion(
        cursor: isEnabled ? SystemMouseCursors.click : MouseCursor.defer,
        onEnter: (_) => setState(() => _hovered = true),
        onExit: (_) => setState(() => _hovered = false),
        child: Listener(
          onPointerDown: isEnabled ? (_) => _setPressed(true) : null,
          onPointerUp: (_) => _setPressed(false),
          onPointerCancel: (_) => _setPressed(false),
          child: AnimatedSlide(
            duration: AppMotion.fast,
            curve: AppMotion.curveStandard,
            offset: Offset(0, _hovered && !_pressed && isEnabled ? -0.02 : 0),
            child: AnimatedContainer(
              duration: AppMotion.fast,
              curve: AppMotion.curveStandard,
              decoration: BoxDecoration(
                borderRadius: borderRadius,
                color: background,
                boxShadow: [
                  if (isEnabled)
                    BoxShadow(
                      color: const Color(0x0C14111E),
                      blurRadius: _hovered ? 8 : 4,
                      offset: Offset(0, _hovered ? 2 : 1),
                    ),
                  if (_focused)
                    BoxShadow(
                      color: AppColors.brandPrimary.withValues(alpha: 0.35),
                      blurRadius: 0,
                      spreadRadius: 2,
                    ),
                ],
              ),
              child: FilledButton(
                onPressed: widget.loading ? null : widget.onPressed,
                style: FilledButton.styleFrom(
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: Colors.transparent,
                  disabledForegroundColor: Colors.white.withValues(alpha: .7),
                  overlayColor: Colors.transparent,
                  minimumSize: Size(
                    widget.fullWidth ? double.infinity : 0,
                    height,
                  ),
                  padding: padding,
                  shape: RoundedRectangleBorder(borderRadius: borderRadius),
                ),
                child: _ButtonContent(
                  label: widget.label,
                  icon: widget.icon,
                  loading: widget.loading,
                  iconSize: iconSize,
                  textStyle: textStyle.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.1,
                  ),
                  loadingColor: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ),
    );
    return widget.fullWidth
        ? SizedBox(width: double.infinity, child: button)
        : button;
  }
}

class AppSecondaryButton extends StatelessWidget {
  const AppSecondaryButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.loading = false,
    this.size = AppButtonSize.medium,
    this.fullWidth = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final AppButtonSize size;
  final bool fullWidth;

  @override
  Widget build(BuildContext context) {
    final (height, padding, iconSize, textStyle) = _buttonSizeProps(
      context,
      size,
    );
    final button = OutlinedButton(
      onPressed: loading ? null : onPressed,
      style: OutlinedButton.styleFrom(
        elevation: 0,
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.textPrimary,
        disabledForegroundColor: AppColors.textDisabled,
        minimumSize: Size(fullWidth ? double.infinity : 0, height),
        padding: padding,
        side: AppBorders.thin,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.button),
        ),
      ),
      child: _ButtonContent(
        label: label,
        icon: icon,
        loading: loading,
        iconSize: iconSize,
        textStyle: textStyle.copyWith(
          color: onPressed != null
              ? AppColors.textPrimary
              : AppColors.textDisabled,
        ),
        loadingColor: AppColors.textSecondary,
      ),
    );
    return fullWidth ? SizedBox(width: double.infinity, child: button) : button;
  }
}

class AppDestructiveButton extends StatelessWidget {
  const AppDestructiveButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.loading = false,
    this.size = AppButtonSize.medium,
    this.fullWidth = false,
    this.outlined = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final AppButtonSize size;
  final bool fullWidth;
  final bool outlined;

  @override
  Widget build(BuildContext context) {
    final (height, padding, iconSize, textStyle) = _buttonSizeProps(
      context,
      size,
    );
    final button = outlined
        ? OutlinedButton(
            onPressed: loading ? null : onPressed,
            style: OutlinedButton.styleFrom(
              elevation: 0,
              backgroundColor: AppColors.surface,
              foregroundColor: AppColors.danger,
              disabledForegroundColor: AppColors.textDisabled,
              minimumSize: Size(fullWidth ? double.infinity : 0, height),
              padding: padding,
              side: AppBorders.error,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppRadius.button),
              ),
            ),
            child: _ButtonContent(
              label: label,
              icon: icon,
              loading: loading,
              iconSize: iconSize,
              textStyle: textStyle.copyWith(color: AppColors.danger),
              loadingColor: AppColors.danger,
            ),
          )
        : FilledButton(
            onPressed: loading ? null : onPressed,
            style: FilledButton.styleFrom(
              elevation: 0,
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
              disabledBackgroundColor: AppColors.danger.withValues(alpha: .5),
              disabledForegroundColor: Colors.white.withValues(alpha: .7),
              minimumSize: Size(fullWidth ? double.infinity : 0, height),
              padding: padding,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppRadius.button),
              ),
            ),
            child: _ButtonContent(
              label: label,
              icon: icon,
              loading: loading,
              iconSize: iconSize,
              textStyle: textStyle.copyWith(color: Colors.white),
              loadingColor: Colors.white,
            ),
          );
    return fullWidth ? SizedBox(width: double.infinity, child: button) : button;
  }
}

class AppTextButton extends StatelessWidget {
  const AppTextButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.loading = false,
    this.size = AppButtonSize.medium,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final AppButtonSize size;

  @override
  Widget build(BuildContext context) {
    final (height, padding, iconSize, textStyle) = _buttonSizeProps(
      context,
      size,
    );
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark
        ? const Color(0xFF94A3B8)
        : AppColors.textSecondary;
    final disabledColor = isDark
        ? const Color(0xFF475569)
        : AppColors.textDisabled;
    return TextButton(
      onPressed: loading ? null : onPressed,
      style: TextButton.styleFrom(
        foregroundColor: textColor,
        disabledForegroundColor: disabledColor,
        minimumSize: Size(0, height),
        padding: padding,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.button),
        ),
      ),
      child: _ButtonContent(
        label: label,
        icon: icon,
        loading: loading,
        iconSize: iconSize,
        textStyle: textStyle.copyWith(
          color: onPressed != null ? textColor : disabledColor,
        ),
        loadingColor: textColor,
      ),
    );
  }
}

class AppIconButton extends StatelessWidget {
  const AppIconButton({
    super.key,
    required this.icon,
    required this.tooltip,
    this.onPressed,
    this.size = AppButtonSize.medium,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onPressed;
  final AppButtonSize size;

  @override
  Widget build(BuildContext context) {
    final (targetSize, iconSize) = switch (size) {
      AppButtonSize.small => (AppDimensions.controlSm, AppDimensions.iconSm),
      AppButtonSize.medium => (AppDimensions.controlMd, AppDimensions.iconMd),
      AppButtonSize.large => (AppDimensions.controlLg, AppDimensions.iconLg),
    };
    return IconButton(
      tooltip: tooltip,
      onPressed: onPressed,
      style: IconButton.styleFrom(
        minimumSize: Size(targetSize, targetSize),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.button),
        ),
      ),
      icon: Icon(icon, size: iconSize),
    );
  }
}

(double, EdgeInsetsGeometry, double, TextStyle) _buttonSizeProps(
  BuildContext context,
  AppButtonSize size,
) {
  final typo = AppTypography.of(context);
  return switch (size) {
    AppButtonSize.small => (
      32.0,
      const EdgeInsetsDirectional.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.xs,
      ),
      16.0,
      typo.caption.copyWith(fontWeight: FontWeight.w600),
    ),
    AppButtonSize.medium => (
      40.0,
      const EdgeInsetsDirectional.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.xs,
      ),
      18.0,
      typo.label,
    ),
    AppButtonSize.large => (
      48.0,
      const EdgeInsetsDirectional.symmetric(
        horizontal: AppSpacing.xl,
        vertical: AppSpacing.sm,
      ),
      20.0,
      typo.labelLarge,
    ),
  };
}

class _ButtonContent extends StatelessWidget {
  const _ButtonContent({
    required this.label,
    required this.icon,
    required this.loading,
    required this.iconSize,
    required this.textStyle,
    required this.loadingColor,
  });

  final String label;
  final IconData? icon;
  final bool loading;
  final double iconSize;
  final TextStyle textStyle;
  final Color loadingColor;

  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      if (loading)
        SizedBox(
          width: iconSize,
          height: iconSize,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(loadingColor),
          ),
        )
      else if (icon != null)
        Icon(icon, size: iconSize),
      if (loading || icon != null) const SizedBox(width: AppSpacing.sm),
      Flexible(
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: textStyle,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    ],
  );
}

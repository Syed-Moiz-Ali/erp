import 'package:modular_erp/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:modular_erp/core/localization/app_formatters.dart';
import 'package:modular_erp/design_system/theme/app_colors.dart';
import 'package:modular_erp/design_system/theme/app_radius.dart';
import 'package:modular_erp/design_system/theme/app_motion.dart';
import 'package:modular_erp/design_system/theme/app_spacing.dart';
import 'package:modular_erp/design_system/theme/app_typography.dart';

class AppTextField extends StatelessWidget {
  const AppTextField({
    super.key,
    required this.label,
    this.hint,
    this.initialValue,
    this.errorText,
    this.controller,
    this.validator,
    this.onChanged,
    this.keyboardType,
    this.prefixIcon,
    this.suffixIcon,
    this.readOnly = false,
    this.onTap,
    this.focusNode,
    this.textInputAction,
    this.autofillHints,
    this.onFieldSubmitted,
    this.enabled = true,
    this.autocorrect = true,
    this.maxLines = 1,
    this.minLines,
    this.required = false,
    this.helperText,
    this.labelAbove = true,
    this.labelTrailing,
    this.prefixIconSize = 20,
    this.contentPadding,
  });
  final String label;
  final String? hint, errorText, initialValue, helperText;
  final TextEditingController? controller;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String>? onChanged;
  final TextInputType? keyboardType;
  final IconData? prefixIcon;
  final Widget? suffixIcon;
  final bool readOnly;
  final VoidCallback? onTap;
  final FocusNode? focusNode;
  final TextInputAction? textInputAction;
  final Iterable<String>? autofillHints;
  final ValueChanged<String>? onFieldSubmitted;
  final bool enabled, autocorrect, required;
  final int? maxLines, minLines;

  /// Renders a persistent label above the field instead of a floating label.
  /// Defaults to `true`: Services/ERP forms standardize on external labels to
  /// avoid the outlined floating-label/border collision at current density.
  final bool labelAbove;
  final Widget? labelTrailing;
  final double prefixIconSize;
  final EdgeInsetsGeometry? contentPadding;

  @override
  Widget build(BuildContext context) {
    if (!labelAbove) {
      return _LocalizedValidationField<String>(
        builder: (fieldKey) => TextFormField(
          key: fieldKey,
          controller: controller,
          initialValue: controller == null ? initialValue : null,
          focusNode: focusNode,
          textInputAction: textInputAction,
          autofillHints: autofillHints,
          onFieldSubmitted: onFieldSubmitted,
          enabled: enabled,
          autocorrect: autocorrect,
          enableSuggestions: autocorrect,
          validator: validator,
          onChanged: onChanged,
          keyboardType: keyboardType,
          textDirection:
              keyboardType == TextInputType.emailAddress ||
                  keyboardType == TextInputType.phone
              ? TextDirection.ltr
              : null,
          readOnly: readOnly,
          onTap: onTap,
          maxLines: maxLines,
          minLines: minLines,
          decoration: InputDecoration(
            labelText: required ? '$label *' : label,
            hintText: hint,
            errorText: errorText,
            helperText: helperText,
            prefixIcon: prefixIcon == null
                ? null
                : Icon(prefixIcon, size: prefixIconSize),
            suffixIcon: suffixIcon,
            contentPadding: contentPadding,
          ),
        ),
      );
    }
    return AppFieldLabelGroup(
      label: label,
      required: required,
      trailing: labelTrailing,
      child: AppFieldShell(
        focusNode: focusNode,
        enabled: enabled,
        builder: (node, hovered, focused) => _LocalizedValidationField<String>(
          builder: (fieldKey) => TextFormField(
            key: fieldKey,
            controller: controller,
            initialValue: controller == null ? initialValue : null,
            focusNode: node,
            textInputAction: textInputAction,
            autofillHints: autofillHints,
            onFieldSubmitted: onFieldSubmitted,
            enabled: enabled,
            autocorrect: autocorrect,
            enableSuggestions: autocorrect,
            validator: validator,
            onChanged: onChanged,
            keyboardType: keyboardType,
            textDirection:
                keyboardType == TextInputType.emailAddress ||
                    keyboardType == TextInputType.phone
                ? TextDirection.ltr
                : null,
            readOnly: readOnly,
            onTap: onTap,
            maxLines: maxLines,
            minLines: minLines,
            decoration: appCustomInputDecoration(
              context,
              hint: hint ?? label,
              errorText: errorText,
              helperText: helperText,
              hovered: hovered,
              focused: focused,
              enabled: enabled,
              prefixIcon: prefixIcon,
              prefixIconSize: prefixIconSize,
              suffixIcon: suffixIcon,
              contentPadding: contentPadding,
            ),
          ),
        ),
      ),
    );
  }
}

class AppPasswordField extends StatefulWidget {
  const AppPasswordField({
    super.key,
    this.controller,
    this.validator,
    this.label,
    this.hint,
    this.prefixIcon,
    this.focusNode,
    this.textInputAction,
    this.autofillHints,
    this.onFieldSubmitted,
    this.enabled = true,
    this.labelAbove = true,
    this.labelTrailing,
    this.prefixIconSize = 20,
    this.suffixIconSize = 20,
    this.contentPadding,
  });
  final TextEditingController? controller;
  final FormFieldValidator<String>? validator;
  final String? label;
  final String? hint;
  final IconData? prefixIcon;
  final FocusNode? focusNode;
  final TextInputAction? textInputAction;
  final Iterable<String>? autofillHints;
  final ValueChanged<String>? onFieldSubmitted;
  final bool enabled;
  final bool labelAbove;
  final Widget? labelTrailing;
  final double prefixIconSize;
  final double suffixIconSize;
  final EdgeInsetsGeometry? contentPadding;
  @override
  State<AppPasswordField> createState() => _PasswordState();
}

class _PasswordState extends State<AppPasswordField> {
  bool hidden = true;

  Widget _reveal(BuildContext context) => IconButton(
    tooltip: hidden ? context.l10n.showPassword : context.l10n.hidePassword,
    onPressed: widget.enabled ? () => setState(() => hidden = !hidden) : null,
    iconSize: widget.suffixIconSize,
    splashRadius: 18,
    visualDensity: VisualDensity.compact,
    style: IconButton.styleFrom(
      foregroundColor: AppColors.textMuted,
      overlayColor: AppColors.brandSubtle,
      hoverColor: AppColors.brandSubtle,
    ),
    icon: Icon(
      hidden ? Icons.visibility_outlined : Icons.visibility_off_outlined,
    ),
  );

  @override
  Widget build(BuildContext context) {
    final label = widget.label ?? context.l10n.password;
    if (!widget.labelAbove) {
      return _LocalizedValidationField<String>(
        builder: (fieldKey) => TextFormField(
          key: fieldKey,
          controller: widget.controller,
          focusNode: widget.focusNode,
          textInputAction: widget.textInputAction,
          autofillHints: widget.autofillHints,
          onFieldSubmitted: widget.onFieldSubmitted,
          enabled: widget.enabled,
          validator: widget.validator,
          obscureText: hidden,
          enableSuggestions: false,
          autocorrect: false,
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: widget.prefixIcon == null
                ? null
                : Icon(widget.prefixIcon, size: widget.prefixIconSize),
            suffixIcon: _reveal(context),
            contentPadding: widget.contentPadding,
          ),
        ),
      );
    }
    return AppFieldLabelGroup(
      label: label,
      trailing: widget.labelTrailing,
      child: AppFieldShell(
        focusNode: widget.focusNode,
        enabled: widget.enabled,
        builder: (node, hovered, focused) => _LocalizedValidationField<String>(
          builder: (fieldKey) => TextFormField(
            key: fieldKey,
            controller: widget.controller,
            focusNode: node,
            textInputAction: widget.textInputAction,
            autofillHints: widget.autofillHints,
            onFieldSubmitted: widget.onFieldSubmitted,
            enabled: widget.enabled,
            validator: widget.validator,
            obscureText: hidden,
            enableSuggestions: false,
            autocorrect: false,
            decoration: appCustomInputDecoration(
              context,
              hint: widget.hint,
              hovered: hovered,
              focused: focused,
              enabled: widget.enabled,
              prefixIcon: widget.prefixIcon,
              prefixIconSize: widget.prefixIconSize,
              suffixIcon: _reveal(context),
              contentPadding: widget.contentPadding,
            ),
          ),
        ),
      ),
    );
  }
}

class AppSearchField extends StatefulWidget {
  const AppSearchField({
    super.key,
    this.controller,
    this.onChanged,
    this.hint,
    this.label,
    this.onClear,
    this.enabled = true,
  });
  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;
  final String? hint;
  final String? label;
  final VoidCallback? onClear;
  final bool enabled;

  @override
  State<AppSearchField> createState() => _AppSearchFieldState();
}

class _AppSearchFieldState extends State<AppSearchField> {
  TextEditingController? _internalController;
  TextEditingController get _controller =>
      widget.controller ?? (_internalController ??= TextEditingController());

  @override
  void initState() {
    super.initState();
    _controller.addListener(_handleControllerChange);
  }

  @override
  void didUpdateWidget(AppSearchField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      (oldWidget.controller ?? _internalController)?.removeListener(
        _handleControllerChange,
      );
      _controller.addListener(_handleControllerChange);
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_handleControllerChange);
    _internalController?.dispose();
    super.dispose();
  }

  void _handleControllerChange() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final hasText = _controller.text.isNotEmpty;
    return AppTextField(
      label: widget.label ?? context.l10n.search,
      hint: widget.hint ?? context.l10n.searchRecords,
      controller: _controller,
      onChanged: widget.onChanged,
      prefixIcon: Icons.search,
      enabled: widget.enabled,
      suffixIcon: hasText && widget.enabled
          ? IconButton(
              icon: const Icon(Icons.clear, size: 18),
              onPressed: () {
                _controller.clear();
                widget.onChanged?.call('');
                widget.onClear?.call();
              },
            )
          : null,
    );
  }
}

class AppDropdown<T> extends StatelessWidget {
  const AppDropdown({
    super.key,
    required this.label,
    required this.items,
    this.value,
    this.onChanged,
    this.validator,
  });
  final String label;
  final List<DropdownMenuItem<T>> items;
  final T? value;
  final ValueChanged<T?>? onChanged;
  final FormFieldValidator<T>? validator;
  @override
  Widget build(BuildContext context) => _LocalizedValidationField<T>(
    builder: (fieldKey) => DropdownButtonFormField<T>(
      key: fieldKey,
      initialValue: value,
      isExpanded: true,
      items: items,
      onChanged: onChanged,
      validator: validator,
      decoration: InputDecoration(labelText: label),
    ),
  );
}

class AppDateField extends StatelessWidget {
  const AppDateField({
    super.key,
    required this.label,
    this.value,
    required this.onChanged,
    this.lastDate,
    this.errorText,
    this.helperText,
    this.enabled = true,
    this.required = false,
  });
  final DateTime? lastDate;
  final bool enabled, required;
  final String label;
  final String? errorText, helperText;
  final DateTime? value;
  final ValueChanged<DateTime> onChanged;
  @override
  Widget build(BuildContext context) => AppFieldLabelGroup(
    label: label,
    required: required,
    child: AppFieldShell(
      enabled: enabled,
      builder: (node, hovered, focused) => InkWell(
        focusNode: node,
        onTap: !enabled
            ? null
            : () async {
                final date = await showDatePicker(
                  context: context,
                  cancelText: context.l10n.cancel,
                  confirmText: context.l10n.confirm,
                  initialDate: value ?? DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: lastDate ?? DateTime(2100),
                );
                if (date != null) onChanged(date);
              },
        child: InputDecorator(
          decoration: appCustomInputDecoration(
            context,
            errorText: errorText,
            helperText: helperText,
            hovered: hovered,
            focused: focused,
            enabled: enabled,
            suffixIcon: const Icon(Icons.calendar_today_outlined, size: 18),
          ),
          child: Text(
            value == null
                ? context.l10n.selectDate
                : AppDateFormatter(
                    Localizations.localeOf(context),
                  ).date(value!),
          ),
        ),
      ),
    ),
  );
}

class AppTimeField extends StatelessWidget {
  const AppTimeField({
    super.key,
    required this.label,
    this.value,
    required this.onChanged,
    this.enabled = true,
    this.errorText,
    this.helperText,
    this.required = false,
  });
  final String label;
  final bool enabled, required;
  final String? errorText, helperText;
  final TimeOfDay? value;
  final ValueChanged<TimeOfDay> onChanged;
  @override
  Widget build(BuildContext context) => AppFieldLabelGroup(
    label: label,
    required: required,
    child: AppFieldShell(
      enabled: enabled,
      builder: (node, hovered, focused) => InkWell(
        focusNode: node,
        onTap: !enabled
            ? null
            : () async {
                final time = await showTimePicker(
                  context: context,
                  cancelText: context.l10n.cancel,
                  confirmText: context.l10n.confirm,
                  initialTime: value ?? TimeOfDay.now(),
                );
                if (time != null) onChanged(time);
              },
        child: InputDecorator(
          decoration: appCustomInputDecoration(
            context,
            errorText: errorText,
            helperText: helperText,
            hovered: hovered,
            focused: focused,
            enabled: enabled,
            suffixIcon: const Icon(Icons.schedule, size: 18),
          ),
          child: Text(
            value == null
                ? context.l10n.selectTime
                : AppTimeFormatter(Localizations.localeOf(context)).timeOfDay(
                    value!,
                    use24Hour: MediaQuery.alwaysUse24HourFormatOf(context),
                  ),
          ),
        ),
      ),
    ),
  );
}

// Revalidate only previously invalid controls when locale changes. Text,
// selection and focus stay intact; untouched fields gain no new errors.
class _LocalizedValidationField<T> extends StatefulWidget {
  const _LocalizedValidationField({required this.builder});
  final Widget Function(GlobalKey<FormFieldState<T>>) builder;
  @override
  State<_LocalizedValidationField<T>> createState() =>
      _LocalizedValidationFieldState<T>();
}

class _LocalizedValidationFieldState<T>
    extends State<_LocalizedValidationField<T>> {
  final _fieldKey = GlobalKey<FormFieldState<T>>();
  Locale? _locale;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final locale = Localizations.localeOf(context);
    if (_locale != null && _locale != locale) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _fieldKey.currentState?.hasError == true) {
          _fieldKey.currentState!.validate();
        }
      });
    }
    _locale = locale;
  }

  @override
  Widget build(BuildContext context) => widget.builder(_fieldKey);
}

/// Custom input surface shell. Tracks focus and pointer hover so the field
/// can render a plum focus halo and a subtle hover tone without falling back
/// to thick Material outlined fields.
class AppFieldShell extends StatefulWidget {
  const AppFieldShell({
    super.key,
    required this.builder,
    this.focusNode,
    this.enabled = true,
  });
  final FocusNode? focusNode;
  final bool enabled;
  final Widget Function(FocusNode focusNode, bool hovered, bool focused)
  builder;

  @override
  State<AppFieldShell> createState() => _AppFieldShellState();
}

class _AppFieldShellState extends State<AppFieldShell> {
  late final FocusNode _node = widget.focusNode ?? FocusNode();
  late final bool _ownsNode = widget.focusNode == null;
  bool _focused = false;
  bool _hovered = false;

  @override
  void initState() {
    super.initState();
    _node.addListener(_handleFocusChange);
    _focused = _node.hasFocus;
  }

  void _handleFocusChange() => setState(() => _focused = _node.hasFocus);

  @override
  void dispose() {
    _node.removeListener(_handleFocusChange);
    if (_ownsNode) _node.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MouseRegion(
    cursor: widget.enabled ? SystemMouseCursors.text : MouseCursor.defer,
    onEnter: (_) => setState(() => _hovered = true),
    onExit: (_) => setState(() => _hovered = false),
    child: AnimatedContainer(
      duration: AppMotion.fast,
      curve: AppMotion.curveStandard,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.field),
        boxShadow: _focused && widget.enabled
            ? [
                BoxShadow(
                  color: AppColors.brandPrimary.withValues(alpha: 0.16),
                  blurRadius: 0,
                  spreadRadius: 2.5,
                ),
              ]
            : const [],
      ),
      child: widget.builder(_node, _hovered && widget.enabled, _focused),
    ),
  );
}

/// Shared custom decoration for persistent-label inputs.
InputDecoration appCustomInputDecoration(
  BuildContext context, {
  String? hint,
  bool hovered = false,
  bool focused = false,
  bool enabled = true,
  String? errorText,
  String? helperText,
  IconData? prefixIcon,
  double prefixIconSize = 18,
  Widget? suffixIcon,
  EdgeInsetsGeometry? contentPadding,
}) {
  final typography = AppTypography.of(context);
  final isDark = Theme.of(context).brightness == Brightness.dark;
  final accent = isDark ? AppColors.darkBrand : AppColors.brandPrimary;
  final danger = isDark ? AppColors.darkDanger : AppColors.danger;
  final restBorder = isDark ? AppColors.darkBorder : AppColors.inputBorder;
  final hoverBorder = isDark
      ? AppColors.darkBorderStrong
      : AppColors.inputBorderHover;
  OutlineInputBorder border(Color color, double width) => OutlineInputBorder(
    borderRadius: BorderRadius.circular(AppRadius.field),
    borderSide: BorderSide(color: color, width: width),
  );
  final borderColor = hovered ? hoverBorder : restBorder;
  final fill = !enabled
      ? (isDark ? AppColors.darkSurfaceDisabled : AppColors.surfaceSubtle)
      : focused
      ? (isDark ? AppColors.darkSurfaceRaised : AppColors.surface)
      : hovered
      ? (isDark ? AppColors.darkSurfaceHover : AppColors.inputHover)
      : (isDark ? AppColors.darkSurfaceRaised : AppColors.inputBackground);
  final iconColor = isDark
      ? AppColors.darkTextTertiary
      : AppColors.textTertiary;
  return InputDecoration(
    hintText: hint,
    errorText: errorText,
    helperText: helperText,
    helperStyle: typography.caption.copyWith(
      color: isDark ? AppColors.darkTextTertiary : AppColors.textTertiary,
    ),
    filled: true,
    fillColor: fill,
    hintStyle: typography.body.copyWith(
      color: isDark ? AppColors.darkTextDisabled : AppColors.textDisabled,
    ),
    errorStyle: typography.caption.copyWith(color: danger),
    prefixIcon: prefixIcon == null
        ? null
        : Icon(prefixIcon, size: prefixIconSize, color: iconColor),
    prefixIconConstraints: const BoxConstraints(minWidth: 36, minHeight: 36),
    suffixIconColor: iconColor,
    suffixIcon: suffixIcon,
    contentPadding:
        contentPadding ??
        const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    border: border(borderColor, 1),
    enabledBorder: border(borderColor, 1),
    focusedBorder: border(accent, 1.5),
    errorBorder: border(danger, 1),
    focusedErrorBorder: border(danger, 1.5),
  );
}

/// Persistent label rendered above a field, with an optional logical-end
/// trailing control (e.g. "Forgot password"). Keeps auth inputs label-led
/// rather than floating-label form controls.
class AppFieldLabelGroup extends StatelessWidget {
  const AppFieldLabelGroup({
    super.key,
    required this.label,
    required this.child,
    this.trailing,
    this.required = false,
  });
  final String label;
  final Widget child;
  final Widget? trailing;
  final bool required;

  @override
  Widget build(BuildContext context) {
    final typography = AppTypography.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsetsDirectional.only(
            start: 2,
            end: 2,
            bottom: 8,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(text: label),
                      if (required)
                        TextSpan(
                          text: ' *',
                          style: const TextStyle(color: AppColors.danger),
                        ),
                    ],
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: typography.formLabel,
                ),
              ),
              if (trailing != null) trailing!,
            ],
          ),
        ),
        child,
      ],
    );
  }
}

/// Standard switch row: external label, optional supporting text, and a single
/// switch using the shared ON/OFF track+thumb styling from [AppTheme].
class AppSwitchField extends StatelessWidget {
  const AppSwitchField({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
    this.description,
    this.enabled = true,
  });
  final String label;
  final String? description;
  final bool value;
  final ValueChanged<bool>? onChanged;
  final bool enabled;
  @override
  Widget build(BuildContext context) {
    final typography = AppTypography.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cb = onChanged;
    final canToggle = enabled && cb != null;
    return Semantics(
      toggled: value,
      enabled: enabled,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: InkWell(
              onTap: canToggle ? () => cb(!value) : null,
              borderRadius: BorderRadius.circular(AppRadius.radiusSm),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      label,
                      style: typography.body.copyWith(
                        color: enabled
                            ? null
                            : (isDark
                                  ? AppColors.darkTextDisabled
                                  : AppColors.textDisabled),
                      ),
                    ),
                    if (description != null) ...[
                      const SizedBox(height: AppSpacing.xxs),
                      Text(description!, style: typography.caption),
                    ],
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.lg),
          Switch.adaptive(
            value: value,
            onChanged: canToggle ? (v) => cb(v) : null,
          ),
        ],
      ),
    );
  }
}

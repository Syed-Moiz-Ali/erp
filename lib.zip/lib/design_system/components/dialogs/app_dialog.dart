import 'package:modular_erp/design_system/theme/app_dimensions.dart';
import 'package:modular_erp/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:modular_erp/design_system/components/buttons/app_buttons.dart';

class AppDialog extends StatelessWidget {
  const AppDialog({
    super.key,
    required this.title,
    required this.child,
    this.actions = const [],
  });
  final String title;
  final Widget child;
  final List<Widget> actions;
  static Future<T?> show<T>(BuildContext context, WidgetBuilder builder) =>
      showDialog<T>(
        context: context,
        useRootNavigator: false,
        builder: builder,
      );
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(title),
    content: SizedBox(width: AppDimensions.dialog, child: child),
    actions: actions,
  );
}

class AppConfirmationDialog {
  static Future<bool> show(
    BuildContext context, {
    required LocalizedText title,
    required LocalizedText message,
    LocalizedText? confirmLabel,
    LocalizedText? cancelLabel,
    bool destructive = false,
  }) async =>
      await AppDialog.show<bool>(
        context,
        (dialogContext) => AppDialog(
          title: title(dialogContext.l10n),
          actions: [
            AppTextButton(
              label:
                  cancelLabel?.call(dialogContext.l10n) ??
                  dialogContext.l10n.cancel,
              onPressed: () => Navigator.pop(dialogContext, false),
            ),
            if (destructive)
              AppDestructiveButton(
                label:
                    confirmLabel?.call(dialogContext.l10n) ??
                    dialogContext.l10n.confirm,
                onPressed: () => Navigator.pop(dialogContext, true),
              )
            else
              AppPrimaryButton(
                label:
                    confirmLabel?.call(dialogContext.l10n) ??
                    dialogContext.l10n.confirm,
                onPressed: () => Navigator.pop(dialogContext, true),
              ),
          ],
          child: Text(message(dialogContext.l10n)),
        ),
      ) ??
      false;
}
